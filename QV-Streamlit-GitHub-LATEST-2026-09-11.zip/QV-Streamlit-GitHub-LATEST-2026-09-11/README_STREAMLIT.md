# كوانتوم فيكتوري — النسخة الشاملة الجاهزة لـ Streamlit

## نقطة التشغيل
`app.py`

## النشر
GitHub Repository -> Streamlit Community Cloud -> Main file: `app.py`

## الأسرار
ضع مفاتيح التشغيل في Streamlit Cloud Secrets فقط، وليس داخل GitHub.

- `GEMINI_API_KEY` أو `GOOGLE_API_KEY`
- مفاتيح مزودي البيانات المطلوبة حسب المصدر

## الحوكمة
`production_authorized=false` و`fail_closed=true` ما لم تتحقق بوابات الأدلة والتفويض الإنتاجي المستقل. لا يسمح Google Gateway بتجاوز هذه الحدود.
