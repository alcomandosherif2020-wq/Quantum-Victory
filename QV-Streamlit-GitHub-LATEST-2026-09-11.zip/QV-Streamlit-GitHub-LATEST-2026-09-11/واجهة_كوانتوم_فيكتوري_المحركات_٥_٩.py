# -*- coding: utf-8 -*-
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from datetime import datetime, timezone
import json, sys, traceback, os, importlib.util

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
VERSION = 'كوانتوم فيكتوري ٥.٩.٤ — بوابة الجاهزية المصححة'

المحركات_الأساسية = {
    'التحليل_الفني': 'qv_whale_hunter/محرك_التحليل_الفني.py',
    'المحرك_العالمي_الموحد': 'qv_whale_hunter/المحرك_العالمي_الموحد.py',
    'تقرير_السهم_العالمي': 'qv_whale_hunter/تقرير_السهم_العالمي.py',
    'قرار_الأدلة': 'qv_whale_hunter/محرك_قرار_الأدلة.py',
    'قناص_السيولة': 'qv_whale_hunter/live_liquidity_sniper.py',
    'قناص_الحيتان': 'qv_whale_hunter/whale_hunter.py',
}


def فحص_الجاهزية():
    الآن = datetime.now(timezone.utc).isoformat()
    المحركات = {}
    أسباب = []
    for الاسم, المسار in المحركات_الأساسية.items():
        موجود = (ROOT / المسار).is_file()
        المحركات[الاسم] = موجود
        if not موجود:
            أسباب.append(f'ملف المحرك غير موجود: {المسار}')

    الواجهة = (ROOT / 'واجهة_كوانتوم_فيكتوري_تحليل_السهم_٥_٩.html').is_file()
    if not الواجهة:
        أسباب.append('ملف الواجهة غير موجود')

    python_ok = sys.version_info >= (3, 10)
    if not python_ok:
        أسباب.append('إصدار بايثون غير مدعوم')

    تشغيل_الخدمة = not أسباب
    # الجاهزية التشغيلية للخدمة لا تعني اعتماد توصية أو اعتماد إنتاجي.
    return {
        'الحالة': 'جاهز تشغيليًا' if تشغيل_الخدمة else 'محجوب',
        'جاهز_تشغيليًا': تشغيل_الخدمة,
        'جاهز_للمعالجة': تشغيل_الخدمة,
        'جاهز_للتنبيه': False,
        'الإنتاج_مصرح': False,
        'الإصدار': VERSION,
        'وقت_الفحص_بالتوقيت_العالمي': الآن,
        'إصدار_بايثون': '.'.join(map(str, sys.version_info[:3])),
        'المحركات': المحركات,
        'واجهة_الويب': الواجهة,
        'الأسباب': أسباب,
        'ملاحظة': 'الجاهزية التشغيلية لا تعني أن البيانات الحية متاحة أو أن أي توصية استثمارية معتمدة.'
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def _send(self, code, obj, content_type='application/json; charset=utf-8'):
        b = json.dumps(obj, ensure_ascii=False, default=str, indent=2).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(b)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(b)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def do_GET(self):
        path = self.path.split('?', 1)[0].rstrip('/') or '/'
        if path == '/':
            p = ROOT / 'واجهة_كوانتوم_فيكتوري_تحليل_السهم_٥_٩.html'
            if not p.is_file():
                return self._send(500, {'خطأ': 'ملف الواجهة غير موجود'})
            b = p.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(b)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b)
            return
        if path in ('/readiness', '/الجاهزية'):
            return self._send(200, فحص_الجاهزية())
        if path in ('/health', '/حالة'):
            return self._send(200, فحص_الجاهزية())
        if path == '/favicon.ico':
            return self._send(204, {})
        return self._send(404, {'خطأ': 'المسار غير موجود', 'المسار': path, 'المسارات_المتاحة': ['/', '/readiness', '/health', '/حالة', '/تحليل']})

    def do_POST(self):
        path = self.path.split('?', 1)[0].rstrip('/')
        if path != '/تحليل':
            return self._send(404, {'خطأ': 'المسار غير موجود'})
        try:
            n = int(self.headers.get('Content-Length', '0'))
            if n <= 0 or n > 20 * 1024 * 1024:
                return self._send(400, {'خطأ': 'حجم الطلب غير صالح'})
            body = json.loads(self.rfile.read(n).decode('utf-8'))
            rows = body.get('البيانات', []) if isinstance(body, dict) else body
            if not rows:
                return self._send(400, {'خطأ': 'أدخل بيانات الشموع أولاً'})
            try:
                import pandas as pd
                from qv_whale_hunter.المحرك_العالمي_الموحد import المحرك_العالمي_الموحد
                df = pd.DataFrame(rows)
                if 'الرمز' not in df.columns:
                    df['الرمز'] = body.get('الرمز', 'غير_معروف') if isinstance(body, dict) else 'غير_معروف'
                result = المحرك_العالمي_الموحد().تشغيل(
                    df,
                    دلالة_الافتتاح='افتتاح_الجلسة',
                    مصدر_البيانات=body.get('مصدر', 'إدخال_يدوي') if isinstance(body, dict) else 'إدخال_يدوي'
                )
                return self._send(200, result)
            except ImportError as e:
                return self._send(503, {'خطأ': 'اعتمادية التحليل غير مثبتة', 'تفصيل': str(e), 'الجاهزية': فحص_الجاهزية()})
        except json.JSONDecodeError as e:
            return self._send(400, {'خطأ': 'الطلب ليس بصيغة JSON صحيحة', 'تفصيل': str(e)})
        except Exception as e:
            return self._send(500, {'خطأ': 'تعذر تحليل البيانات', 'تفصيل': str(e), 'التفاصيل': traceback.format_exc()})

    def log_message(self, fmt, *args):
        print('[واجهة]', fmt % args)


def تشغيل():
    المضيف = os.getenv('QV_UI_HOST', os.getenv('HOST', '0.0.0.0'))
    المنفذ = int(os.getenv('PORT', os.getenv('QV_UI_PORT', '8765')))
    server = ThreadingHTTPServer((المضيف, المنفذ), Handler)
    print(f'كوانتوم فيكتوري يعمل على {المضيف}:{المنفذ}')
    print('بوابة الجاهزية: /readiness')
    server.serve_forever()


if __name__ == '__main__':
    تشغيل()
