import os
from qv_whale_hunter.google_strategic_gateway import GoogleStrategicGateway
from qv_whale_hunter.google_strategic_permissions import GooglePermissionProfile, SCOPES

def test_google_gateway_is_fail_closed_without_key(tmp_path, monkeypatch):
    monkeypatch.delenv('GOOGLE_API_KEY', raising=False)
    monkeypatch.delenv('GEMINI_API_KEY', raising=False)
    g=GoogleStrategicGateway(state_dir=tmp_path)
    assert not g.configured
    assert g.manifest()['production_authorized'] is False
    assert g.manifest()['fail_closed'] is True

def test_google_permission_boundaries():
    d=GooglePermissionProfile().to_dict()
    assert d['production_authorized'] is False
    assert d['fail_closed'] is True
    assert sum(bool(v) for v in SCOPES.values()) == 17
    assert SCOPES['override_fail_closed'] is False

def test_google_query_requires_nonempty_prompt(tmp_path, monkeypatch):
    monkeypatch.delenv('GOOGLE_API_KEY', raising=False)
    monkeypatch.delenv('GEMINI_API_KEY', raising=False)
    g=GoogleStrategicGateway(state_dir=tmp_path)
    try:
        g.query('')
    except ValueError:
        pass
    else:
        raise AssertionError('empty prompt must be rejected')
