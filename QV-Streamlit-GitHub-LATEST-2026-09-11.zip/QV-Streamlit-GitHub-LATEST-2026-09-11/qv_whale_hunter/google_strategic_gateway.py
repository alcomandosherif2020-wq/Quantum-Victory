from __future__ import annotations
import hashlib, json, os, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import requests

ENGINE = 'QV-GOOGLE-STRATEGIC-GATEWAY'
VERSION = '1.0.0'
ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/interactions'

@dataclass(frozen=True)
class GoogleGatewayPolicy:
    enabled: bool = True
    role: str = 'strategic_discovery_mediation_evidence_assistant'
    permissions: tuple[str, ...] = (
        'google_search',
        'web_evidence_discovery',
        'source_citation_capture',
        'url_context_assistance',
        'cross_source_reconciliation_assistance',
        'historical_gap_discovery',
    )
    forbidden_authorities: tuple[str, ...] = (
        'production_approval',
        'market_truth_authority',
        'synthetic_data_authorization',
        'override_fail_closed',
    )
    required_evidence: tuple[str, ...] = (
        'query', 'response_timestamp', 'grounding_sources', 'response_sha256'
    )

class GoogleStrategicGateway:
    """Google Gemini + Google Search grounding as an evidence-assistance layer.

    It may discover and corroborate evidence, but can never self-authorize QV
    production or replace EGX/EGID verification authority.
    """
    def __init__(self, state_dir='QV-GOOGLE-GATEWAY-RUN', api_key=None, model=None, timeout=30):
        self.state = Path(state_dir); self.state.mkdir(parents=True, exist_ok=True)
        self.api_key = api_key or os.getenv('GOOGLE_API_KEY') or os.getenv('GEMINI_API_KEY')
        self.model = model or os.getenv('QV_GOOGLE_MODEL', 'gemini-3.8-flash')
        self.timeout = timeout
        self.policy = GoogleGatewayPolicy()

    @property
    def configured(self):
        return bool(self.api_key)

    def manifest(self):
        data = {
            'engine': ENGINE, 'version': VERSION,
            'configured': self.configured,
            'model': self.model,
            'endpoint': ENDPOINT,
            'policy': asdict(self.policy),
            'production_authorized': False,
            'fail_closed': True,
        }
        (self.state / 'QV-GOOGLE-GATEWAY-MANIFEST.json').write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
        return data

    def _save(self, payload: dict[str, Any], name='google_evidence.json'):
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode('utf-8')
        payload['response_sha256'] = hashlib.sha256(raw).hexdigest()
        (self.state / name).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        return payload

    def query(self, prompt: str, *, use_google_search=True, extra_system_instruction=''):
        if not prompt.strip():
            raise ValueError('prompt must not be empty')
        if not self.configured:
            return self._save({
                'status': 'NOT_CONFIGURED', 'query': prompt,
                'response_timestamp': time.time(), 'grounding_sources': [],
                'production_authorized': False, 'fail_closed': True,
                'reason': 'GOOGLE_API_KEY/GEMINI_API_KEY is not configured in the runtime environment.'
            })
        body = {
            'model': self.model,
            'input': prompt,
            'system_instruction': (extra_system_instruction or '') +
                '\nQV policy: return verifiable sources; never claim production approval; never invent missing market data.'
        }
        if use_google_search:
            body['tools'] = [{'type': 'google_search'}]
        started = time.time()
        try:
            r = requests.post(ENDPOINT, headers={
                'x-goog-api-key': self.api_key,
                'Content-Type': 'application/json',
            }, json=body, timeout=self.timeout)
            r.raise_for_status()
            data = r.json()
            sources = []
            for step in data.get('steps', []) or []:
                if step.get('type') == 'google_search_result':
                    for item in step.get('result', []) or []:
                        if isinstance(item, dict):
                            sources.append({k: item.get(k) for k in ('title','url') if item.get(k)})
                elif step.get('type') == 'google_search_call':
                    pass
            output = data.get('output_text') or ''
            result = {
                'status': data.get('status', 'completed'), 'query': prompt,
                'response_timestamp': time.time(), 'latency_ms': round((time.time()-started)*1000, 2),
                'output_text': output, 'grounding_sources': sources,
                'interaction_id': data.get('id'),
                'production_authorized': False, 'fail_closed': True,
            }
            return self._save(result)
        except Exception as exc:
            return self._save({
                'status': 'ERROR', 'query': prompt, 'response_timestamp': time.time(),
                'latency_ms': round((time.time()-started)*1000, 2), 'grounding_sources': [],
                'error_type': type(exc).__name__, 'error': str(exc)[:500],
                'production_authorized': False, 'fail_closed': True,
            })

    def authorization_statement(self):
        """Return the explicit boundary: Google can corroborate, not authorize QV production."""
        return {
            'google_role': self.policy.role,
            'permissions_granted_to_gateway': list(self.policy.permissions),
            'authority_not_granted': list(self.policy.forbidden_authorities),
            'production_authorized': False,
            'fail_closed': True,
        }
