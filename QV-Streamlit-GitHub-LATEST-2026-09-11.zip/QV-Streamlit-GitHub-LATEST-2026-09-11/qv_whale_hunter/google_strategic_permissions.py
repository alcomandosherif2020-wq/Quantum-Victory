from __future__ import annotations
import json, os, hashlib
from dataclasses import dataclass, asdict
from pathlib import Path

ENGINE='QV-GOOGLE-STRATEGIC-PERMISSIONS'
VERSION='1.0.0'

# Maximum operational authority inside Quantum Victory, without granting
# unrestricted access to the host, user accounts, credentials, or trading execution.
SCOPES = {
    'web_discovery': True,
    'google_search_grounding': True,
    'historical_source_discovery': True,
    'source_cross_check': True,
    'evidence_extraction': True,
    'evidence_reconciliation': True,
    'source_health_checks': True,
    'session_gap_detection': True,
    'download_public_authorized_data': True,
    'archive_evidence': True,
    'hash_and_provenance': True,
    'feed_unverified_results_to_qv_qualification': True,
    'trigger_qv_validation': True,
    'trigger_qv_oos_pipeline': True,
    'trigger_qv_audit_pipeline': True,
    'notify_telegram_via_qv': True,
    'continuous_background_execution': True,
    # Explicitly bounded capabilities:
    'override_fail_closed': False,
    'self_grant_production_authorization': False,
    'declare_external_market_authority': False,
    'invent_or_fill_missing_market_data': False,
    'bypass_provider_terms_or_authentication': False,
    'access_private_google_account_data_without_oauth': False,
    'access_user_credentials_or_secrets': False,
    'place_live_broker_orders': False,
}

@dataclass(frozen=True)
class GooglePermissionProfile:
    engine: str = ENGINE
    version: str = VERSION
    enabled: bool = True
    mode: str = 'AUTONOMOUS_QV_ASSISTANT'
    production_authorized: bool = False
    fail_closed: bool = True
    scopes: dict = None

    def to_dict(self):
        d=asdict(self)
        d['scopes']=SCOPES.copy()
        d['google_api_configured']=bool(os.getenv('GEMINI_API_KEY') or os.getenv('GOOGLE_API_KEY'))
        d['authorization_model']='API_KEY_OR_AUTH_KEY_REQUIRED'
        return d


def activate(state_dir='QV-GOOGLE-STRATEGIC-GATEWAY-RUN'):
    p=Path(state_dir); p.mkdir(parents=True, exist_ok=True)
    profile=GooglePermissionProfile().to_dict()
    raw=json.dumps(profile,ensure_ascii=False,sort_keys=True).encode()
    profile['sha256']=hashlib.sha256(raw).hexdigest()
    (p/'google_permission_profile.json').write_text(json.dumps(profile,ensure_ascii=False,indent=2),encoding='utf-8')
    return profile

if __name__ == '__main__':
    print(json.dumps(activate(),ensure_ascii=False,indent=2))
