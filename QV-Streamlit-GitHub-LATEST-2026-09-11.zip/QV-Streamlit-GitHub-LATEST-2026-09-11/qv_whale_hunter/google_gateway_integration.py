from __future__ import annotations
import json
from pathlib import Path
from .google_strategic_gateway import GoogleStrategicGateway

ENGINE='QV-GOOGLE-GATEWAY-INTEGRATION'
VERSION='1.0.0'

def activate(state_dir='QV-GOOGLE-GATEWAY-RUN'):
    gateway=GoogleStrategicGateway(state_dir=state_dir)
    manifest=gateway.manifest()
    binding={
        'engine':ENGINE,'version':VERSION,
        'gateway':manifest,
        'bindings':{
            'discovery':'enabled',
            'historical_gap_recovery':'enabled',
            'evidence_corroboration':'enabled',
            'source_reconciliation_assistance':'enabled',
            'citation_capture':'enabled',
            'production_authority':'disabled',
        },
        'production_authorized':False,
        'fail_closed':True,
    }
    p=Path(state_dir); p.mkdir(parents=True,exist_ok=True)
    (p/'QV-GOOGLE-GATEWAY-INTEGRATION.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2),encoding='utf-8')
    return binding
