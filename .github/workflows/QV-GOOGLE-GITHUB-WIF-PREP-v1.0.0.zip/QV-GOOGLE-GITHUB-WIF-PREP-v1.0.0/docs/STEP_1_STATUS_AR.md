# حالة التنفيذ — Quantum Victory / Google

الحالة الحالية: **AUTH_PENDING / FAIL-CLOSED**

تم تجهيز طبقة GitHub Actions + OIDC/WIF محليًا، دون إنشاء أي أسرار أو مفاتيح طويلة الأجل.

المطلوب من حساب Google قبل تنفيذ أوامر WIF فعليًا:
- مشروع Google Cloud صالح.
- Project ID وProject Number.
- تفعيل Billing للمشروع إذا طلبت Google ذلك لتكوين WIF/الخدمات المطلوبة.

المطلوب من GitHub:
- المستودع: `alcomandosherif2020-wq/Quantum-Victory`
- متغيرا مستودع (Repository Variables) بعد إنشاء WIF:
  - `GOOGLE_WORKLOAD_IDENTITY_PROVIDER`
  - `GOOGLE_SERVICE_ACCOUNT`

لا يتم وضع API keys أو private keys أو tokens داخل المستودع.
