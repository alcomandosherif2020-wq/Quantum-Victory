#!/usr/bin/env bash
set -euo pipefail

# Replace placeholders locally. Do not paste secrets into this file.
PROJECT_ID="REPLACE_PROJECT_ID"
PROJECT_NUMBER="REPLACE_PROJECT_NUMBER"
POOL_ID="qv-github-pool"
PROVIDER_ID="qv-github-provider"
SERVICE_ACCOUNT_ID="qv-github"
SERVICE_ACCOUNT_EMAIL="${SERVICE_ACCOUNT_ID}@${PROJECT_ID}.iam.gserviceaccount.com"
GITHUB_REPO="alcomandosherif2020-wq/Quantum-Victory"

# 1) Create service account
# gcloud iam service-accounts create "${SERVICE_ACCOUNT_ID}" --project="${PROJECT_ID}" --display-name="QV GitHub WIF"

# 2) Create workload identity pool
# gcloud iam workload-identity-pools create "${POOL_ID}" --project="${PROJECT_ID}" --location="global" --display-name="QV GitHub Pool"

# 3) Create GitHub OIDC provider with repository restriction.
# gcloud iam workload-identity-pools providers create-oidc "${PROVIDER_ID}" \
#   --project="${PROJECT_ID}" --location="global" --workload-identity-pool="${POOL_ID}" \
#   --issuer-uri="https://token.actions.githubusercontent.com/" \
#   --attribute-mapping="google.subject=assertion.sub,attribute.repository=assertion.repository,attribute.repository_id=assertion.repository_id" \
#   --attribute-condition="assertion.repository == '${GITHUB_REPO}'"

# 4) Allow the repository principal to impersonate the service account.
# Use the project NUMBER in the principalSet resource path.
# gcloud iam service-accounts add-iam-policy-binding "${SERVICE_ACCOUNT_EMAIL}" \
#   --project="${PROJECT_ID}" \
#   --role="roles/iam.workloadIdentityUser" \
#   --member="principalSet://iam.googleapis.com/projects/${PROJECT_NUMBER}/locations/global/workloadIdentityPools/${POOL_ID}/attribute.repository/${GITHUB_REPO}"

# 5) After least-privilege roles are decided, add only the roles actually required by QV.
