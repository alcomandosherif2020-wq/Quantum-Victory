# QV Google GitHub WIF Preparation v1.0.0

حزمة تجهيز آمنة لربط Quantum Victory بـ Google Cloud عبر GitHub Actions + OIDC + Workload Identity Federation.

هذه الحزمة لا تدّعي وجود مشروع Google أو موافقة Web Search Service أو client_id. التنفيذ الفعلي لتلك الموارد يحتاج حساب Google Cloud وصلاحياته.

## المسار
GitHub Actions -> GitHub OIDC -> Google WIF -> Service Account -> Google capability layer -> QV evidence gate -> Engine Bus

## Fail-Closed
عند غياب الاعتماد أو الموارد المطلوبة، لا يتم تنفيذ استدعاء Google ولا يتم اختلاق بيانات اعتماد.
