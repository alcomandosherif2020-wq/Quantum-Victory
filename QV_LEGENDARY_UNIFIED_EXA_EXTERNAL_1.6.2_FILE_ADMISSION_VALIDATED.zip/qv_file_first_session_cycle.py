# -*- coding: utf-8 -*-
"""QV File-First Session Cycle.

Turns an archived EGX session file set into a reproducible Quantum Victory
analysis run. The official downloaded files remain the primary evidence;
external providers are optional corroboration layers only.
"""
from __future__ import annotations
import hashlib, json, os
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

from qv_offline_session_archive import QVOfflineSessionArchive
from qv_unified_signal_orchestrator import QVUnifiedSignalOrchestrator
from qv_external_integrations import QVExternalIntegrationBridge
from qv_exa_intelligence import QVExaIntelligenceEngine
from qv_historical_context_bridge import QVHistoricalContextBridge
from qv_persistence_audit import QVPersistenceAudit
from qv_durable_persistence import QVGithubDurablePersistence

ENGINE = "QV-FILE-FIRST-SESSION-CYCLE"
VERSION = "1.2.0"

class QVFileFirstSessionCycle:
    def __init__(self, root="QV-OFFLINE-SESSIONS", top_n=50):
        self.root = Path(root)
        self.inbox = self.root / "inbox"
        self.archive = self.root / "archive"
        self.index = self.root / "index"
        self.runs = self.root / "analysis_runs"
        self.brain = self.root / "brain"
        for p in (self.inbox, self.archive, self.index, self.runs, self.brain):
            p.mkdir(parents=True, exist_ok=True)
        self.top_n = int(top_n)

    @staticmethod
    def _sha(obj):
        return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()

    def _external(self, data: pd.DataFrame):
        """Optional external corroboration. Disabled unless explicitly enabled."""
        enabled = os.getenv("QV_EXTERNAL_MESH_ENABLED", "0") == "1"
        if not enabled or data.empty or "symbol" not in data.columns:
            return {"enabled": False, "providers": [], "reason": "EXTERNAL_MESH_DISABLED", "production_authorized": False}
        bridge = QVExternalIntegrationBridge()
        symbols = list(dict.fromkeys(data["symbol"].astype(str).head(int(os.getenv("QV_EXTERNAL_MAX_SYMBOLS", "10")))))
        reports = []
        for symbol in symbols:
            r = bridge.collect(symbol)
            reports.extend(r.get("providers", []))
        return {"enabled": True, "providers": reports, "symbol_count": len(symbols), "production_authorized": False, "fail_closed": True}

    def _exa(self, data: pd.DataFrame):
        enabled = bool(os.getenv("EXA_API_KEY")) and os.getenv("QV_EXA_FILE_FIRST_ENABLED", "0") == "1"
        if not enabled or data.empty or "symbol" not in data.columns:
            return {"enabled": False, "results": [], "reason": "EXA_FILE_FIRST_DISABLED", "production_authorized": False}
        engine = QVExaIntelligenceEngine()
        symbols = list(dict.fromkeys(data["symbol"].astype(str).head(int(os.getenv("QV_EXA_MAX_SYMBOLS", "10")))))
        results = []
        for symbol in symbols:
            results.append(engine.search_symbol_events(symbol=symbol))
        return {"enabled": True, "results": results, "symbol_count": len(symbols), "production_authorized": False, "fail_closed": True}

    def _durable_mirror(self):
        """Mirror evidence artifacts to an explicitly configured durable backend.

        No credentials are stored in source. When GitHub is not configured the
        result is LOCAL_RUNTIME_ONLY and no network call is attempted.
        """
        backend = QVGithubDurablePersistence()
        paths = []
        for base in (self.archive, self.index, self.brain, self.runs):
            if base.exists():
                paths.extend(p for p in base.rglob("*") if p.is_file())
        results = backend.mirror_paths(self.root, paths) if backend.configured else []
        if not backend.configured:
            return {"backend": "LOCAL_ONLY", "status": "NOT_CONFIGURED", "uploaded": 0, "failed": 0, "production_authorized": False}
        failed = sum(1 for r in results if r.get("status") not in ("UPLOADED",))
        return {"backend": "GITHUB_CONTENTS", "status": "PASS" if failed == 0 else "BLOCKED", "uploaded": sum(1 for r in results if r.get("status") == "UPLOADED"), "failed": failed, "results": results, "production_authorized": False}

    def run(self, run_id=None):
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        run_id = run_id or stamp
        out = self.runs / run_id
        out.mkdir(parents=True, exist_ok=True)

        archive = QVOfflineSessionArchive(self.inbox, self.archive, self.index)
        report, data = archive.ingest()
        (out / "QV-ARCHIVE-REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

        manifest = {
            "engine": ENGINE, "version": VERSION, "run_id": run_id,
            "mode": "OFFLINE_FILE_FIRST",
            "live_data_claim": False,
            "production_authorized": False,
            "fail_closed": True,
            "input_archive_sha256": report.get("archive_sha256"),
            "files_discovered": report.get("files_discovered", 0),
            "tabular_rows": report.get("tabular_rows", 0),
            "file_validations": report.get("validations", []),
        }
        if data.empty:
            manifest["status"] = "NO_ANALYZABLE_TABULAR_DATA"
            manifest["analysis_executed"] = False
            manifest["reason"] = "No normalized OHLCV session rows were available. Originals remain archived."
            manifest["sha256"] = self._sha(manifest)
            (out / "QV-SESSION-CYCLE-MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            QVPersistenceAudit(self.root).run()
            return manifest, report, data, None

        # Historical bridge: automatically link the latest session to strictly prior
        # archived sessions. The current session remains separate from its history.
        bridge = QVHistoricalContextBridge(archive_root=self.root, max_sessions=int(os.getenv("QV_HISTORICAL_MAX_SESSIONS", "20")))
        context_report, current_context, historical_sessions, all_sessions = bridge.build(data.copy())
        (out / "QV-HISTORICAL-CONTEXT-MANIFEST.json").write_text(
            json.dumps(context_report, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
        )
        if not current_context.empty:
            current_context.to_csv(out / "QV-HISTORICAL-CURRENT-CONTEXT.csv", index=False)
        if not historical_sessions.empty:
            historical_sessions.to_csv(out / "QV-HISTORICAL-SESSION-CONTEXT.csv", index=False)
        if not all_sessions.empty:
            all_sessions.to_csv(out / "QV-HISTORICAL-ALL-SESSIONS.csv", index=False)

        session_dates = sorted(data["session_date"].dropna().astype(str).unique().tolist()) if "session_date" in data.columns else []
        current_day = context_report.get("current_session") or (session_dates[-1] if session_dates else None)
        current_data = data[data["session_date"].astype(str) == str(current_day)].copy() if current_day else data.copy()

        external = self._external(current_data)
        exa = self._exa(current_data)
        (out / "QV-EXTERNAL-EVIDENCE.json").write_text(json.dumps(external, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        (out / "QV-EXA-EVIDENCE.json").write_text(json.dumps(exa, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

        # File-first analysis: current rows are analyzed against a separately
        # linked historical context. No live source is required.
        orch = QVUnifiedSignalOrchestrator(out / "unified_orchestrator")
        historical_for_engine = all_sessions.copy() if all_sessions is not None and not all_sessions.empty else current_data.copy()
        gate, cert, integrated, alerts, health, reconciliation = orch.run(
            current_data, historical_intraday_df=historical_for_engine,
            external_report=external, top_n=self.top_n
        )
        if integrated is not None and not integrated.empty:
            integrated.to_csv(out / "QV-UNIFIED-INTEGRATED-EVIDENCE.csv", index=False)
        if alerts is not None and not alerts.empty:
            alerts.to_csv(out / "QV-UNIFIED-ALERT-QUEUE.csv", index=False)

        session_dates = sorted(data["session_date"].dropna().astype(str).unique().tolist()) if "session_date" in data.columns else []
        brain_entry = {
            "run_id": run_id,
            "session_dates": session_dates,
            "archive_sha256": report.get("archive_sha256"),
            "orchestrator_gate_sha256": gate.get("sha256"),
            "symbols": int(data["symbol"].nunique()) if "symbol" in data.columns else 0,
            "rows": int(len(data)),
            "current_session": current_day,
            "historical_sessions": context_report.get("prior_completed_sessions", []),
            "historical_rows": int(len(historical_sessions)),
            "historical_context_sha256": context_report.get("historical_context_sha256"),
            "external_enabled": external.get("enabled", False),
            "exa_enabled": exa.get("enabled", False),
            "production_authorized": False,
            "evidence_only": True,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        with (self.brain / "QV-SESSION-MEMORY.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(brain_entry, ensure_ascii=False, default=str) + "\n")

        manifest.update({
            "status": "PASS",
            "analysis_executed": True,
            "session_dates": session_dates,
            "current_session": current_day,
            "historical_sessions": context_report.get("prior_completed_sessions", []),
            "historical_rows": int(len(historical_sessions)),
            "historical_symbols_with_context": context_report.get("symbols_with_history", 0),
            "historical_context_sha256": context_report.get("historical_context_sha256"),
            "historical_context": context_report,
            "symbols": int(current_data["symbol"].nunique()) if "symbol" in current_data.columns else 0,
            "rows_analyzed": int(len(current_data)),
            "orchestrator_gate": gate,
            "v42_certificate": cert,
            "integration_health": health,
            "external_reconciliation": reconciliation,
            "external_enabled": external.get("enabled", False),
            "exa_enabled": exa.get("enabled", False),
            "production_authorized": False,
            "evidence_only": True,
            "file_validations": report.get("validations", []),
        })
        manifest["sha256"] = self._sha(manifest)
        (out / "QV-SESSION-CYCLE-MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        durable = self._durable_mirror()
        (out / "QV-DURABLE-PERSISTENCE-REPORT.json").write_text(
            json.dumps(durable, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
        )
        # Persist the cycle manifest first, then audit the complete storage chain.
        # The audit remains a separate integrity artifact to avoid hash circularity.
        QVPersistenceAudit(self.root).run()
        return manifest, report, data, out
