# -*- coding: utf-8 -*-
"""QV file admission validator.

Validates session-file structure and OHLCV integrity before analysis admission.
Fail-closed: validation never authorizes live production.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import pandas as pd

ENGINE = "QV-FILE-ADMISSION-VALIDATOR"
VERSION = "1.0.0"

REQUIRED_COLUMNS = ["Date", "Symbol", "Open", "High", "Low", "Close", "Volume"]
ALIASES = {
    "date": "Date", "Date": "Date", "trading_date": "Date", "TradingDate": "Date",
    "symbol": "Symbol", "Symbol": "Symbol", "ticker": "Symbol", "Ticker": "Symbol", "code": "Symbol", "Code": "Symbol",
    "open": "Open", "Open": "Open", "open_price": "Open",
    "high": "High", "High": "High", "high_price": "High",
    "low": "Low", "Low": "Low", "low_price": "Low",
    "close": "Close", "Close": "Close", "close_price": "Close",
    "volume": "Volume", "Volume": "Volume", "vol": "Volume",
}
NUMERIC = ["Open", "High", "Low", "Close", "Volume"]


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _canonical_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    rename = {}
    for c in out.columns:
        s = str(c).strip()
        key = s if s in ALIASES else s.lower().strip().replace(" ", "_")
        rename[c] = ALIASES.get(key, s)
    return out.rename(columns=rename)


def validate_dataframe(df: pd.DataFrame) -> dict[str, Any]:
    report: dict[str, Any] = {
        "engine": ENGINE,
        "version": VERSION,
        "status": "BLOCKED",
        "production_authorized": False,
        "live_data_claim": False,
        "fail_closed": True,
        "total_rows": int(len(df)) if df is not None else 0,
        "valid_rows": 0,
        "invalid_rows": 0,
        "missing_columns": [],
        "duplicate_date_symbol_rows": 0,
        "invalid_date_rows": 0,
        "invalid_symbol_rows": 0,
        "non_numeric_rows": 0,
        "invalid_price_rows": 0,
        "negative_volume_rows": 0,
        "ohlc_integrity_failure_rows": 0,
        "errors": [],
        "warnings": [],
    }
    if df is None or df.empty:
        report["errors"].append("NO_ROWS")
        return report

    x = _canonical_columns(df)
    missing = [c for c in REQUIRED_COLUMNS if c not in x.columns]
    report["missing_columns"] = missing
    if missing:
        report["errors"].append("MISSING_REQUIRED_COLUMNS")
        return report

    x["Date"] = pd.to_datetime(x["Date"], errors="coerce")
    invalid_date = x["Date"].isna()
    report["invalid_date_rows"] = int(invalid_date.sum())

    x["Symbol"] = x["Symbol"].astype("string").str.strip()
    invalid_symbol = x["Symbol"].isna() | (x["Symbol"] == "") | (x["Symbol"].str.lower() == "<na>")
    report["invalid_symbol_rows"] = int(invalid_symbol.sum())

    for c in NUMERIC:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    non_numeric = x[NUMERIC].isna().any(axis=1)
    report["non_numeric_rows"] = int(non_numeric.sum())

    invalid_price = (x[["Open", "High", "Low", "Close"]] <= 0).any(axis=1)
    negative_volume = x["Volume"] < 0
    report["invalid_price_rows"] = int(invalid_price.sum())
    report["negative_volume_rows"] = int(negative_volume.sum())

    invalid_ohlc = (
        (x["High"] < x["Open"]) |
        (x["High"] < x["Close"]) |
        (x["Low"] > x["Open"]) |
        (x["Low"] > x["Close"]) |
        (x["High"] < x["Low"])
    )
    report["ohlc_integrity_failure_rows"] = int(invalid_ohlc.sum())

    duplicate = x.duplicated(subset=["Date", "Symbol"], keep=False)
    report["duplicate_date_symbol_rows"] = int(duplicate.sum())

    valid = ~(invalid_date | invalid_symbol | non_numeric | invalid_price | negative_volume | invalid_ohlc)
    report["valid_rows"] = int(valid.sum())
    report["invalid_rows"] = int(len(x) - valid.sum())

    if report["duplicate_date_symbol_rows"]:
        report["warnings"].append("DUPLICATE_DATE_SYMBOL_ROWS")
    if report["invalid_date_rows"]:
        report["warnings"].append("INVALID_DATE_ROWS")
    if report["invalid_symbol_rows"]:
        report["warnings"].append("INVALID_SYMBOL_ROWS")

    if report["valid_rows"] == 0:
        report["errors"].append("NO_ANALYZABLE_ROWS")
    if report["ohlc_integrity_failure_rows"]:
        report["errors"].append("OHLC_INTEGRITY_FAILURE")
    if report["negative_volume_rows"]:
        report["errors"].append("NEGATIVE_VOLUME")

    report["status"] = "PASS" if not report["errors"] and report["valid_rows"] > 0 else "BLOCKED"
    report["report_sha256"] = hashlib.sha256(json.dumps(report, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()
    return report


def validate_file(file_path: str | Path) -> dict[str, Any]:
    path = Path(file_path)
    report = {"engine": ENGINE, "version": VERSION, "status": "BLOCKED", "production_authorized": False, "live_data_claim": False, "fail_closed": True, "file_name": path.name, "file_sha256": None, "errors": [], "warnings": []}
    if not path.exists():
        report["errors"].append("FILE_NOT_FOUND")
        return report
    report["file_sha256"] = _file_sha256(path)
    try:
        suf = path.suffix.lower()
        if suf == ".csv":
            df = pd.read_csv(path)
        elif suf in {".xlsx", ".xls"}:
            df = pd.read_excel(path)
        elif suf == ".parquet":
            df = pd.read_parquet(path)
        elif suf == ".json":
            obj = json.loads(path.read_text(encoding="utf-8-sig"))
            rows = obj if isinstance(obj, list) else next((obj[k] for k in ("data", "rows", "records", "results", "items", "quotes") if isinstance(obj, dict) and isinstance(obj.get(k), list)), [obj] if isinstance(obj, dict) else [])
            df = pd.DataFrame(rows)
        else:
            report["errors"].append("UNSUPPORTED_FILE_TYPE")
            return report
    except Exception as exc:
        report["errors"].append(f"READ_ERROR:{type(exc).__name__}")
        return report
    result = validate_dataframe(df)
    result.update({"file_name": path.name, "file_sha256": report["file_sha256"]})
    return result
