import pandas as pd
from qv_file_validator import validate_dataframe


def _good():
    return pd.DataFrame({
        'Date':['2026-09-10'], 'Symbol':['COMI'], 'Open':[100], 'High':[105],
        'Low':[99], 'Close':[104], 'Volume':[1000]
    })


def test_validator_passes_good_ohlcv():
    r=validate_dataframe(_good())
    assert r['status']=='PASS'
    assert r['valid_rows']==1
    assert r['production_authorized'] is False


def test_validator_blocks_missing_columns():
    r=validate_dataframe(_good().drop(columns=['Volume']))
    assert r['status']=='BLOCKED'
    assert 'Volume' in r['missing_columns']


def test_validator_blocks_bad_ohlc():
    x=_good(); x.loc[0,'High']=90
    r=validate_dataframe(x)
    assert r['status']=='BLOCKED'
    assert 'OHLC_INTEGRITY_FAILURE' in r['errors']


def test_validator_blocks_negative_volume():
    x=_good(); x.loc[0,'Volume']=-1
    r=validate_dataframe(x)
    assert r['status']=='BLOCKED'
    assert 'NEGATIVE_VOLUME' in r['errors']
