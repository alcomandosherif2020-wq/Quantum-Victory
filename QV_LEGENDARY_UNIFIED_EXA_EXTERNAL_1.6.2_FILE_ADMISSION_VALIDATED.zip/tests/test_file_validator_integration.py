import pandas as pd
from qv_offline_session_archive import QVOfflineSessionArchive

def test_archive_blocks_invalid_ohlcv(tmp_path):
    inbox=tmp_path/"inbox"; archive=tmp_path/"archive"; index=tmp_path/"index"
    inbox.mkdir()
    pd.DataFrame({"Date":["2026-09-10"],"Symbol":["COMI"],"Open":[100],"High":[90],"Low":[99],"Close":[104],"Volume":[1000]}).to_csv(inbox/"bad.csv",index=False)
    report,data=QVOfflineSessionArchive(inbox,archive,index).ingest()
    assert data.empty
    assert report["validations"][0]["status"]=="BLOCKED"
    assert any(x["error"]=="FILE_ADMISSION_BLOCKED" for x in report["failures"])

def test_archive_accepts_valid_ohlcv(tmp_path):
    inbox=tmp_path/"inbox"; archive=tmp_path/"archive"; index=tmp_path/"index"
    inbox.mkdir()
    pd.DataFrame({"Date":["2026-09-10"],"Symbol":["COMI"],"Open":[100],"High":[105],"Low":[99],"Close":[104],"Volume":[1000]}).to_csv(inbox/"good.csv",index=False)
    report,data=QVOfflineSessionArchive(inbox,archive,index).ingest()
    assert len(data)==1
    assert report["validations"][0]["status"]=="PASS"
