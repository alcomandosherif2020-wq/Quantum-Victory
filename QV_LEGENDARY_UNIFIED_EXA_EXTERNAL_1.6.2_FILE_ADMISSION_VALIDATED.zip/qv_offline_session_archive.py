from __future__ import annotations
import hashlib, json, shutil
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable
import pandas as pd
from qv_file_validator import validate_dataframe

ENGINE='QV-OFFLINE-SESSION-ARCHIVE-ENGINE'
VERSION='1.0.0'

@dataclass(frozen=True)
class ArchivedFile:
    source_path: str
    archive_path: str
    sha256: str
    size: int
    file_type: str
    status: str

class QVOfflineSessionArchive:
    """File-first EGX session archive.

    Officially downloaded session files are preserved byte-for-byte, fingerprinted,
    indexed and normalized for analysis. This layer never pretends archived data
    is live and never requires the market to be open.
    """
    SUPPORTED=('*.csv','*.CSV','*.xlsx','*.XLSX','*.xls','*.XLS','*.json','*.JSON','*.parquet','*.PARQUET','*.txt','*.TXT','*.pdf','*.PDF')
    ALIASES={
        'ticker':'symbol','Symbol':'symbol','Ticker':'symbol','code':'symbol','Code':'symbol',
        'date':'session_date','Date':'session_date','trading_date':'session_date','TradingDate':'session_date',
        'open_price':'open','Open':'open','OPEN':'open','high_price':'high','High':'high','HIGH':'high',
        'low_price':'low','Low':'low','LOW':'low','close_price':'close','Close':'close','CLOSE':'close',
        'vol':'volume','Volume':'volume','VOLUME':'volume','value':'turnover','Value':'turnover','Turnover':'turnover',
        'datetime':'timestamp','DateTime':'timestamp','time':'timestamp'
    }
    def __init__(self, inbox='QV-OFFLINE-SESSIONS/inbox', archive='QV-OFFLINE-SESSIONS/archive', index='QV-OFFLINE-SESSIONS/index'):
        self.inbox=Path(inbox); self.archive=Path(archive); self.index=Path(index)
        for p in (self.inbox,self.archive,self.index): p.mkdir(parents=True,exist_ok=True)

    @staticmethod
    def sha256(path: Path)->str:
        h=hashlib.sha256()
        with path.open('rb') as f:
            for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
        return h.hexdigest()

    def discover(self)->list[Path]:
        found=[]
        for pattern in self.SUPPORTED: found.extend(self.inbox.rglob(pattern))
        return sorted(set(p for p in found if p.is_file()))

    def _archive_one(self, src: Path)->ArchivedFile:
        digest=self.sha256(src); rel=src.relative_to(self.inbox)
        dest=self.archive/rel.parent/f'{src.stem}__sha256_{digest[:16]}{src.suffix.lower()}'
        dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists(): shutil.copy2(src,dest)
        return ArchivedFile(str(src),str(dest),digest,src.stat().st_size,src.suffix.lower().lstrip('.'),'ARCHIVED')

    def _read_table(self,path:Path)->pd.DataFrame:
        suf=path.suffix.lower()
        if suf=='.csv': return pd.read_csv(path)
        if suf in ('.xlsx','.xls'): return pd.read_excel(path)
        if suf=='.parquet': return pd.read_parquet(path)
        if suf=='.json':
            obj=json.loads(path.read_text(encoding='utf-8-sig'))
            if isinstance(obj,list): return pd.DataFrame(obj)
            if isinstance(obj,dict):
                for k in ('data','rows','records','results','items','quotes'):
                    if isinstance(obj.get(k),list): return pd.DataFrame(obj[k])
                return pd.DataFrame([obj])
        if suf=='.txt':
            try: return pd.read_csv(path,sep=None,engine='python')
            except Exception: return pd.DataFrame()
        return pd.DataFrame()

    def normalize(self,df:pd.DataFrame, source_id:str)->pd.DataFrame:
        if df is None or df.empty: return pd.DataFrame()
        x=df.copy(); x.columns=[str(c).strip() for c in x.columns]
        x=x.rename(columns={c:self.ALIASES.get(c,c.lower().strip().replace(' ','_')) for c in x.columns})
        if 'symbol' not in x.columns: return pd.DataFrame()
        if 'session_date' not in x.columns and 'timestamp' in x.columns:
            x['session_date']=pd.to_datetime(x['timestamp'],errors='coerce').dt.strftime('%Y-%m-%d')
        if 'timestamp' in x.columns: x['timestamp']=pd.to_datetime(x['timestamp'],errors='coerce')
        elif 'session_date' in x.columns: x['timestamp']=pd.to_datetime(x['session_date'],errors='coerce')
        for c in ('open','high','low','close','volume','turnover'):
            if c in x.columns: x[c]=pd.to_numeric(x[c],errors='coerce')
        if 'price' not in x.columns:
            x['price']=x['close'] if 'close' in x.columns else pd.NA
        x['symbol']=x['symbol'].astype(str).str.strip()
        x['source_id']=source_id; x['provenance']='OFFICIAL_DOWNLOADED_SESSION_FILE'; x['production_authorized']=False
        return x

    def ingest(self)->tuple[dict,pd.DataFrame]:
        files=[]; frames=[]; failures=[]; validations=[]
        for src in self.discover():
            meta=self._archive_one(src); files.append(asdict(meta))
            try:
                df=self._read_table(src)
                if not df.empty:
                    validation=validate_dataframe(df)
                    validation.update({"source_path": str(src), "source_sha256": meta.sha256})
                    validations.append(validation)
                    if validation.get("status") != "PASS":
                        failures.append({"path":str(src),"error":"FILE_ADMISSION_BLOCKED","detail":json.dumps(validation, ensure_ascii=False)[:1200]})
                        continue
                norm=self.normalize(df,meta.sha256)
                if not norm.empty: frames.append(norm)
            except Exception as exc:
                failures.append({'path':str(src),'error':type(exc).__name__,'detail':str(exc)[:240]})
        data=pd.concat(frames,ignore_index=True) if frames else pd.DataFrame()
        if not data.empty:
            data['evidence_fingerprint']=data.apply(lambda r:hashlib.sha256('|'.join(str(r.get(c,'')) for c in ['source_id','symbol','session_date','timestamp','open','high','low','close','volume','turnover']).encode()).hexdigest(),axis=1)
        report={'engine':ENGINE,'version':VERSION,'mode':'OFFLINE_FILE_FIRST','files_discovered':len(files),'tabular_rows':len(data),'failures':failures,'files':files,'validations':validations,'production_authorized':False,'live_data_claim':False,'fail_closed':True}
        report['archive_sha256']=hashlib.sha256(json.dumps(files,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        (self.index/'QV-OFFLINE-SESSION-INDEX.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        if not data.empty: data.to_csv(self.index/'QV-OFFLINE-NORMALIZED-EVIDENCE.csv',index=False)
        return report,data
