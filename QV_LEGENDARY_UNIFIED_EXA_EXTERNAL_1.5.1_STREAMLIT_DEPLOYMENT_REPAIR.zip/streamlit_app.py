# -*- coding: utf-8 -*-
"""Quantum Victory — File-First EGX historical session workspace.
No live-market claim. Uploaded/downloaded session files are the primary evidence.
"""
from __future__ import annotations
import json, os, shutil, tempfile
from pathlib import Path
import pandas as pd
import streamlit as st

from qv_offline_session_archive import QVOfflineSessionArchive
from qv_file_first_session_cycle import QVFileFirstSessionCycle
from qv_historical_context_bridge import QVHistoricalContextBridge

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "QV-OFFLINE-SESSIONS"
INBOX = WORK / "inbox"
ARCHIVE = WORK / "archive"
INDEX = WORK / "index"
for p in (INBOX, ARCHIVE, INDEX):
    p.mkdir(parents=True, exist_ok=True)

st.set_page_config(page_title="كوانتوم فيكتوري — المخزن والأرشيف", page_icon="📊", layout="wide")

st.title("كوانتوم فيكتوري")
st.caption("التحليل التاريخي للجلسات — FILE_FIRST / OFFLINE — دون ادعاء بيانات حية")

with st.sidebar:
    st.header("حوكمة التشغيل")
    st.success("وضع التشغيل: OFFLINE_FILE_FIRST")
    st.info("المصدر الأساسي: ملفات جلسات التداول الرسمية التي تم تنزيلها وحفظها.")
    st.warning("الإنتاج/التداول الحي غير مصرح به في هذه المرحلة.")
    st.write("live_data_claim = False")
    st.write("production_authorized = False")
    st.write("fail_closed = True")

st.subheader("1) إدخال ملفات جلسات التداول")
uploads = st.file_uploader(
    "ارفع ملفات الجلسات الرسمية بعد تنزيلها من المصدر المعتمد",
    type=["csv", "xlsx", "xls", "json", "parquet", "txt", "pdf"],
    accept_multiple_files=True,
)

if uploads:
    for up in uploads:
        target = INBOX / Path(up.name).name
        target.write_bytes(up.getbuffer())
    st.success(f"تم استقبال {len(uploads)} ملف/ملفات في صندوق الاستلام.")

col1, col2, col3 = st.columns(3)
with col1:
    if st.button("📥 أرشفة وفهرسة", type="primary", use_container_width=True):
        archive = QVOfflineSessionArchive(inbox=INBOX, archive=ARCHIVE, index=INDEX)
        report, data = archive.ingest()
        st.session_state["qv_report"] = report
        st.session_state["qv_data"] = data
        st.rerun()
with col2:
    if st.button("🧠 تشغيل دورة كوانتوم الكاملة", type="primary", use_container_width=True):
        cycle = QVFileFirstSessionCycle(root=WORK, top_n=50)
        manifest, report, data, out = cycle.run()
        st.session_state["qv_report"] = report
        st.session_state["qv_data"] = data
        st.session_state["qv_cycle_manifest"] = manifest
        st.session_state["qv_cycle_out"] = str(out) if out else None
        st.rerun()
with col3:
    if st.button("🔄 إعادة تحميل المخزن", use_container_width=True):
        archive = QVOfflineSessionArchive(inbox=INBOX, archive=ARCHIVE, index=INDEX)
        report, data = archive.ingest()
        st.session_state["qv_report"] = report
        st.session_state["qv_data"] = data
        st.rerun()

report = st.session_state.get("qv_report")
data = st.session_state.get("qv_data", pd.DataFrame())

if report:
    st.subheader("2) حالة المخزن والأرشيف")
    a,b,c,d = st.columns(4)
    a.metric("الملفات المكتشفة", report.get("files_discovered", 0))
    b.metric("الصفوف القابلة للتحليل", report.get("tabular_rows", 0))
    c.metric("الإخفاقات", len(report.get("failures", [])))
    d.metric("الوضع", report.get("mode", "OFFLINE_FILE_FIRST"))

    st.code(json.dumps({
        "archive_sha256": report.get("archive_sha256"),
        "live_data_claim": report.get("live_data_claim"),
        "production_authorized": report.get("production_authorized"),
        "fail_closed": report.get("fail_closed"),
    }, ensure_ascii=False, indent=2), language="json")

    if report.get("failures"):
        st.error("ملفات لم تُحلل جدوليًا؛ تم الاحتفاظ بها كأدلة أصلية وعدم اختلاق بيانات منها.")
        st.json(report["failures"])

cycle_manifest = st.session_state.get("qv_cycle_manifest")
if cycle_manifest:
    st.subheader("3) دورة كوانتوم فيكتوري الموحدة")
    m1,m2,m3,m4 = st.columns(4)
    m1.metric("الحالة", cycle_manifest.get("status", "UNKNOWN"))
    m2.metric("الأدوات", cycle_manifest.get("symbols", 0))
    m3.metric("الصفوف المحللة", cycle_manifest.get("rows_analyzed", 0))
    m4.metric("مصادر خارجية مفعلة", int(bool(cycle_manifest.get("external_enabled"))))
    st.json({
        "mode": cycle_manifest.get("mode"),
        "session_dates": cycle_manifest.get("session_dates", []),
        "analysis_executed": cycle_manifest.get("analysis_executed"),
        "production_authorized": cycle_manifest.get("production_authorized"),
        "external_enabled": cycle_manifest.get("external_enabled"),
        "exa_enabled": cycle_manifest.get("exa_enabled"),
        "run_id": cycle_manifest.get("run_id"),
    })
    if cycle_manifest.get("orchestrator_gate"):
        st.write("حالة بوابة الأوركسترا")
        st.json(cycle_manifest["orchestrator_gate"])

    if cycle_manifest.get("historical_context"):
        hc = cycle_manifest["historical_context"]
        st.subheader("4) الربط التلقائي بين الجلسة الحالية والجلسات السابقة")
        h1,h2,h3,h4 = st.columns(4)
        h1.metric("الجلسة الحالية", hc.get("current_session", "—"))
        h2.metric("الجلسات السابقة المرتبطة", len(hc.get("prior_completed_sessions", [])))
        h3.metric("صفوف التاريخ", hc.get("historical_raw_rows", 0))
        h4.metric("أدوات لها تاريخ", hc.get("symbols_with_history", 0))
        st.caption("الحد الزمني: لا تدخل أي جلسة مساوية أو لاحقة للجلسة الحالية في السياق التاريخي.")
        if hc.get("prior_completed_sessions"):
            st.write("الجلسات السابقة:", hc.get("prior_completed_sessions"))
        ctx_path = Path(st.session_state.get("qv_cycle_out") or "") / "QV-HISTORICAL-CURRENT-CONTEXT.csv"
        if ctx_path.exists():
            ctx = pd.read_csv(ctx_path)
            cols = [c for c in ["symbol","session_date","ret1","ret3","ret5","rvol5","ema5","ema10","rsi14","volatility5","ad_flow5","trend_state","state_transition","prior_sessions_available","multi_session_confirmation"] if c in ctx.columns]
            st.dataframe(ctx[cols], use_container_width=True)

if isinstance(data, pd.DataFrame) and not data.empty:
    st.subheader("5) البيانات الموحّدة — Historical Evidence")
    st.caption("هذه البيانات مشتقة من الملفات المؤرشفة وتحمل provenance صريحًا.")
    st.dataframe(data.head(1000), use_container_width=True)

    st.subheader("6) ملخص الجلسة")
    symbols = data["symbol"].nunique() if "symbol" in data.columns else 0
    sessions = data["session_date"].dropna().astype(str).nunique() if "session_date" in data.columns else 0
    x,y = st.columns(2)
    x.metric("عدد الأدوات", symbols)
    y.metric("عدد الجلسات", sessions)

st.subheader("7) المبدأ التشغيلي")
st.markdown(
    """
- **الملف الرسمي المحفوظ هو الدليل الأساسي للجلسة.**
- يتم حفظ الأصل وبصمته SHA-256 قبل التحليل.
- يتم إنشاء نسخة موحّدة للتحليل دون إتلاف الأصل.
- المصادر الخارجية تستخدم للمقارنة والإثراء والمصالحة، وليست بديلًا عن دليل الجلسة.
- لا يتم تحويل نتيجة تاريخية إلى ادعاء Live.
- لا يتم فتح اعتماد إنتاجي من خلال هذه الواجهة.
"""
)
