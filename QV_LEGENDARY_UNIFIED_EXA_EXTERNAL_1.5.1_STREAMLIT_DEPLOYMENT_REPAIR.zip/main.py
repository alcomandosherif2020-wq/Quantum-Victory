# -*- coding: utf-8 -*-
"""Streamlit Cloud entrypoint for Quantum Victory.

Important: this entrypoint launches the Streamlit FILE-FIRST application directly.
It deliberately does NOT execute the legacy Nafezu HTTP-wrapper, which can cause
FileNotFoundError when an older deployment points at the wrapper instead of the
Streamlit app.
"""
from streamlit_app import *  # noqa: F401,F403
