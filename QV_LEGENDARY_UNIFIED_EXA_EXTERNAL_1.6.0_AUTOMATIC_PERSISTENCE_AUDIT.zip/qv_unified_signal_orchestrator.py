from __future__ import annotations
import hashlib, json
from pathlib import Path
from qv_external_integrations import reconcile, build_health
from qv_whale_hunter.v42_pipeline import run as run_v42

ENGINE='QV-UNIFIED-SIGNAL-ORCHESTRATOR'; VERSION='1.1.0'

class QVUnifiedSignalOrchestrator:
    """Deterministic orchestration layer: QV evidence fusion + external corroboration.
    External providers remain evidence-only and can never authorize production.
    """
    def __init__(self, out_dir='QV-UNIFIED-ORCHESTRATOR-RUN'):
        self.out=Path(out_dir); self.out.mkdir(parents=True,exist_ok=True)

    def run(self, intraday_df, recommendation_df=None, historical_intraday_df=None,
            external_report=None, top_n=20, **kwargs):
        external_report=external_report or {'providers':[]}
        providers=external_report.get('providers',[])
        reconciliation=reconcile(providers)
        health=build_health(providers,reconciliation)
        cert, integrated, alerts = run_v42(
            intraday_df, recommendation_df= recommendation_df,
            historical_intraday_df=historical_intraday_df,
            out_dir=self.out/'v42', top_n=top_n, **kwargs)

        # External reconciliation is a decision-safety layer, not a score generator.
        # A confirmed multi-source consensus may corroborate an existing QV state;
        # any same-symbol/time conflict must force review and suppress an actionable alert.
        conflict_keys = {(str(r.get('symbol')), str(r.get('timestamp')))
                         for r in reconciliation.get('records', [])
                         if r.get('status') == 'CONFLICT'}
        consensus_keys = {(str(r.get('symbol')), str(r.get('timestamp')))
                          for r in reconciliation.get('records', [])
                          if r.get('status') == 'CONSENSUS'}
        if integrated is not None and not integrated.empty:
            integrated = integrated.copy()
            keys = list(zip(integrated.get('symbol', '' ).astype(str), integrated.get('timestamp', '' ).astype(str)))
            integrated['external_reconciliation_state'] = [
                'CONFLICT_REVIEW' if k in conflict_keys else ('CONSENSUS_CORROBORATED' if k in consensus_keys else 'NO_EXTERNAL_MATCH')
                for k in keys
            ]
            conflicted = integrated['external_reconciliation_state'].eq('CONFLICT_REVIEW')
            if conflicted.any():
                integrated.loc[conflicted, 'integration_action'] = 'WAIT_FOR_CONFIRMATION_EXTERNAL_CONFLICT'
                integrated.loc[conflicted, 'integration_state'] = 'EXTERNAL_CONFLICT_REVIEW'
            integrated.to_csv(self.out/'v42'/'QV-V42-INTEGRATED-EVIDENCE-EXTERNAL-RECONCILED.csv', index=False)

        if alerts is not None and not alerts.empty and conflict_keys:
            alerts = alerts.copy()
            alert_keys = list(zip(alerts.get('symbol', '' ).astype(str), alerts.get('timestamp', '' ).astype(str)))
            alerts['external_reconciliation_state'] = [
                'CONFLICT_REVIEW' if k in conflict_keys else ('CONSENSUS_CORROBORATED' if k in consensus_keys else 'NO_EXTERNAL_MATCH')
                for k in alert_keys
            ]
            alerts.loc[alerts['external_reconciliation_state'].eq('CONFLICT_REVIEW'), 'action_evidence'] = 'WAIT_FOR_CONFIRMATION_EXTERNAL_CONFLICT'
            alerts.to_csv(self.out/'v42'/'QV-V42-ALERT-QUEUE-EXTERNAL-RECONCILED.csv', index=False)

        gate={
            'engine':ENGINE,'version':VERSION,
            'v42_status':cert.get('status'),
            'external_reconciliation_status':reconciliation.get('status'),
            'external_conflicts':reconciliation.get('conflicts',0),
            'external_consensus':reconciliation.get('consensus',0),
            'external_health_ok':health.get('ok_count',0),
            'production_authorized':False,
            'fail_closed':True,
            'decision_rule':'external evidence may corroborate or flag conflict; it cannot independently authorize production',
        }
        gate['sha256']=hashlib.sha256(json.dumps(gate,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        (self.out/'QV-UNIFIED-ORCHESTRATOR-GATE.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2),encoding='utf-8')
        (self.out/'QV-GLOBAL-INTEGRATION-HEALTH.json').write_text(json.dumps(health,ensure_ascii=False,indent=2),encoding='utf-8')
        (self.out/'QV-EXTERNAL-RECONCILIATION.json').write_text(json.dumps(reconciliation,ensure_ascii=False,indent=2),encoding='utf-8')
        return gate, cert, integrated, alerts, health, reconciliation
