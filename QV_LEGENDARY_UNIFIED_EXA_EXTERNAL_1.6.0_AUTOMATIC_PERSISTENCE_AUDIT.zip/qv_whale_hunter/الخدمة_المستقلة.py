from __future__ import annotations
import os,time,json
from pathlib import Path
import pandas as pd
from .source_mesh import SourceMesh
from .source_registry import configured_sources
from .v42_pipeline import run as run_v42
from .secure_telegram_gateway import SecureTelegramGateway
from .حارس_البيانات import حارس_البيانات
from .مصفاة_التحليل import فصل_البيانات
from qv_exa_intelligence import QVExaIntelligenceEngine
from qv_external_integrations import QVExternalIntegrationBridge, reconcile, build_health
from qv_offline_session_archive import QVOfflineSessionArchive

class خدمة_كوانتوم_فيكتوري:
    """الخدمة المستقلة: تجمع البيانات المصرح بها، تتحقق منها، تحللها، ثم ترسل التنبيهات."""
    def __init__(self, interval=10.0, out_dir='تشغيل-كوانتوم-فيكتوري', recommendation_csv=None):
        self.interval=max(1.0,float(interval)); self.out=Path(out_dir); self.out.mkdir(parents=True,exist_ok=True)
        self.mesh=SourceMesh(configured_sources(),state_dir=self.out/'حالة-المصادر')
        self.telegram=SecureTelegramGateway(state_dir=self.out/'حالة-التنبيهات'); self.recommendation_csv=recommendation_csv
        self.آخر_بيانات={}
        self.الحارس=حارس_البيانات(مجلد=self.out/'حارس-البيانات')
        # Exa: external evidence only; never an OHLCV source and never opens production.
        self.exa=QVExaIntelligenceEngine()
        # External provider bridge: optional inputs only; never bypasses QV validation/release gates.
        self.external=QVExternalIntegrationBridge()
        self.offline=QVOfflineSessionArchive(
            inbox=os.getenv('QV_OFFLINE_INBOX','QV-OFFLINE-SESSIONS/inbox'),
            archive=os.getenv('QV_OFFLINE_ARCHIVE','QV-OFFLINE-SESSIONS/archive'),
            index=os.getenv('QV_OFFLINE_INDEX','QV-OFFLINE-SESSIONS/index'))

    def _exa_أدلة(self, df):
        """جمع أدلة Exa الاختيارية على مستوى الرموز مع فشل مغلق وعدم التأثير على بوابة الإنتاج."""
        if not self.exa.enabled:
            return {'status':'DISABLED','reason':'EXA_API_KEY غير مضبوط','production_authorized':False,'evidence_only':True}
        if df is None or df.empty or 'symbol' not in df.columns:
            return {'status':'SKIPPED_NO_SYMBOL_DATA','production_authorized':False,'evidence_only':True}
        max_symbols=max(1,int(os.getenv('QV_EXA_MAX_SYMBOLS','10')))
        symbols=[str(x) for x in df['symbol'].dropna().astype(str).drop_duplicates().head(max_symbols)]
        results=[]
        for symbol in symbols:
            results.append(self.exa.stage({'symbol':symbol}))
        payload={'status':'OK','symbols':len(symbols),'results':results,'production_authorized':False,'evidence_only':True}
        (self.out/'QV-EXA-EVIDENCE.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
        return payload

    def _external_بيانات(self, df):
        """Supplement internal source mesh with optional external providers.
        Every row remains source-tagged and production_authorized=False until
        the existing QV reconciliation/validation/release gates approve it.
        """
        if os.getenv("QV_EXTERNAL_MESH_ENABLED","0")!="1":
            return df, {"enabled":False,"providers":[],"production_authorized":False}
        symbols=[]
        if df is not None and not df.empty and 'symbol' in df.columns:
            symbols=[str(x) for x in df['symbol'].dropna().astype(str).drop_duplicates().head(
                max(1,int(os.getenv("QV_EXTERNAL_MAX_SYMBOLS","10"))))]
        frames=[]; reports=[]
        for symbol in symbols:
            report=self.external.collect(symbol)
            reports.append(report)
            for p in report.get("providers",[]):
                rows=p.get("rows") or []
                if rows:
                    frames.append(pd.DataFrame(rows))
        flat=[p for r in reports for p in r.get("providers",[])]
        reconciliation=reconcile(flat, tolerance_pct=float(os.getenv("QV_EXTERNAL_RECONCILIATION_TOLERANCE_PCT","0.5")))
        health=build_health(flat,reconciliation)
        (self.out/'QV-GLOBAL-INTEGRATION-HEALTH.json').write_text(json.dumps(health,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
        # External data is evidence by default. It is never injected into the
        # production analysis dataframe unless an explicit consensus mode is enabled.
        if os.getenv("QV_EXTERNAL_PROMOTE_CONSENSUS","0")!="1" or not frames:
            return df, {"enabled":True,"providers":reports,"rows_added":0,
                        "candidate_rows":sum(len(x) for x in frames),
                        "reconciliation":reconciliation,"health":health,
                        "production_authorized":False,"fail_closed":True}
        ext=pd.concat(frames,ignore_index=True)
        for c in ("timestamp",):
            ext[c]=pd.to_datetime(ext[c],errors="coerce")
        for c in ("price","open","high","low","close","volume"):
            if c in ext.columns: ext[c]=pd.to_numeric(ext[c],errors="coerce")
        ext=ext.dropna(subset=["symbol","timestamp","price","volume"])
        # Do not overwrite the internal/official mesh: append provenance-preserving rows.
        merged=pd.concat([df,ext],ignore_index=True) if df is not None else ext
        return merged, {"enabled":True,"providers":reports,"rows_added":len(ext),
                        "production_authorized":False,"fail_closed":True}

    def _توصيات(self):
        if self.recommendation_csv and Path(self.recommendation_csv).exists(): return pd.read_csv(self.recommendation_csv)
        return None

    def _دورة_ملفات_الجلسات(self):
        تقرير_الأرشيف, df=self.offline.ingest()
        تقرير_المصادر={'mode':'OFFLINE_FILE_FIRST','sources':[{'source':'OFFICIAL_DOWNLOADED_SESSION_FILES','ok':not bool(تقرير_الأرشيف.get('failures')),'rows':len(df)}],
                        'rows':len(df),'production_approved':False,'offline_archive':تقرير_الأرشيف}
        if df.empty:
            حالة={'الحالة':'لم توجد بيانات جدولية قابلة للتحليل داخل أرشيف الجلسات','عدد الصفوف':0,'عدد التنبيهات':0,'إرسال_التنبيهات':0,
                  'حالة_السوق':'غير ذي صلة — وضع الملفات التاريخية','اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر}
        else:
            # Historical session files are the decision-time dataset. No market-open
            # check and no live-freshness gate is applied in this mode.
            exa_أدلة=self._exa_أدلة(df)
            الشهادة,الدمج,التنبيهات=run_v42(df,recommendation_df=self._توصيات(),out_dir=self.out/'المحرك-التاريخي',top_n=50)
            حالة={'الحالة':'تمت دورة تحليل جلسات تاريخية من الأرشيف','عدد الصفوف':len(df),'عدد التنبيهات':len(التنبيهات),'إرسال_التنبيهات':0,
                  'حالة_السوق':'غير ذي صلة — التحليل بعد الجلسة','اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر,'Exa_الأدلة':exa_أدلة,
                  'وضع_التشغيل':'OFFLINE_FILE_FIRST','live_data_claim':False}
        with (self.out/'سجل_الخدمة.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(حالة,ensure_ascii=False,default=str)+'\n')
        return حالة

    def دورة_واحدة(self):
        if os.getenv('QV_OFFLINE_MODE','0')=='1':
            return self._دورة_ملفات_الجلسات()
        df, تقرير_المصادر=self.mesh.collect()
        df, تقرير_الخارج=self._external_بيانات(df)
        تقرير_المصادر['external_integration']=تقرير_الخارج
        for مصدر in تقرير_المصادر.get('sources',[]):
            الاسم=مصدر.get('source','غير معروف')
            self.الحارس.تسجيل_المصدر(الاسم,'بيانات السوق',0)
            (self.الحارس.تسجيل_نجاح if مصدر.get('ok') else self.الحارس.تسجيل_فشل)(الاسم)
        حالة_السوق=self.الحارس.حالة_الجلسة()
        حداثة=self.الحارس.فحص_الحداثة(df)
        exa_أدلة=self._exa_أدلة(df)
        self.الحارس.تقرير(حالة_السوق,حداثة)
        if not حالة_السوق['مفتوحة'] and df.empty:
            حالة={'الحالة':'لا توجد بيانات موثوقة حالياً','عدد الصفوف':0,'إرسال_التنبيهات':0,'حالة_السوق':حالة_السوق['السبب'],'اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر,'Exa_الأدلة':exa_أدلة}
        elif not حالة_السوق['مفتوحة']:
            حالة={'الحالة':'السوق مغلق ولم يتم تشغيل تحليل لحظي جديد','عدد الصفوف':len(df),'عدد التنبيهات':0,'إرسال_التنبيهات':0,'حالة_السوق':حالة_السوق['السبب'],'اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر,'Exa_الأدلة':exa_أدلة}
        elif not حداثة['سليم']:
            حالة={'الحالة':'تم حجب البيانات المتقادمة','عدد الصفوف':len(df),'عدد التنبيهات':0,'إرسال_التنبيهات':0,'حالة_السوق':حالة_السوق['السبب'],'اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر,'Exa_الأدلة':exa_أدلة}
        else:
            الشهادة,الدمج,التنبيهات=run_v42(df,recommendation_df=self._توصيات(),out_dir=self.out/'المحرك',top_n=50)
            مرسل=0
            for _,تنبيه in التنبيهات.iterrows():
                if not bool(الشهادة.get('production_approved', False)):
                    continue
                نتيجة=self.telegram.send(str(تنبيه.message),alert_id=str(تنبيه.alert_id))
                if نتيجة.get('sent'): مرسل+=1
            حالة={'الحالة':'تمت دورة التحليل','عدد الصفوف':len(df),'عدد التنبيهات':len(التنبيهات),'إرسال_التنبيهات':مرسل,'حالة_السوق':'بيانات مستلمة','اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر,'Exa_الأدلة':exa_أدلة}
        with (self.out/'سجل_الخدمة.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(حالة,ensure_ascii=False,default=str)+'\n')
        return حالة

    def تشغيل(self, مدة=None):
        البداية=time.monotonic(); دورات=0
        while مدة is None or time.monotonic()-البداية<مدة:
            self.دورة_واحدة(); دورات+=1; time.sleep(self.interval)
        return {'الحالة':'توقفت الخدمة','عدد الدورات':دورات,'إعداد التنبيهات':self.telegram.configured,'اعتماد_الإنتاج':False}
