from __future__ import annotations
import hashlib, json, os
from pathlib import Path
from qv_unified_signal_orchestrator import QVUnifiedSignalOrchestrator
from .secure_telegram_gateway import SecureTelegramGateway
ENGINE='QV-SECURE-INTEGRATED-WHALE-RECOMMENDATION'; VERSION='4.3.0'

def security_manifest():
    return {
      'engine':ENGINE,'version':VERSION,'transport':'OUTBOUND_TELEGRAM_ONLY',
      'chatgpt_required_at_runtime':False,
      'controls':['environment_secrets','hmac_payload_signing','chat_id_allowlist','idempotent_alert_ids','rate_limit','retry_backoff','secret_redaction','atomic_state','least_exposure','no_inbound_webhook_required'],
      'production_approved':False,'evidence_only':True
    }

def run(intraday_df,recommendation_df=None,historical_intraday_df=None,out_dir='QV-V43-SECURE-RUN',top_n=20,send_telegram=False,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    orch=QVUnifiedSignalOrchestrator(out/'orchestrator')
    gate,cert,integrated,alerts,health,reconciliation=orch.run(intraday_df,recommendation_df,historical_intraday_df,external_report=kwargs.pop('external_report',None),top_n=top_n,**kwargs)
    manifest=security_manifest(); manifest['orchestrator_gate']=gate; manifest['external_health']=health; manifest['external_reconciliation']=reconciliation; manifest['telegram_send_requested']=bool(send_telegram)
    gateway=SecureTelegramGateway(state_dir=out/'telegram_state')
    sent=[]
    if send_telegram:
        for _,r in alerts.iterrows():
            sent.append(gateway.send(r['message'],alert_id=r['alert_id']))
    manifest['telegram_configured']=gateway.configured
    manifest['sent_count']=sum(bool(x.get('sent')) for x in sent)
    manifest['certificate_hash']=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    (out/'QV-V43-SECURITY-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-V43-TELEGRAM-DELIVERY.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in sent),encoding='utf-8')
    return manifest,integrated,alerts,sent
