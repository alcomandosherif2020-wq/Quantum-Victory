from qv_external_integrations import reconcile, build_health

def test_conflict_is_fail_closed():
    r=reconcile([{'provider':'A','enabled':True,'ok':True,'rows':[{'symbol':'COMI','timestamp':'t1','price':100}]},
                 {'provider':'B','enabled':True,'ok':True,'rows':[{'symbol':'COMI','timestamp':'t1','price':102}] }], tolerance_pct=.5)
    assert r['conflicts']==1
    assert r['production_authorized'] is False
    assert r['fail_closed'] is True

def test_consensus_health():
    r=reconcile([{'provider':'A','rows':[{'symbol':'COMI','timestamp':'t1','price':100}]},
                 {'provider':'B','rows':[{'symbol':'COMI','timestamp':'t1','price':100.2}]}])
    assert r['consensus']==1
    h=build_health([],r)
    assert h['production_authorized'] is False
