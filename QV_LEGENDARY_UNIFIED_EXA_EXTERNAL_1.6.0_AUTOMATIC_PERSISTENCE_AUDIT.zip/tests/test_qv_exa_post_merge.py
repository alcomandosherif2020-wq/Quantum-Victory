import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from qv_exa_intelligence import QVExaIntelligenceEngine
from qv_whale_hunter.الخدمة_المستقلة import خدمة_كوانتوم_فيكتوري

def test_exa_package_and_fail_closed():
    e=QVExaIntelligenceEngine()
    assert e.VERSION == '1.0.0'
    old=os.environ.pop('EXA_API_KEY',None)
    try:
        assert e.enabled is False
        out=e.stage({'symbol':'COMI'})
        assert out['exa']['status']=='DISABLED'
        assert out['exa']['production_authorized'] is False
    finally:
        if old is not None: os.environ['EXA_API_KEY']=old

def test_real_service_has_exa_layer():
    with tempfile.TemporaryDirectory() as d:
        svc=خدمة_كوانتوم_فيكتوري(interval=1,out_dir=d)
        assert hasattr(svc,'exa')
        assert svc.exa.VERSION=='1.0.0'
        assert svc.exa.enabled is False

def test_service_cycle_propagates_exa_disabled_state(monkeypatch, tmp_path):
    import pandas as pd
    svc=خدمة_كوانتوم_فيكتوري(interval=1,out_dir=str(tmp_path))
    svc.mesh.collect=lambda: (pd.DataFrame(columns=['symbol','timestamp','price','volume']), {'sources':[]})
    svc.الحارس.حالة_الجلسة=lambda: {'مفتوحة':False,'السبب':'اختبار'}
    svc.الحارس.فحص_الحداثة=lambda df: {'سليم':True}
    svc.الحارس.تقرير=lambda *args, **kwargs: None
    result=svc.دورة_واحدة()
    assert result['Exa_الأدلة']['status']=='DISABLED'
    assert result['اعتماد_الإنتاج'] is False
