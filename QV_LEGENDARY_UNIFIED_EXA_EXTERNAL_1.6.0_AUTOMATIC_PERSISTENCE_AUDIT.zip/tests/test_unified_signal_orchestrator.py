import pandas as pd
from qv_unified_signal_orchestrator import QVUnifiedSignalOrchestrator

def test_orchestrator_is_fail_closed_and_reconciles(tmp_path):
    df=pd.DataFrame([{'symbol':'COMI','timestamp':'2026-09-10 10:00:00','price':100.0,'volume':1000}])
    ext={'providers':[
        {'provider':'A','enabled':True,'ok':True,'fetched_at':'x','latency_ms':1,'rows':[{'symbol':'COMI','timestamp':'2026-09-10 10:00:00','price':100}]},
        {'provider':'B','enabled':True,'ok':True,'fetched_at':'x','latency_ms':2,'rows':[{'symbol':'COMI','timestamp':'2026-09-10 10:00:00','price':100.1}]},
    ]}
    gate,cert,integrated,alerts,health,recon=QVUnifiedSignalOrchestrator(tmp_path).run(df,external_report=ext)
    assert gate['external_consensus']==1
    assert gate['production_authorized'] is False
    assert gate['fail_closed'] is True
    assert integrated.iloc[0]['external_reconciliation_state']=='CONSENSUS_CORROBORATED'

def test_external_conflict_forces_review(tmp_path):
    df=pd.DataFrame([{'symbol':'COMI','timestamp':'2026-09-10 10:00:00','price':100.0,'volume':1000}])
    ext={'providers':[
        {'provider':'A','enabled':True,'ok':True,'rows':[{'symbol':'COMI','timestamp':'2026-09-10 10:00:00','price':100}]},
        {'provider':'B','enabled':True,'ok':True,'rows':[{'symbol':'COMI','timestamp':'2026-09-10 10:00:00','price':102}]},
    ]}
    gate,cert,integrated,alerts,health,recon=QVUnifiedSignalOrchestrator(tmp_path).run(df,external_report=ext)
    assert gate['external_conflicts']==1
    assert integrated.iloc[0]['integration_state']=='EXTERNAL_CONFLICT_REVIEW'
    assert integrated.iloc[0]['integration_action']=='WAIT_FOR_CONFIRMATION_EXTERNAL_CONFLICT'
    assert gate['production_authorized'] is False
