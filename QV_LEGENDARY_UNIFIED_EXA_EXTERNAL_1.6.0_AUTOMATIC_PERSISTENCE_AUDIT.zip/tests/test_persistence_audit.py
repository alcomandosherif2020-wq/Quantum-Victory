import json
from pathlib import Path
import pandas as pd
from qv_offline_session_archive import QVOfflineSessionArchive
from qv_persistence_audit import QVPersistenceAudit


def test_persistence_audit_passes_integrity_and_reports_runtime_only(tmp_path, monkeypatch):
    monkeypatch.delenv("QV_DURABLE_BACKEND", raising=False)
    root = tmp_path / "QV-OFFLINE-SESSIONS"
    inbox = root / "inbox"
    inbox.mkdir(parents=True)
    pd.DataFrame([{
        "Ticker": "COMI", "Date": "2026-09-10", "Open": 100,
        "High": 105, "Low": 99, "Close": 104, "Volume": 1000,
    }]).to_csv(inbox / "official_session.csv", index=False)
    archive = QVOfflineSessionArchive(inbox, root / "archive", root / "index")
    report, _ = archive.ingest()
    (root / "analysis_runs" / "R1").mkdir(parents=True)
    (root / "analysis_runs" / "R1" / "QV-SESSION-CYCLE-MANIFEST.json").write_text(
        json.dumps({"status": "PASS", "sha256": "x", "analysis_executed": True}), encoding="utf-8"
    )
    (root / "analysis_runs" / "R1" / "QV-ARCHIVE-REPORT.json").write_text("{}", encoding="utf-8")
    (root / "analysis_runs" / "R1" / "QV-HISTORICAL-CONTEXT-MANIFEST.json").write_text("{}", encoding="utf-8")
    (root / "analysis_runs" / "R1" / "QV-EXTERNAL-EVIDENCE.json").write_text("{}", encoding="utf-8")
    (root / "analysis_runs" / "R1" / "QV-EXA-EVIDENCE.json").write_text("{}", encoding="utf-8")
    audit = QVPersistenceAudit(root).run()
    assert audit["status"] == "PASS"
    assert audit["durability_status"] == "LOCAL_RUNTIME_ONLY"
    assert "DURABLE_BACKEND_NOT_CONFIGURED" in audit["warnings"]
    assert (root / "index" / "QV-AUTOMATIC-PERSISTENCE-AUDIT.json").exists()


def test_persistence_audit_blocks_tampered_archive(tmp_path):
    root = tmp_path / "QV-OFFLINE-SESSIONS"
    inbox = root / "inbox"
    inbox.mkdir(parents=True)
    p = inbox / "session.csv"
    p.write_text("Ticker,Date,Close\nCOMI,2026-09-10,100\n", encoding="utf-8")
    QVOfflineSessionArchive(inbox, root / "archive", root / "index").ingest()
    archived = next((root / "archive").rglob("*.csv"))
    archived.write_text(archived.read_text(encoding="utf-8") + "tamper\n", encoding="utf-8")
    audit = QVPersistenceAudit(root).run()
    assert audit["status"] == "BLOCKED"
    assert "ARCHIVE_SHA256_MISMATCH" in audit["blockers"]
