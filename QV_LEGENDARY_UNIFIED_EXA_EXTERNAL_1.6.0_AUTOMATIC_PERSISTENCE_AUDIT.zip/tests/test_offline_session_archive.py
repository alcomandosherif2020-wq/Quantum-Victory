from pathlib import Path
import pandas as pd
from qv_offline_session_archive import QVOfflineSessionArchive

def test_offline_ingestion_archives_and_normalizes(tmp_path):
    inbox=tmp_path/'inbox'; inbox.mkdir()
    pd.DataFrame([{'Ticker':'COMI.CA','Date':'2026-09-10','Open':100,'High':105,'Low':99,'Close':104,'Volume':1000}]).to_csv(inbox/'session.csv',index=False)
    e=QVOfflineSessionArchive(inbox=inbox,archive=tmp_path/'archive',index=tmp_path/'index')
    report,df=e.ingest()
    assert report['mode']=='OFFLINE_FILE_FIRST'
    assert report['files_discovered']==1
    assert len(df)==1 and df.iloc[0]['symbol']=='COMI.CA'
    assert df.iloc[0]['provenance']=='OFFICIAL_DOWNLOADED_SESSION_FILE'
    assert report['production_authorized'] is False and report['live_data_claim'] is False

def test_offline_pdf_is_archived_without_live_claim(tmp_path):
    inbox=tmp_path/'inbox'; inbox.mkdir(); (inbox/'session.pdf').write_bytes(b'%PDF-test')
    e=QVOfflineSessionArchive(inbox=inbox,archive=tmp_path/'archive',index=tmp_path/'index')
    report,df=e.ingest()
    assert report['files_discovered']==1 and df.empty
    assert report['fail_closed'] is True
