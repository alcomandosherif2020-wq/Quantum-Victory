import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from qv_external_integrations import QVExternalIntegrationBridge

def test_external_bridge_is_fail_closed_without_keys(monkeypatch):
    for k in ["QV_TWELVE_DATA_KEY","QV_EODHD_KEY","QV_ALPHA_VANTAGE_KEY","QV_FMP_KEY","QV_FMP_URL"]:
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("QV_YFINANCE_ENABLED","0")
    b=QVExternalIntegrationBridge()
    out=b.collect("COMI")
    assert out["production_authorized"] is False
    assert out["fail_closed"] is True
    assert out["enabled_count"] == 0

def test_external_bridge_normalizes_twelve_data_shape():
    b=QVExternalIntegrationBridge()
    rows=b._normalize({"values":[{"datetime":"2026-09-10 10:00:00","open":"10","high":"11","low":"9","close":"10.5","volume":"1000"}]},"TWELVE_DATA","COMI")
    assert len(rows)==1
    assert rows[0]["price"]==10.5
    assert rows[0]["volume"]==1000
    assert rows[0]["source"]=="TWELVE_DATA"
