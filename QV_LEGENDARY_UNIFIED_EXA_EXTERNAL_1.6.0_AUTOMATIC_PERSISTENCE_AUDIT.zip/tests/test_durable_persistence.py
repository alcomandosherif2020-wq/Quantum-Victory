from pathlib import Path
from qv_durable_persistence import QVGithubDurablePersistence


def test_durable_backend_is_fail_closed_when_not_configured(monkeypatch, tmp_path):
    monkeypatch.delenv("QV_GITHUB_TOKEN", raising=False)
    monkeypatch.delenv("QV_GITHUB_REPOSITORY", raising=False)
    d = QVGithubDurablePersistence()
    assert d.configured is False
    r = d.put_file(tmp_path / "missing.txt", "x.txt", "test")
    assert r["status"] == "NOT_CONFIGURED"
    assert r["production_authorized"] is False
