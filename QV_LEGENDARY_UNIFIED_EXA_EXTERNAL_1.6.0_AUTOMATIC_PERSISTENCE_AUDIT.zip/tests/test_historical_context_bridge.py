import pandas as pd
from qv_historical_context_bridge import QVHistoricalContextBridge


def _rows():
    return pd.DataFrame([
        {"Ticker":"COMI.CA","Date":"2026-09-07","Open":100,"High":102,"Low":99,"Close":101,"Volume":1000},
        {"Ticker":"COMI.CA","Date":"2026-09-08","Open":101,"High":104,"Low":100,"Close":103,"Volume":1500},
        {"Ticker":"COMI.CA","Date":"2026-09-09","Open":103,"High":105,"Low":102,"Close":104,"Volume":2000},
        {"Ticker":"COMI.CA","Date":"2026-09-10","Open":104,"High":107,"Low":103,"Close":106,"Volume":3000},
        {"Ticker":"SWDY.CA","Date":"2026-09-09","Open":50,"High":52,"Low":49,"Close":51,"Volume":900},
        {"Ticker":"SWDY.CA","Date":"2026-09-10","Open":51,"High":51,"Low":49,"Close":49.5,"Volume":1800},
    ])


def test_latest_session_is_current_and_prior_sessions_are_strictly_earlier():
    d = _rows()
    report, current, hist, all_sessions = QVHistoricalContextBridge(max_sessions=20).build(d)
    assert report["current_session"] == "2026-09-10"
    assert report["prior_completed_sessions"] == ["2026-09-07", "2026-09-08", "2026-09-09"]
    assert not (hist["session_date"].astype(str) >= "2026-09-10").any()
    assert set(current["session_date"].astype(str)) == {"2026-09-10"}
    assert int(current.loc[current.symbol.eq("COMI.CA"), "prior_sessions_available"].iloc[0]) == 3


def test_no_synthetic_rows_and_no_live_claim():
    d = pd.DataFrame([{"Ticker":"ABUK.CA","Date":"2026-09-10","Open":10,"High":11,"Low":9,"Close":10.5,"Volume":100}])
    report, current, hist, _ = QVHistoricalContextBridge().build(d)
    assert report["fabricated_rows"] == 0
    assert report["synthetic_sessions"] == 0
    assert report["live_data_claim"] is False
    assert report["production_authorized"] is False
    assert hist.empty
