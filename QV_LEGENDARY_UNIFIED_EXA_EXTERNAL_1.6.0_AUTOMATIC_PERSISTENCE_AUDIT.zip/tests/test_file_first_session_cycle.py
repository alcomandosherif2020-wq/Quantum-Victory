import pandas as pd
from qv_file_first_session_cycle import QVFileFirstSessionCycle

def test_file_first_cycle_runs_from_archived_session(tmp_path, monkeypatch):
    root=tmp_path/'QV-OFFLINE-SESSIONS'
    inbox=root/'inbox'; inbox.mkdir(parents=True)
    pd.DataFrame([
        {'Ticker':'COMI','Date':'2026-09-08','Open':100,'High':105,'Low':99,'Close':104,'Volume':1000},
        {'Ticker':'COMI','Date':'2026-09-09','Open':104,'High':106,'Low':103,'Close':105,'Volume':1200},
        {'Ticker':'COMI','Date':'2026-09-10','Open':105,'High':108,'Low':104,'Close':107,'Volume':1500},
    ]).to_csv(inbox/'official_session.csv',index=False)
    monkeypatch.setenv('QV_EXTERNAL_MESH_ENABLED','0')
    monkeypatch.delenv('EXA_API_KEY', raising=False)
    c=QVFileFirstSessionCycle(root=root)
    manifest, report, data, out=c.run('TEST-RUN')
    assert manifest['mode']=='OFFLINE_FILE_FIRST'
    assert manifest['analysis_executed'] is True
    assert manifest['production_authorized'] is False
    assert manifest['current_session'] == '2026-09-10'
    assert manifest['historical_sessions'] == ['2026-09-08', '2026-09-09']
    assert manifest['historical_rows'] >= 2
    assert out.joinpath('QV-HISTORICAL-CONTEXT-MANIFEST.json').exists()
    assert len(data)==3
    assert out.joinpath('QV-SESSION-CYCLE-MANIFEST.json').exists()
    assert out.joinpath('unified_orchestrator/QV-UNIFIED-ORCHESTRATOR-GATE.json').exists()
    assert (root/'brain'/'QV-SESSION-MEMORY.jsonl').exists()
