# QV Automatic Persistence Audit 1.6

The persistence chain is audited automatically after archive/reload and after every FILE_FIRST session cycle.

Checks include:
- original archive files and SHA-256 fingerprints
- normalized evidence/index presence
- analysis-run manifests and required artifacts
- append-only brain session ledger syntax and duplicate run IDs
- archive tamper detection
- explicit durability state

## Durability rule
`LOCAL_RUNTIME_ONLY` is reported when no durable backend is configured. This is intentional: a Streamlit Community Cloud local filesystem must not be represented as permanent storage.

An optional GitHub Contents backend can mirror archive/index/brain/analysis-run artifacts when `QV_GITHUB_TOKEN` and `QV_GITHUB_REPOSITORY` are supplied through deployment secrets. Credentials are never stored in source code. Failed durable writes remain fail-closed and are reported separately.
