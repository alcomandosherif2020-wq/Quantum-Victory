# QV File-First Session Cycle 1.4

رفع ملفات جلسة EGX الرسمية لا يقتصر على الأرشفة: يمكن تشغيل دورة كوانتوم فيكتوري الموحدة من زر واحد.

1. حفظ الأصل وبصمة SHA-256.
2. التطبيع إلى Historical Evidence.
3. تشغيل QV Unified Signal Orchestrator.
4. تشغيل V42/V41/V40 وسلسلة Whale/Flow evidence المتصلة به.
5. مصالحة المصادر الخارجية عند تفعيلها.
6. حفظ بوابة الأوركسترا، صحة المصادر، المصالحة، الأدلة، والنتائج.
7. تسجيل ملخص الجلسة في QV-SESSION-MEMORY.jsonl.

## الحوكمة
- `OFFLINE_FILE_FIRST`
- `live_data_claim=False`
- `production_authorized=False`
- `fail_closed=True`
- لا بيانات اصطناعية.
- المصادر الخارجية لا تستبدل الملف الرسمي ولا تفتح بوابة الإنتاج.
- Exa دليل ويب فقط وليس مصدر OHLCV.
