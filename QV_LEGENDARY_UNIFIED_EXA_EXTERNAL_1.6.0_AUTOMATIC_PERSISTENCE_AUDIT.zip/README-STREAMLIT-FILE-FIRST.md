# كوانتوم فيكتوري — Streamlit FILE_FIRST

هذه الواجهة مخصصة للمرحلة التاريخية بعد إغلاق جلسة التداول.

المسار:

`ملف جلسة رسمي → inbox → SHA-256 → archive → index → normalization → Historical Evidence`

لا تعتمد الواجهة على اتصال حي بالسوق ولا تدعي أن الملفات المؤرشفة بيانات حية.

## التشغيل

```bash
streamlit run streamlit_app.py
```

## Community Cloud

اجعل `streamlit_app.py` هو Entrypoint، واحتفظ بـ `requirements.txt` في جذر المستودع أو بجانب ملف الدخول.
