# -*- coding: utf-8 -*-
"""Optional durable persistence adapter for Quantum Victory.

The FILE_FIRST engine remains fully functional without this adapter. When a
GitHub Contents API backend is explicitly configured through environment
variables, selected evidence artifacts can be mirrored automatically without
putting credentials in source code.
"""
from __future__ import annotations

import base64
import os
from pathlib import Path
from typing import Iterable

import requests

ENGINE = "QV-DURABLE-PERSISTENCE-GITHUB"
VERSION = "1.0.0"


class QVGithubDurablePersistence:
    def __init__(self, timeout=20):
        self.token = os.getenv("QV_GITHUB_TOKEN", "").strip()
        self.repo = os.getenv("QV_GITHUB_REPOSITORY", "").strip()
        self.branch = os.getenv("QV_GITHUB_BRANCH", "main").strip() or "main"
        self.prefix = os.getenv("QV_GITHUB_ARCHIVE_PREFIX", "qv-runtime-archive").strip().strip("/")
        self.base = os.getenv("QV_GITHUB_API", "https://api.github.com").rstrip("/")
        self.timeout = float(timeout)

    @property
    def configured(self):
        return bool(self.token and self.repo and "/" in self.repo)

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _get_sha(self, path: str):
        r = requests.get(f"{self.base}/repos/{self.repo}/contents/{path}", headers=self._headers(), params={"ref": self.branch}, timeout=self.timeout)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json().get("sha")

    def put_file(self, local_path: str | Path, remote_path: str, message: str):
        if not self.configured:
            return {"status": "NOT_CONFIGURED", "production_authorized": False}
        p = Path(local_path)
        content = base64.b64encode(p.read_bytes()).decode("ascii")
        payload = {"message": message, "content": content, "branch": self.branch}
        sha = self._get_sha(remote_path)
        if sha:
            payload["sha"] = sha
        r = requests.put(f"{self.base}/repos/{self.repo}/contents/{remote_path}", headers=self._headers(), json=payload, timeout=self.timeout)
        if r.status_code >= 400:
            return {"status": "FAILED", "http_status": r.status_code, "detail": r.text[:240], "production_authorized": False}
        data = r.json()
        return {"status": "UPLOADED", "remote_path": remote_path, "commit_sha": data.get("commit", {}).get("sha"), "production_authorized": False}

    def mirror_paths(self, root: str | Path, paths: Iterable[str | Path], remote_prefix: str | None = None):
        root = Path(root)
        prefix = (remote_prefix or self.prefix).strip("/")
        results = []
        for item in paths:
            p = Path(item)
            if not p.is_absolute():
                p = root / p
            if not p.exists() or not p.is_file():
                results.append({"status": "MISSING", "path": str(p), "production_authorized": False})
                continue
            try:
                rel = p.relative_to(root).as_posix()
            except ValueError:
                rel = p.name
            results.append(self.put_file(p, f"{prefix}/{rel}", f"QV automatic archive: {rel}"))
        return results
