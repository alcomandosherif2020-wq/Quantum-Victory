# -*- coding: utf-8 -*-
"""QV automatic persistence and integrity audit.

Audits the FILE_FIRST storage chain without treating local Streamlit storage as
permanent storage.  It verifies archive fingerprints, manifests, brain ledger,
analysis-run artifacts, duplicate evidence, and durability configuration.
"""
from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

ENGINE = "QV-AUTOMATIC-PERSISTENCE-AUDIT"
VERSION = "1.0.0"


def _sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_json_atomic(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    tmp.replace(path)


class QVPersistenceAudit:
    def __init__(self, root="QV-OFFLINE-SESSIONS"):
        self.root = Path(root)
        self.inbox = self.root / "inbox"
        self.archive = self.root / "archive"
        self.index = self.root / "index"
        self.runs = self.root / "analysis_runs"
        self.brain = self.root / "brain"
        for p in (self.inbox, self.archive, self.index, self.runs, self.brain):
            p.mkdir(parents=True, exist_ok=True)

    def _audit_archive(self):
        files = []
        mismatches = []
        for p in sorted(self.archive.rglob("*")):
            if not p.is_file():
                continue
            digest = _sha_file(p)
            files.append({"path": str(p), "size": p.stat().st_size, "sha256": digest})
            marker = "__sha256_"
            if marker in p.stem:
                expected = p.stem.split(marker, 1)[1]
                if expected and not digest.startswith(expected):
                    mismatches.append({"path": str(p), "expected_prefix": expected, "actual_sha256": digest})
        return files, mismatches

    def _audit_runs(self):
        runs = []
        missing = []
        for d in sorted(self.runs.iterdir() if self.runs.exists() else []):
            if not d.is_dir():
                continue
            m = d / "QV-SESSION-CYCLE-MANIFEST.json"
            row = {"run_id": d.name, "manifest": str(m), "manifest_present": m.exists()}
            if m.exists():
                try:
                    obj = json.loads(m.read_text(encoding="utf-8"))
                    row.update({"status": obj.get("status"), "sha256": obj.get("sha256"), "analysis_executed": obj.get("analysis_executed")})
                    required = [
                        "QV-ARCHIVE-REPORT.json",
                        "QV-HISTORICAL-CONTEXT-MANIFEST.json",
                        "QV-EXTERNAL-EVIDENCE.json",
                        "QV-EXA-EVIDENCE.json",
                    ]
                    row["required_artifacts_present"] = all((d / x).exists() for x in required)
                except Exception as exc:
                    row["manifest_error"] = type(exc).__name__
            else:
                missing.append(d.name)
            runs.append(row)
        return runs, missing

    def _audit_brain(self):
        p = self.brain / "QV-SESSION-MEMORY.jsonl"
        if not p.exists():
            return {"present": False, "rows": 0, "malformed_rows": 0, "duplicate_run_ids": 0}
        rows = []
        malformed = 0
        for line in p.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                malformed += 1
        ids = [str(x.get("run_id")) for x in rows if x.get("run_id") is not None]
        dup = len(ids) - len(set(ids))
        return {"present": True, "rows": len(rows), "malformed_rows": malformed, "duplicate_run_ids": dup}

    def run(self, write_report=True):
        archive_files, archive_mismatches = self._audit_archive()
        runs, missing_runs = self._audit_runs()
        brain = self._audit_brain()

        index_files = sorted(p.name for p in self.index.glob("*") if p.is_file())
        durable_backend = os.getenv("QV_DURABLE_BACKEND", "LOCAL_ONLY").strip().upper() or "LOCAL_ONLY"
        streamlit_env = bool(os.getenv("STREAMLIT_SERVER_HEADLESS")) or bool(os.getenv("STREAMLIT_SHARING_MODE"))
        # Streamlit Community Cloud's local filesystem must not be represented as a
        # durable cross-restart archive. Durable status is only ACTIVE when an
        # explicitly configured backend is present.
        durability = "ACTIVE" if durable_backend not in {"", "LOCAL_ONLY", "NONE"} else "LOCAL_RUNTIME_ONLY"

        blockers = []
        warnings = []
        if archive_mismatches:
            blockers.append("ARCHIVE_SHA256_MISMATCH")
        if missing_runs:
            blockers.append("RUN_MANIFEST_MISSING")
        if brain.get("malformed_rows", 0):
            blockers.append("BRAIN_LEDGER_MALFORMED")
        if brain.get("duplicate_run_ids", 0):
            warnings.append("BRAIN_DUPLICATE_RUN_IDS")
        if not (self.index / "QV-OFFLINE-SESSION-INDEX.json").exists():
            warnings.append("SESSION_INDEX_NOT_PRESENT")
        if durability == "LOCAL_RUNTIME_ONLY":
            warnings.append("DURABLE_BACKEND_NOT_CONFIGURED")

        status = "PASS" if not blockers else "BLOCKED"
        report = {
            "engine": ENGINE,
            "version": VERSION,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "status": status,
            "root": str(self.root),
            "archive_files": len(archive_files),
            "archive_sha256_mismatches": archive_mismatches,
            "analysis_runs": runs,
            "missing_run_manifests": missing_runs,
            "brain": brain,
            "index_files": index_files,
            "durable_backend": durable_backend,
            "durability_status": durability,
            "streamlit_environment_detected": streamlit_env,
            "blockers": blockers,
            "warnings": warnings,
            "production_authorized": False,
            "live_data_claim": False,
            "fail_closed": True,
            "automatic_persistence_scope": [
                "original_session_archive",
                "sha256_fingerprints",
                "normalized_evidence",
                "analysis_run_manifests",
                "historical_context",
                "brain_session_memory",
                "integrity_audit",
            ],
        }
        report["audit_sha256"] = hashlib.sha256(
            json.dumps(report, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        if write_report:
            _write_json_atomic(self.index / "QV-AUTOMATIC-PERSISTENCE-AUDIT.json", report)
        return report
