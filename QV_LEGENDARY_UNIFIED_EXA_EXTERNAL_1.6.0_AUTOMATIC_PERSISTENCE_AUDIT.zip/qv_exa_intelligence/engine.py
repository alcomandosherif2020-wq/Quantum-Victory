# -*- coding: utf-8 -*-
"""QV Exa Intelligence Engine.

Exa is treated as an external evidence-discovery layer only. It never becomes
an OHLCV/price source, never manufactures market data, and never opens the
QV production gate by itself.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from typing import Any, Callable
from urllib import request, error


@dataclass(frozen=True)
class ExaConfig:
    api_key: str | None = None
    endpoint: str = "https://api.exa.ai/search"
    num_results: int = 8
    timeout_seconds: int = 20
    search_type: str = "auto"
    max_highlight_chars: int = 1200

    @classmethod
    def from_env(cls) -> "ExaConfig":
        return cls(
            api_key=os.getenv("EXA_API_KEY"),
            endpoint=os.getenv("EXA_API_URL", cls.endpoint),
            num_results=max(1, min(int(os.getenv("QV_EXA_NUM_RESULTS", "8")), 50)),
            timeout_seconds=max(5, int(os.getenv("QV_EXA_TIMEOUT", "20"))),
        )


class QVExaIntelligenceEngine:
    """Search-and-normalize layer for news/events/source discovery."""

    VERSION = "1.0.0"
    SOURCE_NAME = "Exa Web Intelligence"

    def __init__(self, config: ExaConfig | None = None, transport: Callable[..., Any] | None = None):
        self.config = config or ExaConfig.from_env()
        self._transport = transport or self._http_search

    @property
    def enabled(self) -> bool:
        return bool(self.config.api_key)

    def _http_search(self, payload: dict) -> dict:
        if not self.config.api_key:
            raise RuntimeError("EXA_API_KEY غير مضبوط")
        body = json.dumps(payload).encode("utf-8")
        req = request.Request(
            self.config.endpoint,
            data=body,
            headers={
                "x-api-key": self.config.api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=self.config.timeout_seconds) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:1000]
            raise RuntimeError(f"Exa HTTP {exc.code}: {detail}") from exc
        except error.URLError as exc:
            raise RuntimeError(f"Exa network error: {exc.reason}") from exc

    @staticmethod
    def _query(symbol: str, company_name: str | None = None, decision_time: str | None = None) -> str:
        subject = f"{symbol} {company_name}" if company_name else symbol
        q = (
            f"{subject} Egypt EGX latest material news disclosure earnings contract expansion "
            "regulatory event affecting the company or stock"
        )
        if decision_time:
            q += f" published before {decision_time}"
        return q

    def search_symbol_events(
        self,
        symbol: str,
        company_name: str | None = None,
        decision_time: str | None = None,
        domains: list[str] | None = None,
        start_published_date: str | None = None,
    ) -> dict:
        if not symbol:
            raise ValueError("رمز السهم مطلوب")
        query = self._query(symbol, company_name, decision_time)
        payload: dict[str, Any] = {
            "query": query,
            "type": self.config.search_type,
            "numResults": self.config.num_results,
            "contents": {
                "highlights": {"maxCharacters": self.config.max_highlight_chars},
            },
        }
        if domains:
            payload["includeDomains"] = domains
        if start_published_date:
            payload["startPublishedDate"] = start_published_date

        fetched_at = datetime.now(timezone.utc).isoformat()
        raw = self._transport(payload)
        results = raw.get("results", []) if isinstance(raw, dict) else []
        normalized = [self._normalize_result(r, symbol, decision_time) for r in results]
        normalized = [r for r in normalized if r["url"]]
        digest = hashlib.sha256(json.dumps(normalized, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
        return {
            "engine": self.SOURCE_NAME,
            "engine_version": self.VERSION,
            "symbol": symbol,
            "company_name": company_name,
            "query": query,
            "fetched_at": fetched_at,
            "decision_time": decision_time,
            "result_count": len(normalized),
            "results": normalized,
            "evidence_sha256": digest,
            "production_authorized": False,
            "is_market_price_source": False,
            "status": "OK" if normalized else "NO_RESULTS",
        }

    @staticmethod
    def _normalize_result(result: dict, symbol: str, decision_time: str | None) -> dict:
        highlights = result.get("highlights") or []
        if isinstance(highlights, str):
            highlights = [highlights]
        published = result.get("publishedDate") or result.get("published_date")
        return {
            "symbol": symbol,
            "title": result.get("title") or "",
            "url": result.get("url") or "",
            "published_at": published,
            "author": result.get("author"),
            "highlights": [str(x) for x in highlights[:5]],
            "source": result.get("url") or "",
            "eligible_at_decision_time": QVExaIntelligenceEngine._eligible_at_decision_time(published, decision_time),
            "evidence_only": True,
        }

    @staticmethod
    def _eligible_at_decision_time(published: str | None, decision_time: str | None) -> bool | None:
        if not published or not decision_time:
            return None
        try:
            p = datetime.fromisoformat(published.replace("Z", "+00:00"))
            d = datetime.fromisoformat(decision_time.replace("Z", "+00:00"))
            return p <= d
        except (TypeError, ValueError):
            return None

    def build_evidence_card(self, event_result: dict) -> dict:
        """Create an auditable evidence object; no score/probability/price target."""
        return {
            "source": self.SOURCE_NAME,
            "engine_version": self.VERSION,
            "symbol": event_result.get("symbol"),
            "status": event_result.get("status"),
            "evidence": event_result.get("results", []),
            "evidence_sha256": event_result.get("evidence_sha256"),
            "score": None,
            "probability": None,
            "target_price": None,
            "production_authorized": False,
            "message": "Exa supplies external web evidence only; it does not authorize a QV production signal.",
        }

    def stage(self, context: dict) -> dict:
        """Engine-bus compatible stage. Errors fail closed and preserve prior context."""
        if not isinstance(context, dict):
            raise TypeError("Exa stage expects a dict context")
        symbol = context.get("symbol") or context.get("الرمز")
        if not symbol:
            return {**context, "exa": {"status": "SKIPPED_NO_SYMBOL"}}
        if not self.enabled:
            return {**context, "exa": {"status": "DISABLED", "reason": "EXA_API_KEY غير مضبوط", "production_authorized": False, "evidence_only": True}}
        try:
            result = self.search_symbol_events(
                symbol=str(symbol),
                company_name=context.get("company_name") or context.get("اسم_الشركة"),
                decision_time=context.get("decision_time") or context.get("وقت_القرار"),
                domains=context.get("exa_domains"),
                start_published_date=context.get("exa_start_published_date"),
            )
            return {**context, "exa": self.build_evidence_card(result)}
        except Exception as exc:
            # External intelligence must never crash the core market pipeline.
            return {**context, "exa": {"status": "BLOCKED", "reason": str(exc), "production_authorized": False}}


def register_exa_stage(unified_engine, exa_engine: QVExaIntelligenceEngine | None = None):
    """Register Exa as an optional, fail-closed stage on the existing engine bus."""
    engine = exa_engine or QVExaIntelligenceEngine()
    unified_engine.إضافة_مرحلة("QV_EXA_INTELLIGENCE", engine.stage)
    return engine
