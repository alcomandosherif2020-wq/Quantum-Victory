# QV Exa Intelligence Engine

طبقة اختيارية لربط Quantum Victory ببحث الويب عبر Exa.

## Governance
- Exa ليس مصدر OHLCV أو سعر.
- لا يمنح تصريح الإنتاج ولا يفتح Production Gate.
- الأخبار والأدلة تُعامل Point-in-Time حسب `decision_time`.
- عند غياب `EXA_API_KEY` تعمل الطبقة في وضع `DISABLED`.
- فشل Exa يُحجب داخل المرحلة ولا يُسقط محرك السوق الأساسي.
- لا يتم تحويل نتائج Exa إلى احتمال أو هدف سعري.

## Configuration
```bash
export EXA_API_KEY="..."
export QV_EXA_NUM_RESULTS="8"
export QV_EXA_TIMEOUT="20"
```

## Integration
```python
from qv_whale_hunter.محرك_التشغيل_الموحد import محرك_التشغيل_الموحد
from qv_exa_intelligence import register_exa_stage

bus = محرك_التشغيل_الموحد()
exa = register_exa_stage(bus)

ctx = {
    "symbol": "COMI",
    "decision_time": "2026-09-11T08:00:00+03:00",
}
result = bus.تشغيل("COMI", ctx)
```
