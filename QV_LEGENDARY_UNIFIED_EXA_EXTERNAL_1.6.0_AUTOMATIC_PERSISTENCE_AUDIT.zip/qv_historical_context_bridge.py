# -*- coding: utf-8 -*-
"""Quantum Victory historical-context bridge.

Builds a deterministic, file-first multi-session context from admitted archived
EGX evidence.  It never fabricates missing sessions and never treats historical
files as live data.  The latest discovered session is the current analysis
session; only strictly earlier completed sessions enter the historical context.
"""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

ENGINE = "QV-HISTORICAL-CONTEXT-BRIDGE"
VERSION = "1.0.0"

_DATE_PATTERNS = [
    re.compile(r"(?<!\d)(20\d{2})[-_](\d{2})[-_](\d{2})(?!\d)"),
    re.compile(r"(?<!\d)(20\d{2})(\d{2})(\d{2})(?!\d)"),
    re.compile(r"(?<!\d)(\d{2})[-_](\d{2})[-_](20\d{2})(?!\d)"),
]


def _sha(obj) -> str:
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()


def _date_from_name(name: str):
    for p in _DATE_PATTERNS:
        m = p.search(name)
        if not m:
            continue
        a, b, c = m.groups()
        try:
            if len(a) == 4:
                return pd.Timestamp(int(a), int(b), int(c)).strftime("%Y-%m-%d")
            return pd.Timestamp(int(c), int(a), int(b)).strftime("%Y-%m-%d")
        except Exception:
            pass
    return None


def _normalize(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    x = df.copy()
    x.columns = [str(c).strip() for c in x.columns]
    aliases = {
        "Ticker": "symbol", "ticker": "symbol", "Code": "symbol", "code": "symbol", "Symbol": "symbol",
        "Date": "session_date", "date": "session_date", "trading_date": "session_date",
        "Open": "open", "High": "high", "Low": "low", "Close": "close", "Volume": "volume",
        "Turnover": "turnover", "Value": "turnover", "datetime": "timestamp", "DateTime": "timestamp",
    }
    x = x.rename(columns={c: aliases.get(c, c.lower().replace(" ", "_")) for c in x.columns})
    if "symbol" not in x.columns:
        return pd.DataFrame()
    if "session_date" not in x.columns and "timestamp" in x.columns:
        x["session_date"] = pd.to_datetime(x["timestamp"], errors="coerce").dt.strftime("%Y-%m-%d")
    if "session_date" in x.columns:
        x["session_date"] = pd.to_datetime(x["session_date"], errors="coerce").dt.strftime("%Y-%m-%d")
    if "timestamp" in x.columns:
        x["timestamp"] = pd.to_datetime(x["timestamp"], errors="coerce")
    else:
        x["timestamp"] = pd.to_datetime(x.get("session_date"), errors="coerce")
    for c in ("open", "high", "low", "close", "volume", "turnover"):
        if c in x.columns:
            x[c] = pd.to_numeric(x[c], errors="coerce")
    x["symbol"] = x["symbol"].astype(str).str.strip()
    x = x[(x["symbol"] != "") & x["session_date"].notna()].copy()
    # Prevent repeated copies of the same observation from inflating volume/liquidity.
    dedupe = [c for c in ["symbol","session_date","timestamp","open","high","low","close","volume","turnover"] if c in x.columns]
    if dedupe:
        x = x.drop_duplicates(dedupe, keep="first")
    return x


def _session_aggregate(df: pd.DataFrame) -> pd.DataFrame:
    """Reduce daily or intraday observations to one reproducible session row."""
    x = _normalize(df)
    if x.empty:
        return x
    x = x.sort_values(["symbol", "session_date", "timestamp"])
    rows = []
    for (sym, day), g in x.groupby(["symbol", "session_date"], sort=False):
        r = {"symbol": sym, "session_date": day, "timestamp": pd.to_datetime(day)}
        if "open" in g: r["open"] = g["open"].dropna().iloc[0] if g["open"].notna().any() else np.nan
        if "high" in g: r["high"] = g["high"].max()
        if "low" in g: r["low"] = g["low"].min()
        if "close" in g: r["close"] = g["close"].dropna().iloc[-1] if g["close"].notna().any() else np.nan
        if "volume" in g: r["volume"] = g["volume"].sum(min_count=1)
        if "turnover" in g: r["turnover"] = g["turnover"].sum(min_count=1)
        r["source_ids"] = sorted(set(str(v) for v in g.get("source_id", pd.Series(dtype=str)).dropna()))
        r["evidence_fingerprints"] = sorted(set(str(v) for v in g.get("evidence_fingerprint", pd.Series(dtype=str)).dropna()))
        r["provenance"] = "OFFICIAL_DOWNLOADED_SESSION_FILE"
        rows.append(r)
    return pd.DataFrame(rows)


def _rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff(); up = d.clip(lower=0); dn = -d.clip(upper=0)
    au = up.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    ad = dn.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    return 100 - 100 / (1 + au / ad.replace(0, np.nan))


class QVHistoricalContextBridge:
    def __init__(self, archive_root="QV-OFFLINE-SESSIONS", max_sessions=20):
        self.archive_root = Path(archive_root)
        self.max_sessions = int(max_sessions)

    def _load_archived_tables(self) -> pd.DataFrame:
        """Read previously archived tabular originals; PDFs remain evidence-only."""
        inbox = self.archive_root / "archive"
        if not inbox.exists():
            return pd.DataFrame()
        frames = []
        for p in sorted(inbox.rglob("*")):
            if not p.is_file() or p.suffix.lower() not in {".csv", ".xlsx", ".xls", ".json", ".parquet", ".txt"}:
                continue
            try:
                suf = p.suffix.lower()
                if suf == ".csv": df = pd.read_csv(p)
                elif suf in {".xlsx", ".xls"}: df = pd.read_excel(p)
                elif suf == ".parquet": df = pd.read_parquet(p)
                elif suf == ".json":
                    obj = json.loads(p.read_text(encoding="utf-8-sig"))
                    if isinstance(obj, list): df = pd.DataFrame(obj)
                    elif isinstance(obj, dict):
                        val = next((obj[k] for k in ("data", "rows", "records", "results", "items", "quotes") if isinstance(obj.get(k), list)), [obj])
                        df = pd.DataFrame(val)
                    else: df = pd.DataFrame()
                else: df = pd.read_csv(p, sep=None, engine="python")
                x = _normalize(df)
                if not x.empty:
                    x["archive_path"] = str(p)
                    x["filename_session_date"] = _date_from_name(p.name)
                    # Preserve the original archive path as lineage when a source id is absent.
                    if "source_id" not in x: x["source_id"] = hashlib.sha256(p.read_bytes()).hexdigest()
                    frames.append(x)
            except Exception:
                continue
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

    def build(self, current_df: pd.DataFrame, historical_df: pd.DataFrame | None = None):
        current = _normalize(current_df)
        if current.empty:
            report = self._report([], [], [], 0, 0, "NO_CURRENT_SESSION")
            return report, pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        # Session date is content-first; filename inference is used only when content lacks a date.
        if "session_date" not in current.columns or current["session_date"].isna().all():
            inferred = _date_from_name(str(current_df.attrs.get("source_filename", "")))
            if inferred:
                current["session_date"] = inferred
        current_day = max(current["session_date"].dropna().astype(str).tolist())

        archive = self._load_archived_tables()
        supplied_hist = _normalize(historical_df) if historical_df is not None else pd.DataFrame()
        pool = pd.concat([archive, supplied_hist, current], ignore_index=True) if not archive.empty or not supplied_hist.empty else current.copy()
        pool = _normalize(pool)
        # Strict point-in-time boundary: nothing on/after current session can be historical.
        hist_raw = pool[pool["session_date"].astype(str) < str(current_day)].copy()
        if not hist_raw.empty:
            hist_days = sorted(hist_raw["session_date"].astype(str).unique().tolist())
            selected_days = hist_days[-self.max_sessions:]
            hist_raw = hist_raw[hist_raw["session_date"].astype(str).isin(selected_days)].copy()
        else:
            selected_days = []

        current_raw = current[current["session_date"].astype(str) == str(current_day)].copy()
        hist_sessions = _session_aggregate(hist_raw)
        current_sessions = _session_aggregate(current_raw)
        all_sessions = pd.concat([hist_sessions, current_sessions], ignore_index=True)
        all_sessions = all_sessions.sort_values(["symbol", "session_date"]).reset_index(drop=True)

        context_rows = []
        for sym, g in all_sessions.groupby("symbol", sort=False):
            g = g.sort_values("session_date").copy()
            closes = pd.to_numeric(g.get("close"), errors="coerce")
            vols = pd.to_numeric(g.get("volume"), errors="coerce")
            ret = closes.pct_change()
            g["ret1"] = ret
            g["ret3"] = closes.pct_change(3)
            g["ret5"] = closes.pct_change(5)
            g["ret10"] = closes.pct_change(10)
            g["ema5"] = closes.ewm(span=5, adjust=False, min_periods=5).mean()
            g["ema10"] = closes.ewm(span=10, adjust=False, min_periods=10).mean()
            g["ema20"] = closes.ewm(span=20, adjust=False, min_periods=20).mean()
            g["rsi14"] = _rsi(closes, 14)
            g["volatility5"] = ret.rolling(5, min_periods=3).std(ddof=0)
            g["volume_median5"] = vols.shift(1).rolling(5, min_periods=1).median()
            g["volume_median10"] = vols.shift(1).rolling(10, min_periods=1).median()
            g["rvol5"] = vols / g["volume_median5"].replace(0, np.nan)
            rng = (pd.to_numeric(g.get("high"), errors="coerce") - pd.to_numeric(g.get("low"), errors="coerce")).replace(0, np.nan)
            clv = ((pd.to_numeric(g.get("close"), errors="coerce") - pd.to_numeric(g.get("low"), errors="coerce")) / rng).clip(0, 1)
            g["clv"] = clv
            g["ad_flow"] = ((clv * 2 - 1) * vols).fillna(0)
            g["ad_flow5"] = g["ad_flow"].rolling(5, min_periods=1).sum()
            g["trend_state"] = np.select(
                [
                    (g["ret1"] > 0) & (g["rvol5"] >= 1.2) & (g["clv"] >= .6),
                    (g["ret1"] < 0) & (g["rvol5"] >= 1.2) & (g["clv"] <= .4),
                    (g["ret1"] > 0) & (g["ret5"] > 0),
                    (g["ret1"] < 0) & (g["ret5"] < 0),
                ],
                ["ACCUMULATION_PRESSURE", "DISTRIBUTION_PRESSURE", "REACCELERATION", "WEAKNESS"],
                default="NEUTRAL_OR_INSUFFICIENT",
            )
            g["prior_state"] = g["trend_state"].shift(1)
            g["state_transition"] = np.where(
                g["prior_state"].notna() & (g["trend_state"] != g["prior_state"]),
                g["prior_state"].astype(str) + "->" + g["trend_state"].astype(str),
                "NO_TRANSITION",
            )
            context_rows.append(g)
        context = pd.concat(context_rows, ignore_index=True) if context_rows else pd.DataFrame()
        current_context = context[context["session_date"].astype(str) == str(current_day)].copy() if not context.empty else pd.DataFrame()

        # Multi-session confirmation is a descriptive evidence count, not a probability.
        if not current_context.empty:
            counts = hist_sessions.groupby("symbol").size().rename("prior_sessions_available").reset_index() if not hist_sessions.empty else pd.DataFrame(columns=["symbol", "prior_sessions_available"])
            current_context = current_context.merge(counts, on="symbol", how="left")
            current_context["prior_sessions_available"] = pd.to_numeric(current_context["prior_sessions_available"], errors="coerce").fillna(0).astype(int)
            current_context["multi_session_confirmation"] = current_context["prior_sessions_available"] >= 3
            current_context["historical_context_source"] = "OFFICIAL_ARCHIVED_TABULAR_SESSION_FILES"
            current_context["production_authorized"] = False

        source_files = sorted(set(str(v) for v in hist_raw.get("archive_path", pd.Series(dtype=str)).dropna()))
        report = self._report(
            sorted(current["session_date"].dropna().astype(str).unique().tolist()),
            selected_days,
            source_files,
            len(hist_raw),
            len(current_raw),
            "PASS" if selected_days else "PASS_WITH_NO_PRIOR_SESSIONS",
        )
        report["current_session"] = current_day
        report["symbols_with_history"] = int(current_context["prior_sessions_available"].gt(0).sum()) if not current_context.empty else 0
        report["max_prior_sessions"] = self.max_sessions
        report["historical_context_sha256"] = _sha({
            "current": current_day, "prior_sessions": selected_days,
            "rows": int(len(hist_sessions)), "current_rows": int(len(current_sessions)),
        })
        return report, current_context, hist_sessions, all_sessions

    @staticmethod
    def _report(current_days, prior_days, source_files, historical_rows, current_rows, status):
        return {
            "engine": ENGINE, "version": VERSION, "status": status,
            "current_session_candidates": current_days,
            "prior_completed_sessions": prior_days,
            "source_files_used": source_files,
            "historical_raw_rows": int(historical_rows),
            "current_raw_rows": int(current_rows),
            "fabricated_rows": 0,
            "synthetic_sessions": 0,
            "future_rows_in_historical_context": 0,
            "point_in_time_boundary": "historical_session_date < current_session_date",
            "production_authorized": False,
            "live_data_claim": False,
            "fail_closed": True,
        }
