# QV 1.5.0 — Automatic Historical Session Linking

This release extends FILE_FIRST/OFFLINE operation with `QV-HISTORICAL-CONTEXT-BRIDGE`.

- Detects the current session from the latest session date in normalized official evidence.
- Links only strictly earlier completed sessions from the archive.
- Keeps current-session rows separate from historical context.
- Produces multi-session technical/quantitative context: returns, EMA, RSI, volatility, relative volume, accumulation/distribution flow, trend state, state transitions and multi-session confirmation.
- Preserves provenance and fingerprints; no synthetic rows are created.
- External/Exa layers remain corroboration/evidence only.
- Production authorization remains `false`; `live_data_claim` remains `false`; `fail_closed` remains `true`.
