from __future__ import annotations
from datetime import datetime, timezone
import json, hashlib

ENGINE='QV-GLOBAL-INTEGRATION-HEALTH'; VERSION='1.0.0'

def build_health(reports, reconciliation=None):
    providers=[]
    for r in reports or []:
        providers.append({k:r.get(k) for k in ('provider','enabled','ok','fetched_at','latency_ms','error','evidence_sha256','production_authorized')})
    payload={'engine':ENGINE,'version':VERSION,'generated_at':datetime.now(timezone.utc).isoformat(),
             'providers':providers,'provider_count':len(providers),
             'enabled_count':sum(bool(x.get('enabled')) for x in providers),
             'ok_count':sum(bool(x.get('ok')) for x in providers),
             'reconciliation':reconciliation or {},
             'production_authorized':False,'fail_closed':True}
    payload['sha256']=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()
    return payload
