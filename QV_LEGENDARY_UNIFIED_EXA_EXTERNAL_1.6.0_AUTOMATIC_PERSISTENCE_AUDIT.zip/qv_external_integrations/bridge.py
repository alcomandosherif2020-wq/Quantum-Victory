# -*- coding: utf-8 -*-
"""QV External Integration Bridge 1.0.0.

Purpose: connect optional lawful external providers/apps to Quantum Victory
without weakening the fail-closed production gate.

External providers are adapters, not authorities. Raw responses are normalized,
fingerprinted and marked production_authorized=False until QV's existing
validation/reconciliation/release gates approve them.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json, os, time
from typing import Any
import requests

ENGINE="QV-EXTERNAL-INTEGRATION-BRIDGE"
VERSION="1.0.0"

@dataclass
class ExternalProviderResult:
    provider: str
    enabled: bool
    ok: bool
    rows: list[dict]
    fetched_at: str
    latency_ms: float
    error: str | None = None
    evidence_sha256: str | None = None
    production_authorized: bool = False

class QVExternalIntegrationBridge:
    """Optional adapters for market-data providers and supporting apps."""
    def __init__(self, timeout: float = 8.0, session=None):
        self.timeout=max(2.0,float(timeout))
        self.session=session or requests.Session()

    def _result(self, provider, enabled, started, rows=None, error=None):
        rows=rows or []
        digest=hashlib.sha256(json.dumps(rows,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()
        return ExternalProviderResult(provider,enabled,bool(rows),rows,
            datetime.now(timezone.utc).isoformat(),round((time.monotonic()-started)*1000,2),
            error,digest,False)

    @staticmethod
    def _num(v):
        try: return float(v)
        except (TypeError,ValueError): return None

    def _normalize(self, payload: Any, provider: str, symbol: str) -> list[dict]:
        rows=[]
        if isinstance(payload,list):
            records=payload
        elif isinstance(payload,dict):
            # Twelve Data / Alpha Vantage / generic envelopes.
            records=[]
            for key in ("values","data","results","historical","items"):
                if isinstance(payload.get(key),list):
                    records=payload[key]; break
            if not records:
                # Alpha Vantage intraday: {"Time Series (5min)": {...}}
                for key,val in payload.items():
                    if isinstance(val,dict) and "Time Series" in key:
                        records=[dict(v,datetime=k) for k,v in val.items()]
                        break
        else:
            records=[]
        for r in records:
            if not isinstance(r,dict): continue
            dt=r.get("datetime") or r.get("timestamp") or r.get("date") or r.get("time")
            close=self._num(r.get("close") if r.get("close") is not None else r.get("4. close"))
            price=self._num(r.get("price") if r.get("price") is not None else r.get("last"))
            if close is None: close=price
            vol=self._num(r.get("volume") if r.get("volume") is not None else r.get("5. volume"))
            if dt is None or close is None or close<=0: continue
            rows.append({
                "symbol":symbol,"timestamp":str(dt),"price":close,
                "open":self._num(r.get("open") if r.get("open") is not None else r.get("1. open")),
                "high":self._num(r.get("high") if r.get("high") is not None else r.get("2. high")),
                "low":self._num(r.get("low") if r.get("low") is not None else r.get("3. low")),
                "close":close,"volume":0 if vol is None else max(0,vol),
                "source":provider
            })
        return rows

    def _get(self, provider, url, params, symbol):
        started=time.monotonic()
        try:
            r=self.session.get(url,params=params,timeout=self.timeout,
                               headers={"Accept":"application/json","User-Agent":"QuantumVictory-ExternalBridge/1.0"})
            r.raise_for_status()
            payload=r.json()
            rows=self._normalize(payload,provider,symbol)
            return self._result(provider,True,started,rows)
        except Exception as exc:
            return self._result(provider,True,started,error=f"{type(exc).__name__}: {str(exc)[:220]}")

    def fetch_twelve_data(self, symbol: str, interval: str|None=None):
        key=os.getenv("QV_TWELVE_DATA_KEY")
        if not key: return self._result("TWELVE_DATA",False,time.monotonic(),error="disabled: QV_TWELVE_DATA_KEY not set")
        return self._get("TWELVE_DATA","https://api.twelvedata.com/time_series",
            {"symbol":symbol,"interval":interval or os.getenv("QV_TWELVE_DATA_INTERVAL","5min"),
             "outputsize":os.getenv("QV_TWELVE_DATA_OUTPUTSIZE","100"),"apikey":key},symbol)

    def fetch_eodhd(self, symbol: str, suffix: str|None=None):
        key=os.getenv("QV_EODHD_KEY")
        if not key: return self._result("EODHD",False,time.monotonic(),error="disabled: QV_EODHD_KEY not set")
        s=suffix or os.getenv("QV_EODHD_SUFFIX",".EGX")
        return self._get("EODHD",f"https://eodhd.com/api/intraday/{symbol}{s}",
            {"api_token":key,"interval":os.getenv("QV_EODHD_INTERVAL","5m"),"fmt":"json"},symbol)

    def fetch_alpha_vantage(self, symbol: str, interval: str|None=None):
        key=os.getenv("QV_ALPHA_VANTAGE_KEY")
        if not key: return self._result("ALPHA_VANTAGE",False,time.monotonic(),error="disabled: QV_ALPHA_VANTAGE_KEY not set")
        return self._get("ALPHA_VANTAGE","https://www.alphavantage.co/query",
            {"function":"TIME_SERIES_INTRADAY","symbol":symbol,
             "interval":interval or os.getenv("QV_ALPHA_VANTAGE_INTERVAL","5min"),
             "outputsize":"compact","apikey":key},symbol)

    def fetch_fmp(self, symbol: str):
        key=os.getenv("QV_FMP_KEY"); base=os.getenv("QV_FMP_URL")
        if not key or not base: return self._result("FMP",False,time.monotonic(),error="disabled: QV_FMP_KEY/QV_FMP_URL not set")
        return self._get("FMP",base,{"symbol":symbol,"apikey":key},symbol)

    def fetch_yfinance(self, symbol: str):
        if os.getenv("QV_YFINANCE_ENABLED","0")!="1":
            return self._result("YFINANCE",False,time.monotonic(),error="disabled: QV_YFINANCE_ENABLED!=1")
        started=time.monotonic()
        try:
            import yfinance as yf
            ticker=symbol if "." in symbol else f"{symbol}.CA"
            df=yf.download(ticker,period=os.getenv("QV_YFINANCE_PERIOD","5d"),
                           interval=os.getenv("QV_YFINANCE_INTERVAL","5m"),progress=False,auto_adjust=False)
            rows=[]
            if hasattr(df,"reset_index"):
                for _,r in df.reset_index().iterrows():
                    dt=r.get("Datetime") or r.get("Date")
                    close=self._num(r.get("Close"))
                    vol=self._num(r.get("Volume"))
                    if dt is not None and close is not None and close>0:
                        rows.append({"symbol":symbol,"timestamp":str(dt),"price":close,
                                     "open":self._num(r.get("Open")),"high":self._num(r.get("High")),
                                     "low":self._num(r.get("Low")),"close":close,
                                     "volume":0 if vol is None else max(0,vol),"source":"YFINANCE"})
            return self._result("YFINANCE",True,started,rows)
        except Exception as exc:
            return self._result("YFINANCE",True,started,error=f"{type(exc).__name__}: {str(exc)[:220]}")

    def capabilities(self):
        return {
            "engine":ENGINE,"version":VERSION,
            "providers":{
                "EXA":"evidence/search (already integrated separately)",
                "TWELVE_DATA":"optional market-data adapter",
                "EODHD":"optional market-data adapter",
                "ALPHA_VANTAGE":"optional market-data adapter",
                "FMP":"optional market-data adapter",
                "YFINANCE":"optional market-data adapter",
                "TELEGRAM":"existing QV delivery gateway",
                "GITHUB_STREAMLIT":"deployment/source-control integration by repository"
            },
            "production_authorized":False,
            "fail_closed":True
        }

    def collect(self, symbol: str):
        results=[]
        # Provider order: official/paid feeds first, then secondary research feeds.
        results += [self.fetch_twelve_data(symbol), self.fetch_eodhd(symbol),
                    self.fetch_alpha_vantage(symbol), self.fetch_fmp(symbol), self.fetch_yfinance(symbol)]
        enabled=[r for r in results if r.enabled]
        return {
            "engine":ENGINE,"version":VERSION,"symbol":symbol,
            "providers":[asdict(r) for r in results],
            "enabled_count":len(enabled),
            "ok_count":sum(1 for r in enabled if r.ok),
            "production_authorized":False,
            "fail_closed":True
        }
