# QV External Integration Bridge 1.0.0

Optional external integration layer for Quantum Victory.

## Providers
- Exa: external web/evidence intelligence (already integrated in `qv_exa_intelligence`).
- Twelve Data: optional market-data adapter.
- EODHD: optional market-data adapter.
- Alpha Vantage: optional market-data adapter.
- FMP: optional custom-endpoint adapter.
- yfinance: optional local adapter.
- Telegram: existing QV delivery gateway.
- GitHub + Streamlit Community Cloud: deployment/source-control workflow.

## Governance
No adapter can open the production gate. External rows are source-tagged,
fingerprinted and passed into the existing validation/reconciliation path.
Missing credentials, network failures and unsupported providers fail closed.

## Activation
Set `QV_EXTERNAL_MESH_ENABLED=1` and only the provider keys/endpoints that
are legally available to the operator. Never commit secrets.
