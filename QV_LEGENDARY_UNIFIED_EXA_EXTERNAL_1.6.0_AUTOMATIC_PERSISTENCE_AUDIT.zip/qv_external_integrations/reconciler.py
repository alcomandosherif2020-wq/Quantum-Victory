from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timezone
import hashlib, json

ENGINE='QV-EXTERNAL-RECONCILIATION-GATE'; VERSION='1.0.0'


def reconcile(provider_reports, tolerance_pct=0.5):
    """Reconcile external provider rows by symbol/time bucket.
    Returns evidence only; production authorization is always False.
    """
    buckets=defaultdict(list)
    for report in provider_reports or []:
        provider=report.get('provider','UNKNOWN')
        for row in report.get('rows') or []:
            try:
                ts=str(row.get('timestamp'))
                sym=str(row.get('symbol'))
                price=float(row.get('price'))
            except (TypeError,ValueError):
                continue
            buckets[(sym,ts)].append((provider,price,row))
    reconciled=[]; conflicts=[]
    for (sym,ts),items in buckets.items():
        prices=[x[1] for x in items]
        if not prices: continue
        ref=sum(prices)/len(prices)
        spread=((max(prices)-min(prices))/ref*100) if ref else 999.0
        status='CONSENSUS' if len(items)>=2 and spread<=tolerance_pct else ('SINGLE_SOURCE' if len(items)==1 else 'CONFLICT')
        rec={'symbol':sym,'timestamp':ts,'providers':[x[0] for x in items],
             'prices':[x[1] for x in items],'reference_price':ref,'spread_pct':spread,'status':status}
        reconciled.append(rec)
        if status=='CONFLICT': conflicts.append(rec)
    payload={'engine':ENGINE,'version':VERSION,'status':'OK','buckets':len(reconciled),
             'consensus':sum(x['status']=='CONSENSUS' for x in reconciled),
             'single_source':sum(x['status']=='SINGLE_SOURCE' for x in reconciled),
             'conflicts':len(conflicts),'records':reconciled,
             'production_authorized':False,'fail_closed':True}
    payload['sha256']=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()
    return payload
