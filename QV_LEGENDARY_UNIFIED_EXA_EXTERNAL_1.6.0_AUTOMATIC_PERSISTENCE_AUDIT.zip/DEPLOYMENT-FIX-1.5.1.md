# Quantum Victory 1.5.1 — Streamlit Deployment Repair

## Root cause addressed
The failing deployment traceback shows Streamlit executing the legacy `Nafezu.py` HTTP wrapper from a temporary `qv130_*` directory. That wrapper expects `واجهة_كوانتوم_فيكتوري_المحركات_٥_٩.py` beside `Nafezu.py`; the deployed entrypoint was therefore not the intended Streamlit FILE-FIRST application.

## Correct entrypoint
Use:

`main.py`

This file imports `streamlit_app.py` directly and does not execute the legacy HTTP wrapper.

## Streamlit Cloud settings
- Repository: the repository containing this package
- Branch: the intended deployment branch (normally `main`)
- Main file path: `main.py`
- Python: `3.12` (from `.python-version`)
- Secrets: add only real API keys if/when external integrations are intentionally enabled; never commit them.

## Safety
The application remains FILE-FIRST / OFFLINE by default:
- `live_data_claim = False`
- `production_authorized = False`
- `fail_closed = True`
