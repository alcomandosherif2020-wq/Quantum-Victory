from pathlib import Path
from qv_whale_hunter.منظومة_التحديث_والتنشيط_الشامل import منظومة_التحديث_والتنشيط_الشامل

def test_تنشيط_شامل_ينشئ_الحالة(tmp_path):
    r = منظومة_التحديث_والتنشيط_الشامل(tmp_path).تنفيذ(آخر_جلسة="2026-09-03")
    assert r["الإصدار"] == "5.6.1"
    assert r["الحالة"] == "تم التنشيط الشامل"
    assert r["الإنتاج_مصرح"] is False
    assert len(r["الطبقات"]) >= 10
    assert (tmp_path/"حالة_المصادر"/"حالة_المصادر_المحدثة.json").exists()
    assert (tmp_path/"حالة_التحديث"/"حالة_التنشيط_الشامل_2026-09-06.json").exists()
