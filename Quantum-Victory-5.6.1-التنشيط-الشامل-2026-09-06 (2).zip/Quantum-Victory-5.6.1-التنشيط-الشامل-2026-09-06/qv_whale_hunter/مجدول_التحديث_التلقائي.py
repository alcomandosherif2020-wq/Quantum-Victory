from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Any
import hashlib, json, time

@dataclass
class مهمة_تحديث:
    الاسم: str
    الفترة_بالثواني: int
    آخر_تشغيل: float = 0.0
    عدد_النجاحات: int = 0
    عدد_الإخفاقات: int = 0
    الحالة: str = "جاهز"
    def مستحقة(self, الآن: float) -> bool:
        return الآن - self.آخر_تشغيل >= self.الفترة_بالثواني

class منسق_التحديث_التلقائي:
    def __init__(self, مجلد_الحالة="حالة_التحديث"):
        self.مجلد_الحالة=Path(مجلد_الحالة); self.مجلد_الحالة.mkdir(parents=True,exist_ok=True)
        self.المهام={}; self.آخر_دورة=None
    def إضافة_مهمة(self, الاسم, الفترة_بالثواني):
        if الفترة_بالثواني<=0: raise ValueError("الفترة يجب أن تكون موجبة")
        self.المهام[الاسم]=مهمة_تحديث(الاسم,الفترة_بالثواني)
    def تشغيل_مهمة(self, الاسم, دالة:Callable[[],Any], الآن=None):
        الآن=time.time() if الآن is None else الآن; m=self.المهام[الاسم]; m.آخر_تشغيل=الآن
        try:
            x=دالة(); m.عدد_النجاحات+=1; m.الحالة="نجح"; return {"نجح":True,"الناتج":x}
        except Exception as e:
            m.عدد_الإخفاقات+=1; m.الحالة="فشل"; return {"نجح":False,"خطأ":str(e)}
    def دورة(self, الآن=None):
        الآن=time.time() if الآن is None else الآن; self.آخر_دورة=datetime.now(timezone.utc).isoformat()
        return [asdict(m)|{"مستحقة":m.مستحقة(الآن)} for m in self.المهام.values()]
    def حفظ_الحالة(self):
        d={"الإصدار":"5.6.1","آخر_دورة":self.آخر_دورة,"المهام":[asdict(m) for m in self.المهام.values()],"الإنتاج_مصرح":False}
        raw=json.dumps(d,ensure_ascii=False,sort_keys=True); d["بصمة_الحالة"]=hashlib.sha256(raw.encode()).hexdigest()
        p=self.مجلد_الحالة/"حالة_التحديث.json"; t=p.with_suffix(".tmp"); t.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8"); t.replace(p); return p

def إنشاء_جدول_التحديث_الافتراضي():
    m=منسق_التحديث_التلقائي()
    for n,s in [("السوق_اللحظي",15),("الصفقات",15),("العمق",15),("الأخبار_والإفصاحات",60),("المؤشرات_والقطاعات",60),("التاريخ_والتحليل_اليومي",3600),("صحة_المصادر",60)]: m.إضافة_مهمة(n,s)
    return m
