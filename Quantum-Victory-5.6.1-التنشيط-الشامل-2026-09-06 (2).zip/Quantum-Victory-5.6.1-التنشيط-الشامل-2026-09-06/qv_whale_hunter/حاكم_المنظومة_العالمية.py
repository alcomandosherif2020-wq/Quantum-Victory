# -*- coding: utf-8 -*-
"""الحاكم المركزي لكوانتوم فيكتوري.
يجمع الحواجز والبيانات والتحليل وقناص السيولة في عقد واحد، ولا يسمح
بمرور أي نتيجة تنبيهية ما لم تكن كل بوابات السلامة مجتازة.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Mapping
import hashlib, json
import pandas as pd

from .حارس_سلامة_البيانات_الشامل import فحص_الشموع, فحص_المصالحة
from .محرك_التحليل_الفني import تحليل_فني
from .live_liquidity_sniper import scan as فحص_السيولة
from .محرك_قرار_الأدلة import محرك_قرار_الأدلة

@dataclass(frozen=True)
class نتيجة_الحكم:
    الرمز: str
    الحالة: str
    التوصية: str
    الأسباب: tuple[str, ...]
    الأدلة: tuple[str, ...]
    درجة_الأدلة: float | None
    احتمال: None = None
    سعر_مستهدف: None = None
    إنتاج_مصرح: bool = False

class حاكم_المنظومة_العالمية:
    """واجهة تشغيل موحدة: سلامة -> تحليل -> سيولة -> قرار أدلة."""
    الإصدار = "5.6.1"

    def __init__(self, إنتاج_مصرح=False):
        # لا يمكن فتح الإنتاج من خلال هذا الكائن.
        self._إنتاج_مصرح = False

    @staticmethod
    def _رمز(df):
        for c in ("الرمز", "symbol", "ticker", "code"):
            if c in df.columns:
                return str(df[c].iloc[-1])
        return "غير_معروف"

    @staticmethod
    def _إلى_إنجليزية(df):
        return df.rename(columns={"الرمز":"symbol","التاريخ":"session_date","الافتتاح":"open","الأعلى":"high","الأدنى":"low","الإغلاق":"close","الحجم":"volume"}).copy()

    def تحليل_سهم(self, df: pd.DataFrame, *, دلالة_الافتتاح=None, مصادر=None, intraday=None):
        if df is None or df.empty:
            return asdict(نتيجة_الحكم("غير_معروف", "محجوب", "لا_بيانات", ("لا توجد بيانات",), (), None))
        x=df.copy()
        guard=فحص_الشموع(x, دلالة_الافتتاح=دلالة_الافتتاح)
        أسباب=list(guard.get("reasons", [])); تحذيرات=list(guard.get("warnings", []))
        evidence=[]
        if guard.get("status") == "محجوب" or guard.get("opening_semantics") != "افتتاح_الجلسة":
            return asdict(نتيجة_الحكم(self._رمز(x), "محجوب", "لا_قرار", tuple(أسباب), tuple(evidence), None))
        if مصادر:
            rec=فحص_المصالحة(مصادر)
            if rec.get("status") == "متعارض":
                أسباب.append("تعارض_مصادر")
                return asdict(نتيجة_الحكم(self._رمز(x), "محجوب", "لا_قرار", tuple(dict.fromkeys(أسباب)), tuple(evidence), None))
            if rec.get("status") == "مُثبت": evidence.append("مصالحة_مصادر_مثبتة")
        try:
            _, tech=تحليل_فني(x)
        except Exception as e:
            return asdict(نتيجة_الحكم(self._رمز(x), "محجوب", "لا_قرار", (f"فشل_التحليل:{type(e).__name__}",), tuple(evidence), None))
        الاتجاه=tech.get("الاتجاه","متوازن")
        الدرجة=float(tech.get("درجة الأدلة",0))
        evidence.extend([str(v) for v in tech.get("أسباب",[])])
        if intraday is not None and not intraday.empty:
            try:
                liq=فحص_السيولة(intraday)
                alerts=liq[liq["signal"]!="NO_ALERT"] if "signal" in liq else pd.DataFrame()
                if not alerts.empty: evidence.append("بصمة_سيولة_لحظية_موجودة")
            except Exception as e:
                تحذيرات.append(f"تعذر_فحص_السيولة:{type(e).__name__}")
        if الاتجاه == "إيجابي": التوصية="انحياز_إيجابي_للمراجعة"
        elif الاتجاه == "سلبي": التوصية="انحياز_سلبي_للمراجعة"
        else: التوصية="انتظار_تأكيد"
        return asdict(نتيجة_الحكم(self._رمز(x), "جاهز_للمراجعة", التوصية, tuple(dict.fromkeys(أسباب+تحذيرات)), tuple(dict.fromkeys(evidence)), round(الدرجة,3)))

    @classmethod
    def بصمة_النتيجة(cls, نتيجة):
        raw=json.dumps(نتيجة,ensure_ascii=False,sort_keys=True,default=str,separators=(",",":" )).encode()
        return hashlib.sha256(raw).hexdigest()
