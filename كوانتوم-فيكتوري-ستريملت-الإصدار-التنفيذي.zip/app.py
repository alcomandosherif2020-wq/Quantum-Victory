# -*- coding: utf-8 -*-
"""واجهة كوانتوم فيكتوري التنفيذية لستريملت.

مهم: هذا الملف لا يشغل خادم HTTP يدويًا. ستريملت هو الذي يدير الخادم والمنفذ.
"""
import io
import os
import json
from datetime import datetime

import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="كوانتوم فيكتوري للتحليل الفني والكمي",
    page_icon="⚛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# اتجاه عربي
st.markdown(
    """
    <style>
    .stApp { direction: rtl; }
    [data-testid="stSidebar"] { direction: rtl; }
    .block-container { direction: rtl; }
    div[data-testid="stMetricValue"], div[data-testid="stMetricLabel"] { text-align: right; }
    </style>
    """,
    unsafe_allow_html=True,
)

REQUIRED_COLUMNS = {"التاريخ", "الاغلاق"}
COLUMN_ALIASES = {
    "Date": "التاريخ", "date": "التاريخ", "تاريخ": "التاريخ",
    "Close": "الاغلاق", "close": "الاغلاق", "سعر الاغلاق": "الاغلاق",
    "Open": "الافتتاح", "open": "الافتتاح",
    "High": "الاعلى", "high": "الاعلى",
    "Low": "الادنى", "low": "الادنى",
    "Volume": "الحجم", "volume": "الحجم", "حجم التداول": "الحجم",
    "Turnover": "قيمة التداول", "turnover": "قيمة التداول", "قيمة التداول": "قيمة التداول",
    "Change": "التغير", "change": "التغير", "نسبة التغير": "التغير",
    "Symbol": "الرمز", "symbol": "الرمز", "الرمز": "الرمز",
}


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [COLUMN_ALIASES.get(str(c).strip(), str(c).strip()) for c in out.columns]
    if "التاريخ" in out.columns:
        out["التاريخ"] = pd.to_datetime(out["التاريخ"], errors="coerce")
    for c in ["الاغلاق", "الافتتاح", "الاعلى", "الادنى", "الحجم", "قيمة التداول", "التغير"]:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    return out


def quality_report(df: pd.DataFrame) -> dict:
    checks = {}
    checks["الحد الأدنى للحقول"] = REQUIRED_COLUMNS.issubset(df.columns)
    checks["التاريخ صالح"] = bool(df["التاريخ"].notna().all()) if "التاريخ" in df else False
    checks["الإغلاق صالح"] = bool(df["الاغلاق"].notna().all()) if "الاغلاق" in df else False
    checks["لا توجد أسعار إغلاق غير موجبة"] = bool((df["الاغلاق"] > 0).all()) if "الاغلاق" in df else False
    checks["لا توجد تواريخ مكررة"] = bool(not df["التاريخ"].duplicated().any()) if "التاريخ" in df else False
    return checks


def compute_analysis(df: pd.DataFrame) -> dict:
    d = df.sort_values("التاريخ").dropna(subset=["التاريخ", "الاغلاق"]).copy()
    d["عائد"] = d["الاغلاق"].pct_change()
    if len(d) >= 5:
        d["متوسط_5"] = d["الاغلاق"].rolling(5).mean()
    if len(d) >= 20:
        d["متوسط_20"] = d["الاغلاق"].rolling(20).mean()
    last = d.iloc[-1]
    prev = d.iloc[-2] if len(d) >= 2 else None
    change = ((last["الاغلاق"] / prev["الاغلاق"]) - 1) * 100 if prev is not None and prev["الاغلاق"] else None
    score = None
    evidence = []
    if len(d) >= 20:
        if last["الاغلاق"] > last["متوسط_20"]:
            score = 60
            evidence.append("الإغلاق أعلى من متوسط العشرين جلسة")
        else:
            score = 40
            evidence.append("الإغلاق أسفل متوسط العشرين جلسة")
    elif len(d) >= 5:
        score = 50
        evidence.append("العينة قصيرة؛ القراءة استرشادية فقط")
    return {"البيانات": d, "آخر إغلاق": float(last["الاغلاق"]), "التغير": change, "الدرجة": score, "الأدلة": evidence}


def load_url(url: str):
    import requests
    r = requests.get(url, timeout=20)
    r.raise_for_status()
    ctype = r.headers.get("content-type", "").lower()
    if "json" in ctype or url.lower().endswith(".json"):
        payload = r.json()
        if isinstance(payload, dict):
            for key in ["data", "rows", "result", "البيانات"]:
                if isinstance(payload.get(key), list):
                    payload = payload[key]
                    break
        return pd.DataFrame(payload)
    return pd.read_csv(io.BytesIO(r.content))


def empty_state():
    st.warning("لا توجد بيانات سوق مؤهلة حاليًا. لا يتم إنشاء توصية أو احتمال رقمي دون بيانات صالحة.")

st.title("⚛️ كوانتوم فيكتوري")
st.subheader("التحليل الفني والكمي للبورصة المصرية")
st.caption("نسخة تنفيذية آمنة لستريملت — بدون تشغيل خادم منفصل أو ربط منفذ يدوي.")

with st.sidebar:
    st.header("مصدر البيانات")
    uploaded = st.file_uploader("استيراد ملف بيانات تاريخية", type=["csv"])
    url = st.text_input("رابط بيانات مصرح به", value=os.getenv("QV_DATA_URL", ""))
    st.divider()
    st.header("حالة الأمان")
    st.success("تشغيل ستريملت مباشر")
    st.info("القرار لا يصدر عند نقص البيانات أو تعارضها.")

source_df = None
source_name = "لا يوجد مصدر مؤهل"

try:
    if uploaded is not None:
        source_df = pd.read_csv(uploaded)
        source_name = uploaded.name
    elif url.strip():
        source_df = load_url(url.strip())
        source_name = url.strip()
except Exception as exc:
    st.error(f"تعذر استقبال مصدر البيانات: {exc}")

if source_df is None:
    empty_state()
    st.markdown("### 🎯 الهدف التنفيذي")
    st.write("هذه الواجهة هي نقطة التشغيل الصحيحة للمشروع على خدمة ستريملت. لا تستخدم خادم HTTP يدويًا، ولا تستدعي ربط منفذ داخل التطبيق.")
    st.markdown("### 🛡️ قاعدة كوانتوم")
    st.write("إذا لم تصل بيانات مؤهلة، تبقى النتيجة: لا توجد قراءة موثوقة.")
else:
    df = normalize_columns(source_df)
    st.markdown(f"**المصدر الحالي:** {source_name}")
    checks = quality_report(df)
    passed = sum(bool(v) for v in checks.values())
    total = len(checks)
    if not all(checks.values()):
        st.error(f"بوابة الجودة: {passed}/{total} — البيانات محجوبة عن القرار.")
        st.dataframe(df.head(50), use_container_width=True)
    else:
        analysis = compute_analysis(df)
        d = analysis["البيانات"]
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("آخر إغلاق", f"{analysis['آخر إغلاق']:.2f}")
        c2.metric("التغير الأخير", "غير متاح" if analysis["التغير"] is None else f"{analysis['التغير']:.2f}%")
        c3.metric("عدد الجلسات", f"{len(d):,}")
        c4.metric("درجة القراءة الأولية", "غير متاحة" if analysis["الدرجة"] is None else f"{analysis['الدرجة']}/100")

        st.markdown("### 📈 حركة السهم")
        chart = d.set_index("التاريخ")["الاغلاق"]
        st.line_chart(chart, use_container_width=True)

        st.markdown("### 🧠 قراءة كوانتوم فيكتوري الأولية")
        for item in analysis["الأدلة"]:
            st.write(f"• {item}")
        st.warning("هذه النسخة لا تدّعي احتمالًا تاريخيًا معايرًا ولا توصية شراء أو بيع. الاحتمالات النهائية لا تُفعل إلا بعد اجتياز طبقات التحقق والمعايرة التاريخية.")

        st.markdown("### 🔐 بوابات الجودة")
        for name, ok in checks.items():
            st.write(("🟢 " if ok else "🔴 ") + name)

        st.markdown("### 🩺 نصيحة كوانتوم فيكتوري")
        st.write("لا تطارد الحركة ولا تتعامل مع قراءة غير مكتملة كأنها يقين. حماية رأس المال تسبق مطاردة الربح.")

st.divider()
st.caption("كوانتوم فيكتوري للتحليل الفني والكمي للبورصة المصرية — الدليل قبل القرار، ورأس المال أولًا.")
