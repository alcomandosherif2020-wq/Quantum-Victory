import pandas as pd, numpy as np
from qv_whale_hunter.evidence_lab import *
from qv_whale_hunter.drift_guard import *
from qv_whale_hunter.adversarial_guard import *
from qv_whale_hunter.decision_ledger import *

def run():
    n=60; df=pd.DataFrame({'session_date':pd.date_range('2026-01-01',periods=n),'symbol':['X']*n,'open':np.arange(n)+10,'high':np.arange(n)+11,'low':np.arange(n)+9,'close':np.arange(n)+10.5,'volume':np.arange(n)+100})
    exp=make_protocol('a'*64); assert validate_protocol(exp)['status']=='PASS'
    assert realized_edge(.02,1,10,5)==.0185
    assert bootstrap_mean(np.arange(30))['status']=='PASS'
    assert calibration_bins(np.linspace(.1,.9,30),np.linspace(0,1,30)>0.5)['status']=='PASS'
    assert psi(np.arange(30),np.arange(30))['status']=='PASS'
    assert audit_dataframe(df)['status']=='PASS'
    assert mutation_suite(df)['future_injection']['status']=='BLOCKED'
    a=seal_decision({'symbol':'X','action':'WAIT'}); b=seal_decision({'symbol':'X','action':'BUY'},a['record_hash'])
    assert verify_chain([a,b])['status']=='PASS'
    return 8
if __name__=='__main__': print(f'نجحت {run()} اختبارات 5.4')
