from qv_whale_hunter.مجدول_التحديث_التلقائي import *
from qv_whale_hunter.منسق_التحديث_الشامل import منسق_التحديث_الشامل
import tempfile,json
from pathlib import Path

def run():
    with tempfile.TemporaryDirectory() as d:
        m=منسق_التحديث_التلقائي(d); m.إضافة_مهمة("اختبار",10)
        assert m.المهام["اختبار"].مستحقة(20) and not m.المهام["اختبار"].مستحقة(0)
        assert m.تشغيل_مهمة("اختبار",lambda:{"قيمة":1},الآن=20)["نجح"]
        assert not m.تشغيل_مهمة("اختبار",lambda:1/0,الآن=30)["نجح"]
        p=m.حفظ_الحالة(); assert Path(p).exists()
        assert json.loads(Path(p).read_text(encoding="utf-8"))["الإنتاج_مصرح"] is False
        x=منسق_التحديث_الشامل(Path(d)/"all"); assert len(x.تشغيل_دورة_مراقبة())>=7
    return 6
if __name__=="__main__": print(f"نجح {run()} اختبارات 4.16")
