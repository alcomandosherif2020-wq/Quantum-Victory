from pathlib import Path
import json
import re

الجذر = Path(__file__).resolve().parent
الملفات_المستثناة = {"فاحص_العربية_العليا.py"}

# الكلمات اللاتينية المسموح بها فقط داخل الشيفرة البرمجية نفسها.
# الفحص هنا مخصص للنصوص الظاهرة للمستخدم والوثائق والبيانات الوصفية.
امتدادات_العرض = {".md", ".txt", ".json", ".csv"}

نمط_الحروف_اللاتينية = re.compile(r"[A-Za-z]")


def فحص_ملف(مسار):
    if مسار.name in الملفات_المستثناة or مسار.suffix.lower() not in امتدادات_العرض:
        return []
    try:
        النص = مسار.read_text(encoding="utf-8")
    except Exception:
        return [f"تعذر قراءة الملف: {مسار.relative_to(الجذر)}"]
    مخالفات = []
    for رقم, سطر in enumerate(النص.splitlines(), 1):
        if نمط_الحروف_اللاتينية.search(سطر):
            مخالفات.append(f"{مسار.relative_to(الجذر)}:{رقم}")
    return مخالفات


def فحص():
    المخالفات = []
    for مسار in الجذر.rglob("*"):
        if مسار.is_file() and "__pycache__" not in مسار.parts:
            المخالفات.extend(فحص_ملف(مسار))
    return المخالفات


if __name__ == "__main__":
    النتائج = فحص()
    التقرير = {
        "اسم_المنظومة": "كوانتوم فيكتوري",
        "نوع_الفحص": "فحص العربية في النصوص الظاهرة والوثائق",
        "عدد_المخالفات": len(النتائج),
        "المخالفات": النتائج[:500],
        "الحكم": "اجتاز الفحص" if not النتائج else "يحتاج إلى تعريب إضافي"
    }
    وجهة = الجذر / "تقرير_فحص_العربية_العليا.json"
    وجهة.write_text(json.dumps(التقرير, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(التقرير, ensure_ascii=False, indent=2))
