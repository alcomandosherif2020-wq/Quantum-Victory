from pathlib import Path
import re, json

ROOT = Path(__file__).resolve().parents[1]
IGNORE = {'.png','.jpg','.jpeg','.webp','.zip','.pyc'}

مسموح_استثناءات = {"sha256", "utf-8"}

def فحص_ملف(مسار):
    if مسار.suffix.lower() in IGNORE:
        return []
    try:
        نص = مسار.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return []
    النتائج=[]
    for رقم, سطر in enumerate(نص.splitlines(),1):
        if re.search(r'[A-Za-z]', سطر):
            النتائج.append({"السطر":رقم,"النص":سطر[:300]})
    return النتائج

def فحص_الأسماء():
    النتائج=[]
    for مسار in ROOT.rglob('*'):
        if مسار.is_file() and re.search(r'[A-Za-z]', مسار.name):
            النتائج.append(str(مسار.relative_to(ROOT)))
    return النتائج

def تشغيل():
    ملفات={}
    for مسار in ROOT.rglob('*'):
        if مسار.is_file():
            مواضع=فحص_ملف(مسار)
            if مواضع:
                ملفات[str(مسار.relative_to(ROOT))]=مواضع
    تقرير={
        "اسم_المنظومة":"كوانتوم فيكتوري",
        "الغرض":"قياس اكتمال التعريب ومنع إدخال نصوص أجنبية جديدة",
        "عدد_الملفات_ذات_نصوص_لاتينية":len(ملفات),
        "عدد_المواضع":sum(len(v) for v in ملفات.values()),
        "الأسماء_غير_العربية":فحص_الأسماء(),
        "المواضع":ملفات
    }
    (ROOT/'تقرير_التعريب_الشامل_٥_٨.json').write_text(json.dumps(تقرير,ensure_ascii=False,indent=2),encoding='utf-8')
    return تقرير

if __name__ == '__main__':
    تقرير=تشغيل()
    print(json.dumps({"عدد_الملفات":تقرير["عدد_الملفات_ذات_نصوص_لاتينية"],"عدد_المواضع":تقرير["عدد_المواضع"]},ensure_ascii=False))
