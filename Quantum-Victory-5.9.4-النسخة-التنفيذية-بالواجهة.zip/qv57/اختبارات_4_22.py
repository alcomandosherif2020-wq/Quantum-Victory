# -*- coding: utf-8 -*-
from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import datetime, timezone, timedelta
import json, sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from qv_whale_hunter.مراقب_الجاهزية_الحي import مراقب_الجاهزية_الحي
from qv_whale_hunter.لوحة_التشغيل_الحية import لوحة_التشغيل_الحية
from qv_whale_hunter.محرك_التشغيل_الموحد import محرك_التشغيل_الموحد

def run():
  with TemporaryDirectory() as td:
    p=Path(td)/'حالة.json'; m=مراقب_الجاهزية_الحي(p); now=datetime.now(timezone.utc)
    m.بناء_اللقطة({'مصدر':{'الحالة':'نجح'}},{'السوق':{'وقت':(now-timedelta(seconds=2)).isoformat(),'حد_العمر_ثانية':120}},[],{'التحليل':True})
    e=محرك_التشغيل_الموحد(); e.إضافة_مرحلة('اختبار',lambda x:x)
    d=لوحة_التشغيل_الحية(m,e).لقطة()
    assert d['الإنتاج_مصرح'] is False
    assert d['المراقب']['آخر_لقطة']['جاهزية_المعالجة'] is True
    assert d['المحرك']['الإنتاج_مصرح'] is False
    assert 'رسالة_السلامة' in d
    raw=json.dumps(d,ensure_ascii=False); assert 'مصرح' in raw
  return 4
if __name__=='__main__': print(f'نجحت {run()} اختبارات الإصدار 4.22')
