# -*- coding: utf-8 -*-
"""واجهة عربية مرتبطة بمخرجات المحرك العالمي الموحد؛ لا تدعي اتصالاً حياً بلا دليل."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from datetime import datetime, timezone
import json, os, sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

ROOT=Path(__file__).resolve().parents[1]
HTML='''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>كوانتوم فيكتوري — المركز العالمي</title><style>body{font-family:Tahoma,Arial,sans-serif;background:#07111f;color:#eef;margin:0;padding:18px}.رأس,.بطاقة{background:#102038;border:1px solid #28415f;border-radius:18px;padding:18px}.شبكة{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin-top:14px}.قيمة{font-size:23px;font-weight:bold;margin-top:6px}.مغلق{color:#ffcf70}.آمن{color:#8ee6a8}pre{white-space:pre-wrap;word-break:break-word;line-height:1.5}button{padding:10px 14px;border:0;border-radius:10px;cursor:pointer}</style></head><body><div class="رأس"><h1>كوانتوم فيكتوري للتحليل الفني والكمي للبورصة المصرية</h1><div id="زمن">—</div><p id="حالة" class="مغلق">الإنتاج مقفل. الواجهة لا تعتبر البيانات حية إلا إذا ثبت اتصال المصدر.</p><button onclick="تحديث()">تحديث الآن</button></div><div id="بطاقات" class="شبكة"></div><div class="بطاقة"><h2>آخر بطاقة سهم</h2><pre id="تقرير">لا توجد بطاقة بعد.</pre></div><script>async function تحديث(){try{let r=await fetch('/api/الحالة',{cache:'no-store'}),d=await r.json();document.getElementById('زمن').textContent='آخر تحديث للواجهة: '+d.وقت_الواجهة;let t=d.آخر_تقرير||{};let b=[['الرمز',t.الرمز||'—'],['الحالة',t.الحالة||'—'],['التوصية',t.التوصية||'—'],['الإنتاج',t.الإنتاج_مصرح?'مصرح':'مقفل'],['مصدر البيانات',t.حالة_المصادر?.اسم||'غير محدد'],['درجة الأدلة',t.درجة_الأدلة??'غير متاحة']];document.getElementById('بطاقات').innerHTML=b.map(x=>`<div class="بطاقة"><div>${x[0]}</div><div class="قيمة">${x[1]}</div></div>`).join('');document.getElementById('حالة').textContent=d.اتصال_حي_مثبت?'اتصال حي مثبت من المصدر.':'الإنتاج مقفل؛ لا يوجد اتصال حي مثبت في هذه اللحظة.';document.getElementById('تقرير').textContent=JSON.stringify(t,null,2)}catch(e){document.getElementById('تقرير').textContent='تعذر قراءة الحالة: '+e}}تحديث();setInterval(تحديث,10000)</script></body></html>'''

def _قراءة_آخر_تقرير():
    candidates=sorted((ROOT/'تقارير_كوانتوم').glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True) if (ROOT/'تقارير_كوانتوم').exists() else []
    if not candidates:return {}
    try:return json.loads(candidates[0].read_text(encoding='utf8'))
    except Exception:return {}

def _حالة():
    r=_قراءة_آخر_تقرير()
    return {'وقت_الواجهة':datetime.now(timezone.utc).isoformat(),'الإنتاج_مصرح':False,'اتصال_حي_مثبت':bool(r.get('حالة_المصادر',{}).get('متصل') is True and r.get('حالة_المصادر',{}).get('حي_موثق') is True),'آخر_تقرير':r}

class معالج(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith('/api/الحالة'):
            body=json.dumps(_حالة(),ensure_ascii=False).encode(); self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(body); return
        body=HTML.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(body)
    def log_message(self,*args):pass
if __name__=='__main__':
    HTTPServer((os.getenv('QV_UI_HOST','127.0.0.1'),int(os.getenv('QV_UI_PORT','8765'))),معالج).serve_forever()
