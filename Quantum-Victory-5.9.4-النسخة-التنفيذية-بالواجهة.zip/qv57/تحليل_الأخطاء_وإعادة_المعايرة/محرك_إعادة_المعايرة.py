from __future__ import annotations
from dataclasses import dataclass
from math import isfinite

@dataclass
class نتيجة_المعايرة:
    عدد_المشاهدات: int
    متوسط_الخطأ: float
    الانحياز: float
    معامل_المعايرة: float
    مؤهل_للاستخدام: bool
    ملاحظة: str


def إعادة_المعايرة(توقعات, نتائج, حد_العينة=100, حد_الخطأ=0.15):
    if len(توقعات) != len(نتائج):
        raise ValueError("يجب تساوي عدد التوقعات والنتائج")
    n = len(توقعات)
    if n == 0:
        return نتيجة_المعايرة(0, 1.0, 0.0, 1.0, False, "لا توجد بيانات")
    أخطاء = [float(p) - float(y) for p, y in zip(توقعات, نتائج)]
    if not all(isfinite(x) for x in أخطاء):
        raise ValueError("توجد قيمة غير صالحة")
    متوسط_الخطأ = sum(abs(x) for x in أخطاء) / n
    الانحياز = sum(أخطاء) / n
    معامل = max(0.0, min(1.0, 1.0 - متوسط_الخطأ))
    مؤهل = n >= حد_العينة and متوسط_الخطأ <= حد_الخطأ
    ملاحظة = "مؤهل بعد تحقق خارج العينة" if مؤهل else "غير مؤهل؛ لا تُحوّل الدرجة إلى احتمال"
    return نتيجة_المعايرة(n, متوسط_الخطأ, الانحياز, معامل, مؤهل, ملاحظة)
