# -*- coding: utf-8 -*-
from datetime import datetime, timezone, timedelta
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'qv_whale_hunter'))
from qv_whale_hunter.سجل_تتبع_الأدلة import سجل_تتبع_الأدلة

def run():
    now=datetime.now(timezone.utc)
    s=سجل_تتبع_الأدلة()
    a=s.إضافة(الاسم='إغلاق COMI', المصدر='مصدر_اختباري_مصرح', النوع='سعر_يومي', البيانات={'الإغلاق':1}, وقت_المعلومة=now.isoformat(), حد_العمر_بالثواني=60)
    assert len(a['البصمة'])==64
    q=s.تقييم(now.isoformat())
    assert q['عدد_الأدلة']==1 and len(q['صالحة'])==1 and not q['الموانع']
    s2=سجل_تتبع_الأدلة(); s2.إضافة(الاسم='دليل قديم', المصدر='مصدر_اختباري_مصرح', النوع='سعر_يومي', البيانات={'الإغلاق':1}, وقت_المعلومة=(now-timedelta(seconds=100)).isoformat(), حد_العمر_بالثواني=60)
    assert s2.تقييم(now.isoformat())['الموانع']
    s3=سجل_تتبع_الأدلة(); s3.إضافة(الاسم='دليل مستقبلي', المصدر='مصدر_اختباري_مصرح', النوع='خبر', البيانات={}, متاح_قبل_القرار=False)
    assert 'تسرب زمني: دليل مستقبلي' in s3.تقييم(now.isoformat())['الموانع']
    s4=سجل_تتبع_الأدلة(); s4.إضافة(الاسم='دليل غير معتمد', المصدر='مصدر غير معتمد', النوع='سعر', البيانات={}, حالة_المصدر='غير_موثق')
    assert s4.حزمة_التدقيق(now.isoformat())['جاهز_للقرار'] is False
    return 4
if __name__=='__main__': print(f'نجحت {run()} اختبارات الإصدار 4.25')
