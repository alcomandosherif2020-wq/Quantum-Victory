from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json

@dataclass
class سجل_نتيجة:
    المعرف: str
    الزمن: str
    النموذج: str
    القرار: str
    النتيجة: str
    درجة_الثقة: float
    نتيجة_لاحقة: float | None = None
    سبب_الخطأ: str | None = None

class ذاكرة_تاريخية:
    def __init__(self, المسار):
        self.المسار = Path(المسار)
        self.السجلات = []
        if self.المسار.exists():
            self.تحميل()

    def إضافة(self, سجل: سجل_نتيجة):
        if not 0 <= سجل.درجة_الثقة <= 1:
            raise ValueError("درجة الثقة يجب أن تكون بين صفر وواحد")
        self.السجلات.append(sجل := سجل)
        self.حفظ()

    def تحميل(self):
        البيانات = json.loads(self.المسار.read_text(encoding="utf-8"))
        self.السجلات = [سجل_نتيجة(**س) for س in البيانات]

    def حفظ(self):
        self.المسار.parent.mkdir(parents=True, exist_ok=True)
        self.المسار.write_text(json.dumps([asdict(س) for س in self.السجلات], ensure_ascii=False, indent=2), encoding="utf-8")

    def ملخص_الأخطاء(self):
        أخطاء = [س for س in self.السجلات if س.سبب_الخطأ]
        حسب_السبب = {}
        for س in أخطاء:
            حسب_السبب[س.سبب_الخطأ] = حسب_السبب.get(س.سبب_الخطأ, 0) + 1
        return {"إجمالي_السجلات": len(self.السجلات), "إجمالي_الأخطاء": len(أخطاء), "حسب_السبب": حسب_السبب}
