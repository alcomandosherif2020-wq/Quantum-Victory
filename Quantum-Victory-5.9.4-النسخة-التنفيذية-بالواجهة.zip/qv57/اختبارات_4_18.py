# -*- coding: utf-8 -*-
"""اختبار توافق الإصدار 4.18 — يستخدم التنفيذ المعتمد داخل الحزمة."""
import tempfile
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from qv_whale_hunter.مربط_المصادر_التلقائي import مربط_المصادر_التلقائي, تعريف_مصدر


def run():
    with tempfile.TemporaryDirectory() as td:
        m = مربط_المصادر_التلقائي(Path(td))
        m.تسجيل_مصدر(تعريف_مصدر('اختبار', 'اختبار', 1), lambda: {'قيمة': 1})
        assert m.تشغيل('اختبار', 0)['الحالة'] == 'نجح'
        m2 = مربط_المصادر_التلقائي(Path(td))
        assert m2.states['اختبار'].عدد_النجاح == 1

        calls = {'n': 0}
        def bad():
            calls['n'] += 1
            raise RuntimeError('انقطاع')
        m.تسجيل_مصدر(تعريف_مصدر('فاشل', 'اختبار', 1, الحد_الأقصى_للفشل=2), bad)
        assert m.تشغيل('فاشل', 0)['الحالة'] == 'فشل'
        assert m.تشغيل('فاشل', 1)['الحالة'] == 'متراجع'
        assert m.تشغيل('فاشل', 5)['الحالة'] == 'قاطع_دائرة'
        assert calls['n'] == 2
    return 6


if __name__ == '__main__':
    print(f'نجحت {run()} اختبارات الإصدار 4.18')
