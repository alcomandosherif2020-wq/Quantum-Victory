from datetime import datetime
from zoneinfo import ZoneInfo
from qv_whale_hunter.egid_feed_adapter import EGIDConfig, market_session_open, _records

def test_weekend_closed():
    dt=datetime(2026,9,5,11,0,tzinfo=ZoneInfo('Africa/Cairo'))
    assert market_session_open(dt) is False

def test_regular_session_open():
    dt=datetime(2026,9,6,11,0,tzinfo=ZoneInfo('Africa/Cairo'))
    assert market_session_open(dt) is True

def test_records_nested():
    assert _records({'data': {'items': [{'symbol':'COMI'}]}}) == [{'symbol':'COMI'}]

def test_env_defaults(monkeypatch):
    monkeypatch.delenv('QV_EGID_BASE_URL', raising=False)
    c=EGIDConfig.from_env()
    assert c.base_url == 'https://ticker.egidegypt.com'
