import pandas as pd
from qv_whale_hunter.autonomous_service import AutonomousQVService

def test_service_batch_without_telegram():
    s=AutonomousQVService('http://127.0.0.1:9',out_dir='QV-AUTO-TEST')
    rec=[{'symbol':'AAA','timestamp':'2026-09-04 10:00','price':100,'volume':1000,'bid':99,'ask':101,'turnover':100000}]
    out=s.process_batch(rec)
    assert out['rows']==1 and out['production_approved'] is False
