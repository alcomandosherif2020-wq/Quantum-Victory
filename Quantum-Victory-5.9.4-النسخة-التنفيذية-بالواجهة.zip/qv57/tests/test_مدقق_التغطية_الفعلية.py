import pandas as pd
from qv_whale_hunter.مدقق_التغطية_الفعلية import *

def test_good_daily():
    df=pd.DataFrame({'Date':['2026-09-03'],'Open':[10],'High':[11],'Low':[9],'Close':[10.5],'Volume':[100]})
    r=فحص_صفوف_السعر('COMI.CA','ياهو',df,'اختبار')
    assert r.الحالة=='مُثبت' and r.آخر_تاريخ=='2026-09-03'

def test_bad_ohlc():
    df=pd.DataFrame({'Date':['2026-09-03'],'Open':[12],'High':[11],'Low':[9],'Close':[10],'Volume':[100]})
    assert فحص_صفوف_السعر('COMI','مصدر',df).الحالة=='فشل_الفحص'

def test_missing():
    df=pd.DataFrame({'Date':['2026-09-03'],'Close':[10]})
    assert فحص_صفوف_السعر('COMI','مصدر',df).الحالة=='بيانات_ناقصة'

def test_report():
    r=بناء_تقرير_التغطية(['COMI'],[{'الرمز':'COMI.CA','المصدر':'ياهو','الحالة':'مُثبت','عدد_السجلات':20}])
    assert r['الملخص'][0]['مصادر_مُثبتة']==1
