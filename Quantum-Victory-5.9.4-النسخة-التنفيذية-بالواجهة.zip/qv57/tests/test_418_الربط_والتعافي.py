import sys, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from qv_whale_hunter.مربط_المصادر_التلقائي import *

def test_success_and_persistence(tmp_path):
    p=tmp_path/'state'; m=مربط_المصادر_التلقائي(p)
    m.تسجيل_مصدر(تعريف_مصدر('س','اختبار',10),lambda:{'ok':True})
    assert m.تشغيل('س',0)['الحالة']=='نجح'
    n=مربط_المصادر_التلقائي(p)
    assert n.states['س'].عدد_النجاح==1

def test_backoff_and_breaker(tmp_path):
    m=مربط_المصادر_التلقائي(tmp_path)
    m.تسجيل_مصدر(تعريف_مصدر('ف','اختبار',1,الحد_الأقصى_للفشل=2),lambda:1/0)
    assert m.تشغيل('ف',0)['الحالة']=='فشل'
    assert m.تشغيل('ف',1)['الحالة']=='متراجع'
    assert m.تشغيل('ف',5)['الحالة']=='قاطع_دائرة'

def test_recovery(tmp_path):
    state={'ok':False}
    def f():
        if not state['ok']: raise RuntimeError('down')
        return {'ok':True}
    m=مربط_المصادر_التلقائي(tmp_path)
    m.تسجيل_مصدر(تعريف_مصدر('ر','اختبار',1,الحد_الأقصى_للفشل=1),f)
    m.تشغيل('ر',0); state['ok']=True
    assert m.تشغيل('ر',1810)['الحالة']=='نجح'

def test_stale_and_conflict_block():
    m=مربط_المصادر_التلقائي('/tmp/qv418test')
    m.تسجيل_مصدر(تعريف_مصدر('س','اختبار',10,أقصى_تأخير_ثوان=120))
    assert m.فحص_التعارض([10,10.0001],1e-6)['صالح_للتنبيه'] is False
    assert m.فحص_التقادم('س',0,1000)['صالح_للتنبيه'] is False
