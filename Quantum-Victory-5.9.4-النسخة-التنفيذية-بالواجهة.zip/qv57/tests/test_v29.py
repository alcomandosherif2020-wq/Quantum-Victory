import pandas as pd
from qv_whale_hunter.shadow_mode import build_shadow_ledger, shadow_evaluation, drift_check
from qv_whale_hunter.v29_pipeline import run

def test_shadow_is_deterministic_and_non_predictive():
    d=pd.DataFrame({'decision_date':['2026-01-01','2026-01-02'],'symbol':['A','A'],'scenario_score':[2,-2]})
    l,s=build_shadow_ledger(d)
    assert s['status']=='PASS' and l['shadow_only'].all()
    assert list(l.shadow_action)==['LONG_BIAS','BEARISH_BIAS']

def test_shadow_without_outcomes_is_observation_only():
    d=pd.DataFrame({'decision_date':['2026-01-01'],'symbol':['A'],'scenario_score':[1]})
    l,_=build_shadow_ledger(d)
    assert shadow_evaluation(l)['status']=='OBSERVATION_ONLY'



def test_shadow_preserves_outcome_for_posthoc_evaluation_only():
    d=pd.DataFrame({'decision_date':['2026-01-01','2026-01-02'],'symbol':['A','A'],'scenario_score':[2,-2],'outcome_binary':[1,0]})
    l,s=build_shadow_ledger(d)
    assert s['outcome_embedded_for_evaluation'] is True
    assert shadow_evaluation(l)['status']=='PASS'
    assert list(l.shadow_action)==['LONG_BIAS','BEARISH_BIAS']

def test_drift_blocks_large_shift():
    a=pd.DataFrame({'scenario_score':[1,1,1]}); b=pd.DataFrame({'scenario_score':[0,0,0]})
    assert drift_check(a,b)['status']=='BLOCKED_DRIFT'

def test_v29_production_blocked_by_default(tmp_path):
    d=pd.DataFrame({'decision_date':pd.date_range('2026-01-01',periods=3),'symbol':['A']*3,'scenario_score':[1,0,-1],
                    'model':['champion']*3,'oos_return':[0.01]*3})
    cert,_=run(d,tmp_path)
    assert cert['production_approved'] is False
    assert cert['production_gate']['status']=='BLOCKED'
