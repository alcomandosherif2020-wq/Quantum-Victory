import pandas as pd
from qv_whale_hunter.مركز_القنص_المحادثي import مركز_القنص_المحادثي

def test_ready_state_before_open():
    r=مركز_القنص_المحادثي().تجهيز(); assert r["جاهزية_القناص"] is True; assert r["الإنتاج_مصرح"] is False; assert r["ادعاء_هوية"] is False; assert r["احتمال"] is False

def test_chat_commands_are_stable():
    c=مركز_القنص_المحادثي(); assert c.أمر_جاهز()=="جهز قناص الحيتان"; assert c.أمر_تشغيل()=="شغل قناص الحيتان والسيولة"; assert c.أمر_تحديث()=="حدث القناص"; assert c.أمر_مسح()=="امسح السيولة"

def test_snapshot_run_keeps_safety():
    ts=pd.date_range("2026-09-07 10:00",periods=25,freq="min"); rows=[]; vol=[100]*20+[300,450,700,900,1200]; price=100.0
    for i,tm in enumerate(ts):
        if i>=20: price+=.1
        rows.append({"symbol":"COMI","timestamp":tm,"price":price,"volume":vol[i]})
    r=مركز_القنص_المحادثي().تشغيل_لقطة(pd.DataFrame(rows)); s=r["قواعد_السلامة"]; assert s["ادعاء_هوية"] is False and s["احتمال"] is False and s["هدف_سعري_ثابت"] is False and s["الإنتاج_مصرح"] is False

def test_empty_snapshot_is_blocked_not_guessed():
    r=مركز_القنص_المحادثي().تشغيل_لقطة(pd.DataFrame()); assert r["الحالة"]=="محجوب_لعدم_وجود_بيانات"; assert r["الإنتاج_مصرح"] is False
