import pandas as pd
from qv_whale_hunter.regime_stability import assign_regime,regime_metrics,stability_audit
from qv_whale_hunter.v27_pipeline import run

def test_regime_assignment_is_deterministic():
    d=pd.DataFrame({'ret1':[-2,-1,0,1,2],'range':[1,1,1,1,2]})
    assert assign_regime(d).tolist()==assign_regime(d).tolist()

def test_insufficient_regime_coverage_blocks():
    m=pd.DataFrame({'regime':['UP','DOWN'],'n_evaluable':[10,40],'hit_rate':[.5,.6]})
    assert stability_audit(m,min_regime_samples=30,min_coverage=3)['status'].startswith('BLOCKED')

def test_v27_certificate_never_approves(tmp_path):
    d=pd.DataFrame({'session_date':pd.date_range('2025-01-01',periods=10),'ret1':[0]*10,'range':[1]*10,'scenario_score':[1]*10})
    cert,_,_=run(d,tmp_path,min_regime_samples=30,min_coverage=3)
    assert cert['production_approved'] is False
    assert cert['score_is_not_probability'] is True
