import pandas as pd
from qv_whale_hunter.calibration import empirical_oos_calibration
from qv_whale_hunter.production_gate import final_production_gate

def test_calibration_blocks_small_sample():
    r=empirical_oos_calibration([1,2,3],[0,1,1],min_samples=10)
    assert r['status'].startswith('BLOCKED')

def test_gate_blocks_until_all_checks_pass():
    r=final_production_gate(real_egx=True,leakage_clean=True,oos_pass=True,walk_forward_pass=True,sample_pass=True,regime_pass=True,calibration_pass=True,champion_pass=True,shadow_pass=False)
    assert r['production_approved'] is False
