import pandas as pd
from qv_whale_hunter.fusion_core import build_fusion
from qv_whale_hunter.v39_pipeline import run

def _df():
    rows=[]
    for i,s in enumerate(['COMI','EFIH','SWDY','TALM']):
        for m in range(6):
            rows.append({'symbol':s,'timestamp':f'2026-09-04 10:0{m}:00','price':100+i+m*.1,
                         'volume':1000+i*100+m*10,'bid_size':9000 if s=='COMI' else 1000,
                         'ask_size':1000 if s=='COMI' else 9000,'trade_count':50 if s=='COMI' else 5,
                         'turnover':100000+i*1000,'sector':'BANKS' if s=='COMI' else 'OTHER'})
    return pd.DataFrame(rows)

def test_network_fusion_outputs_and_separation():
    x=_df();
    # pre-score directly enough for fusion contract
    x['sniper_score']=[80 if s=='COMI' else 30 for s in x.symbol]
    x['signal']=['HIGH_PRIORITY_BUY_FLOW' if s=='COMI' else 'NO_ALERT' for s in x.symbol]
    x['buy_pressure']=[.85 if s=='COMI' else .5 for s in x.symbol]
    x['confirmation_state']=['CONFIRMED_FLOW' if s=='COMI' else 'WATCH' for s in x.symbol]
    x['confirmation_ready']=[True if s=='COMI' else False for s in x.symbol]
    x['false_whale_trap_score']=0
    f,r,n=build_fusion(x,top_n=4)
    assert not f.empty and not r.empty and r.iloc[0].symbol=='COMI'
    assert r.iloc[0].fusion_score<=100
    assert r.iloc[0].probability != r.iloc[0].fusion_score
    assert bool(r.iloc[0].identity_claim) is False

def test_v39_pipeline_runs(tmp_path):
    r,*_=run(_df(),out_dir=tmp_path,top_n=3,lookback=5,min_acceleration=-1)
    assert r['version']=='3.9.0' and r['production_approved'] is False
