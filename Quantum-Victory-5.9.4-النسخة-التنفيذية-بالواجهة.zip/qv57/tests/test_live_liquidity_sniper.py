import pandas as pd
from qv_whale_hunter.live_liquidity_sniper import scan

def test_burst_detected():
    ts=pd.date_range('2026-09-07 10:00',periods=25,freq='min')
    rows=[]; vol=[100]*20+[300,450,700,900,1200]
    price=100
    for i,t in enumerate(ts):
        price += .05 if i>=20 else 0
        rows.append({'symbol':'COMI','timestamp':t,'price':price,'volume':vol[i]})
    r=scan(pd.DataFrame(rows),lookback=20,min_rvol=1.8,min_acceleration=0.1)
    assert (r.signal=='HIGH_PRIORITY_BUY_FLOW').any() or (r.signal=='BUY_FLOW_WATCH').any()

def test_no_identity_or_probability():
    df=pd.DataFrame({'symbol':['COMI']*6,'timestamp':pd.date_range('2026-09-07 10:00',periods=6,freq='min'),'price':[100,100,100.1,100.2,100.3,100.4],'volume':[100]*6})
    r=scan(df,lookback=5)
    assert r.identity_claim.eq(False).all(); assert r.probability.isna().all(); assert r.fixed_price_target.isna().all()
