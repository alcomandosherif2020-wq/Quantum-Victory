import pandas as pd
from qv_whale_hunter.حارس_سلامة_البيانات_الشامل import فحص_الشموع
from qv_whale_hunter.حاكم_المنظومة_العالمية import حاكم_المنظومة_العالمية
from qv_whale_hunter.v29_pipeline import run as run_v29

def df(close=92):
    return pd.DataFrame([{"الرمز":"TEST","التاريخ":"2026-09-03","الافتتاح":95,"الأعلى":95,"الأدنى":90,"الإغلاق":close,"الحجم":1000}])

def test_previous_close_can_exceed_day_high():
    x=df(); x["إغلاق_سابق"]=[100]
    r=فحص_الشموع(x,دلالة_الافتتاح="افتتاح_الجلسة")
    assert r["status"] in {"مُثبت","تحذير"}

def test_unknown_open_is_not_used_as_session_open():
    x=df(); x["الافتتاح"]=[100]
    r=فحص_الشموع(x,دلالة_الافتتاح="إغلاق_سابق")
    assert r["status"] in {"مُثبت","تحذير"}

def test_global_facade_runs():
    r=حاكم_المنظومة_العالمية().تحليل_سهم(df(),دلالة_الافتتاح="افتتاح_الجلسة")
    assert r["الحالة"]=="جاهز_للمراجعة"
    assert r["احتمال"] is None and r["سعر_مستهدف"] is None and r["إنتاج_مصرح"] is False
