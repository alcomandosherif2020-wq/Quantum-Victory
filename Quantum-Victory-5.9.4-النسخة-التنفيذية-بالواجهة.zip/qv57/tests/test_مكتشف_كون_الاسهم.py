from qv_whale_hunter.مكتشف_كون_الاسهم import *

def test_yahoo_symbol():
    assert رموز_ياهو('COMI') == 'COMI.CA'
    assert رموز_ياهو('COMI.CA') == 'COMI.CA'

def test_normalization():
    assert توحيد_الرمز('COMI.CA') == 'COMI'
    assert توحيد_الرمز('EGS60121C018') == 'COMI'

def test_matrix_and_summary():
    m=بناء_مصفوفة_التغطية(['COMI','ABUK'])
    assert len(m) == 2 * len(المصادر)
    s=ملخص_التغطية(m)
    assert set(s['الرمز_الموحد']) == {'COMI','ABUK'}
    assert int(s.loc[s['الرمز_الموحد']=='COMI','مصادر_يومية'].iloc[0]) >= 1

def test_no_production_claim():
    r=فحص_التغطية(['COMI'])
    assert 'إثباتًا' in r['تنبيه']
