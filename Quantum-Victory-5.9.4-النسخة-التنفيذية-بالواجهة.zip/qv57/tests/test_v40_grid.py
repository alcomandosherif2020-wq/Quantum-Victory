import pandas as pd
from qv_whale_hunter.distributed_grid import build_grid

def test_grid_detects_multi_node_flow():
    t=pd.date_range('2026-09-03 10:00',periods=3,freq='min')
    rows=[]
    for sym,score in [('A',82),('B',78),('C',40)]:
        for i,ts in enumerate(t):
            rows.append({'symbol':sym,'timestamp':ts,'fusion_score':score,'sniper_score':score-5,
                         'buy_pressure':.72 if sym!='C' else .48,'book_imbalance':.2,'sector':'S1' if sym!='C' else 'S2'})
    df=pd.DataFrame(rows); grid,snap=build_grid(df)
    assert not grid.empty and snap.iloc[0]['symbols']==3
    assert (grid.grid_state=='GRID_ARMED_FLOW').any()
    assert grid.probability.isna().all()
    assert grid.identity_claim.eq(False).all()
