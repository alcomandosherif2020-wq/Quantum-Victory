import pandas as pd
from qv_whale_hunter.false_whale import apply_false_whale_defense

def test_clean_footprint_passes():
    x=pd.DataFrame([{'flow_intensity':70,'confirmation_score':75,'uncertainty_score':10,'whale_radar_score':80,'buy_event_count':4,'sell_event_count':1,'close_loc':0.8,'breakout_volume':1,'failed_breakout':0}])
    y=apply_false_whale_defense(x)
    assert y.iloc[0].defense_action=='PASS'

def test_failed_breakout_can_block():
    x=pd.DataFrame([{'flow_intensity':90,'confirmation_score':25,'uncertainty_score':70,'whale_radar_score':75,'buy_event_count':1,'sell_event_count':5,'close_loc':0.2,'breakout_volume':1,'failed_breakout':1}])
    y=apply_false_whale_defense(x)
    assert y.iloc[0].defense_action=='BLOCK'
