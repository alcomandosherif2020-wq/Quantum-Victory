import pandas as pd
from qv_whale_hunter.egx_evidence_adapter import normalize_egx,reconcile_egx

def base():
 return pd.DataFrame({'ticker':['COMI','COMI'],'date':['2026-01-04','2026-01-05'],'open':[10,11],'high':[11,12],'low':[9,10],'close':[10.5,11.5],'vol':[100,120]})

def test_alias_normalization():
 x=normalize_egx(base()); assert list(x.columns)[:2]==['symbol','session_date']; assert x.symbol.iloc[0]=='COMI'

def test_empty_is_blocked():
 r,_=reconcile_egx(pd.DataFrame()); assert r.status=='BLOCKED'

def test_missing_calendar_is_reported_not_fabricated():
 r,x=reconcile_egx(base(),session_calendar=['2026-01-04','2026-01-05','2026-01-06']); assert r.missing_sessions==1; assert len(x)==2

def test_bad_universe_blocks():
 u=pd.DataFrame({'symbol':['COMI'],'start_date':['2027-01-01']})
 r,_=reconcile_egx(base(),universe_history=u); assert r.status=='BLOCKED'

def test_asof_blocks_future():
 r,_=reconcile_egx(base(),asof='2026-01-04'); assert r.status=='BLOCKED'
