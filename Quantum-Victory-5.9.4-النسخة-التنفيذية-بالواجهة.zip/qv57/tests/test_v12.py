import pandas as pd
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from qv_whale_hunter.v12_pipeline import run

p=Path(__file__).resolve().parent/'fixture.csv'
df=pd.read_csv(p)
# v1.1 fixture lacks canonical provenance; research adapter permits research-only mode.
report=run(df,Path(__file__).resolve().parent/'v12-run')
assert report['status']=='PASS'
assert report['production_approved'] is False
print('QV-WHALE-HUNTER v1.2 TEST: PASS')
