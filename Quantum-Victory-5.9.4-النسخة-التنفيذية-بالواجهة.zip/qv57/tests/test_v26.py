import pandas as pd
from qv_whale_hunter.oos_walk_forward import audit_information_set,make_splits,validate_splits,evidence_hash

def sample():
    d=pd.date_range('2026-01-01',periods=130,freq='D')
    return pd.DataFrame({'symbol':['AAA']*len(d),'session_date':d,'close':range(1,len(d)+1)})

def test_forbidden_future_fields_blocked():
    x=sample(); x['forward_return']=0.1
    assert audit_information_set(x)['status']=='BLOCKED_FUTURE_FIELDS'

def test_walk_forward_has_purge_embargo():
    s=make_splits(sample(),60,20,20,1,1)
    assert not s.empty
    assert all(pd.to_datetime(s.train_end)<pd.to_datetime(s.test_start))
    assert s.iloc[0].purge_sessions==1 and s.iloc[0].embargo_sessions==1

def test_split_audit_passes():
    s=make_splits(sample())
    assert validate_splits(s)['status']=='PASS'

def test_hash_deterministic():
    s=make_splits(sample())
    a=audit_information_set(sample())
    assert evidence_hash(s,a)==evidence_hash(s,a)
