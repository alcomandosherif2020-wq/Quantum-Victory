import pandas as pd
from qv_whale_hunter.validation_memory import chronological_walk_forward, build_memory, score_memory

def test_v13_walk_forward_is_chronological():
    dates=pd.date_range('2026-01-01',periods=120,freq='D')
    df=pd.DataFrame({'symbol':['AAA']*120,'session_date':dates,'close':range(100,220),'high':range(101,221),'low':range(99,219)})
    s=chronological_walk_forward(df,60,20,20)
    assert len(s)>0
    assert all(pd.to_datetime(s.test_start)>pd.to_datetime(s.train_end))

def test_v13_memory_and_metrics():
    ledger=pd.DataFrame([{'event_id':'WH-A-1','symbol':'A','session_date':'2026-01-01','sequence_state':'ACCUMULATION_SEQUENCE','direction':'BUY','horizon':1,'forward_return':0.05,'mfe':0.07,'mae':-0.01,'evidence_count':2,'evidence_json':'{}','false_signal_risk':0.1},{'event_id':'WH-A-2','symbol':'A','session_date':'2026-01-02','sequence_state':'ACCUMULATION_SEQUENCE','direction':'BUY','horizon':1,'forward_return':-0.02,'mfe':0.01,'mae':-0.03,'evidence_count':2,'evidence_json':'{}','false_signal_risk':0.2}])
    m=build_memory(ledger); s=score_memory(m)
    assert len(m)==2 and len(s)==1
    assert abs(float(s.iloc[0].hit_rate)-0.5)<1e-9
