from qv_whale_hunter.e2e_verification import *


def lock():
    return build_experiment_lock(dataset_sha256='a'*64, code_sha256='b'*64, config={'h': [1,3,5]}, seed=42)


def evidence(independent=True):
    return [{'gate': g, 'status': 'PASS', 'independent': independent, 'artifact_sha256': 'c'*64} for g in REQUIRED_ARTIFACTS]


def test_lock_round_trip():
    r = verify_experiment_lock(lock())
    assert r['status'] == 'PASS'


def test_lock_tamper_is_blocked():
    x = lock(); x['seed'] = 43
    assert verify_experiment_lock(x)['status'] == 'BLOCKED'


def test_all_independent_evidence_passes_contract():
    assert evaluate_evidence(evidence())['status'] == 'PASS'


def test_internal_evidence_cannot_be_called_independent():
    r = evaluate_evidence(evidence(independent=False))
    assert r['status'] == 'BLOCKED'
    assert 'oos' in r['non_independent']


def test_promotion_requires_explicit_approval():
    r = create_promotion_decision(evidence=evidence(), experiment_lock=lock(), production_approved=False)
    assert r['status'] == 'BLOCKED'


def test_promotion_can_only_pass_with_all_contracts_and_approval():
    approval = bool(1)
    r = create_promotion_decision(evidence=evidence(), experiment_lock=lock(), production_approved=approval)
    assert r['status'] == 'APPROVED'
