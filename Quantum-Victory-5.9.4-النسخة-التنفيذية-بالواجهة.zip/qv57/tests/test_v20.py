import json, pandas as pd
from pathlib import Path
from qv_whale_hunter.v20_pipeline import run

def test_v20_pipeline(tmp_path):
    df=pd.read_csv(Path(__file__).parent/'fixture.csv')
    rep=run(df,tmp_path)
    out=pd.read_csv(tmp_path/'QV-WHALE-V20-SCENARIO-FUSION-001.csv')
    assert rep['production_approved'] is False
    assert len(out)==len(df)
    assert out['probability'].isna().all()
    assert out['no_fixed_price_prediction'].astype(bool).all()
    assert out['identity_claim'].astype(bool).eq(False).all()
    assert (tmp_path/'QV-WHALE-V20-SCENARIO-CONTRACT-001.json').exists()
