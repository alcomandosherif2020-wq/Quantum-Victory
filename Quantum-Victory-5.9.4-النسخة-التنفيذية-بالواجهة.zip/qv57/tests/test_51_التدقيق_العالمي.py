import pandas as pd
from qv_whale_hunter.حاكم_المنظومة_العالمية import حاكم_المنظومة_العالمية
from qv_whale_hunter.تقرير_التدقيق_الشامل import مدقق_المنظومة

def sample():
    rows=[]
    for i in range(25):
        rows.append({'الرمز':'TEST','التاريخ':f'2026-08-{i+1:02d}','الافتتاح':100+i*0.1,'الأعلى':101+i*0.1,'الأدنى':99+i*0.1,'الإغلاق':100.5+i*0.1,'الحجم':1000+i*10})
    return pd.DataFrame(rows)

def test_global_facade_requires_explicit_open_semantics():
    r=حاكم_المنظومة_العالمية().تحليل_سهم(sample())
    assert r['الحالة']=='محجوب'

def test_global_facade_with_semantics():
    r=حاكم_المنظومة_العالمية().تحليل_سهم(sample(),دلالة_الافتتاح='افتتاح_الجلسة')
    assert r['الحالة']=='جاهز_للمراجعة'
    assert r['إنتاج_مصرح'] is False

def test_static_audit_no_critical():
    r=مدقق_المنظومة('.').run()
    assert not any(x['الخطورة']=='حرج' for x in r['الملاحظات'])
