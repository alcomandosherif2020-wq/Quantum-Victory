import pandas as pd
from qv_whale_hunter.lifecycle import build_lifecycle, summarize_lifecycles

def test_lifecycle_tracks_progression_without_future_data():
    df=pd.DataFrame([
      {'symbol':'AAA','session_date':'2026-01-01','flow_intensity':20,'institutional_flow_score':15,'confirmation_score':30,'uncertainty_score':10,'whale_size_class':'MICRO_FLOW','radar_direction':'BUY_SIDE','sequence_state':'NO_SEQUENCE','buy_event_count':1,'sell_event_count':0},
      {'symbol':'AAA','session_date':'2026-01-02','flow_intensity':55,'institutional_flow_score':40,'confirmation_score':50,'uncertainty_score':10,'whale_size_class':'SMALL_FLOW','radar_direction':'BUY_SIDE','sequence_state':'ACCUMULATION_SEQUENCE','buy_event_count':2,'sell_event_count':0},
      {'symbol':'AAA','session_date':'2026-01-03','flow_intensity':90,'institutional_flow_score':80,'confirmation_score':70,'uncertainty_score':10,'whale_size_class':'MEGA_WHALE','radar_direction':'BUY_SIDE','sequence_state':'ACCUMULATION_SEQUENCE','buy_event_count':4,'sell_event_count':0},
    ])
    x=build_lifecycle(df)
    assert list(x.lifecycle_phase)==['EMERGING','ACCUMULATING','CONFIRMED']
    assert x.lifecycle_episode_id.nunique()==1
    assert x.episode_started.iloc[0] is True or bool(x.episode_started.iloc[0])

def test_lifecycle_summary():
    df=pd.DataFrame([
      {'symbol':'AAA','session_date':'2026-01-01','flow_intensity':20,'whale_size_class':'MICRO_FLOW','radar_direction':'BUY_SIDE','lifecycle_episode_id':'QWL-1','lifecycle_phase':'EMERGING','phase_changed':False},
      {'symbol':'AAA','session_date':'2026-01-02','flow_intensity':80,'whale_size_class':'LARGE_WHALE','radar_direction':'BUY_SIDE','lifecycle_episode_id':'QWL-1','lifecycle_phase':'CONFIRMED','phase_changed':True},
    ])
    s=summarize_lifecycles(df)
    assert len(s)==1 and s.iloc[0].peak_size_class=='LARGE_WHALE'
