import pandas as pd
from pathlib import Path
from qv_whale_hunter.v21_pipeline import run

def test_v21_final_layer(tmp_path):
    df=pd.read_csv(Path(__file__).parent/'fixture.csv')
    rep=run(df,tmp_path)
    out=pd.read_csv(tmp_path/'QV-WHALE-V21-FINAL-RECOMMENDATION-EVIDENCE-001.csv')
    assert len(out)==len(df)
    assert rep['production_approved'] is False
    assert out['probability'].isna().all()
    assert out['fixed_price_target'].isna().all()
    assert out['identity_claim'].eq(False).all()
    assert out['human_risk_check_required'].eq(True).all()
