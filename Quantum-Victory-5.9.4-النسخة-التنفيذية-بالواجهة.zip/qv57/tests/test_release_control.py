from qv_whale_hunter.release_control import audit_gate_contract

def test_release_gate_contract_requires_all_gates():
    r=audit_gate_contract({'checks':{'oos':True},'production_approved':False})
    assert r['status']=='BLOCKED_INVALID_GATE_ARTIFACT'
    assert 'real_egx_qualification' in r['missing']

def test_release_gate_never_conflates_partial_evidence_with_approval():
    checks={k:True for k in ['real_egx_qualification','leakage_audit','oos','walk_forward','sample_size','regime_stability','oos_calibration','champion_challenger','shadow']}
    r=audit_gate_contract({'checks':checks,'production_approved':False})
    assert r['all_required_checks_true'] is True
    assert r['effective_production_approved'] is False
