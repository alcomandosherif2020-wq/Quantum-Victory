from qv_whale_hunter.مدقق_دلالة_الحقول import تحقق_دلالة_الحقول, تحقق_شمعة_جلسة

خريطة={'open':'session open','high':'session high','low':'session low','close':'session close','previous_close':'previous close'}

def test_إغلاق_أمس_قد_يكون_أعلى_من_قمة_اليوم():
    d=تحقق_دلالة_الحقول(خريطة); assert d.صالح
    r=تحقق_شمعة_جلسة({'open':95,'high':95,'low':90,'close':92,'previous_close':100},d)
    assert r.صالح

def test_افتتاح_جلسة_خارج_النطاق_يرفض():
    d=تحقق_دلالة_الحقول(خريطة); assert d.صالح
    r=تحقق_شمعة_جلسة({'open':100,'high':95,'low':90,'close':92,'previous_close':100},d)
    assert not r.صالح

def test_إغلاق_سابق_ليس_افتتاحاً():
    d=تحقق_دلالة_الحقول({'open':'previous close','high':'session high','low':'session low','close':'session close'})
    assert not d.صالح

def test_إغلاق_الجلسة_داخل_النطاق():
    d=تحقق_دلالة_الحقول(خريطة); assert d.صالح
    r=تحقق_شمعة_جلسة({'open':100,'high':105,'low':95,'close':96,'previous_close':100},d)
    assert r.صالح
