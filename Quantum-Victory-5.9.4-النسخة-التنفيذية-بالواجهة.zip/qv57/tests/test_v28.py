import numpy as np, pandas as pd
from qv_whale_hunter.robustness_gate import bootstrap_mean_ci, permutation_pvalue, compare_models, multiple_comparison_guard
from qv_whale_hunter.v28_pipeline import run

def test_bootstrap_is_deterministic():
    x=np.array([1,2,3,4,5.],float)
    assert bootstrap_mean_ci(x,n_boot=100,seed=7)==bootstrap_mean_ci(x,n_boot=100,seed=7)

def test_permutation_detects_strong_paired_edge():
    p=permutation_pvalue(np.ones(40),n_perm=500,seed=7)
    assert p < .05

def test_multiple_comparison_guard_controls_holm():
    r=multiple_comparison_guard([.001,.02,.9],alpha=.05)
    assert r['rejected']==2

def test_challenger_needs_real_oos_sample():
    d=pd.DataFrame({'model':['champion']*20+['challenger']*20,'oos_return':[0.0]*40})
    assert compare_models(d,min_oos_rows=100)['status'].startswith('BLOCKED')

def test_v28_never_approves(tmp_path):
    d=pd.DataFrame({'model':['champion']*120+['challenger']*120,'oos_return':[0.01]*120+[0.02]*120,
                    'ret1':[0]*240,'range':[1]*240,'scenario_score':[1]*240,'session_date':pd.date_range('2025-01-01',periods=240)})
    cert=run(d,tmp_path,min_oos_rows=100)
    assert cert['production_approved'] is False
