import json, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
run=root/'tests'/'run'; rep=json.loads((run/'REPORT.json').read_text())
assert rep['status']=='PASS' and rep['symbols_scored']==2
print('QV-WHALE-HUNTER TEST GATE: PASS')
