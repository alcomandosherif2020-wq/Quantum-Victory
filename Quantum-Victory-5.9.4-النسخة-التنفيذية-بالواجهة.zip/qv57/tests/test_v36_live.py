from qv_whale_hunter.live_feed_adapters import adapt_provider_records
from qv_whale_hunter.live_session_engine import LiveSessionEngine
def test_adapter():
 d=adapt_provider_records([{'ticker':'COMI','time':'2026-09-05T10:00:00','last':140,'qty':10000}],'X'); assert d.symbol.iloc[0]=='COMI' and d.volume.iloc[0]==10000
def test_safety():
 s=LiveSessionEngine(out_dir='/tmp/qv_test_live').snapshot(); assert s['identity_claim'] is False and s['production_approved'] is False
