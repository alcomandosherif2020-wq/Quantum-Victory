import pandas as pd
from qv_whale_hunter.محرك_التحليل_الفني import تحليل_فني

def test_التحليل_الفني():
    rows=[]
    for i in range(260):
        p=100+i*0.1
        rows.append({'التاريخ':f'2025-01-{1 if False else 1:02d}'})
    dates=pd.date_range('2025-01-01',periods=260,freq='D')
    df=pd.DataFrame({'التاريخ':dates,'الافتتاح':[100+i*.1 for i in range(260)],'الأعلى':[101+i*.1 for i in range(260)],'الأدنى':[99+i*.1 for i in range(260)],'الإغلاق':[100.5+i*.1 for i in range(260)],'الحجم':[1000+i for i in range(260)]})
    x,r=تحليل_فني(df)
    assert len(x)==260
    assert 'متوسط أسي 200' in x.columns
    assert r['الاتجاه'] in ('إيجابي','سلبي','متوازن')
