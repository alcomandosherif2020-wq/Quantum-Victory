import pandas as pd
from qv_whale_hunter.market_radar import build_market_radar

def test_market_radar_ranks_and_separates_direction():
    x=pd.DataFrame([
      {'symbol':'A','session_date':'2026-01-01','whale_size_class':'MEGA_WHALE','radar_strength':90,'defended_radar_score':90,'flow_intensity':90,'confirmation_score':80,'uncertainty_score':10,'false_whale_trap_score':5,'radar_direction':'BUY_SIDE'},
      {'symbol':'B','session_date':'2026-01-01','whale_size_class':'SMALL_FLOW','radar_strength':40,'defended_radar_score':40,'flow_intensity':40,'confirmation_score':40,'uncertainty_score':40,'false_whale_trap_score':10,'radar_direction':'SELL_SIDE'}])
    stock,market=build_market_radar(x)
    assert stock.iloc[0].radar_rank == 1
    assert set(stock.direction)=={'BUY_SIDE','SELL_SIDE'}
    assert market.iloc[0].market_flow_state=='BUY_DOMINANT'

def test_trap_reduces_strength():
    x=pd.DataFrame([{'symbol':'A','session_date':'2026-01-01','whale_size_class':'LARGE_WHALE','defended_radar_score':80,'flow_intensity':80,'confirmation_score':70,'uncertainty_score':10,'false_whale_trap_score':90,'radar_direction':'BUY_SIDE'}])
    stock,_=build_market_radar(x)
    assert stock.iloc[0].radar_strength < 80
