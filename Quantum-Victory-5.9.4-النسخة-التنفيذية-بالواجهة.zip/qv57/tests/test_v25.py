import pandas as pd
from qv_whale_hunter.historical_replay import replay_at, build_replay

def base():
    return pd.DataFrame([
      {'symbol':'AAA','session_date':'2026-01-02','eligibility_time':'2026-01-02 18:00','close':10,'fwd_ret_1':.2},
      {'symbol':'AAA','session_date':'2026-01-05','eligibility_time':'2026-01-05 18:00','close':11,'fwd_ret_1':.1},
      {'symbol':'AAA','session_date':'2026-01-06','eligibility_time':'2026-01-07 18:00','close':12,'fwd_ret_1':-.2},
    ])

def test_replay_excludes_future_and_outcomes():
    x=replay_at(base(),'2026-01-05 23:00')
    assert len(x)==2 and 'fwd_ret_1' not in x.columns

def test_replay_hash_deterministic():
    a,_=build_replay(base(),['2026-01-05 23:00'])
    b,_=build_replay(base(),['2026-01-05 23:00'])
    assert a.equals(b)

def test_replay_audit_counts_future_rows():
    _,audit=build_replay(base(),['2026-01-05 23:00'])
    assert audit['future_rows_excluded']==1
