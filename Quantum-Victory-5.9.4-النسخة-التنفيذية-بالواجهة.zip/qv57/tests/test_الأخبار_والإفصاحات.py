from qv_whale_hunter.الأخبار_والإفصاحات import جامع_الأخبار

HTML='''<html><body>
<a href="/news/1"><h4>شركة مثال (COMI.CA) تعلن نتائج أعمالها عن 6 أشهر</h4></a>
<a href="/news/2"><h4>شركة أخرى (ABCD.CA) قرارات مجلس إدارة الشركة</h4></a>
<a href="/news/3"><h4>تعاملات الداخليين والمساهمين الرئيسيين</h4></a>
</body></html>'''

def test_استخراج_وتصنيف_الأخبار():
    items=جامع_الأخبار().تحليل_نص(HTML)
    assert len(items)==3
    assert items[0].الرمز=='COMI.CA'
    assert items[0].التصنيف=='قوائم مالية'
    assert items[0].درجة_الأثر=='عالٍ'
    assert items[1].التصنيف=='مجلس إدارة'
    assert items[2].التصنيف=='أسهم خزينة وملكية'
    assert all(x.بصمة for x in items)
