import pandas as pd
from qv_whale_hunter.المحرك_العالمي_الموحد import المحرك_العالمي_الموحد

def test_engine_rejects_mixed_symbols():
    rows=[]
    for sym in ('AAA','BBB'):
        for i in range(1,4):
            rows.append({'الرمز':sym,'التاريخ':f'2026-08-0{i}','الافتتاح':100+i,'الأعلى':102+i,'الأدنى':99+i,'الإغلاق':101+i,'الحجم':1000})
    r=المحرك_العالمي_الموحد().تشغيل(pd.DataFrame(rows), دلالة_الافتتاح='افتتاح_الجلسة')
    assert r['الحالة']=='محجوب'
    assert 'المدخل يحتوي أكثر من سهم' in r['الأسباب'][0]
