import pandas as pd
from qv_whale_hunter.integrated_fusion import fuse_recommendation_and_whale,build_alert_payloads
from qv_whale_hunter.telegram_gateway import TelegramGateway
def test_corroboration():
 w=pd.DataFrame([{'symbol':'COMI','timestamp':'2026-09-04 10:00','network_state':'CONFIRMED_NETWORK_FLOW','propagation_score':88,'migration_direction':'INFLOW_NETWORK','false_whale_trap_score':10}]); r=pd.DataFrame([{'symbol':'COMI','recommendation_posture':'BULLISH_EVIDENCE','risk_level':'NORMAL'}]); x=fuse_recommendation_and_whale(w,r); assert x.iloc[0].integration_state=='BULLISH_EVIDENCE_CORROBORATED' and x.iloc[0].integration_probability is None
def test_trap():
 w=pd.DataFrame([{'symbol':'AAA','timestamp':'2026-09-04 10:00','network_state':'CONFIRMED_NETWORK_FLOW','propagation_score':95,'migration_direction':'INFLOW_NETWORK','false_whale_trap_score':85}]); assert fuse_recommendation_and_whale(w).iloc[0].integration_state=='BLOCKED_HIGH_TRAP_RISK'
def test_alert():
 w=pd.DataFrame([{'symbol':'AAA','timestamp':'2026-09-04 10:00','network_state':'CONFIRMED_NETWORK_FLOW','propagation_score':80,'migration_direction':'INFLOW_NETWORK','false_whale_trap_score':5}]); assert len(build_alert_payloads(fuse_recommendation_and_whale(w)))==1
def test_gateway():
 g=TelegramGateway(token=None,chat_id=None); assert not g.configured and not g.send('x')['sent']
