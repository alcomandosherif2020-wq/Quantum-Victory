import pandas as pd
from qv_whale_hunter.حارس_البيانات import حارس_البيانات

def test_السوق_مغلق_السبت():
    h=حارس_البيانات()
    t=pd.Timestamp('2026-09-05 12:00',tz='Africa/Cairo').to_pydatetime()
    assert h.حالة_الجلسة(t)['مفتوحة'] is False

def test_البيانات_الحديثة():
    h=حارس_البيانات(مهلة_البيانات=120)
    now=pd.Timestamp.now(tz='Africa/Cairo').tz_localize(None)
    df=pd.DataFrame({'timestamp':[now],'price':[10],'volume':[100]})
    assert h.فحص_الحداثة(df)['سليم'] is True

def test_المصدر_يتوقف_بعد_ثلاثة_اخطاء():
    h=حارس_البيانات(عدد_الأخطاء_للتوقف=3,مدة_التوقف=100)
    h.تسجيل_المصدر('مصدر تجريبي','بيانات',1)
    for _ in range(3): h.تسجيل_فشل('مصدر تجريبي')
    assert h.المصدر_مسموح('مصدر تجريبي') is False
