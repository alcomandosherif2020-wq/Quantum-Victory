import pandas as pd
from qv_whale_hunter.flow_graph import build_flow_graph

def test_graph_propagates_recent_flow():
    rows=[]
    for i,t in enumerate(pd.date_range('2026-09-04 10:00',periods=3,freq='min')):
        for s,score in [('AAA',80+i*2),('BBB',70+i*3),('CCC',30)]:
            rows.append({'timestamp':t,'symbol':s,'sector':'BANK' if s!='CCC' else 'OTHER','grid_score':score,'buy_pressure':.7,'grid_sync_score':50,'sector_sync_score':40})
    g,e,s=build_flow_graph(pd.DataFrame(rows))
    assert not e.empty
    assert {'propagation_in','propagation_out','network_centrality','propagation_score'}.issubset(g.columns)
    assert g.propagation_score.max()<=100

def test_graph_empty():
    g,e,s=build_flow_graph(pd.DataFrame())
    assert g.empty and e.empty and s.empty
