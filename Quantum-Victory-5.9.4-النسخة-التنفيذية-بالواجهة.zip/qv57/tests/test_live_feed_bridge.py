import pandas as pd
from qv_whale_hunter.live_feed_bridge import normalize, normalize_payload

def test_normalize_aliases():
    d=normalize([{'ticker':'COMI','time':'2026-09-03T10:00:00','last':140,'qty':1000}])
    assert list(d.symbol)==['COMI']; assert d.price.iloc[0]==140; assert d.volume.iloc[0]==1000

def test_payload_data_wrapper():
    d=normalize_payload({'data':[{'symbol':'COMI','timestamp':'2026-09-03T10:00:00','price':140,'volume':1000}]})
    assert len(d)==1
