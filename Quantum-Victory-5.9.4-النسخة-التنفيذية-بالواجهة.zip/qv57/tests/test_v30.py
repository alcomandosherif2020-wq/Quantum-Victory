import pandas as pd
from qv_whale_hunter.live_data_contract import validate_intake, build_intake_certificate

def good():
    return pd.DataFrame({'symbol':['A','A'],'session_date':['2026-01-01','2026-01-02'],'open':[10,11],'high':[12,13],'low':[9,10],'close':[11,12],'volume':[100,120]})

def test_good_intake_passes():
    r=validate_intake(good(),'EGX_SOURCE','1.0','2026-01-02'); assert r.status=='PASS'

def test_duplicate_blocks():
    d=pd.concat([good(),good().iloc[[0]]],ignore_index=True); assert 'DUPLICATE_BUSINESS_KEYS:1' in validate_intake(d,'S','1').blocking_reasons

def test_future_asof_blocks():
    assert any(x.startswith('ROWS_AFTER_ASOF') for x in validate_intake(good(),'S','1','2026-01-01').blocking_reasons)

def test_outcome_field_blocks():
    d=good(); d['forward_return']=1; assert any(x.startswith('PROHIBITED_OUTCOME_FIELDS') for x in validate_intake(d,'S','1').blocking_reasons)

def test_adjusted_requires_lineage():
    assert 'ADJUSTED_DATA_WITHOUT_CORPORATE_ACTION_LINEAGE' in validate_intake(good(),'S','1',adjusted=True).blocking_reasons

def test_invalid_ohlcv_blocks():
    d=good(); d.loc[0,'high']=8; assert any(x.startswith('OHLCV_INVARIANT_FAILURE') for x in validate_intake(d,'S','1').blocking_reasons)

def test_certificate_hash_is_deterministic_shape():
    r=validate_intake(good(),'S','1'); c=build_intake_certificate(r,'S','1','2026-01-01T00:00:00+00:00'); assert len(c['certificate_hash'])==64 and c['production_approved'] is False
