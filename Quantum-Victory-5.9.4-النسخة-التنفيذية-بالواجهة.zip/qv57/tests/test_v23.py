import pandas as pd
from qv_whale_hunter.source_reconciliation import reconcile

def test_v23_two_sources_agree():
    a=pd.DataFrame({'symbol':['A'],'session_date':['2026-01-01'],'open':[10],'high':[12],'low':[9],'close':[11],'volume':[1000]})
    b=a.copy()
    r,l=reconcile({'SRC_A':a,'SRC_B':b})
    assert r['status']=='PASS'
    assert l.iloc[0]['reconciliation_status']=='VERIFIED_CROSS_SOURCE'

def test_v23_conflict_is_blocked():
    a=pd.DataFrame({'symbol':['A'],'session_date':['2026-01-01'],'open':[10],'high':[12],'low':[9],'close':[11],'volume':[1000]})
    b=a.copy(); b.loc[0,'close']=14
    r,l=reconcile({'SRC_A':a,'SRC_B':b})
    assert r['status']=='BLOCKED'
    assert l.iloc[0]['reconciliation_status']=='CONFLICT'

def test_v23_single_source_is_not_cross_verified():
    a=pd.DataFrame({'symbol':['A'],'session_date':['2026-01-01'],'open':[10],'high':[12],'low':[9],'close':[11],'volume':[1000]})
    r,l=reconcile({'SRC_A':a})
    assert r['status']=='PASS'
    assert l.iloc[0]['reconciliation_status']=='SINGLE_SOURCE'
