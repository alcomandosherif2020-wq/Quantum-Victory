import pandas as pd
from qv_whale_hunter.المجمع_التاريخي import مجمع_التاريخ

def test_توحيد_التاريخ_وفحص_سلامته():
    df=pd.DataFrame({
      'symbol':['COMI','COMI','COMI'],
      'date':['2026-09-01','2026-09-02','2026-09-02'],
      'open':[10,11,11], 'high':[12,13,13], 'low':[9,10,10], 'close':[11,12,12], 'volume':[100,200,200]
    })
    x,r=مجمع_التاريخ.توحيد(df)
    assert r['سليم'] is True
    assert len(x)==2
    assert r['السجلات_المكررة']==1
    assert list(x['الرمز'])==['COMI','COMI']

def test_رفض_شمعة_غير_منطقية():
    df=pd.DataFrame({'التاريخ':['2026-09-01'],'الافتتاح':[10],'الأعلى':[8],'الأدنى':[9],'الإغلاق':[10],'الحجم':[1]})
    x,r=مجمع_التاريخ.توحيد(df)
    assert not r['سليم']
