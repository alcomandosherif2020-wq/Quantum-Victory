import pandas as pd
from qv_whale_hunter.source_mesh import SourceMesh, SourceSpec

def test_normalize_and_reject_bad_rows():
    df=SourceMesh.normalize([
      {'symbol':'COMI','timestamp':'2026-09-03T10:00:00','last':140,'volume':100,'bid':139.9,'ask':140.1},
      {'symbol':'BAD','timestamp':'2026-09-03T10:01:00','last':-1,'volume':10},
      {'symbol':'BAD2','timestamp':'2026-09-03T10:02:00','last':10,'volume':-1},
    ],'TEST')
    assert len(df)==1 and df.iloc[0].symbol=='COMI'

def test_reconcile_consensus():
    df=pd.DataFrame([
      {'symbol':'COMI','timestamp':pd.Timestamp('2026-09-03 10:00'),'price':100,'volume':10,'source':'A'},
      {'symbol':'COMI','timestamp':pd.Timestamp('2026-09-03 10:00'),'price':100.2,'volume':10,'source':'B'},
    ])
    out=SourceMesh.reconcile(df)
    assert out.consensus.all()

def test_manifest(tmp_path):
    m=SourceMesh([SourceSpec('X','http://x')],state_dir=tmp_path).manifest()
    assert m['engine']=='QV-SOURCE-MESH'
