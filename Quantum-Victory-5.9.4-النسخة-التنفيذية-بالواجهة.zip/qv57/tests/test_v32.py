import json, zipfile
from pathlib import Path
import pandas as pd
from qv_whale_hunter.qv_core_network import inspect_core, read_core_sqlite, build_network_packet
from qv_whale_hunter.v32_pipeline import run

def test_core_network_missing_blocks(tmp_path):
    cert,df=run(out_dir=tmp_path)
    assert cert['status']=='BLOCKED' and cert['production_approved'] is False

def test_core_zip_inspection(tmp_path):
    z=tmp_path/'core.zip'
    with zipfile.ZipFile(z,'w') as zz:
        zz.writestr('qv/scenario_contract.json','{}')
        zz.writestr('qv/experiment_contract.json','{}')
    r=inspect_core(z); assert r.status=='PASS' and r.fingerprint

def test_network_packet_keeps_separation():
    p=build_network_packet('CORE_DF', {'production_approved':False}, pd.DataFrame({'symbol':['COMI'],'close':[10.0]}))
    assert p['score_probability_separation'] is True
    assert p['identity_claim'] is False
    assert p['production_approved'] is False
