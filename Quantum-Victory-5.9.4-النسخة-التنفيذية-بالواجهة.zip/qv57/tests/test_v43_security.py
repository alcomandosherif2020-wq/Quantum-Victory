import os, tempfile
from qv_whale_hunter.secure_telegram_gateway import SecureTelegramGateway

def test_not_configured_without_secret():
    with tempfile.TemporaryDirectory() as d:
        g=SecureTelegramGateway(token='x',chat_id='1',signing_secret=None,state_dir=d)
        assert not g.configured
        assert g.send('hello')['status']=='BLOCKED'

def test_hmac_and_redaction():
    with tempfile.TemporaryDirectory() as d:
        g=SecureTelegramGateway(token='x',chat_id='1',signing_secret='secret',state_dir=d)
        p={'alert_id':'A','symbol':'COMI'}; sig=g.sign(p)
        assert g.verify(p,sig)
        assert not g.verify(p,sig+'x')
        assert 'REDACTED' in g.sanitize('bot123456:ABCDEF_fake_token')

def test_dedup_state_persists():
    with tempfile.TemporaryDirectory() as d:
        g=SecureTelegramGateway(token='x',chat_id='1',signing_secret='secret',state_dir=d)
        g._sent.add('A'); g._save_state()
        g2=SecureTelegramGateway(token='x',chat_id='1',signing_secret='secret',state_dir=d)
        assert 'A' in g2._sent

def test_message_is_bounded():
    with tempfile.TemporaryDirectory() as d:
        g=SecureTelegramGateway(token='x',chat_id='1',signing_secret='secret',state_dir=d)
        assert len(g.sanitize('a'*10000)) == 10000
        assert g.policy.max_message_chars == 3900
