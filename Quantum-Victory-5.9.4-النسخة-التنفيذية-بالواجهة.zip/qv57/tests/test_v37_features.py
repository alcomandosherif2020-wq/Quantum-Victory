import pandas as pd
from qv_whale_hunter.session_profile import build_profile, apply_profile
from qv_whale_hunter.live_liquidity_sniper import scan
from qv_whale_hunter.flow_confirmation import FlowConfirmationEngine
from qv_whale_hunter.market_scanner import scan_market
from qv_whale_hunter.outcome_replay import attach_future_outcomes

def _tape():
    rows=[]
    for d,base in [('2026-09-01',100),('2026-09-02',110),('2026-09-03',120),('2026-09-04',1000)]:
        for m in [0,1,2]: rows.append({'symbol':'COMI','timestamp':f'{d} 10:{m:02d}:00','price':100+m,'volume':base+m})
    return pd.DataFrame(rows)

def test_session_profile_excludes_current_session():
    t=_tape(); p=build_profile(t, min_history_sessions=3)
    today=p[p.session_date==pd.Timestamp('2026-09-04').date()]
    assert float(today.loc[today.session_minute==0,'baseline_volume_per_min'].iloc[0])==110

def test_apply_profile_and_sniper_microstructure():
    t=_tape(); p=build_profile(t,min_history_sessions=3)
    live=pd.DataFrame([{'symbol':'COMI','timestamp':'2026-09-04 10:00:00','price':101,'volume':1000,'bid_size':9000,'ask_size':1000,'trade_count':50,'turnover':101000}])
    a=apply_profile(live,p)
    assert a.session_rvol.iloc[0]>5
    r=scan(live,session_profile=p,lookback=5,min_acceleration=-1)
    assert 'book_imbalance' in r.columns and r.book_imbalance.iloc[0]>0.7

def test_confirmation_state_machine():
    e=FlowConfirmationEngine(confirm_updates=3,fade_updates=2,invalidate_updates=3)
    row={'symbol':'COMI','sniper_score':75,'signal':'HIGH_PRIORITY_BUY_FLOW','buy_pressure':.8}
    states=[e.update(row)['confirmation_state'] for _ in range(3)]
    assert states[-1]=='CONFIRMED_FLOW'
    weak={'symbol':'COMI','sniper_score':20,'signal':'NO_ALERT','buy_pressure':.5}
    assert e.update(weak)['confirmation_state']=='FADING'
    assert e.update(weak)['confirmation_state']=='FADING'
    assert e.update(weak)['confirmation_state']=='INVALIDATED'

def test_market_scan_and_outcomes():
    scored=pd.DataFrame([{'symbol':'COMI','timestamp':'2026-09-04 10:00','price':100,'volume':1000,'sniper_score':80,'signal':'HIGH_PRIORITY_BUY_FLOW','confirmation_state':'CONFIRMED_FLOW','confirmation_ready':True}])
    top=scan_market(scored,top_n=5)
    assert top.iloc[0].reason_code=='CONFIRMED_BUY_FLOW'
    tape=pd.DataFrame([{'symbol':'COMI','timestamp':'2026-09-04 10:00','price':100},{'symbol':'COMI','timestamp':'2026-09-04 10:05','price':101},{'symbol':'COMI','timestamp':'2026-09-04 10:10','price':99}])
    o=attach_future_outcomes(scored,tape,horizons=(5,10))
    assert o.return_5m.iloc[0]>0 and o.return_10m.iloc[0]<0
