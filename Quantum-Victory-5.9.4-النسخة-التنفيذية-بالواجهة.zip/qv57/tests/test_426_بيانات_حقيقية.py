import json
from pathlib import Path
from qv_whale_hunter.تشغيل_بيانات_حقيقية import تشغيل_بيانات_حقيقية

def test_بيانات_حقيقية_تعدد_المصادر():
    p = Path(__file__).parent / "fixture_بيانات_حقيقية.json"
    out = تشغيل_بيانات_حقيقية(p).شغل()
    assert out["عدد_الصفوف"] >= 20
    assert out["المصالحة"]["الحالة"] == "مثبت"
    assert set(out["المصالحة"]["الأدلة"]) >= {"تحليل_الأسهم", "إنفستنج", "مباشر"}
    assert out["التحليل"]["السعر الأخير"] == 141.0

def test_التعارض_يمنع_التثبيت(tmp_path):
    p = Path(__file__).parent / "fixture_بيانات_حقيقية.json"
    data = json.loads(p.read_text(encoding="utf-8"))
    data["المصادر"][1]["صف"]["الإغلاق"] = 140.74
    q = tmp_path / "x.json"; q.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    out = تشغيل_بيانات_حقيقية(q).شغل()
    assert out["المصالحة"]["الحالة"] == "متعارض"
