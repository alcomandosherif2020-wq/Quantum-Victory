import pandas as pd
from qv_whale_hunter.sequence_engine import build_sequence_events
from qv_whale_hunter.backtest import evaluate_signals

def test_sequence_engine_runs():
    d=pd.DataFrame({"symbol":["AAA"]*30,"session_date":pd.date_range("2026-01-01",periods=30),"open":range(100,130),"high":range(101,131),"low":range(99,129),"close":range(100,130),"volume":[100]*20+[500]*10,"turnover":[10000]*20+[50000]*10})
    s=build_sequence_events(d,min_events=2)
    assert len(s)==30
    z=evaluate_signals(d.assign(sequence_state=s.sequence_state))
    assert "signal" in z.columns
if __name__=='__main__': test_sequence_engine_runs(); print('QV-WHALE-HUNTER v1.1 TEST: PASS')
