import pandas as pd
from qv_whale_hunter.data_qualification import qualify

def test_v22_clean_structural_data():
    df=pd.DataFrame({'symbol':['A','A','B'],'session_date':['2026-01-01','2026-01-02','2026-01-01'],'open':[10,11,20],'high':[12,12,21],'low':[9,10,19],'close':[11,11.5,20.5],'volume':[1000,1200,900]})
    r=qualify(df)
    assert r['status']=='PASS'
    assert r['quality_grade']=='A'

def test_v22_blocks_time_travel_and_future_fields():
    df=pd.DataFrame({'symbol':['A'],'session_date':['2026-01-01'],'open':[10],'high':[11],'low':[9],'close':[10.5],'volume':[1000], 'eligibility_time':['2026-01-02T10:00:00+00:00'], 'fwd_ret_1':[.1], 'source_id':['S'],'source_version':['1'],'row_fingerprint':['x']})
    r=qualify(df,decision_time='2026-01-01T15:00:00+00:00',source_columns_required=True)
    assert r['status']=='BLOCKED'
    assert any(f['type']=='POINT_IN_TIME_VIOLATION' for f in r['findings'])
    assert any(f['type']=='FUTURE_OR_OUTCOME_FIELDS_PRESENT' for f in r['findings'])

def test_v22_blocks_ohlc_and_duplicates():
    df=pd.DataFrame({'symbol':['A','A'],'session_date':['2026-01-01','2026-01-01'],'open':[10,10],'high':[9,12],'low':[8,9],'close':[10,11],'volume':[100,200]})
    r=qualify(df)
    assert r['status']=='BLOCKED'
    assert r['quality_grade']=='D'
