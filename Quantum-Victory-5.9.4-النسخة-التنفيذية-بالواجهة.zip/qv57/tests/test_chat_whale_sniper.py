import pandas as pd
from qv_whale_hunter.قناص_الحيتان_المحادثي import قناص_الحيتان_المحادثي

def test_ready_before_session():
    q=قناص_الحيتان_المحادثي()
    r=q.تجهيز_بداية_الجلسة()
    assert r['جاهز'] is True
    assert r['ادعاء_هوية_الحيتان'] is False
    assert r['احتمالات'] is False

def test_protocol_has_opening_sequence():
    p=قناص_الحيتان_المحادثي().بروتوكول_المحادثة()
    assert p['أمر_التشغيل'] == 'شغل قناص الحيتان والسيولة'
    assert len(p['تسلسل_الافتتاح']) >= 6
