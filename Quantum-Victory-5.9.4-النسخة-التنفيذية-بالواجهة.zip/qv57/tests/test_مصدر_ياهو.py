import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]))
from qv_whale_hunter.مصدر_ياهو import رمز_ياهو, _تسوية_الأعمدة
import pandas as pd

def test_symbol():
    assert رمز_ياهو('COMI')=='COMI.CA'
    assert رمز_ياهو('COMI.CA')=='COMI.CA'

def test_normalize():
    df=pd.DataFrame({'Date':['2026-09-03'],'Open':[10],'High':[11],'Low':[9],'Close':[10.5],'Volume':[100]})
    out=_تسوية_الأعمدة(df)
    assert 'الإغلاق' in out.columns and float(out.loc[0,'الإغلاق'])==10.5
