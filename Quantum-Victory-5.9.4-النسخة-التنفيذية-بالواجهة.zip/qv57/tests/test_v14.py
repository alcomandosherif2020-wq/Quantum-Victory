from pathlib import Path
import pandas as pd
from qv_whale_hunter.v14_pipeline import run

def test_v14(tmp_path):
    df=pd.read_csv(Path(__file__).parent/'fixture.csv')
    r=run(df,tmp_path,train_sessions=3,test_sessions=2,step=2)
    assert r['status']=='PASS'
    assert r['production_approved'] is False
    assert r['calibration_status']=='NOT_CALIBRATED'
    assert r['recommendation_role']=='EVIDENCE_ONLY'
    assert (tmp_path/'QV-WHALE-V14-RECOMMENDATION-EVIDENCE-001.csv').exists()
    assert (tmp_path/'QV-WHALE-V14-RECOMMENDATION-CONTRACT-001.json').exists()
