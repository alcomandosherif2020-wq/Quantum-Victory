from pathlib import Path
from qv_whale_hunter.global_certification import audit_evidence_manifest, certify, REQUIRED_GATES


def good_manifest():
    return {
        'manifest_version':'1.0','created_at':'2026-09-05T00:00:00Z',
        'dataset_id':'EGX-DEMO-001','dataset_sha256':'a'*64,
        'source_records':[{'source_id':'SRC-1','retrieved_at':'2026-09-05T00:00:00Z'}],
        'attestor':'independent-review-required'
    }


def good_gate():
    return {'production_approved':True,'checks':{k:True for k in REQUIRED_GATES}}


def test_manifest_shape_passes():
    assert audit_evidence_manifest(good_manifest())['status']=='PASS'


def test_manifest_missing_is_blocked():
    m=good_manifest(); del m['dataset_sha256']
    assert audit_evidence_manifest(m)['status']=='BLOCKED_INVALID_MANIFEST'


def test_certification_requires_independent_manifest():
    r=certify(good_gate())
    assert r['status']=='BLOCKED'
    assert 'independent_evidence_manifest' in r['blocking_reasons']


def test_certification_can_approve_only_when_all_claims_exist():
    r=certify(good_gate(), evidence_manifest=good_manifest())
    assert r['status']=='APPROVED'
    assert r['production_approved'] is True
