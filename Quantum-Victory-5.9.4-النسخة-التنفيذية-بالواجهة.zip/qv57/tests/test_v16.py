import pandas as pd
from qv_whale_hunter.size_radar import classify_whale_size, build_whale_radar

def test_multisize_classes_exist():
    rows=[]
    for i in range(20):
        rows.append({'symbol':'AAA','session_date':f'2026-01-{i+1:02d}','volume_z20':i/3,'turnover_z20':i/3,'buy_event_count':i%7,'institutional_flow_score':i*3,'confirmation_score':50,'uncertainty_score':10})
    x=classify_whale_size(pd.DataFrame(rows))
    assert set(x.whale_size_class).issubset({'MICRO_FLOW','SMALL_FLOW','MEDIUM_FLOW','LARGE_WHALE','MEGA_WHALE'})
    assert x.flow_intensity.max() > x.flow_intensity.min()

def test_radar_rank_and_direction():
    df=pd.DataFrame([{'symbol':'AAA','session_date':'2026-01-01','volume_z20':3,'turnover_z20':3,'buy_event_count':5,'institutional_flow_score':80,'confirmation_score':70,'uncertainty_score':10}])
    r=build_whale_radar(df)
    assert r.iloc[0].radar_rank == 1
    assert r.iloc[0].radar_direction == 'BUY_SIDE'
