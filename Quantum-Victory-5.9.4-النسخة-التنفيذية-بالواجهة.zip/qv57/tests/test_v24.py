import pandas as pd
from qv_whale_hunter.historical_evidence import build_evidence

def base():
    return pd.DataFrame([{'symbol':'OLD','session_date':'2026-01-01','open':10,'high':11,'low':9,'close':10.5,'volume':100}])

def test_alias_and_deterministic_fingerprint():
    a,_=build_evidence({'A':base()},aliases={'OLD':'NEW'})
    b,_=build_evidence({'A':base()},aliases={'OLD':'NEW'})
    assert a['status']=='PASS'; assert a['evidence_chain_sha256']==b['evidence_chain_sha256']

def test_expected_session_gap_is_warning():
    r,_=build_evidence({'A':base()},expected_sessions=['2026-01-01','2026-01-02'])
    assert r['status']=='PASS_WITH_WARNINGS'; assert r['missing_session_groups'][0]['count']==1

def test_adjusted_requires_lineage():
    d=base(); d['adjusted']=True
    r,_=build_evidence({'A':d})
    # adjusted flag without corporate action input is treated as missing lineage
    assert r['status']=='BLOCKED'

def test_duplicate_blocks():
    d=pd.concat([base(),base()],ignore_index=True)
    r,_=build_evidence({'A':d})
    assert r['status']=='BLOCKED'
