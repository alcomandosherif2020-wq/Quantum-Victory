# -*- coding: utf-8 -*-
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/qv_whale_hunter.__str__()) if False else str(Path(__file__).resolve().parent/'qv_whale_hunter'))
from qv_whale_hunter.مركز_القيادة_التشغيلي import مركز_القيادة_التشغيلي

class لوحة:
    def __init__(self, ready=True, alert=False, blockers=None): self.ready=ready; self.alert=alert; self.blockers=blockers or []
    def لقطة(self): return {"المراقب":{"آخر_لقطة":{"جاهزية_المعالجة":self.ready,"جاهزية_التنبيه":self.alert,"الأسباب_المانعة":self.blockers}},"المحرك":{"الإنتاج_مصرح":False}}
class مربط:
    def __init__(self,state="ناجح"): self.state=state
    def تقرير(self): return {"المصادر":{"مصدر":{"الحالة":self.state}}}

def run():
    a=مركز_القيادة_التشغيلي(لوحة(),مربط()).لقطة(); assert a['الحالة_العامة']=='مراقبة'; assert a['عدد_الموانع']==0
    b=مركز_القيادة_التشغيلي(لوحة(blockers=['تعارض']),مربط()).لقطة(); assert b['الحالة_العامة']=='محجوب'; assert b['جاهزية_التنبيه'] is False
    c=مركز_القيادة_التشغيلي(لوحة(),مربط('غير موصول')).لقطة(); assert c['الحالة_العامة']=='غير_موصول'
    assert c['الإنتاج_مصرح'] is False
    return 4
if __name__=='__main__': print(f'نجحت {run()} اختبارات الإصدار 4.23')
