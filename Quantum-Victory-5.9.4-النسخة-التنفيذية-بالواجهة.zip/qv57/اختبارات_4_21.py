# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime, timezone, timedelta
import tempfile, sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from qv_whale_hunter.مراقب_الجاهزية_الحي import مراقب_الجاهزية_الحي

def run():
    with tempfile.TemporaryDirectory() as td:
        m=مراقب_الجاهزية_الحي(Path(td)/'حالة.json')
        now=datetime.now(timezone.utc)
        fresh=(now-timedelta(seconds=5)).isoformat()
        r=m.بناء_اللقطة({'المصدر':{'الحالة':'نجح'}},{'السوق':{'وقت':fresh,'حد_العمر_ثانية':120}},[],{'التحليل':True})
        assert r.جاهزية_المعالجة is True and r.جاهزية_التنبيه is False and r.الإنتاج_مصرح is False
        r=m.بناء_اللقطة({'المصدر':{'الحالة':'نجح'}},{'السوق':{'وقت':(now-timedelta(seconds=300)).isoformat(),'حد_العمر_ثانية':120}},[],{'التحليل':True})
        assert r.جاهزية_المعالجة is False and 'متقادم' in ' '.join(r.الأسباب_المانعة)
        r=m.بناء_اللقطة({'المصدر':{'الحالة':'قاطع_دائرة'}},{'السوق':{'وقت':fresh}},['السوق/المصدر'],{'التحليل':False})
        assert r.جاهزية_التنبيه is False and len(r.الأسباب_المانعة)>=2
        s=m.حالة_مختصرة(); assert s['جاهزية_التنبيه'] is False and s['الإنتاج_مصرح'] is False
        assert m.مسار_الحالة.exists()
    return 4
if __name__=='__main__': print(f'نجحت {run()} اختبارات الإصدار 4.21')
