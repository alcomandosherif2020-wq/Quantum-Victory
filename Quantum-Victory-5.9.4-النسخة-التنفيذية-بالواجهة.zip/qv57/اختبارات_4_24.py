# -*- coding: utf-8 -*-
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'qv_whale_hunter'))
from qv_whale_hunter.محرك_قرار_الأدلة import محرك_قرار_الأدلة

def run():
    a=محرك_قرار_الأدلة(تحليل={'اتجاه':'صاعد'}, سيولة={'أدلة':['تدفق']}).بطاقة('COMI')
    assert a['الحالة']=='جاهز_للمراجعة' and a['الاحتمال'] is None and a['السعر_المستهدف'] is None
    b=محرك_قرار_الأدلة(تحليل={'الحالة':'متعارض'}).بطاقة('COMI')
    assert b['الحالة']=='محجوب' and b['قرار_تنبيه']=='محجوب'
    c=محرك_قرار_الأدلة().بطاقة('COMI')
    assert c['الحالة']=='لا_أدلة_كافية' and c['الإنتاج_مصرح'] is False
    d=محرك_قرار_الأدلة(تحليل={'الأسباب_المانعة':['بيانات متقادمة']}).بطاقة('COMI')
    assert d['الحالة']=='محجوب'
    return 4
if __name__=='__main__': print(f'نجحت {run()} اختبارات الإصدار 4.24')
