from dataclasses import dataclass

@dataclass
class نتيجة_نموذج:
    الاسم: str
    ثبات: float
    جودة_المعايرة: float
    أداء_خارج_العينة: float
    حجم_العينة: int
    مخاطر_التسرب: float

    def مؤهل(self):
        return (
            self.حجم_العينة >= 100
            and self.مخاطر_التسرب == 0
            and self.ثبات >= 0.70
            and self.جودة_المعايرة >= 0.70
            and self.أداء_خارج_العينة >= 0.55
        )

def اختيار_المتصدر(النماذج):
    المؤهلون=[ن for ن in النماذج if ن.مؤهل()]
    if not المؤهلون:
        return None
    return max(المؤهلون,key=lambda ن:(ن.أداء_خارج_العينة,ن.جودة_المعايرة,ن.ثبات))
