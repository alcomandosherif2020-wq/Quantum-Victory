from واجهة.لوحة_كوانتوم_فيكتوري import HTTPServer, معالج, os

if __name__ == '__main__':
    المضيف=os.getenv('QV_UI_HOST','127.0.0.1'); المنفذ=int(os.getenv('QV_UI_PORT','8765'))
    print(f'واجهة كوانتوم فيكتوري تعمل على {المضيف}:{المنفذ}')
    HTTPServer((المضيف,المنفذ),معالج).serve_forever()
