# -*- coding: utf-8 -*-
"""مشغل مستمر آمن — لا يدّعي اتصالاً حقيقياً ولا يخلق بيانات بديلة."""
from __future__ import annotations
import signal, time
from مربط_المصادر_التلقائي import مربط_المصادر_التلقائي

class تشغيل_مستمر:
    def __init__(self, المربط=None, فترة_فحص=1):
        self.المربط=المربط or مربط_المصادر_التلقائي(); self.فترة_فحص=فترة_فحص; self.يعمل=True
        signal.signal(signal.SIGINT, self.إيقاف); signal.signal(signal.SIGTERM, self.إيقاف)
    def إيقاف(self,*_): self.يعمل=False
    def دورة(self): return self.المربط.تشغيل_المستحق()
    def تشغيل(self, حد_الدورات=None):
        n=0
        while self.يعمل and (حد_الدورات is None or n<حد_الدورات):
            self.دورة(); n+=1; time.sleep(self.فترة_فحص)
        return n
