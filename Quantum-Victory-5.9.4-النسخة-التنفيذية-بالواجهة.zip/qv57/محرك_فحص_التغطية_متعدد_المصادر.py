from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json
import pandas as pd
from qv_whale_hunter.حارس_سلامة_البيانات_الشامل import فحص_الشموع, بصمة_بيانات

أنواع_البيانات=("اليومي","اللحظي","الصفقات","العمق","الأخبار","الإفصاحات","المؤشرات")

@dataclass(frozen=True)
class نتيجة_التغطية:
    الرمز:str; المصدر:str; نوع_البيانات:str; الحالة:str
    آخر_تاريخ:str|None=None; جودة:float|None=None; سبب:str=""; بصمة:str=""

def توحيد_الرمز(الرمز):
    s=str(الرمز or "").strip().upper()
    for suffix in (".CA","-CA","_CA"):
        if s.endswith(suffix): s=s[:-3]
    return s

def رمز_ياهو(الرمز): return f"{توحيد_الرمز(الرمز)}.CA"

def فحص_صفوف(صفوف):
    rows=list(صفوف or [])
    if not rows:return False,0.0,"لا توجد بيانات",None
    df=pd.DataFrame(rows)
    r=فحص_الشموع(df)
    # لا نستخدم إغلاق الأمس كاختبار لقمة/قاع اليوم.
    # عند غياب دلالة الافتتاح نرفع تحذيرًا ولا نختلق دلالة.
    if r["status"]=="محجوب": return False,0.0,"؛ ".join(r["reasons"]),None
    valid_ratio=1.0 if r["status"] in {"مُثبت","تحذير"} else 0.0
    date_col=next((c for c in ["التاريخ","date","session_date","datetime"] if c in df.columns),None)
    last=None
    if date_col:
        ds=pd.to_datetime(df[date_col],errors="coerce")
        if ds.notna().any(): last=str(ds.max().date())
    reason="اجتازت فحوص سلامة الشمعة والزمن والتكرار."
    if r["warnings"]: reason+=" "+"؛ ".join(r["warnings"])
    return True,round(valid_ratio,4),reason,last

def فحص_المصدر(الرمز,المصدر,نوع_البيانات,صفوف):
    rows=list(صفوف or [])
    good,q,reason,last=فحص_صفوف(rows)
    state="مثبت" if good and q>=.95 else ("جزئي" if good else "غير مثبت")
    payload={"الرمز":توحيد_الرمز(الرمز),"المصدر":المصدر,"نوع_البيانات":نوع_البيانات,
             "الحالة":state,"آخر_تاريخ":last,"الجودة":q,"السبب":reason,
             "عدد_السجلات":len(rows)}
    fp=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    return نتيجة_التغطية(payload["الرمز"],المصدر,نوع_البيانات,state,last,q,reason,fp)

def اختيار_الأفضل(النتائج):
    rank={"مثبت":3,"جزئي":2,"غير مثبت":0,"غير متاح":-1}; best={}
    for r in النتائج:
        k=(r.الرمز,r.نوع_البيانات)
        if k not in best or (rank.get(r.الحالة,0),r.جودة or 0)>(rank.get(best[k].الحالة,0),best[k].جودة or 0): best[k]=r
    return list(best.values())

def تقرير_تغطية(النتائج):
    return {"اسم_المنظومة":"كوانتوم فيكتوري","الإصدار":"4.30","وقت_التقرير":datetime.now(timezone.utc).isoformat(),
            "إجمالي_النتائج":len(النتائج),"مثبت":sum(r.الحالة=="مثبت" for r in النتائج),
            "جزئي":sum(r.الحالة=="جزئي" for r in النتائج),"غير_مثبت":sum(r.الحالة=="غير مثبت" for r in النتائج),
            "أفضل_مصادر":[asdict(r) for r in اختيار_الأفضل(النتائج)],
            "النتائج":[asdict(r) for r in النتائج],"الإنتاج_مصرح":False}

def حفظ_التقرير(نتائج,path):
    Path(path).write_text(json.dumps(تقرير_تغطية(نتائج),ensure_ascii=False,indent=2),encoding="utf-8")
