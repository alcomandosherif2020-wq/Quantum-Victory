# -*- coding: utf-8 -*-
"""فاحص اكتمال النسخة التنفيذية نفذ."""
from pathlib import Path
import hashlib, json
ROOT=Path(__file__).resolve().parent
files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
required=['Nafezu.py','منظومة_الإصدار_والاعتماد_٥_٩.py','محرك_قرار_الأدلة.py','المحرك_العالمي_الموحد.py']
missing=[x for x in required if not (ROOT/x).exists()]
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
out={'عدد_الملفات':len(files),'مفقودات_الأساس':missing,'مكتمل':not missing,'بصمات':manifest}
print(json.dumps(out,ensure_ascii=False,indent=2))
