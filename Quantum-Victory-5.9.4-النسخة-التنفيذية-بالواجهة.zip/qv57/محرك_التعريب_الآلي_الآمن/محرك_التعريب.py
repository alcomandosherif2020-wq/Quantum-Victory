from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, re

@dataclass
class نتيجة_التعريب:
    الملف: str
    عدد_المواضع_قبل: int
    عدد_المواضع_بعد: int
    عدد_الاستبدالات: int
    حالة: str
    محمي: bool = False

# تعريب آمن لعبارات واجهة وتقارير شائعة فقط؛ لا يغيّر أسماء المتغيرات أو الاستدعاءات البرمجية.
قاموس_آمن = {
    "PASS": "ناجح", "FAIL": "فاشل", "WARNING": "تحذير", "BLOCKED": "محجوب",
    "APPROVED": "معتمد", "REJECTED": "مرفوض", "SAFE STOP": "إيقاف آمن",
    "production": "التشغيل الفعلي", "shadow": "التشغيل الظلي", "validation": "التحقق",
    "calibration": "المعايرة", "out-of-sample": "خارج العينة", "walk-forward": "التقدم الزمني",
    "leakage": "التسرب", "sample size": "حجم العينة", "stability": "الثبات",
    "data quality": "جودة البيانات", "freshness": "حداثة البيانات", "source consistency": "توافق المصادر",
}

_امتدادات_نصية = {".md", ".txt", ".json", ".jsonl", ".csv", ".yaml", ".yml", ".toml"}
_أسماء_محمية = {".git", "__pycache__", ".pytest_cache"}


def _محمي(مسار: Path) -> bool:
    return any(جزء in _أسماء_محمية for جزء in مسار.parts)


def _عدد_لاتيني(نص: str) -> int:
    return len(re.findall(r"[A-Za-z]", نص))


def تعريب_آمن(جذر: str | Path, تنفيذ: bool = False) -> list[نتيجة_التعريب]:
    الجذر = Path(جذر)
    النتائج = []
    for ملف in الجذر.rglob("*"):
        if not ملف.is_file() or _محمي(ملف) or ملف.suffix.lower() not in _امتدادات_نصية:
            continue
        try:
            القديم = ملف.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        الجديد = القديم
        استبدالات = 0
        for مصدر, هدف in sorted(قاموس_آمن.items(), key=lambda x: -len(x[0])):
            الجديد, عدد = re.subn(re.escape(مصدر), هدف, الجديد, flags=re.IGNORECASE)
            استبدالات += عدد
        قبل = _عدد_لاتيني(القديم)
        بعد = _عدد_لاتيني(الجديد)
        حالة = "لا تغيير"
        if استبدالات:
            حالة = "مقترح" if not تنفيذ else "نُفذ"
            if تنفيذ:
                ملف.write_text(الجديد, encoding="utf-8")
        النتائج.append(نتيجة_التعريب(str(ملف.relative_to(الجذر)), قبل, بعد, استبدالات, حالة))
    return النتائج


def حفظ_التقرير(النتائج, المسار):
    Path(المسار).write_text(json.dumps([asdict(x) for x in النتائج], ensure_ascii=False, indent=2), encoding="utf-8")
