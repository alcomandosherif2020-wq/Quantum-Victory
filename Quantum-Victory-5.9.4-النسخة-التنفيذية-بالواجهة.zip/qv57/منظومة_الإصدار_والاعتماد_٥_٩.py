from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys

البوابات = [
    "تأهيل_البيانات_الحقيقية", "تدقيق_التسرب", "اختبار_خارج_العينة", "التقدم_الزمني",
    "حجم_العينة", "ثبات_النظام", "معايرة_خارج_العينة", "المتصدر_والمنافس", "التشغيل_الظلي"
]

@dataclass
class نتيجة_الإصدار:
    سلامة_البرمجيات: bool
    الاختبارات_الناجحة: bool
    البوابات_العلمية_المكتملة: bool
    الاعتماد_للإنتاج: bool
    الحالة: str
    أسباب_الحجب: list[str]
    وقت_الفحص: str


def فحص_الإصدار(جذر: str | Path) -> نتيجة_الإصدار:
    جذر = Path(جذر)
    تجميع = subprocess.run([sys.executable, "-m", "compileall", "-q", str(جذر)], capture_output=True)
    اختبارات = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=جذر, capture_output=True, text=True)
    سلامة = تجميع.returncode == 0
    نجاح = اختبارات.returncode == 0
    # لا توجد في هذه الحزمة بيانات سوقية مستقلة موثقة تسمح بفتح بوابات الإنتاج.
    أسباب = []
    if not سلامة: أسباب.append("فشل_التجميع")
    if not نجاح: أسباب.append("فشل_الاختبارات")
    أسباب += ["الدليل_السوقي_المستقل_غير_مكتمل", "لا_يُسمح_بتحويل_الدرجات_إلى_احتمالات_دون_معايرة_خارج_العينة"]
    اعتماد = False
    return نتيجة_الإصدار(سلامة, نجاح, False, اعتماد, "محجوب_للبحث_والتحقق", أسباب, datetime.now(timezone.utc).isoformat())


def بصمة_المنظومة(جذر: str | Path) -> str:
    جذر = Path(جذر); هاش = hashlib.sha256()
    for ملف in sorted(جذر.rglob("*")):
        if ملف.is_file() and ".pytest_cache" not in ملف.parts and "__pycache__" not in ملف.parts:
            هاش.update(str(ملف.relative_to(جذر)).encode()); هاش.update(ملف.read_bytes())
    return هاش.hexdigest()

if __name__ == "__main__":
    جذر = Path(__file__).resolve().parent
    نتيجة = فحص_الإصدار(جذر)
    الناتج = {"النتيجة": asdict(نتيجة), "البوابات_المطلوبة": البوابات, "بصمة_المنظومة": بصمة_المنظومة(جذر)}
    مسار = جذر / "تقرير_اعتماد_الإصدار_٥_٩.json"
    مسار.write_text(json.dumps(الناتج, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(nاتج if False else الناتج["النتيجة"], ensure_ascii=False))
