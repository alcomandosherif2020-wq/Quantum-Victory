from __future__ import annotations
import math
import pandas as pd
import numpy as np

أعمدة = ['التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم']


def _سلسلة(df, الاسم):
    return pd.to_numeric(df[الاسم], errors='coerce').astype(float)


def المتوسط_البسيط(x, n):
    return x.rolling(n, min_periods=n).mean()


def المتوسط_الأسي(x, n):
    return x.ewm(span=n, adjust=False, min_periods=n).mean()


def مؤشر_القوة_النسبية(close, n=14):
    d=close.diff(); up=d.clip(lower=0); down=-d.clip(upper=0)
    au=up.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    ad=down.ewm(alpha=1/n, adjust=False, min_periods=n).mean()
    rs=au/ad.replace(0,np.nan)
    return 100-(100/(1+rs))


def الماكد(close):
    سريع=المتوسط_الأسي(close,12); بطيء=المتوسط_الأسي(close,26)
    خط=سريع-بطيء; إشارة=المتوسط_الأسي(خط,9)
    return خط,إشارة,خط-إشارة


def متوسط_المدى_الحقيقي(df,n=14):
    c=_سلسلة(df,'الإغلاق'); h=_سلسلة(df,'الأعلى'); l=_سلسلة(df,'الأدنى')
    tr=pd.concat([h-l,(h-c.shift()).abs(),(l-c.shift()).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n,adjust=False,min_periods=n).mean()


def مؤشر_الاتجاه(df,n=14):
    h=_سلسلة(df,'الأعلى'); l=_سلسلة(df,'الأدنى'); c=_سلسلة(df,'الإغلاق')
    up=h.diff(); dn=-l.diff()
    plus=up.where((up>dn)&(up>0),0.0); minus=dn.where((dn>up)&(dn>0),0.0)
    tr=pd.concat([h-l,(h-c.shift()).abs(),(l-c.shift()).abs()],axis=1).max(axis=1)
    atr=tr.ewm(alpha=1/n,adjust=False,min_periods=n).mean()
    pdi=100*plus.ewm(alpha=1/n,adjust=False,min_periods=n).mean()/atr
    mdi=100*minus.ewm(alpha=1/n,adjust=False,min_periods=n).mean()/atr
    dx=100*(pdi-mdi).abs()/(pdi+mdi).replace(0,np.nan)
    return dx.ewm(alpha=1/n,adjust=False,min_periods=n).mean(),pdi,mdi


def تحليل_فني(df):
    """تحليل يومي قابل لإعادة الحساب آلياً. لا يحول الدرجات إلى احتمالات."""
    if df is None or len(df)==0: return pd.DataFrame(), {}
    x=df.copy()
    x['التاريخ']=pd.to_datetime(x['التاريخ'],errors='coerce')
    for c in ['الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم']: x[c]=pd.to_numeric(x[c],errors='coerce')
    x=x.dropna(subset=['التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم']).sort_values('التاريخ').drop_duplicates('التاريخ').reset_index(drop=True)
    c=x['الإغلاق']
    for n in (5,10,20,50,100,200): x[f'متوسط بسيط {n}']=المتوسط_البسيط(c,n); x[f'متوسط أسي {n}']=المتوسط_الأسي(c,n)
    x['القوة النسبية 14']=مؤشر_القوة_النسبية(c,14)
    x['خط الماكد'],x['إشارة الماكد'],x['فارق الماكد']=الماكد(c)
    x['متوسط المدى الحقيقي 14']=متوسط_المدى_الحقيقي(x,14)
    x['مؤشر الاتجاه 14'],x['+الاتجاه'],x['-الاتجاه']=مؤشر_الاتجاه(x,14)
    x['متوسط الحجم 20']=x['الحجم'].rolling(20,min_periods=1).mean()
    x['نسبة الحجم']=x['الحجم']/x['متوسط الحجم 20'].replace(0,np.nan)
    x['الزخم 10']=c.pct_change(10)*100
    x['التغير اليومي %']=c.pct_change()*100
    x['قوة المشتري التقريبية']=((x['الإغلاق']-x['الأدنى'])/(x['الأعلى']-x['الأدنى']).replace(0,np.nan)).clip(0,1)
    # الشموع اليابانية الأساسية
    جسم=(x['الإغلاق']-x['الافتتاح']).abs(); مدى=(x['الأعلى']-x['الأدنى']).replace(0,np.nan)
    علوي=x['الأعلى']-x[['الافتتاح','الإغلاق']].max(axis=1); سفلي=x[['الافتتاح','الإغلاق']].min(axis=1)-x['الأدنى']
    x['الشمعة']='عادية'
    x.loc[(جسم/مدى<0.15),'الشمعة']='دوجي'
    x.loc[(سفلي>جسم*2)&(علوي<جسم),'الشمعة']='مطرقة/رفض هبوط'
    x.loc[(علوي>جسم*2)&(سفلي<جسم),'الشمعة']='شهاب/رفض صعود'
    x.loc[(x['الإغلاق']>x['الافتتاح'])&(جسم/مدى>0.65),'الشمعة']='صاعدة قوية'
    x.loc[(x['الإغلاق']<x['الافتتاح'])&(جسم/مدى>0.65),'الشمعة']='هابطة قوية'
    last=x.iloc[-1]
    score=0.0; أسباب=[]
    def add(cond,val,text):
        nonlocal score
        if bool(cond): score+=val; أسباب.append(text)
    add(last['الإغلاق']>last['متوسط أسي 20'],2,'الإغلاق أعلى من المتوسط الأسي 20')
    add(last['الإغلاق']>last['متوسط أسي 50'],2,'الإغلاق أعلى من المتوسط الأسي 50')
    add(last['متوسط أسي 20']>last['متوسط أسي 50'],1.5,'المتوسط الأسي 20 أعلى من 50')
    add(last['القوة النسبية 14']>55,1.5,'القوة النسبية داعمة'); add(last['القوة النسبية 14']<45,-1.5,'القوة النسبية ضعيفة')
    add(last['فارق الماكد']>0,1.5,'الماكد داعم'); add(last['فارق الماكد']<0,-1.5,'الماكد ضاغط')
    add(last['نسبة الحجم']>1.2,1,'الحجم أعلى من متوسطه')
    add(last['مؤشر الاتجاه 14']>25 and last['+الاتجاه']>last['-الاتجاه'],1.5,'اتجاه صاعد قوي نسبياً')
    add(last['مؤشر الاتجاه 14']>25 and last['-الاتجاه']>last['+الاتجاه'],-1.5,'اتجاه هابط قوي نسبياً')
    الاتجاه='إيجابي' if score>=4 else ('سلبي' if score<=-4 else 'متوازن')
    atr=float(last['متوسط المدى الحقيقي 14']) if pd.notna(last['متوسط المدى الحقيقي 14']) else float(c.iloc[-1]*0.03)
    السعر=float(c.iloc[-1]); مقاومة=float(x['الأعلى'].tail(20).max()); دعم=float(x['الأدنى'].tail(20).min())
    التقرير={'الاتجاه':الاتجاه,'درجة الأدلة':round(score,3),'السعر الأخير':السعر,'الدعم القريب':دعم,'المقاومة القريبة':مقاومة,'مدى الحركة المتوقع المبني على التقلب':round(atr,4),'أسباب':أسباب,'تنبيه':'هذه الدرجة ليست احتمالاً ولا ضماناً لسعر مستهدف.'}
    return x,التقرير
