from __future__ import annotations
import json, os, time
from dataclasses import dataclass
from typing import Callable, Iterable, Iterator, Any
import pandas as pd
try: import requests
except Exception: requests=None
ENGINE='QV-LIVE-FEED-ADAPTERS'; VERSION='1.1.0'
@dataclass
class ProviderConfig:
    name:str; url:str; headers:dict[str,str]|None=None; timeout:float=5.0
def _json_records(payload:Any)->list[dict]:
    if isinstance(payload,list): return [x for x in payload if isinstance(x,dict)]
    if isinstance(payload,dict):
        for k in ('data','results','quotes','trades','items','marketWatch','stocks','symbols'):
            if isinstance(payload.get(k),list): return [x for x in payload[k] if isinstance(x,dict)]
        return [payload]
    return []
def http_poll(config:ProviderConfig)->list[dict]:
    if requests is None: raise RuntimeError('requests is required')
    r=requests.get(config.url,headers=config.headers or {},timeout=config.timeout); r.raise_for_status(); return _json_records(r.json())
def env_config(prefix:str,default_url='')->ProviderConfig:
    return ProviderConfig(prefix,os.getenv(f'{prefix}_URL',default_url),{k[len(prefix)+8:]:v for k,v in os.environ.items() if k.startswith(prefix+'_HEADER_')},float(os.getenv(f'{prefix}_TIMEOUT','5')))
def adapt_provider_records(records:Iterable[dict],provider:str)->pd.DataFrame:
    from .live_feed_bridge import normalize
    df=normalize(records)
    if not df.empty: df['provider']=provider
    return df
def poll_provider(config:ProviderConfig,seconds=1.0,duration=None,on_batch=None)->pd.DataFrame:
    started=time.monotonic(); out=[]
    while duration is None or time.monotonic()-started<duration:
        b=adapt_provider_records(http_poll(config),config.name)
        if not b.empty:
            out.append(b)
            if on_batch: on_batch(b)
        time.sleep(max(.1,seconds))
    return pd.concat(out,ignore_index=True) if out else pd.DataFrame()
def websocket_messages(url:str,subscribe_message=None,headers=None)->Iterator[dict]:
    try: import websocket
    except Exception as e: raise RuntimeError('websocket-client is required') from e
    ws=websocket.create_connection(url,header=[f'{k}: {v}' for k,v in (headers or {}).items()],timeout=10)
    try:
        if subscribe_message is not None: ws.send(json.dumps(subscribe_message))
        while True:
            raw=ws.recv()
            if raw is None: break
            try: yield json.loads(raw)
            except Exception: continue
    finally: ws.close()
