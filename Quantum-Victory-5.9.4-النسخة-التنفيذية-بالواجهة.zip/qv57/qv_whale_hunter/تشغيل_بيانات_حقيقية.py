from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

from .ممر_البيانات_متعدد_المصادر import ممر_البيانات_متعدد_المصادر
from .محرك_التحليل_الفني import تحليل_فني

class تشغيل_بيانات_حقيقية:
    def __init__(self, ملف_لقطة: Path):
        self.ملف_لقطة = Path(ملف_لقطة)

    def شغل(self):
        لقطة = json.loads(self.ملف_لقطة.read_text(encoding="utf-8"))
        ممر = ممر_البيانات_متعدد_المصادر(self.ملف_لقطة.with_name("سجل_مرور_البيانات.json"))
        for مصدر in لقطة["المصادر"]:
            ممر.أضف(مصدر["الاسم"], {"صف": مصدر["صف"]})
        مصالحة = ممر.المصالحة(لقطة["الرمز"], لقطة["التاريخ"])
        rows = لقطة["التاريخ_اليومي"]
        df = pd.DataFrame(rows)
        _, تحليل = تحليل_فني(df)
        ممر.احفظ()
        return {"المصالحة": مصالحة, "التحليل": تحليل, "عدد_الصفوف": len(df)}
