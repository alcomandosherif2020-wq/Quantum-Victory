from __future__ import annotations
import numpy as np
import pandas as pd

ENGINE='QV-DISTRIBUTED-WHALE-GRID'; VERSION='4.0.0'


def _num(df,c,d=0.0):
    if c in df.columns: return pd.to_numeric(df[c],errors='coerce').fillna(d)
    return pd.Series(d,index=df.index,dtype=float)


def build_grid(fusion_df: pd.DataFrame, top_n=20, decay_minutes=5):
    """Cross-sectional/time-window graph layer. It detects coordinated flow and
    liquidity migration without inferring actor identity. Scores are evidence indices."""
    if fusion_df is None or fusion_df.empty: return pd.DataFrame(), pd.DataFrame()
    x=fusion_df.copy(); x['timestamp']=pd.to_datetime(x['timestamp'],errors='coerce')
    x['_minute']=x['timestamp'].dt.floor('min'); x['_session']=x['timestamp'].dt.date.astype(str)
    x['fusion_score']=_num(x,'fusion_score'); x['buy_pressure']=_num(x,'buy_pressure',.5).clip(0,1)
    x['sniper_score']=_num(x,'sniper_score'); x['book_imbalance']=_num(x,'book_imbalance').clip(-1,1)
    x['flow_signal']=((x.fusion_score>=55)&(x.buy_pressure>=.52)).astype(float)
    # Cross-node synchronization in a rolling time window.
    x['grid_flow_nodes']=0; x['grid_sync_score']=0.0; x['sector_sync_score']=0.0
    for t,g in x.groupby('_minute'):
        active=g[g.flow_signal>0]
        if active.empty: continue
        node_count=active.symbol.nunique()
        sync=min(100.0, node_count*12.5 + float(active.fusion_score.mean())*.35)
        x.loc[g.index,'grid_flow_nodes']=node_count
        x.loc[g.index,'grid_sync_score']=sync
        if 'sector' in g.columns:
            sec_counts=active.groupby(active['sector'].fillna('UNKNOWN')).symbol.nunique()
            for sec,n in sec_counts.items():
                idx=g[g['sector'].fillna('UNKNOWN').eq(sec)].index
                x.loc[idx,'sector_sync_score']=min(100.0,n*20.0+float(active[active['sector'].fillna('UNKNOWN').eq(sec)].fusion_score.mean())*.25)
    # Liquidity migration: rank change among symbols between consecutive observations.
    x['migration_score']=0.0
    for sym,g in x.groupby('symbol'):
        g=g.sort_values('timestamp'); prev=g['fusion_score'].shift(1)
        delta=(g['fusion_score']-prev).fillna(0)
        x.loc[g.index,'migration_score']=delta.clip(-100,100)
    # Grid score is not a probability.
    x['grid_score']=(.55*x.fusion_score + .18*x.grid_sync_score + .12*x.sector_sync_score +
                     .10*((x.book_imbalance+1)*50) + .05*(50+x.migration_score)).clip(0,100).round(4)
    x['grid_state']=np.select([
        (x.grid_score>=75)&(x.grid_sync_score>=45)&(x.flow_signal>0),
        (x.grid_score>=60)&(x.flow_signal>0),
        (x.grid_score<45)&(x.migration_score< -15),
    ],['GRID_CONFIRMED_FLOW','GRID_ARMED_FLOW','GRID_FLOW_EXIT'],default='GRID_WATCH')
    x['grid_reason']=np.select([
        x.grid_state.eq('GRID_CONFIRMED_FLOW'),x.grid_state.eq('GRID_ARMED_FLOW'),x.grid_state.eq('GRID_FLOW_EXIT')],
        ['MULTI_NODE_SYNCHRONIZED_FLOW','NETWORK_SUPPORTED_FLOW','LIQUIDITY_MIGRATION_AWAY'],default='GRID_WAIT')
    x['identity_claim']=False; x['evidence_only']=True; x['probability']=np.nan; x['fixed_price_target']=np.nan
    latest=x.sort_values('timestamp').groupby('symbol',as_index=False).tail(1).sort_values('grid_score',ascending=False).head(top_n)
    snap=pd.DataFrame([{'timestamp':x.timestamp.max(),'symbols':int(x.symbol.nunique()),
        'active_flow_nodes':int((x.flow_signal>0).sum()),'confirmed_grid_nodes':int((x.grid_state=='GRID_CONFIRMED_FLOW').sum()),
        'mean_grid_score':float(x.grid_score.mean()),'max_grid_score':float(x.grid_score.max()),
        'top_grid_symbol':latest.symbol.iloc[0] if not latest.empty else None}])
    return x, snap
