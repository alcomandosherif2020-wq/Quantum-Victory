# -*- coding: utf-8 -*-
"""قاموس العرض: يحافظ على المعرفات الداخلية ويمنع تسرب التسميات الإنجليزية للواجهة."""

القيم = {
    'NO_SIGNAL': 'لا توجد إشارة',
    'INSTITUTIONAL_ACCUMULATION': 'تدفق تجميعي قوي',
    'EARLY_ACCUMULATION': 'تجميع مبكر محتمل',
    'DISTRIBUTION': 'توزيع/ضغط بيع',
    'PROFIT_TAKING_OR_EXIT_PRESSURE': 'جني أرباح/ضغط خروج',
    'MIXED_FLOW': 'تدفق مختلط',
    'HIGH_PRIORITY_BUY_FLOW': 'تدفق شرائي عالي الأولوية',
    'BUY_FLOW_WATCH': 'مراقبة تدفق شرائي',
    'UNUSUAL_LIQUIDITY': 'سيولة غير اعتيادية',
    'NO_ALERT': 'لا يوجد تنبيه',
}

المفاتيح = {
    'state': 'حالة التدفق',
    'institutional_flow_score': 'درجة التدفق',
    'confirmation_score': 'درجة التأكيد',
    'false_signal_risk': 'مخاطر الإشارة الكاذبة',
    'signal': 'إشارة السيولة',
    'sniper_score': 'درجة القنص',
    'buy_pressure': 'ضغط الشراء',
}

def قيمة(x):
    return القيم.get(str(x), x)

def مفتاح(x):
    return المفاتيح.get(str(x), x)
