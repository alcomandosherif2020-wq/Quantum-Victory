from __future__ import annotations
import json
from pathlib import Path
from .live_data_contract import validate_intake, build_intake_certificate
from .v29_pipeline import run as run_v29

VERSION='3.0.0'

def run(df,out_dir,source_id='UNSPECIFIED',source_version='UNSPECIFIED',asof=None,adjusted=False,corporate_action_lineage_present=False,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    result=validate_intake(df,source_id,source_version,asof,adjusted,corporate_action_lineage_present)
    cert=build_intake_certificate(result,source_id,source_version)
    (out/'QV-V30-DATA-INTAKE-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    if result.status!='PASS':
        return {'version':VERSION,'intake':cert,'pipeline_status':'BLOCKED','production_approved':False}, None
    upstream=run_v29(df,out,**kwargs)
    return {'version':VERSION,'intake':cert,'pipeline_status':'PASS','production_approved':False,'upstream':upstream[0]}, upstream[1]
