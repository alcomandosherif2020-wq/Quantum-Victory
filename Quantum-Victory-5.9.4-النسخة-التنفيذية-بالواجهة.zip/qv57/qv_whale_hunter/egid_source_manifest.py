from __future__ import annotations
import json
from pathlib import Path

MANIFEST = {
  "engine": "QV-EGID-SOURCE-DISCOVERY",
  "version": "1.0.0",
  "provider": "EGID",
  "authority_note": "EGID states it is a wholly owned EGX subsidiary and an authorized EGX market-data provider.",
  "documented_host": "https://ticker.egidegypt.com",
  "documented_endpoints": {
    "market_watch": "/api/Feed/GetEGXMarketWatch",
    "market_status": "/api/Feed/GetMarketStatus",
    "market_depth": "/api/Feed/GetMarketDepth",
    "symbol_trades": "/api/Feed/GetSymbolTrades",
    "today_trades": "/api/Feed/GetTodayTrades",
    "all_market_watch": "/api/Feed/GetAllMarketWatch",
    "token": "/api/Settings/GetToken"
  },
  "websocket": False,
  "preferred_transport": "REST/JSON polling",
  "secrets": "environment_only",
  "production_approved": False,
  "requires_provider_contract_validation": True,
  "notes": [
    "Endpoint availability and authentication requirements must be confirmed with the EGID provider account/contract.",
    "No reverse engineering is permitted.",
    "No live claims are made while the exchange is closed."
  ]
}

def write(out='QV-EGID-SOURCE-MANIFEST.json'):
    Path(out).write_text(json.dumps(MANIFEST, ensure_ascii=False, indent=2), encoding='utf-8')
    return MANIFEST
