from __future__ import annotations
import hashlib, hmac, json, os, re, time
from pathlib import Path
from urllib.request import Request, urlopen

SECRET_RE = re.compile(r'(bot\d+:[A-Za-z0-9_-]+|\b\d{8,12}:[A-Za-z0-9_-]{20,}\b)')

class SecurityPolicy:
    def __init__(self, *, max_message_chars=3900, min_interval=1.0, max_retries=3):
        self.max_message_chars = int(max_message_chars)
        self.min_interval = float(min_interval)
        self.max_retries = int(max_retries)

class SecureTelegramGateway:
    """Outbound-only Telegram transport with defense-in-depth controls.
    Secrets are read only from environment; no webhook or inbound port is required.
    """
    def __init__(self, token=None, chat_id=None, signing_secret=None, policy=None, timeout=10, state_dir='QV-SECURE-TELEGRAM'):
        self.token = token or os.getenv('QV_TELEGRAM_BOT_TOKEN')
        self.chat_id = chat_id or os.getenv('QV_TELEGRAM_CHAT_ID')
        self.signing_secret = signing_secret or os.getenv('QV_ALERT_SIGNING_SECRET')
        self.policy = policy or SecurityPolicy()
        self.timeout = float(timeout)
        self.state_dir = Path(state_dir); self.state_dir.mkdir(parents=True, exist_ok=True)
        self._last_send = 0.0
        self._sent = set()
        self._load_state()
        try: os.chmod(self.state_dir, 0o700)
        except OSError: pass

    @property
    def configured(self):
        return bool(self.token and self.chat_id and self.signing_secret)

    def _load_state(self):
        p=self.state_dir/'sent_ids.json'
        try: self._sent=set(json.loads(p.read_text(encoding='utf-8')))
        except Exception: self._sent=set()

    def _save_state(self):
        p=self.state_dir/'sent_ids.json'; tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(sorted(self._sent)[-5000:]),encoding='utf-8')
        try: os.chmod(tmp,0o600)
        except OSError: pass
        tmp.replace(p)

    @staticmethod
    def sanitize(text):
        return SECRET_RE.sub('[REDACTED]', str(text))

    def sign(self, payload):
        body=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
        return hmac.new(self.signing_secret.encode(),body,hashlib.sha256).hexdigest()

    def verify(self, payload, signature):
        return bool(self.signing_secret) and hmac.compare_digest(self.sign(payload), str(signature))

    def send(self, text, alert_id=None, metadata=None, parse_mode=None):
        if not self.configured:
            return {'status':'BLOCKED','reason':'SECURE_TELEGRAM_NOT_CONFIGURED','sent':False}
        text=self.sanitize(text)
        if not text.strip(): return {'status':'BLOCKED','reason':'EMPTY_MESSAGE','sent':False}
        if len(text)>self.policy.max_message_chars: text=text[:self.policy.max_message_chars-20]+'… [TRUNCATED]'
        aid=str(alert_id or hashlib.sha256(text.encode()).hexdigest()[:24])
        if aid in self._sent: return {'status':'DEDUPLICATED','sent':False,'alert_id':aid}
        now=time.monotonic(); wait=self.policy.min_interval-(now-self._last_send)
        if wait>0: time.sleep(wait)
        payload={'chat_id':str(self.chat_id),'text':text}
        if parse_mode: payload['parse_mode']=parse_mode
        data=json.dumps(payload,ensure_ascii=False).encode()
        url=f'https://api.telegram.org/bot{self.token}/sendMessage'
        last='UNKNOWN'
        for attempt in range(self.policy.max_retries):
            try:
                req=Request(url,data=data,headers={'Content-Type':'application/json','User-Agent':'QuantumVictory-SecureGateway/1.0'},method='POST')
                with urlopen(req,timeout=self.timeout) as r: body=json.loads(r.read().decode())
                self._last_send=time.monotonic()
                if body.get('ok'):
                    self._sent.add(aid); self._save_state()
                    return {'status':'SENT','sent':True,'alert_id':aid,'message_id':body.get('result',{}).get('message_id')}
                last=self.sanitize(str(body))
            except Exception as e: last=self.sanitize(str(e))
            time.sleep(min(2**attempt,5))
        return {'status':'FAILED','sent':False,'alert_id':aid,'reason':last}
