from __future__ import annotations

def final_production_gate(*, real_egx=False, leakage_clean=False, oos_pass=False, walk_forward_pass=False, sample_pass=False, regime_pass=False, calibration_pass=False, champion_pass=False, shadow_pass=False):
    checks={'real_egx_qualification':real_egx,'leakage_audit':leakage_clean,'oos':oos_pass,'walk_forward':walk_forward_pass,'sample_size':sample_pass,'regime_stability':regime_pass,'oos_calibration':calibration_pass,'champion_challenger':champion_pass,'shadow':shadow_pass}
    return {'production_approved':all(checks.values()),'status':'APPROVED' if all(checks.values()) else 'BLOCKED','checks':checks,'blocking_reasons':[k for k,v in checks.items() if not v]}
