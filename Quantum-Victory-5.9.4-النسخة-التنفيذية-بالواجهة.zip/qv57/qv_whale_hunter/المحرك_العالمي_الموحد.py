# -*- coding: utf-8 -*-
"""الممر التنفيذي الموحد: سلامة البيانات ← مصالحة ← فني ← سيولة ← قناص ← قرار ← تقرير."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Mapping, Any
import pandas as pd
from .حارس_سلامة_البيانات_الشامل import فحص_الشموع, فحص_المصالحة, بصمة_بيانات
from .محرك_التحليل_الفني import تحليل_فني
from .live_liquidity_sniper import scan as فحص_السيولة
from .whale_hunter import scan as فحص_القناص
from .تقرير_السهم_العالمي import توليد_تقرير, نص_عربي
from .ربط_الأحداث_والتحليل import ربط_الأحداث_بالتاريخ, دمج_ملخص_فني

@dataclass(frozen=True)
class نتيجة_عالمية:
    الرمز:str; الحالة:str; التوصية:str; الأسباب:tuple[str,...]; الأدلة:tuple[str,...]
    درجة_الأدلة:float|None; احتمال:None=None; سعر_مستهدف:None=None; إنتاج_مصرح:bool=False
    البيانات:dict=None; التحليل_الفني:dict=None; السيولة:dict=None; المصالحة:dict=None
    حالة_المصادر:dict=None; بوابات_السلامة:dict=None; بصمة_البيانات:str|None=None

class المحرك_العالمي_الموحد:
    الإصدار='1.0.0'
    def __init__(self): self.إنتاج_مصرح=False
    def تشغيل(self, df:pd.DataFrame, *, دلالة_الافتتاح=None, مصادر:Mapping[str,pd.DataFrame]|None=None, intraday=None, أحداث=None, مصدر_البيانات='غير_محدد'):
        if df is None or df.empty:
            return توليد_تقرير(asdict(نتيجة_عالمية('غير_معروف','محجوب','لا_بيانات',('لا توجد بيانات',),(),None,البيانات={},التحليل_الفني={},السيولة={},المصالحة={},حالة_المصادر={},بوابات_السلامة={})))
        الرمز=str(df.get('الرمز',pd.Series(['غير_معروف'])).iloc[-1]) if 'الرمز' in df.columns else 'غير_معروف'
        if 'الرمز' in df.columns and df['الرمز'].astype(str).nunique(dropna=True) > 1:
            return self._تقرير('متعدد_الأسهم','محجوب','لا_قرار',['المدخل يحتوي أكثر من سهم؛ يجب فصل كل رمز في دورة مستقلة'],[],None,df,{}, {},{}, {'اسم':مصدر_البيانات}, {'status':'محجوب','opening_semantics':'غير_معروف'})
        guard=فحص_الشموع(df,دلالة_الافتتاح=دلالة_الافتتاح)
        أسباب=list(guard.get('reasons',[])); تحذيرات=list(guard.get('warnings',[])); أدلة=[]
        المصالحة={}
        if مصادر:
            المصالحة=فحص_المصالحة(مصادر)
            if isinstance(المصالحة.get('sources'), dict): المصالحة['sources']=list(المصالحة['sources'].keys())
            elif not isinstance(المصالحة.get('sources'), list): المصالحة['sources']=list(المصالحة.get('sources',[]))
            if المصالحة.get('status')=='متعارض':
                أسباب.append('تعارض_مصادر'); return self._تقرير(الرمز,'محجوب','لا_قرار',أسباب,أدلة,None,df,{}, {},المصالحة,{'اسم':مصدر_البيانات},guard)
            if المصالحة.get('status')=='مُثبت': أدلة.append('مصالحة_مصادر_مثبتة')
        if guard.get('status')=='محجوب' or guard.get('opening_semantics')!='افتتاح_الجلسة':
            if guard.get('opening_semantics')!='افتتاح_الجلسة': أسباب.append('دلالة_الافتتاح_غير_مؤكدة')
            return self._تقرير(الرمز,'محجوب','لا_قرار',أسباب+تحذيرات,أدلة,None,df,{}, {},المصالحة,{'اسم':مصدر_البيانات},guard)
        try:
            الفني_المفصل,tech=تحليل_فني(df)
            if len(الفني_المفصل):
                آخر=الفني_المفصل.iloc[-1]
                حقول=('متوسط بسيط 5','متوسط بسيط 10','متوسط بسيط 20','متوسط بسيط 50','متوسط أسي 20','متوسط أسي 50','القوة النسبية 14','خط الماكد','إشارة الماكد','فارق الماكد','متوسط المدى الحقيقي 14','مؤشر الاتجاه 14','نسبة الحجم','الزخم 10','قوة المشتري التقريبية','الشمعة')
                tech.update({k:(float(آخر[k]) if pd.notna(آخر[k]) and k!='الشمعة' else (str(آخر[k]) if pd.notna(آخر[k]) else None)) for k in حقول if k in آخر})
        except Exception as e:
            return self._تقرير(الرمز,'محجوب','لا_قرار',[f'فشل_التحليل:{type(e).__name__}'],أدلة,None,df,{}, {},المصالحة,{'اسم':مصدر_البيانات},guard)
        # ربط الأخبار/الإفصاحات زمنياً دون تسريب المستقبل.
        أخبار={}
        if أحداث:
            try:
                مرتبطة, أخبار = ربط_الأحداث_بالتاريخ(df, أحداث)
                tech = دمج_ملخص_فني(tech, مرتبطة)
                if len(مرتبطة):
                    أدلة.append('أحداث_مرتبطة_زمنياً')
                    if int(tech.get('أعلى_درجة_أثر',0)) >= 3:
                        تحذيرات.append('حدث_مرتفع_الأثر_يحتاج_قراءة_المحتوى')
            except Exception as e:
                تحذيرات.append(f'تعذر_ربط_الأحداث:{type(e).__name__}')
        أدلة += [str(x) for x in tech.get('أسباب',[])]
        السيولة={}
        if intraday is not None and not intraday.empty:
            try:
                q=فحص_السيولة(intraday); alerts=q[q['signal']!='NO_ALERT'] if 'signal' in q else pd.DataFrame()
                السيولة={'عدد_الإشارات':int(len(alerts)),'آخر_إشارة':(str(alerts.iloc[-1]['signal']) if not alerts.empty else None)}
                if not alerts.empty: أدلة.append('بصمة_سيولة_لحظية_موجودة')
            except Exception as e: تحذيرات.append(f'تعذر_فحص_السيولة:{type(e).__name__}')
        # قناص يومي كدليل سلوكي، دون هوية أو احتمال.
        try:
            داخلي=df.rename(columns={'الرمز':'symbol','التاريخ':'session_date','الافتتاح':'open','الأعلى':'high','الأدنى':'low','الإغلاق':'close','الحجم':'volume'}).copy()
            if 'symbol' not in داخلي.columns:
                داخلي['symbol']=الرمز
            wr=فحص_القناص(داخلي); last=wr.iloc[-1].to_dict() if hasattr(wr,'iloc') and len(wr) else {}
            السيولة['القناص_اليومي']={k:last.get(k) for k in ('state','institutional_flow_score','confirmation_score','false_signal_risk') if k in last}
            if last.get('state') not in (None,'NO_SIGNAL'): أدلة.append(f"حالة_تدفق_القناص:{last.get('state')}")
        except Exception as e: تحذيرات.append(f'تعذر_فحص_القناص:{type(e).__name__}')
        الاتجاه=tech.get('الاتجاه','متوازن'); توصية='انحياز_إيجابي_للمراجعة' if الاتجاه=='إيجابي' else ('انحياز_سلبي_للمراجعة' if الاتجاه=='سلبي' else 'انتظار_تأكيد')
        return self._تقرير(الرمز,'جاهز_للمراجعة',توصية,تحذيرات,list(dict.fromkeys(أدلة)),tech.get('درجة الأدلة'),df,tech,السيولة,المصالحة,{'اسم':مصدر_البيانات,'متصل':False,'حي_موثق':False},guard,أخبار)
    def _تقرير(self,الرمز,الحالة,التوصية,أسباب,أدلة,درجة,df,tech,liq,rec,sources,guard,أخبار=None):
        نتيجة=asdict(نتيجة_عالمية(الرمز,الحالة,التوصية,tuple(dict.fromkeys(أسباب)),tuple(dict.fromkeys(أدلة)),درجة,البيانات={'عدد_السجلات':len(df),'آخر_تاريخ':str(df['التاريخ'].iloc[-1]) if 'التاريخ' in df else None},التحليل_الفني=tech,السيولة=liq,المصالحة=rec,حالة_المصادر=sources,بوابات_السلامة={'حارس_البيانات':guard.get('status'),'دلالة_الافتتاح':guard.get('opening_semantics'),'الإنتاج_مصرح':False},بصمة_البيانات=bصمة(df)))
        نتيجة['الأحداث']=أخبار or {}
        نتيجة['النص_العربي']=نص_عربي(نتيجة)
        return توليد_تقرير(نتيجة,آخر_بيانات={'الرمز':الرمز,'عدد_السجلات':len(df),'بصمة':نتيجة['بصمة_البيانات']})

def bصمة(df):
    try:return بصمة_بيانات(df)
    except Exception:return None
