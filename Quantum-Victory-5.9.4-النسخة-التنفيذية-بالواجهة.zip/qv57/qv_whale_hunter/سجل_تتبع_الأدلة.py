# -*- coding: utf-8 -*-
"""كوانتوم فيكتوري 4.25 — سجل تتبع الأدلة.
يربط كل دليل بمصدره ووقت وصوله وبصمته وحدود صلاحيته، ويمنع الدليل
غير القابل للتتبع من الوصول إلى بطاقة القرار.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json
from typing import Any

@dataclass
class دليل:
    الاسم: str
    المصدر: str
    النوع: str
    وقت_الوصول: str
    البيانات: Any
    حالة_المصدر: str = "مصرح_للاستخدام"
    وقت_المعلومة: str | None = None
    حد_العمر_بالثواني: int | None = None
    متاح_قبل_القرار: bool = True

class سجل_تتبع_الأدلة:
    def __init__(self):
        self.الأدلة=[]

    @staticmethod
    def _بصمة(بيانات):
        raw=json.dumps(بيانات, ensure_ascii=False, sort_keys=True, default=str).encode('utf-8')
        return hashlib.sha256(raw).hexdigest()

    def إضافة(self, *, الاسم, المصدر, النوع, البيانات, وقت_الوصول=None,
              وقت_المعلومة=None, حالة_المصدر="مصرح_للاستخدام",
              حد_العمر_بالثواني=None, متاح_قبل_القرار=True):
        if not الاسم or not المصدر or not النوع:
            raise ValueError("بيانات تتبع الدليل غير مكتملة")
        item=دليل(الاسم, المصدر, النوع,
                  وقت_الوصول or datetime.now(timezone.utc).isoformat(),
                  البيانات, حالة_المصدر, وقت_المعلومة,
                  حد_العمر_بالثواني, bool(متاح_قبل_القرار))
        row=asdict(item)
        row["البصمة"]=self._بصمة(البيانات)
        self.الأدلة.append(row)
        return row

    def تقييم(self, الآن=None):
        الآن_dt=datetime.fromisoformat((الآن or datetime.now(timezone.utc).isoformat()).replace('Z','+00:00'))
        صالحة=[]; موانع=[]
        for d in self.الأدلة:
            if d["حالة_المصدر"] not in {"مصرح_للاستخدام","موثوق"}:
                موانع.append(f"المصدر غير معتمد: {d['المصدر']}")
                continue
            if not d["متاح_قبل_القرار"]:
                موانع.append(f"تسرب زمني: {d['الاسم']}")
                continue
            if d["وقت_المعلومة"] and d["حد_العمر_بالثواني"] is not None:
                try:
                    t=datetime.fromisoformat(d["وقت_المعلومة"].replace('Z','+00:00'))
                    age=(الآن_dt-t).total_seconds()
                    if age > d["حد_العمر_بالثواني"]:
                        موانع.append(f"دليل متقادم: {d['الاسم']}")
                        continue
                except Exception:
                    موانع.append(f"وقت معلومة غير صالح: {d['الاسم']}")
                    continue
            صالحة.append(d)
        return {"صالحة":صالحة,"الموانع":list(dict.fromkeys(موانع)),"عدد_الأدلة":len(self.الأدلة)}

    def حزمة_التدقيق(self, الآن=None):
        تقييم=self.تقييم(الآن)
        return {
            "الإصدار":"4.25",
            "عدد_الأدلة":تقييم["عدد_الأدلة"],
            "الأدلة_الصالحة":تقييم["صالحة"],
            "الموانع":تقييم["الموانع"],
            "جاهز_للقرار":bool(تقييم["صالحة"] and not تقييم["الموانع"]),
            "الإنتاج_مصرح":False,
        }
