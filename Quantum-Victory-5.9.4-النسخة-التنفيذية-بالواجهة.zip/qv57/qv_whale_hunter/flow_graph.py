from __future__ import annotations
import numpy as np
import pandas as pd

ENGINE='QV-FLOW-PROPAGATION-GRAPH'; VERSION='4.1.0'

def build_flow_graph(grid_df: pd.DataFrame, top_n=20, half_life_minutes=8):
    if grid_df is None or grid_df.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    x=grid_df.copy(); x['timestamp']=pd.to_datetime(x['timestamp'],errors='coerce')
    x=x.dropna(subset=['timestamp','symbol']).sort_values('timestamp')
    def num(c,d=0.):
        return pd.to_numeric(x[c],errors='coerce').fillna(d) if c in x else pd.Series(d,index=x.index,dtype=float)
    x['grid_score']=num('grid_score'); x['buy_pressure']=num('buy_pressure',.5).clip(0,1)
    x['sector_sync_score']=num('sector_sync_score'); x['grid_sync_score']=num('grid_sync_score')
    x['flow_strength']=((x.grid_score/100)*(.5+.5*x.buy_pressure)).clip(0,1)
    # Edge evidence: nearby symbols in the same minute/session window. This is behavioral co-movement, not actor inference.
    rows=[]; half=max(float(half_life_minutes),1.0)
    for t,g in x.groupby(x.timestamp.dt.floor('min')):
        g=g[g.flow_strength>0.35]
        if len(g)<2: continue
        rec=g[['symbol','sector','flow_strength','grid_score']].to_dict('records')
        for a in range(len(rec)):
            for b in range(a+1,len(rec)):
                ra,rb=rec[a],rec[b]
                if ra['symbol']==rb['symbol']: continue
                sector_link=1.0 if (ra.get('sector')==rb.get('sector') and ra.get('sector') not in (None,'UNKNOWN',np.nan)) else 0.0
                weight=min(1.,(ra['flow_strength']+rb['flow_strength'])/2)*(0.7+0.3*sector_link)
                rows.append({'timestamp':t,'source_symbol':ra['symbol'],'target_symbol':rb['symbol'],'edge_weight':round(weight,6),'sector_link':sector_link})
                rows.append({'timestamp':t,'source_symbol':rb['symbol'],'target_symbol':ra['symbol'],'edge_weight':round(weight,6),'sector_link':sector_link})
    edges=pd.DataFrame(rows)
    if edges.empty:
        x['propagation_in']=0.; x['propagation_out']=0.; x['network_centrality']=0.; x['migration_direction']='STABLE'; x['propagation_score']=x.grid_score
        snap=pd.DataFrame([{'timestamp':x.timestamp.max(),'edges':0,'active_nodes':int(x.symbol.nunique()),'top_propagation_symbol':x.iloc[x.grid_score.argmax()].symbol}])
        return x,edges,snap
    # Exponential recency weighting: recent edges matter more, old edges decay.
    now=x.timestamp.max(); age=(now-edges.timestamp).dt.total_seconds()/60
    edges['recency_weight']=np.exp(-np.log(2)*age/half); edges['effective_weight']=edges.edge_weight*edges.recency_weight
    incoming=edges.groupby('target_symbol').effective_weight.sum(); outgoing=edges.groupby('source_symbol').effective_weight.sum()
    x['propagation_in']=x.symbol.map(incoming).fillna(0.); x['propagation_out']=x.symbol.map(outgoing).fillna(0.)
    scale=max(float(max(x.propagation_in.max(),x.propagation_out.max(),1.0)),1e-9)
    x['network_centrality']=((x.propagation_in+x.propagation_out)/(2*scale)*100).clip(0,100)
    x['propagation_score']=(.65*x.grid_score+.20*x.network_centrality+.15*(x.propagation_in/(x.propagation_in+x.propagation_out+1e-9)*100)).clip(0,100).round(4)
    x['migration_direction']=np.select([x.propagation_in>x.propagation_out*1.25,x.propagation_out>x.propagation_in*1.25],['INFLOW_NETWORK','OUTFLOW_NETWORK'],default='BALANCED_NETWORK')
    latest=x.sort_values('timestamp').groupby('symbol',as_index=False).tail(1).sort_values('propagation_score',ascending=False).head(top_n)
    snap=pd.DataFrame([{'timestamp':x.timestamp.max(),'edges':len(edges),'active_nodes':int(x.symbol.nunique()),'network_centrality_mean':round(float(x.network_centrality.mean()),4),'top_propagation_symbol':latest.symbol.iloc[0] if not latest.empty else None,'top_propagation_score':float(latest.propagation_score.iloc[0]) if not latest.empty else None}])
    return x,edges,snap
