from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .session_profile import build_profile, save_profile
from .live_liquidity_sniper import scan
from .flow_confirmation import FlowConfirmationEngine
from .adaptive_flow import enrich
from .market_scanner import scan_market
from .outcome_replay import attach_future_outcomes

ENGINE='QV-WHALE-HUNTER-V38'; VERSION='3.8.0'

def run(intraday_df: pd.DataFrame, historical_intraday_df: pd.DataFrame|None=None, out_dir='QV-V38-RUN',
        daily_baseline=None, top_n=30, min_history_sessions=3, **scan_kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    profile=build_profile(historical_intraday_df,min_history_sessions=min_history_sessions) if historical_intraday_df is not None and not historical_intraday_df.empty else pd.DataFrame()
    if not profile.empty: save_profile(profile,out)
    scored=scan(intraday_df,daily_baseline=daily_baseline,session_profile=profile,**scan_kwargs)
    confirmer=FlowConfirmationEngine()
    confirmed=confirmer.process(scored)
    intelligent=enrich(confirmed)
    market=scan_market(intelligent,top_n=top_n)
    alerts=market[market['signal']!='NO_ALERT'].copy() if not market.empty else market
    outcomes=attach_future_outcomes(alerts,intraday_df) if not alerts.empty else pd.DataFrame()
    scored.to_csv(out/'QV-V38-SCORES.csv',index=False)
    confirmed.to_csv(out/'QV-V38-CONFIRMED-STREAM.csv',index=False)
    intelligent.to_csv(out/'QV-V38-INTELLIGENCE-STREAM.csv',index=False)
    market.to_csv(out/'QV-V38-MARKET-RADAR.csv',index=False)
    if not outcomes.empty: outcomes.to_csv(out/'QV-V38-OUTCOMES.csv',index=False)
    report={'engine':ENGINE,'version':VERSION,'status':'PASS','rows_scored':len(scored),'symbols_scored':int(scored.symbol.nunique()) if not scored.empty else 0,
            'market_ranked':len(market),'alerts':len(alerts),'confirmed_flow':int(confirmed.confirmation_ready.sum()) if 'confirmation_ready' in confirmed else 0,
            'hunter_lock':int((intelligent.hunter_state=='HUNTER_LOCK').sum()) if not intelligent.empty else 0,
            'trap_risk':int((intelligent.hunter_state=='TRAP_RISK').sum()) if not intelligent.empty else 0,
            'session_baseline':not profile.empty,'baseline_policy':'latest prior completed session only',
            'adaptive_features':['flow_persistence_3','flow_persistence_6','absorption_risk','flow_price_divergence','book_support','turnover_support','trade_support'],
            'state_machine':['WATCH','BUILDING','CONFIRMED_FLOW','FADING','INVALIDATED'],
            'outcome_horizons_minutes':[5,10,20,30],'evidence_only':True,'identity_claim':False,
            'probability_output':None,'fixed_price_target':None,'production_approved':False,'human_risk_check_required':True}
    (out/'QV-V38-CERTIFICATE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report,scored,confirmed,intelligent,market,outcomes
