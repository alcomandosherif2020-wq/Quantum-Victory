from __future__ import annotations
import pandas as pd
VERSION='5.4.0'

SENSITIVE=('fwd_','forward_','mfe_','mae_','outcome_','label_')

def audit_dataframe(df):
    issues=[]
    cols=[str(c).lower() for c in df.columns]
    future=[c for c in cols if c.startswith(SENSITIVE)]
    if future: issues.append({'type':'future_field','columns':future,'severity':'CRITICAL'})
    if 'decision_time' in cols and 'eligibility_time' in cols:
        d=pd.to_datetime(df[df.columns[cols.index('decision_time')]],errors='coerce')
        e=pd.to_datetime(df[df.columns[cols.index('eligibility_time')]],errors='coerce')
        if bool((e>d).fillna(False).any()): issues.append({'type':'point_in_time','severity':'CRITICAL'})
    return {'status':'BLOCKED' if issues else 'PASS','issues':issues,'version':VERSION}

def mutation_suite(df):
    base=audit_dataframe(df)
    results={'base':base}
    if len(df):
        x=df.copy(); x.columns=[str(c) for c in x.columns]
        x['fwd_synthetic']=1.0
        results['future_injection']=audit_dataframe(x)
    return results
