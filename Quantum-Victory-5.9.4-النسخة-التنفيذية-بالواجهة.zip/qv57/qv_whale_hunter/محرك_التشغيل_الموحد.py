# -*- coding: utf-8 -*-
"""كوانتوم فيكتوري 4.19 — محرك التشغيل الموحد.
يربط المصدر بجودة البيانات والمصالحة وسجل الأدلة والتحليل والتنبيه،
مع منع التقادم والتعارض والنتائج غير الصالحة من الوصول إلى التنبيه.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Callable
import math

@dataclass
class نتيجة_التشغيل:
    المصدر: str
    الحالة: str
    صالح_للمعالجة: bool
    صالح_للتنبيه: bool
    السبب: str = ""
    البيانات: Any = None

class محرك_التشغيل_الموحد:
    def __init__(self):
        self.المراحل: list[tuple[str, Callable[[Any], Any]]] = []
        self.سجل: list[dict] = []
        self.بوابة_الإنتاج = False

    def إضافة_مرحلة(self, الاسم: str, وظيفة: Callable[[Any], Any]):
        if not الاسم or not callable(وظيفة):
            raise ValueError("اسم ووظيفة المرحلة مطلوبان")
        self.المراحل.append((الاسم, وظيفة))

    @staticmethod
    def فحص_بيانات(بيانات, عمر_ثوان=None, الحد_الأقصى_للعمر=120, قيم_مرجعية=None, سماحية=1e-9):
        if بيانات is None:
            return False, False, "بيانات فارغة"
        if عمر_ثوان is not None and عمر_ثوان > الحد_الأقصى_للعمر:
            return False, False, "بيانات متقادمة"
        if قيم_مرجعية:
            vals=[]
            for x in قيم_مرجعية:
                try:
                    x=float(x)
                    if math.isfinite(x): vals.append(x)
                except (TypeError, ValueError): pass
            if len(vals)>1 and max(vals)-min(vals)>سماحية:
                return False, False, "تعارض بين المصادر"
        return True, True, ""

    def تشغيل(self, المصدر: str, بيانات=None, عمر_ثوان=None, الحد_الأقصى_للعمر=120, قيم_مرجعية=None):
        ok, alert, reason = self.فحص_بيانات(بيانات, عمر_ثوان, الحد_الأقصى_للعمر, قيم_مرجعية)
        if not ok:
            r=نتيجة_التشغيل(المصدر, "محجوب", False, False, reason)
            self.سجل.append(asdict(r)); return r
        current=بيانات
        try:
            for name, fn in self.المراحل:
                current=fn(current)
                if current is None:
                    raise ValueError(f"المرحلة {name} أعادت نتيجة فارغة")
            # لا تنبيه إنتاجي قبل فتح البوابة العلمية.
            r=نتيجة_التشغيل(المصدر, "مكتمل", True, bool(self.بوابة_الإنتاج and alert), "", current)
        except Exception as e:
            r=نتيجة_التشغيل(المصدر, "فشل", False, False, str(e))
        self.سجل.append(asdict(r)); return r

    def ملخص(self):
        return {
            "الإصدار":"4.19",
            "عدد_التشغيلات":len(self.سجل),
            "المحطات":[x[0] for x in self.المراحل],
            "الإنتاج_مصرح":False,
            "آخر_النتائج":self.سجل[-20:]
        }
