# -*- coding: utf-8 -*-
"""كوانتوم فيكتوري 5.9.3 — مركز قيادة افتتاح الجلسة.
يجمع الافتتاح والسيولة والقناص والسلوك في سجل زمني واحد.
لا يدعي بثاً حياً ولا هوية حوت ولا احتمالات أو أهدافاً سعرية ثابتة.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any
import pandas as pd
from .live_liquidity_sniper import scan, latest_alerts

@dataclass
class حالة_المركز:
    الحالة: str
    المرحلة: str
    آخر_تحديث: str
    جاهز: bool
    الإنتاج_مصرح: bool = False
    ادعاء_هوية: bool = False
    احتمالات: bool = False
    هدف_سعري_ثابت: bool = False

class مركز_قيادة_افتتاح_الجلسة:
    """طبقة تشغيلية فوق قناص السيولة لتتبع تطور الأدلة عبر الجلسة."""
    def __init__(self):
        self.المرحلة = "قبل_بداية_الجلسة"
        self.السجل: list[dict[str, Any]] = []
        self.آخر_نتيجة: dict[str, Any] | None = None

    def تجهيز(self) -> dict[str, Any]:
        self.المرحلة = "جاهز_للافتتاح"
        return asdict(حالة_المركز("جاهز_للتشغيل", self.المرحلة, datetime.now(timezone.utc).isoformat(), True))

    def فحص(self, بيانات: pd.DataFrame, مصدر="بيانات_الجلسة", **kwargs) -> dict[str, Any]:
        if not isinstance(بيانات, pd.DataFrame) or بيانات.empty:
            self.المرحلة = "محجوب_لنقص_البيانات"
            return {"الحالة":"محجوب", "السبب":"لا توجد بيانات جلسة قابلة للتحليل", "الإنتاج_مصرح":False}
        self.المرحلة = "تحليل_متتابع_للجلسة"
        scored = scan(بيانات, **kwargs)
        alerts = latest_alerts(scored)
        timeline = self._timeline(scored)
        self.السجل.extend(timeline)
        self.آخر_نتيجة = {"الدرجات":scored, "التنبيهات":alerts, "المسار":timeline}
        return {
            "الحالة":"تم_الفحص", "المرحلة":self.المرحلة, "مصدر_البيانات":مصدر,
            "عدد_الأسطر":int(len(scored)), "عدد_الأسهم":int(scored.symbol.nunique()) if not scored.empty else 0,
            "عدد_التنبيهات":int(len(alerts)),
            "أولوية_شراء_مرتفعة":int((alerts.signal=="HIGH_PRIORITY_BUY_FLOW").sum()) if not alerts.empty else 0,
            "المسار":timeline, "التنبيهات":alerts.to_dict(orient="records"),
            "الإنتاج_مصرح":False, "هوية_الحيتان":None, "الاحتمالات":None, "الهدف_السعري_الثابت":None,
        }

    @staticmethod
    def _timeline(scored: pd.DataFrame) -> list[dict[str, Any]]:
        if scored.empty: return []
        cols=[c for c in ["symbol","timestamp","price","volume","sniper_score","signal","buy_pressure","volume_accel","rvol_local","book_imbalance","trade_intensity_rv"] if c in scored.columns]
        x=scored[cols].copy()
        for c in ["price","volume","sniper_score","buy_pressure","volume_accel","rvol_local","book_imbalance","trade_intensity_rv"]:
            if c in x: x[c]=pd.to_numeric(x[c],errors="coerce")
        out=[]
        for _,r in x.sort_values("timestamp").iterrows():
            signal=str(r.get("signal","NO_ALERT"))
            out.append({
                "الرمز":r.get("symbol"), "الوقت":str(r.get("timestamp")), "السعر":r.get("price"),
                "الحجم":r.get("volume"), "درجة_القنص":r.get("sniper_score"), "الإشارة":signal,
                "ضغط_الشراء":r.get("buy_pressure"), "تسارع_الحجم":r.get("volume_accel"),
                "السيولة_النسبية":r.get("rvol_local"), "اختلال_دفتر_الأوامر":r.get("book_imbalance"),
                "شدة_التنفيذ":r.get("trade_intensity_rv"),
                "دلالة":"دليل_مرصود_وليس_إثبات_هوية"
            })
        return out

    def ملخص(self) -> dict[str, Any]:
        آخر=self.آخر_نتيجة or {}
        alerts=آخر.get("التنبيهات")
        return {"المرحلة":self.المرحلة,"جاهز":self.المرحلة in {"قبل_بداية_الجلسة","جاهز_للافتتاح"},
                "عدد_السجلات":len(self.السجل),
                "عدد_التنبيهات":int(len(alerts)) if isinstance(alerts,pd.DataFrame) else 0,
                "الإنتاج_مصرح":False,"هوية_الحيتان":None,"الاحتمالات":None,"الهدف_السعري_الثابت":None}
