# -*- coding: utf-8 -*-
"""مدقق عالمي آمن للنسخة النهائية.
لا يتبع الروابط الرمزية أو الأشجار خارج جذر المشروع، ويتجاوز المسارات التي
يتعذر فحصها بدل إسقاط عملية التدقيق كلها.
"""
from __future__ import annotations
import ast, re, warnings
from pathlib import Path

_مستثنيات = {'.git', '.pytest_cache', '__pycache__', '.mypy_cache', '.ruff_cache', '.venv', 'venv'}

class مدقق_المنظومة:
    def __init__(self, root='.'):
        self.root = Path(root).resolve()
        self.findings = []
        self.unreadable = []

    def add(self, severity, code, path, message):
        self.findings.append({'الخطورة': severity, 'الرمز': code, 'الملف': str(path), 'الرسالة': message})

    def _الملفات(self):
        """تعداد آمن لا يعبر خارج الجذر ولا ينهار بسبب صلاحيات نظام التشغيل."""
        stack = [self.root]
        while stack:
            current = stack.pop()
            try:
                with current.open('rb') as _:
                    pass
            except (IsADirectoryError, PermissionError, OSError):
                pass
            try:
                entries = list(current.iterdir())
            except (PermissionError, OSError) as exc:
                self.unreadable.append({'المسار': str(current), 'الخطأ': type(exc).__name__})
                continue
            for p in entries:
                if any(part in _مستثنيات for part in p.parts):
                    continue
                try:
                    if p.is_symlink():
                        # لا نفحص الروابط الرمزية؛ قد تقود إلى /proc أو خارج الحزمة.
                        continue
                    if p.is_dir():
                        stack.append(p)
                    elif p.is_file():
                        yield p
                except (PermissionError, OSError) as exc:
                    self.unreadable.append({'المسار': str(p), 'الخطأ': type(exc).__name__})

    def run(self):
        for p in self._الملفات():
            if p.name.endswith('.bak') or p.suffix == '.tmp':
                self.add('متوسط', 'BACKUP_FILE', p, 'ملف احتياطي داخل حزمة التشغيل')
            if p.suffix == '.py':
                try:
                    source = p.read_text(encoding='utf-8')
                    # التحذيرات اللغوية ليست أخطاء نحوية؛ نسجل الأخطاء الحقيقية فقط.
                    with warnings.catch_warnings():
                        warnings.simplefilter('ignore', SyntaxWarning)
                        ast.parse(source, filename=str(p))
                except Exception as e:
                    self.add('حرج', 'PYTHON_SYNTAX', p, type(e).__name__)
                    continue
                text = source
                if re.search(r'bot\d+:[A-Za-z0-9_-]{20,}', text):
                    self.add('حرج', 'SECRET_LITERAL', p, 'قد يحتوي النص على رمز تيليجرام')
                if re.search(r'production_approved\s*=\s*True', text):
                    self.add('حرج', 'DIRECT_PRODUCTION_ENABLE', p, 'فتح إنتاج مباشر داخل الكود')

        for name in ('الخدمة_المستقلة.py', 'autonomous_service.py'):
            p = self.root / 'qv_whale_hunter' / name
            if p.exists():
                try:
                    text = p.read_text(encoding='utf-8')
                    if 'production_approved' not in text:
                        self.add('حرج', 'TELEGRAM_GATE_MISSING', p, 'لا يوجد حارس اعتماد قبل الإرسال')
                except OSError as exc:
                    self.add('حرج', 'READ_FAILURE', p, type(exc).__name__)

        return self.report()

    def report(self):
        counts = {}
        for f in self.findings:
            counts[f['الخطورة']] = counts.get(f['الخطورة'], 0) + 1
        return {
            'الإصدار': 'نهائي',
            'عدد_الملاحظات': len(self.findings),
            'حسب_الخطورة': counts,
            'الملاحظات': self.findings,
            'عدد_المسارات_غير_القابلة_للقراءة': len(self.unreadable),
            'الحكم': 'يحتاج_تصحيح' if any(f['الخطورة'] == 'حرج' for f in self.findings) else 'اجتاز_التدقيق_الساكن'
        }
