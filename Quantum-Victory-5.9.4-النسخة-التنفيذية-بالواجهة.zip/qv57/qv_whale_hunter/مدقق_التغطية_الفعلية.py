from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable, Mapping
from datetime import datetime, timezone
import pandas as pd

@dataclass(frozen=True)
class نتيجة_الفحص:
    الرمز: str
    المصدر: str
    نوع_البيانات: str
    الحالة: str
    عدد_السجلات: int = 0
    آخر_تاريخ: str | None = None
    سبب: str = ''
    مصدر_الدليل: str = ''

الحالات_المسموحة = {'مُثبت','غير_متاح','فشل_الفحص','بيانات_ناقصة','غير_مُختبر','متعارض'}

def توحيد_الرمز(الرمز: str) -> str:
    s = str(الرمز).strip().upper()
    return s[:-3] if s.endswith('.CA') else s

def فحص_صفوف_السعر(الرمز: str, المصدر: str, df: pd.DataFrame, مصدر_الدليل: str='') -> نتيجة_الفحص:
    if df is None or len(df) == 0:
        return نتيجة_الفحص(توحيد_الرمز(الرمز), المصدر, 'يومي', 'غير_متاح', 0, None, 'لم تصل سجلات سعرية.', مصدر_الدليل)
    cols = {str(c).lower(): c for c in df.columns}
    required_sets = [
        {'date','open','high','low','close','volume'},
        {'التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم'},
    ]
    ok = any(all(k in cols for k in req) for req in required_sets)
    if not ok:
        return نتيجة_الفحص(توحيد_الرمز(الرمز), المصدر, 'يومي', 'بيانات_ناقصة', len(df), None, 'الأعمدة الأساسية غير مكتملة.', مصدر_الدليل)
    # اختبار منطقي مستقل عن أسماء الأعمدة
    def pick(a,b): return cols.get(a, cols.get(b))
    hi, lo, op, cl = pick('high','الأعلى'), pick('low','الأدنى'), pick('open','الافتتاح'), pick('close','الإغلاق')
    h,l,o,c = [pd.to_numeric(df[x], errors='coerce') for x in (hi,lo,op,cl)]
    # دلالة «الافتتاح» مهمة: بعض المصادر تسمي إغلاق الجلسة السابقة
    # سعرًا افتتاحيًا/مرجعيًا. لا يجوز عندها فرض h>=o و l<=o.
    semantic = None
    for key in ('دلالة_الافتتاح','نوع_الافتتاح','open_semantics','opening_semantics'):
        if key in df.columns:
            vals = df[key].dropna().astype(str).str.strip()
            if len(vals): semantic = vals.mode().iloc[0]
            break
    افتتاح_جلسة = semantic in {None, 'افتتاح_الجلسة', 'سعر_افتتاح_الجلسة', 'session_open'}
    bad = (h < l) | (h < c) | (l > c) | h.isna() | l.isna() | o.isna() | c.isna()
    if افتتاح_جلسة:
        bad = bad | (h < o) | (l > o)
    if bool(bad.any()):
        return نتيجة_الفحص(توحيد_الرمز(الرمز), المصدر, 'يومي', 'فشل_الفحص', len(df), None, f'وجدت {int(bad.sum())} شموع تخالف منطق OHLC.', مصدر_الدليل)
    date_col = pick('date','التاريخ')
    dates = pd.to_datetime(df[date_col], errors='coerce')
    if dates.isna().all():
        return نتيجة_الفحص(توحيد_الرمز(الرمز), المصدر, 'يومي', 'بيانات_ناقصة', len(df), None, 'تعذر تفسير التاريخ.', مصدر_الدليل)
    سبب = 'اجتاز فحص البنية ومنطق الشموع.'
    if semantic not in (None, 'افتتاح_الجلسة', 'سعر_افتتاح_الجلسة', 'session_open'):
        سبب += ' دلالة الافتتاح غير جلسة فعلية؛ لم يُفرض h>=open/l<=open.'
    return نتيجة_الفحص(توحيد_الرمز(الرمز), المصدر, 'يومي', 'مُثبت', len(df), dates.max().date().isoformat(), سبب, مصدر_الدليل)

def بناء_تقرير_التغطية(الرموز: Iterable[str], نتائج: Iterable[Mapping]) -> dict:
    wanted = {توحيد_الرمز(x) for x in الرموز}
    parsed=[]
    for r in نتائج:
        rr=dict(r)
        rr['الرمز']=توحيد_الرمز(rr.get('الرمز',''))
        if rr['الرمز'] in wanted:
            parsed.append(rr)
    df=pd.DataFrame(parsed)
    if df.empty:
        summary=pd.DataFrame(columns=['الرمز','مصادر_مُثبتة','مصادر_غير_متاحة','مصادر_فاشلة','مصادر_ناقصة','مصادر_متعارضة'])
    else:
        def n(v): return int((df['الحالة']==v).sum())
        rows=[]
        for sym,g in df.groupby('الرمز'):
            rows.append({'الرمز':sym,'مصادر_مُثبتة':int((g['الحالة']=='مُثبت').sum()),'مصادر_غير_متاحة':int((g['الحالة']=='غير_متاح').sum()),'مصادر_فاشلة':int((g['الحالة']=='فشل_الفحص').sum()),'مصادر_ناقصة':int((g['الحالة']=='بيانات_ناقصة').sum()),'مصادر_متعارضة':int((g['الحالة']=='متعارض').sum())})
        summary=pd.DataFrame(rows)
    return {'وقت_التقرير':datetime.now(timezone.utc).isoformat(),'عدد_الرموز':len(wanted),'النتائج':df.to_dict(orient='records'),'الملخص':summary.to_dict(orient='records'),'قاعدة_القرار':'لا يُعتبر المصدر مثبتًا إلا بعد وصول بيانات فعلية واجتياز فحوص البنية والجودة.'}
