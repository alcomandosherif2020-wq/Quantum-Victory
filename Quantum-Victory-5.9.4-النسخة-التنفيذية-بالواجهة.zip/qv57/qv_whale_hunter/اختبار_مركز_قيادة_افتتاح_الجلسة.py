# -*- coding: utf-8 -*-
import pandas as pd
from مركز_قيادة_افتتاح_الجلسة import مركز_قيادة_افتتاح_الجلسة

def بيانات():
    t=pd.date_range('2026-09-06 10:00',periods=8,freq='min')
    return pd.DataFrame({'symbol':['TEST']*8,'timestamp':t,'price':[1,1.01,1.02,1.025,1.03,1.04,1.05,1.06], 'volume':[10,12,14,18,25,60,90,120]})

def test_تجهيز():
    m=مركز_قيادة_افتتاح_الجلسة(); r=m.تجهيز(); assert r['جاهز'] is True; assert r['الإنتاج_مصرح'] is False

def test_فحص_ومسار():
    m=مركز_قيادة_افتتاح_الجلسة(); r=m.فحص(بيانات()); assert r['الحالة']=='تم_الفحص'; assert r['عدد_الأسطر']==8; assert len(r['المسار'])==8; assert r['هوية_الحيتان'] is None

def test_نقص_البيانات_يحجب():
    m=مركز_قيادة_افتتاح_الجلسة(); r=m.فحص(pd.DataFrame()); assert r['الحالة']=='محجوب'; assert r['الإنتاج_مصرح'] is False
