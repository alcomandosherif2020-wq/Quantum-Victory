from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import pandas as pd
from .live_liquidity_sniper import scan as فحص_السيولة, latest_alerts as آخر_التنبيهات
from .whale_hunter import scan as فحص_السلوك_التاريخي
from .قناص_الحيتان_المحادثي import قناص_الحيتان_المحادثي

@dataclass
class حالة_مركز_القنص:
    الحالة: str
    المرحلة: str
    آخر_تحديث: str
    جاهزية_البيانات: bool
    جاهزية_القناص: bool
    جاهزية_الربط: bool
    يحتاج_بيانات_جلسة: bool
    الإنتاج_مصرح: bool = False
    ادعاء_هوية: bool = False
    احتمال: bool = False
    هدف_سعري_ثابت: bool = False

class مركز_القنص_المحادثي:
    """مركز تشغيل محادثي لقناص السيولة، دون ادعاء بث لحظي أو هوية متداول."""
    def __init__(self):
        self.القناص=قناص_الحيتان_المحادثي(); self.المرحلة="قبل_بداية_الجلسة"; self.سجل=[]
    def تجهيز(self, مصدر="بانتظار_بيانات_الجلسة", ملف_أساس_تاريخي=False, بيانات_لحظية=False):
        self.المرحلة="مستعد_للافتتاح"
        out=asdict(حالة_مركز_القنص("جاهز_ومستعد",self.المرحلة,datetime.now(timezone.utc).isoformat(),bool(بيانات_لحظية or ملف_أساس_تاريخي),True,True,not bool(بيانات_لحظية)))
        out["مصدر_البيانات"]=مصدر
        out["تعليمات_التشغيل"]=["أرسل لقطة الافتتاح أو البيانات اللحظية.","يُفحص الحجم والسيولة وتسارع التدفق وضغط الشراء والبيع.","تُقارن السيولة بالخط الأساس المتاح دون استخدام بيانات مستقبلية.","تُعرض الأدلة مرتبة مع درجة عدم اليقين.","إذا لم تكف الأدلة تكون النتيجة: لا_كفاية_للإشارة."]
        return out
    def تشغيل_لقطة(self, بيانات_لحظية, بيانات_يومية=None, مصدر="بيانات_مقدمة_في_المحادثة"):
        if بيانات_لحظية is None or بيانات_لحظية.empty:
            return {"الحالة":"محجوب_لعدم_وجود_بيانات","جاهز":True,"يحتاج_بيانات_جلسة":True,"الأدلة":[],"الإنتاج_مصرح":False}
        self.المرحلة="تحليل_لقطة_الجلسة"; نتيجة=فحص_السيولة(بيانات_لحظية.copy()); تنبيهات=آخر_التنبيهات(نتيجة)
        تاريخي=فحص_السلوك_التاريخي(بيانات_يومية) if بيانات_يومية is not None and not بيانات_يومية.empty else None
        الأدلة=[]
        for _,r in تنبيهات.iterrows():
            الأدلة.append({"الرمز":str(r.get("symbol")),"وقت_الدليل":str(r.get("timestamp")),"نوع_الدليل":str(r.get("signal")),"درجة_القناص":round(float(r.get("sniper_score",0)),2),"ضغط_الشراء":round(float(r.get("buy_pressure")),4) if pd.notna(r.get("buy_pressure")) else None,"اختلال_دفتر_الأوامر":round(float(r.get("book_imbalance")),4) if pd.notna(r.get("book_imbalance")) else None,"شدة_التنفيذ":round(float(r.get("trade_intensity_rv")),4) if pd.notna(r.get("trade_intensity_rv")) else None})
        if not الأدلة: حالة="لا_كفاية_للإشارة"
        elif any(x["نوع_الدليل"]=="HIGH_PRIORITY_BUY_FLOW" for x in الأدلة): حالة="تنبيه_سيولة_شراء_مرتفع"
        elif any(x["نوع_الدليل"]=="BUY_FLOW_WATCH" for x in الأدلة): حالة="مراقبة_تدفق_شراء"
        else: حالة="سيولة_غير_اعتيادية_تحتاج_تأكيد"
        out={"الحالة":حالة,"المرحلة":self.المرحلة,"مصدر_البيانات":مصدر,"عدد_السجلات_اللحظية":int(len(نتيجة)),"عدد_التنبيهات":int(len(تنبيهات)),"الأدلة":الأدلة,"ملخص_السلوك_التاريخي":None,"قواعد_السلامة":{"ادعاء_هوية":False,"احتمال":False,"هدف_سعري_ثابت":False,"الإنتاج_مصرح":False}}
        if تاريخي is not None and not تاريخي.empty:
            آخر=تاريخي.sort_values("session_date").groupby("symbol",as_index=False).tail(1)
            out["ملخص_السلوك_التاريخي"]=[{"الرمز":str(r.symbol),"حالة_التدفق":str(r.state),"درجة_التدفق":round(float(r.institutional_flow_score),2),"درجة_التأكيد":round(float(r.confirmation_score),2),"مخاطر_الإشارة_الكاذبة":round(float(r.false_signal_risk),2)} for r in آخر.itertuples()]
        self.سجل.append(out); return out
    def أمر_جاهز(self): return "جهز قناص الحيتان"
    def أمر_تشغيل(self): return "شغل قناص الحيتان والسيولة"
    def أمر_تحديث(self): return "حدث القناص"
    def أمر_مسح(self): return "امسح السيولة"
    def لقطة_الحالة(self): return {"الحالة":"جاهز_ومستعد" if self.المرحلة!="تحليل_لقطة_الجلسة" else "مراقبة_الجلسة","المرحلة":self.المرحلة,"عدد_الدورات":len(self.سجل),"الإنتاج_مصرح":False,"ادعاء_هوية":False,"احتمال":False,"هدف_سعري_ثابت":False}
