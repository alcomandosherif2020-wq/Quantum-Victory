from __future__ import annotations
import hashlib, json, re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin
import requests

الرابط_الرسمي = 'https://beta.egx.com.eg/ar'

@dataclass
class خبر_منظم:
    العنوان: str
    الرابط: str
    الرمز: str | None
    تاريخ_النشر: str | None
    الوقت_الظاهر: str | None
    التصنيف: str
    درجة_الأثر: str
    المصدر: str = 'البورصة المصرية'
    بصمة: str = ''

class محلل_صفحة_البورصة(HTMLParser):
    """محلل محافظ للصفحة المنشورة علناً؛ لا يتجاوز الحماية ولا يعتمد على بنية جافاسكربت خاصة."""
    def __init__(self, base_url: str):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.items = []
        self._tag = None
        self._href = None
        self._buf = []
        self._h = False
        self._last_text = []
        self._date = None
        self._time = None
        self._code = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs); self._tag = tag
        if tag == 'a':
            self._href = urljoin(self.base_url, attrs.get('href',''))
            self._buf = []
        elif tag in ('h1','h2','h3','h4','h5','h6'):
            self._h = True; self._buf=[]
        elif tag in ('time',):
            self._buf=[]

    def handle_data(self, data):
        t = re.sub(r'\s+', ' ', data).strip()
        if not t: return
        if self._h: self._buf.append(t)
        self._last_text.append(t)
        if len(self._last_text)>12: self._last_text=self._last_text[-12:]
        if re.fullmatch(r'\d{1,2}:\d{2}\s*(ص|م)?', t): self._time=t
        if re.fullmatch(r'\d{1,2}', t) and self._date is None: self._date=t
        m=re.search(r'([A-Z]{3,6})\.CA', t)
        if m: self._code=m.group(1)+'.CA'

    def handle_endtag(self, tag):
        if tag in ('h1','h2','h3','h4','h5','h6') and self._h:
            title=' '.join(self._buf).strip()
            if title and len(title)>12:
                self.items.append({'title':title,'href':self._href or self.base_url,
                                   'near':' '.join(self._last_text[-8:]),'code':self._code,'time':self._time})
            self._h=False; self._buf=[]
        if tag == 'a': self._href=None

def _استخرج_الرمز(text: str) -> str | None:
    m=re.search(r'\(([A-Z]{2,8}(?:\.[A-Z]{2})?)\)', text or '')
    return m.group(1) if m else None

def _تصنيف_الأثر(text: str) -> tuple[str,str]:
    t=text or ''
    قواعد=[
      ('قوائم مالية','عالٍ',r'نتائج أعمال|قوائم مالية|قوائم مالي|مراقب الحسابات|تقرير مالي'),
      ('تعاقدات وعمليات','متوسط',r'تعاقد|اتفاق|مشروع|تشغيل'),
      ('مجلس إدارة','متوسط',r'مجلس إدارة|قرارات مجلس'),
      ('جمعيات','متوسط',r'الجمعية العامة|جمعية عامة'),
      ('توزيعات وأرباح','عالٍ',r'توزيع|أرباح|كوبون'),
      ('أسهم خزينة وملكية','عالٍ',r'أسهم الخزينة|مساهمين رئيسيين|تعاملات الداخليين'),
      ('رأس مال وحقوق','عالٍ',r'زيادة رأس المال|تخفيض رأس المال|حق اكتتاب|تجزئة|اندماج|استحواذ'),
      ('قيد وإيقاف وتداول','عالٍ',r'القيد|إتاحة تداول|إيقاف|إعادة التداول'),
      ('إصدارات وأدوات دين','متوسط',r'سندات|أذون الخزانة|إعادة فتح الاكتتاب'),
    ]
    for cat,impact,pat in قواعد:
        if re.search(pat,t,re.I): return cat,impact
    return 'أخبار وإفصاحات عامة','غير محدد'

def تنظيم_العناصر(عناصر, وقت_الجلب=None):
    وقت_الجلب = وقت_الجلب or datetime.now(timezone.utc).isoformat()
    out=[]; seen=set()
    for x in عناصر:
        title=re.sub(r'\s+',' ',x.get('title','')).strip()
        if len(title)<12: continue
        key=hashlib.sha256((title+'|'+x.get('href','')).encode('utf-8')).hexdigest()
        if key in seen: continue
        seen.add(key)
        cat,impact=_تصنيف_الأثر(title)
        out.append(خبر_منظم(title, x.get('href') or الرابط_الرسمي, _استخرج_الرمز(title), None, x.get('time'), cat, impact))
    for item in out:
        item.بصمة=hashlib.sha256(json.dumps(asdict(item),ensure_ascii=False,sort_keys=True).encode('utf-8')).hexdigest()
    return out

class جامع_الأخبار:
    def __init__(self, timeout=8): self.timeout=timeout

    def تحليل_نص(self, html: str, وقت_الجلب=None):
        p=محلل_صفحة_البورصة(الرابط_الرسمي); p.feed(html)
        return تنظيم_العناصر(p.items, وقت_الجلب)

    def جلب(self):
        r=requests.get(الرابط_الرسمي,timeout=self.timeout,headers={'User-Agent':'QuantumVictory/ArabicDataCollector/4.8'})
        r.raise_for_status()
        وقت=datetime.now(timezone.utc).isoformat()
        العناصر=self.تحليل_نص(r.text,وقت)
        return {
            'المصدر':'البورصة المصرية','وقت_الجلب':وقت,'حالة':'تم الجلب',
            'حجم_المحتوى':len(r.text),'عدد_العناصر':len(العناصر),
            'العناصر':[asdict(x) for x in العناصر]
        }

    def حفظ(self, تقرير, مسار='تشغيل-كوانتوم-فيكتوري/الأخبار_والإفصاحات.json'):
        from pathlib import Path
        p=Path(مسار); p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps(تقرير,ensure_ascii=False,indent=2),encoding='utf-8')
        return p
