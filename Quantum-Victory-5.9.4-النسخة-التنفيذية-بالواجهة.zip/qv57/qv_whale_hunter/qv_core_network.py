from __future__ import annotations
import hashlib, json, sqlite3, zipfile
from pathlib import Path
from typing import Any, Callable
import pandas as pd

REQUIRED_CORE_ARTIFACTS = {
    'scenario_contract.json', 'experiment_contract.json', 'trend_contract.json'
}

class CoreNetworkResult:
    def __init__(self, status: str, reason: str = '', artifacts=None, tables=None, fingerprint=''):
        self.status=status; self.reason=reason; self.artifacts=artifacts or []; self.tables=tables or []; self.fingerprint=fingerprint

def _sha(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',',':'), default=str).encode()).hexdigest()

def inspect_core(path: str | Path) -> CoreNetworkResult:
    p=Path(path)
    if not p.exists(): return CoreNetworkResult('BLOCKED','CORE_PATH_NOT_FOUND')
    artifacts=[]; tables=[]
    if p.is_dir():
        for f in p.rglob('*'):
            if f.is_file(): artifacts.append(str(f.relative_to(p)))
    elif p.suffix.lower()=='.zip':
        try:
            with zipfile.ZipFile(p) as z:
                artifacts=[n for n in z.namelist() if not n.endswith('/')]
        except zipfile.BadZipFile: return CoreNetworkResult('BLOCKED','CORE_ZIP_INVALID')
    elif p.suffix.lower()=='.sqlite':
        try:
            with sqlite3.connect(p) as c:
                tables=[r[0] for r in c.execute("select name from sqlite_master where type='table' order by name")]
        except sqlite3.Error: return CoreNetworkResult('BLOCKED','CORE_SQLITE_INVALID')
    else:
        return CoreNetworkResult('BLOCKED','UNSUPPORTED_CORE_ARTIFACT')
    fp=_sha({'path':str(p.resolve()),'artifacts':sorted(artifacts),'tables':sorted(tables)})
    return CoreNetworkResult('PASS','',artifacts,tables,fp)

def read_core_sqlite(path: str | Path, table: str | None=None) -> pd.DataFrame:
    with sqlite3.connect(path) as c:
        names=[r[0] for r in c.execute("select name from sqlite_master where type='table' order by name")]
        if not names: return pd.DataFrame()
        candidates=names if table is None else [table]
        best=None
        for t in candidates:
            if t not in names: continue
            cols=[r[1] for r in c.execute(f'pragma table_info("{t}")')]
            score=sum(c in {x.lower() for x in cols} for c in ('symbol','ticker','date','session_date','open','high','low','close','volume','vol'))
            if best is None or score>best[0]: best=(score,t)
        if best is None or best[0]<4: return pd.DataFrame()
        return pd.read_sql_query(f'select * from "{best[1]}"',c)

def build_network_packet(core_path: str | Path, whale_certificate: dict, recommendation_df: pd.DataFrame | None=None) -> dict:
    info = CoreNetworkResult('PASS','CORE_DATAFRAME') if str(core_path) == 'CORE_DF' else inspect_core(core_path)
    packet={
        'network':'QV_CORE_X_WHALE_HUNTER', 'version':'3.2.0',
        'core_status':info.status, 'core_reason':info.reason,
        'core_artifacts':info.artifacts, 'core_tables':info.tables,
        'core_fingerprint':info.fingerprint,
        'whale_certificate':whale_certificate,
        'data_flow':'CORE_DATA -> QV_EVIDENCE -> WHALE_HUNTER -> SCENARIO -> RECOMMENDATION',
        'score_probability_separation':True,
        'identity_claim':False,
        'production_approved':False,
    }
    if recommendation_df is not None:
        packet['recommendation_rows']=int(len(recommendation_df))
        packet['recommendation_columns']=list(recommendation_df.columns)
        packet['recommendation_fingerprint']=hashlib.sha256(pd.util.hash_pandas_object(recommendation_df, index=True).values.tobytes()).hexdigest() if len(recommendation_df) else _sha([])
    packet['network_fingerprint']=_sha(packet)
    return packet
