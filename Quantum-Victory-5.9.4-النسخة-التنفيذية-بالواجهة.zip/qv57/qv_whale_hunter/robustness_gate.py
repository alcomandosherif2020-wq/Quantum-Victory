from __future__ import annotations
import hashlib, json
import numpy as np
import pandas as pd

VERSION='2.8.0'

def _clean_pair(a,b):
    x=pd.to_numeric(a,errors='coerce'); y=pd.to_numeric(b,errors='coerce')
    m=x.notna()&y.notna(); return x[m].to_numpy(float),y[m].to_numpy(float)

def paired_delta(champion, challenger):
    c,h=_clean_pair(champion,challenger); n=min(len(c),len(h));
    if n==0: return np.array([],float)
    return h[:n]-c[:n]

def bootstrap_mean_ci(values, n_boot=2000, seed=20260905, alpha=.05):
    x=np.asarray(values,float); x=x[np.isfinite(x)]
    if len(x)==0: return {'n':0,'mean':None,'ci_low':None,'ci_high':None}
    rng=np.random.default_rng(seed); idx=rng.integers(0,len(x),size=(n_boot,len(x)))
    means=x[idx].mean(axis=1); lo,hi=np.quantile(means,[alpha/2,1-alpha/2])
    return {'n':int(len(x)),'mean':float(x.mean()),'ci_low':float(lo),'ci_high':float(hi)}

def permutation_pvalue(values, n_perm=5000, seed=20260905):
    x=np.asarray(values,float); x=x[np.isfinite(x)]
    if len(x)==0: return None
    obs=abs(float(x.mean())); rng=np.random.default_rng(seed)
    signs=rng.choice([-1.,1.],size=(n_perm,len(x)))
    null=np.abs((signs*x).mean(axis=1))
    return float((1+(null>=obs).sum())/(n_perm+1))

def multiple_comparison_guard(p_values, alpha=.05, method='holm'):
    p=np.asarray([v for v in p_values if v is not None and np.isfinite(v)],float)
    if len(p)==0: return {'status':'NO_PVALUES','rejected':0,'tested':0}
    order=np.argsort(p); rej=0
    if method=='holm':
        for rank,i in enumerate(order):
            if p[i] <= alpha/(len(p)-rank): rej+=1
            else: break
    else:
        rej=int((p<alpha).sum())
    return {'status':'PASS' if rej else 'NO_SIGNIFICANT_RESULT','rejected':rej,'tested':int(len(p)),'method':method,'alpha':alpha}

def compare_models(results, champion='champion', challenger='challenger', min_oos_rows=100, min_improvement=0.0, alpha=.05):
    if results is None or not {'model','oos_return'}.issubset(results.columns):
        return {'status':'BLOCKED_MISSING_OOS_RESULTS'}
    x=results.copy(); x['oos_return']=pd.to_numeric(x['oos_return'],errors='coerce'); x=x.dropna(subset=['oos_return'])
    c=x.loc[x.model==champion,'oos_return'].to_numpy(float); h=x.loc[x.model==challenger,'oos_return'].to_numpy(float)
    n=min(len(c),len(h))
    if n<min_oos_rows: return {'status':'BLOCKED_INSUFFICIENT_OOS_SAMPLE','paired_rows':int(n),'min_oos_rows':min_oos_rows}
    d=h[:n]-c[:n]; boot=bootstrap_mean_ci(d); p=permutation_pvalue(d)
    robust=boot['ci_low']>min_improvement and p<alpha
    return {'status':'PASS' if robust else 'REJECT','paired_rows':int(n),'champion_mean_oos_return':float(c[:n].mean()),'challenger_mean_oos_return':float(h[:n].mean()),'mean_improvement':float(d.mean()),'bootstrap':boot,'permutation_pvalue':p,'alpha':alpha,'minimum_improvement':min_improvement}

def robustness_certificate(audit, stability=None):
    return hashlib.sha256(json.dumps({'version':VERSION,'audit':audit,'stability':stability},sort_keys=True,default=str).encode()).hexdigest()
