from __future__ import annotations
import numpy as np
import pandas as pd

VERSION='1.6.0'

SIZE_LABELS=('MICRO_FLOW','SMALL_FLOW','MEDIUM_FLOW','LARGE_WHALE','MEGA_WHALE')

def _pct_rank(s):
    return s.rank(pct=True, method='average')

def classify_whale_size(df: pd.DataFrame) -> pd.DataFrame:
    x=df.copy()
    if x.empty:
        x['flow_intensity']=pd.Series(dtype=float); x['whale_size_class']=pd.Series(dtype=str)
        return x
    volz=pd.to_numeric(x['volume_z20'],errors='coerce').fillna(0).abs() if 'volume_z20' in x.columns else pd.Series(0.0,index=x.index)
    lz=pd.to_numeric(x['liquidity_z20'],errors='coerce').fillna(0).abs() if 'liquidity_z20' in x.columns else (pd.to_numeric(x['turnover_z20'],errors='coerce').fillna(0).abs() if 'turnover_z20' in x.columns else pd.Series(0.0,index=x.index))
    shock=volz.clip(0,6)/6
    liq=lz.clip(0,6)/6
    persistence=pd.to_numeric(x['buy_event_count'],errors='coerce').fillna(0).clip(0,6)/6 if 'buy_event_count' in x.columns else pd.Series(0.0,index=x.index)
    intensity=(0.45*shock+0.35*liq+0.20*persistence)*100
    x['flow_intensity']=intensity.round(4)
    # Size is relative to the stock's own history where possible, avoiding a raw-volume bias.
    q=intensity.groupby(x.get('symbol',pd.Series('ALL',index=x.index))).transform(lambda s: _pct_rank(s.fillna(0)))
    x['whale_size_class']=np.select([q>=.995,q>=.95,q>=.80,q>=.50],[ 'MEGA_WHALE','LARGE_WHALE','MEDIUM_FLOW','SMALL_FLOW'],default='MICRO_FLOW')
    x['size_confidence']=np.minimum(100, (q*100)).round(2)
    return x

def build_whale_radar(df: pd.DataFrame) -> pd.DataFrame:
    x=classify_whale_size(df)
    if x.empty: return pd.DataFrame(columns=['symbol','session_date','whale_size_class','flow_intensity','radar_rank'])
    evidence=pd.to_numeric(x['institutional_flow_score'],errors='coerce').fillna(0).abs().clip(0,100) if 'institutional_flow_score' in x.columns else pd.Series(0.0,index=x.index)
    confirmation=pd.to_numeric(x['confirmation_score'],errors='coerce').fillna(0).clip(0,100) if 'confirmation_score' in x.columns else pd.Series(0.0,index=x.index)
    uncertainty=pd.to_numeric(x['uncertainty_score'],errors='coerce').fillna(0).clip(0,100) if 'uncertainty_score' in x.columns else pd.Series(0.0,index=x.index)
    intensity=pd.to_numeric(x['flow_intensity'],errors='coerce').fillna(0)
    x['whale_radar_score']=(0.40*intensity+0.35*evidence+0.20*confirmation-0.15*uncertainty).clip(0,100).round(4)
    flow_signed=pd.to_numeric(x['institutional_flow_score'],errors='coerce').fillna(0) if 'institutional_flow_score' in x.columns else pd.Series(0.0,index=x.index)
    x['radar_direction']=np.select([flow_signed>5,flow_signed<-5],['BUY_SIDE','SELL_SIDE'],default='NEUTRAL_OR_MIXED')
    x['radar_rank']=x['whale_radar_score'].rank(method='dense',ascending=False).astype(int)
    return x[['symbol','session_date','whale_size_class','size_confidence','flow_intensity','whale_radar_score','radar_direction','radar_rank']]
