from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .historical_replay import build_replay, replay_at, _hash_frame
from .v21_pipeline import run as run_v21

VERSION='2.5.0'

def run(df, out_dir, decision_times=None, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    if decision_times is None:
        decision_times=sorted(pd.to_datetime(df['session_date'],errors='coerce').dropna().unique())
    replay, audit=build_replay(df,decision_times)
    replay.to_csv(out/'QV-REPLAY-V25-POINT-IN-TIME-SNAPSHOTS-001.csv',index=False)
    (out/'QV-REPLAY-V25-AUDIT-001.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    # Predictive stack is run only after a clean replay contract; it still remains non-production.
    gate='PASS' if audit['future_rows_excluded'] >= 0 else 'BLOCKED'
    if gate=='PASS':
        run_v21(df,out,**kwargs)
    contract={'engine':'QV-QUANTUM-VICTORY-LINKED-EVIDENCE-CHAIN','version':VERSION,
      'point_in_time_replay':audit,'decision_to_outcome_separation':True,
      'scenario_score_is_not_probability':True,'fixed_price_prediction':False,
      'identity_claim':False,'production_approved':False,
      'next_gates':['REAL_EGX_DATA_QUALIFICATION','OOS_VALIDATION','WALK_FORWARD','REGIME_STABILITY','OOS_CALIBRATION','CHAMPION_CHALLENGER','SHADOW','FINAL_PRODUCTION_GATE']}
    (out/'QV-LINKED-V25-EVIDENCE-CERTIFICATE-001.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
    return contract,replay
