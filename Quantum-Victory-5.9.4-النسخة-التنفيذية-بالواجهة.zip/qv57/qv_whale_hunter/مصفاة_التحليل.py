from __future__ import annotations
import pandas as pd
from .محرك_التحليل_الفني import تحليل_فني

الفئات={
 'سعر':'السعر وحركة التداول',
 'صفقات':'الصفقات الفعلية',
 'عمق':'عمق السوق والعرض والطلب',
 'تاريخ':'التاريخ السعري',
 'أخبار':'الأخبار والإفصاحات',
 'مؤشرات':'المؤشرات العامة والقطاعية',
}

def فصل_البيانات(df):
    if df is None or df.empty:
        return {k:pd.DataFrame() for k in الفئات}
    x=df.copy()
    الناتج={k:x.copy() for k in ['سعر','صفقات','عمق']}
    الناتج['تاريخ']=x.copy()
    الناتج['أخبار']=pd.DataFrame()
    الناتج['مؤشرات']=pd.DataFrame()
    return الناتج

def تحليل_متكامل_يومي(df):
    """يبني التحليل الفني من بيانات يومية حقيقية فقط؛ لا يعيد تركيب يومي من لقطات لحظية."""
    مطلوب={'التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم'}
    if df is None or df.empty or not مطلوب.issubset(df.columns):
        return pd.DataFrame(), {'الحالة':'لا توجد سلسلة يومية مكتملة للتحليل'}
    نتائج=[]; تقارير={}
    for الرمز,جزء in df.groupby('الرمز' if 'الرمز' in df.columns else 'symbol'):
        بيانات,تقرير=تحليل_فني(جزء.rename(columns={'الرمز':'symbol'}) if 'الرمز' in جزء.columns else جزء)
        نتائج.append(بيانات.assign(الرمز=الرمز)); تقارير[str(الرمز)]=تقرير
    return pd.concat(نتائج,ignore_index=True) if نتائج else pd.DataFrame(), تقارير
