from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .data_qualification import qualify

VERSION='2.2.0'

def run(df, out_dir, *, decision_time=None, source_columns_required=False, expected_sessions=None):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    rep=qualify(df,decision_time=decision_time,source_columns_required=source_columns_required,expected_sessions=expected_sessions)
    # Immutable-ish evidence artifact: exact input plus qualification report.
    canonical=df.copy()
    canonical.to_csv(out/'QV-DATA-V22-CANONICAL-CANDIDATE-001.csv',index=False)
    (out/'QV-DATA-V22-QUALIFICATION-REPORT-001.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    manifest={'engine':'QV-DATA-QUALIFICATION-PIPELINE','version':VERSION,'qualification_status':rep['status'],'quality_grade':rep['quality_grade'],'production_approved':False,'point_in_time_enforced':bool(decision_time),'critical_findings':rep['critical_findings'],'next_gate':'HISTORICAL_SNAPSHOT_AND_SOURCE_RECONCILIATION'}
    (out/'QV-DATA-V22-MANIFEST-001.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest
