from __future__ import annotations
import json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

VERSION='1.4.0'

BUY_STATES={'ACCUMULATION_SEQUENCE'}
SELL_STATES={'DISTRIBUTION_SEQUENCE'}

def _clip(x):
    return float(np.clip(pd.to_numeric(pd.Series([x]),errors='coerce').iloc[0] if x is not None else np.nan,-100,100)) if pd.notna(x) else np.nan

def build_evidence_bridge(df: pd.DataFrame) -> pd.DataFrame:
    """Translate Whale Hunter observations into recommendation-engine evidence, never probabilities."""
    x=df.copy()
    if x.empty:
        return pd.DataFrame(columns=['symbol','session_date','evidence_id'])
    state=x.get('sequence_state',pd.Series('NO_SEQUENCE',index=x.index)).fillna('NO_SEQUENCE')
    buy=x.get('institutional_flow_score',pd.Series(0,index=x.index)).fillna(0)
    conf=x.get('confirmation_score',pd.Series(0,index=x.index)).fillna(0)
    unc=x.get('uncertainty_score',pd.Series(0,index=x.index)).fillna(0)
    rel=x.get('relative_flow_score',pd.Series(0,index=x.index)).fillna(0)
    evid=[]
    for i,r in x.iterrows():
        st=state.loc[i]
        direction='BUY_EVIDENCE' if st in BUY_STATES else ('SELL_EVIDENCE' if st in SELL_STATES else 'MIXED_EVIDENCE')
        raw=0.60*float(pd.to_numeric(pd.Series([buy.loc[i]]),errors='coerce').iloc[0] or 0)+0.25*float(pd.to_numeric(pd.Series([conf.loc[i]]),errors='coerce').iloc[0] or 0)+0.15*float(pd.to_numeric(pd.Series([rel.loc[i]]),errors='coerce').iloc[0] or 0)
        strength=float(np.clip(abs(raw),0,100))
        uncertainty=float(np.clip(float(pd.to_numeric(pd.Series([unc.loc[i]]),errors='coerce').iloc[0] or 0),0,100))
        if st=='NO_SEQUENCE': status='NO_ACTIONABLE_FLOW'
        elif uncertainty>=70: status='WEAK_DUE_TO_UNCERTAINTY'
        elif strength>=70: status='STRONG_EVIDENCE'
        elif strength>=45: status='MODERATE_EVIDENCE'
        else: status='EARLY_EVIDENCE'
        payload={'engine':'QV-WHALE-HUNTER','version':VERSION,'symbol':r.get('symbol'),'session_date':str(r.get('session_date')),'direction':direction,'state':st,'strength':strength,'uncertainty':uncertainty}
        eid='QVE-'+hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:20].upper()
        evid.append({'evidence_id':eid,'symbol':r.get('symbol'),'session_date':r.get('session_date'),'evidence_direction':direction,'sequence_state':st,'evidence_strength':strength,'uncertainty':uncertainty,'evidence_status':status,'score_is_not_probability':True,'probability':np.nan,'calibration_status':'NOT_CALIBRATED','source_engine':'QV-WHALE-HUNTER','source_version':VERSION})
    return pd.DataFrame(evid)

def build_recommendation_contract(bridge: pd.DataFrame) -> dict:
    """Produce a scenario/recommendation input contract. It intentionally stops before a trade recommendation."""
    rows=[]
    for _,r in bridge.iterrows():
        rows.append({'evidence_id':r.evidence_id,'symbol':r.symbol,'session_date':str(r.session_date),'evidence_direction':r.evidence_direction,'strength':float(r.evidence_strength),'uncertainty':float(r.uncertainty),'status':r.evidence_status,'probability':None,'calibration_status':'NOT_CALIBRATED'})
    return {'contract':'QV-RECOMMENDATION-EVIDENCE-BRIDGE','version':VERSION,'role':'evidence_input_only','score_is_not_probability':True,'rows':rows,'production_approved':False,'next_gate':'SCENARIO_ENGINE_CONSUMPTION + OOS_CALIBRATION + SHADOW'}

def shadow_gate(bridge: pd.DataFrame, min_rows=1):
    n=len(bridge); valid=int(bridge['evidence_id'].notna().sum()) if n else 0
    return {'status':'PASS' if valid>=min_rows else 'BLOCKED','rows':n,'valid_evidence_rows':valid,'production_approved':False,'mode':'SHADOW_ONLY','reason':'Calibration and real-EGX OOS evidence are required before production.'}
