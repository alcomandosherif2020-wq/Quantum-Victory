from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any

@dataclass(frozen=True)
class نتيجة_الدلالة:
    صالح: bool
    الحالة: str
    السبب: str
    خريطة_الحقول: dict[str, str]


def _norm(v: Any) -> str:
    return str(v or '').strip().lower().replace('_',' ').replace('-',' ')


# مهم: لا نفترض أن اسم العمود وحده يثبت معناه.
# المصدر يجب أن يصرّح بدلالة الحقل، أو نستخدم تعيينًا صريحًا يقدمه الموصل.
أسماء_الافتتاح = {'open','opening','session open','افتتاح','الافتتاح','افتتاح الجلسة'}
أسماء_الإغلاق_السابق = {'previous close','prev close','prior close','previous session close','close previous session','إغلاق سابق','إغلاق الجلسة السابقة','إغلاق أمس','سعر الإغلاق السابق'}
أسماء_الأعلى = {'high','session high','day high','intraday high','الأعلى','اعلى','أعلى الجلسة'}
أسماء_الأدنى = {'low','session low','day low','intraday low','الأدنى','ادنى','أدنى الجلسة'}
أسماء_الإغلاق = {'close','last close','session close','day close','الإغلاق','إغلاق الجلسة'}


def تحقق_دلالة_الحقول(خريطة: dict[str, str] | None = None) -> نتيجة_الدلالة:
    """يتحقق من دلالة OHLC قبل تطبيق أي منطق شموع أو جودة.

    القاعدة: أعلى/أدنى الجلسة لا يشترطان أن يتجاوزا إغلاق الجلسة السابقة.
    المقارنة الوحيدة الإلزامية هي مع افتتاح الجلسة الفعلي إذا كان معروفًا.
    """
    خريطة = خريطة or {}
    m = {_norm(k): _norm(v) for k,v in خريطة.items()}
    # نقبل الخريطة بصيغة: العمود -> دلالة
    دلالات = set(m.values())
    if not m:
        return نتيجة_الدلالة(False, 'غير_معروفة', 'دلالة الحقول غير موثقة؛ ممنوع افتراض أن الافتتاح هو افتتاح الجلسة.', {})
    has_open = any(v in {_norm(x) for x in أسماء_الافتتاح} for v in دلالات)
    has_prev = any(v in {_norm(x) for x in أسماء_الإغلاق_السابق} for v in دلالات)
    if has_prev and not has_open:
        return نتيجة_الدلالة(False, 'لا_يوجد_افتتاح_جلسة', 'المصدر يعرّف حقل الإغلاق السابق فقط؛ لا يجوز استخدامه كافتتاح جلسة.', m)
    return نتيجة_الدلالة(True, 'موثقة', 'دلالة الحقول موثقة ويمكن تطبيق قواعد الجلسة دون خلط الإغلاق السابق بالافتتاح.', m)


def تحقق_شمعة_جلسة(صف: dict[str, Any], دلالة: نتيجة_الدلالة) -> نتيجة_الدلالة:
    """يفحص OHLC مع احترام دلالة الحقول.

    لا يرفض الحالة: الإغلاق السابق > أعلى الجلسة، لأنها طبيعية.
    يرفض فقط إذا كان الافتتاح المصرح به نفسه خارج نطاق [الأدنى, الأعلى].
    """
    if not دلالة.صالح:
        return دلالة
    m = دلالة.خريطة_الحقول
    def find(kindset):
        s={_norm(x) for x in kindset}
        for col, meaning in m.items():
            if meaning in s: return col
        return None
    co=find(أسماء_الافتتاح); ch=find(أسماء_الأعلى); cl=find(أسماء_الأدنى); cc=find(أسماء_الإغلاق)
    missing=[x for x,v in [('الافتتاح',co),('الأعلى',ch),('الأدنى',cl),('الإغلاق',cc)] if v is None]
    if missing:
        return نتيجة_الدلالة(False,'بيانات_أساسية_ناقصة','الحقول الأساسية غير مكتملة: '+', '.join(missing),m)
    try:
        o=float(صف[co]); h=float(صف[ch]); l=float(صف[cl]); c=float(صف[cc])
    except Exception:
        return نتيجة_الدلالة(False,'قيم_غير_صالحة','تعذر تحويل OHLC إلى أرقام.',m)
    if h < l:
        return نتيجة_الدلالة(False,'نطاق_غير_صحيح','أعلى الجلسة أقل من أدنى الجلسة.',m)
    if not (l <= o <= h):
        return نتيجة_الدلالة(False,'افتتاح_خارج_النطاق','افتتاح الجلسة الفعلي خارج نطاق أعلى/أدنى الجلسة.',m)
    if not (l <= c <= h):
        return نتيجة_الدلالة(False,'إغلاق_خارج_النطاق','إغلاق الجلسة خارج نطاق أعلى/أدنى الجلسة.',m)
    return نتيجة_الدلالة(True,'شمعة_صحيحة','OHLC متسق مع جلسة التداول. إغلاق الجلسة السابقة لا يدخل في شرط نطاق الجلسة.',m)


def نتيجة_قاموس(نتيجة: نتيجة_الدلالة) -> dict:
    return asdict(نتيجة)
