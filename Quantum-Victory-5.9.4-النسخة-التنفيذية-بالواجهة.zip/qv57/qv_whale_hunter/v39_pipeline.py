from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .session_profile import build_profile, save_profile
from .live_liquidity_sniper import scan
from .flow_confirmation import FlowConfirmationEngine
from .market_scanner import scan_market
from .fusion_core import build_fusion
from .outcome_replay import attach_future_outcomes

ENGINE='QV-WHALE-HUNTER-FUSION'; VERSION='3.9.0'

def run(intraday_df: pd.DataFrame, historical_intraday_df: pd.DataFrame|None=None, out_dir='QV-V39-RUN',
        daily_baseline=None, top_n=20, **scan_kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    profile=build_profile(historical_intraday_df,min_history_sessions=3) if historical_intraday_df is not None and not historical_intraday_df.empty else pd.DataFrame()
    if not profile.empty: save_profile(profile,out)
    scored=scan(intraday_df,daily_baseline=daily_baseline,session_profile=profile,**scan_kwargs)
    confirmed=FlowConfirmationEngine().process(scored)
    market=scan_market(confirmed,top_n=max(top_n,50))
    fusion,radar,network=build_fusion(confirmed,top_n=top_n)
    alerts=radar[radar.network_state.isin(['CONFIRMED_NETWORK_FLOW','ARMED_NETWORK_FLOW'])].copy() if not radar.empty else radar
    outcomes=attach_future_outcomes(alerts,intraday_df) if not alerts.empty else pd.DataFrame()
    scored.to_csv(out/'QV-V39-SCORES.csv',index=False)
    confirmed.to_csv(out/'QV-V39-CONFIRMED-STREAM.csv',index=False)
    market.to_csv(out/'QV-V39-MARKET-CONTEXT.csv',index=False)
    fusion.to_csv(out/'QV-V39-FUSION-STREAM.csv',index=False)
    radar.to_csv(out/'QV-V39-NETWORK-RADAR.csv',index=False)
    network.to_csv(out/'QV-V39-NETWORK-SNAPSHOT.csv',index=False)
    if not outcomes.empty: outcomes.to_csv(out/'QV-V39-OUTCOMES.csv',index=False)
    report={'engine':ENGINE,'version':VERSION,'status':'PASS','rows_scored':len(scored),
      'symbols_scored':int(scored.symbol.nunique()) if not scored.empty else 0,'network_ranked':len(radar),
      'network_confirmed':int((radar.network_state=='CONFIRMED_NETWORK_FLOW').sum()) if not radar.empty else 0,
      'network_armed':int((radar.network_state=='ARMED_NETWORK_FLOW').sum()) if not radar.empty else 0,
      'network_blocked':int((radar.network_state=='BLOCKED_NETWORK_RISK').sum()) if not radar.empty else 0,
      'architecture':['SESSION_BASELINE','LIQUIDITY_SNIPER','MICROSTRUCTURE','CONFIRMATION_STATE','MARKET_CONTEXT','SECTOR_CONTEXT','NETWORK_FUSION','TRAP_DEFENSE','OUTCOME_REPLAY'],
      'graph_semantics':'symbol nodes with market/sector/time contextual edges; no actor identity inference',
      'score_probability_separation':True,'probability_output':None,'fixed_price_target':None,
      'evidence_only':True,'identity_claim':False,'production_approved':False,'human_risk_check_required':True}
    (out/'QV-V39-CERTIFICATE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report,scored,confirmed,market,fusion,radar,network,outcomes
