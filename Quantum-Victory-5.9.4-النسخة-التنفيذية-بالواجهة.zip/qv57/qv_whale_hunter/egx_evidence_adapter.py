from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
import pandas as pd

REQ=['symbol','session_date','open','high','low','close','volume']
ALIASES={'ticker':'symbol','code':'symbol','date':'session_date','datetime':'session_date','qty':'volume','vol':'volume'}

@dataclass(frozen=True)
class EGXEvidenceResult:
    status:str
    rows:int
    symbols:int
    missing_sessions:int
    universe_issues:int
    corporate_action_issues:int
    blocking_reasons:tuple[str,...]
    fingerprint:str


def _sha(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()


def normalize_egx(df:pd.DataFrame, aliases:dict|None=None)->pd.DataFrame:
    x=df.copy()
    amap=dict(ALIASES); amap.update(aliases or {})
    x=x.rename(columns={c:amap.get(str(c).strip().lower(),c) for c in x.columns})
    if 'symbol' in x: x['symbol']=x['symbol'].astype(str).str.strip().str.upper()
    if 'session_date' in x: x['session_date']=pd.to_datetime(x['session_date'],errors='coerce').dt.normalize()
    return x


def reconcile_egx(df, session_calendar=None, universe_history=None, corporate_actions=None, asof=None):
    x=normalize_egx(df); reasons=[]; miss=0; ui=0; cai=0
    missing=[c for c in REQ if c not in x.columns]
    if missing: reasons.append('MISSING_REQUIRED_COLUMNS:'+','.join(missing))
    if x.empty: reasons.append('EMPTY_EGX_EVIDENCE')
    if not missing and not x.empty:
        if x.duplicated(['symbol','session_date']).any(): reasons.append('DUPLICATE_BUSINESS_KEYS')
        bad=(x['high']<x[['open','close']].max(axis=1)) | (x['low']>x[['open','close']].min(axis=1)) | (x[['open','high','low','close']]<=0).any(axis=1) | (x['volume']<0)
        if bad.any(): reasons.append('OHLCV_INVARIANT_FAILURE')
        if asof is not None and (x['session_date']>pd.Timestamp(asof).normalize()).any(): reasons.append('ROWS_AFTER_ASOF')
    if session_calendar is not None and not missing:
        cal=pd.to_datetime(pd.Series(session_calendar),errors='coerce').dropna().dt.normalize().unique()
        actual=set(x['session_date'].dropna().unique())
        miss=len([d for d in cal if d not in actual])
    if universe_history is not None and not missing:
        u=normalize_egx(universe_history)
        if not u.empty and {'symbol','start_date'}.issubset(u.columns):
            u['start_date']=pd.to_datetime(u['start_date'],errors='coerce').dt.normalize()
            if 'end_date' in u: u['end_date']=pd.to_datetime(u['end_date'],errors='coerce').dt.normalize()
            for _,r in x[['symbol','session_date']].dropna().iterrows():
                m=u[u.symbol.eq(r.symbol) & u.start_date.le(r.session_date)]
                if 'end_date' in u: m=m[m.end_date.isna() | u.end_date.ge(r.session_date)]
                if m.empty: ui+=1
            if ui: reasons.append(f'UNIVERSE_MEMBERSHIP_ISSUES:{ui}')
    if corporate_actions is not None:
        ca=normalize_egx(corporate_actions)
        if not {'symbol','session_date'}.issubset(ca.columns): cai=1; reasons.append('INVALID_CORPORATE_ACTION_LINEAGE')
    payload={'rows':len(x),'symbols':sorted(x.symbol.unique().tolist()) if 'symbol' in x else [],'missing_sessions':miss,'universe_issues':ui,'corporate_action_issues':cai,'columns':list(x.columns)}
    return EGXEvidenceResult('BLOCKED' if reasons else 'PASS',len(x),int(x.symbol.nunique()) if 'symbol' in x else 0,miss,ui,cai,tuple(reasons),_sha(payload)),x
