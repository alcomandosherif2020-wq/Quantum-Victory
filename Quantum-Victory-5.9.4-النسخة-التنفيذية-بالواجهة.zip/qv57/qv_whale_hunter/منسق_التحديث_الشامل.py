from pathlib import Path
from datetime import datetime, timezone
import json
from .مجدول_التحديث_التلقائي import إنشاء_جدول_التحديث_الافتراضي

class منسق_التحديث_الشامل:
    def __init__(self, مجلد_الحالة="حالة_التحديث"):
        self.المجدول=إنشاء_جدول_التحديث_الافتراضي(); self.المجلد=Path(مجلد_الحالة); self.المجلد.mkdir(parents=True,exist_ok=True)
    def تسجيل_حدث(self, الاسم, الحالة, تفاصيل=None):
        s={"الوقت":datetime.now(timezone.utc).isoformat(),"المهمة":الاسم,"الحالة":الحالة,"التفاصيل":تفاصيل}
        with (self.المجلد/"سجل_التحديثات.jsonl").open("a",encoding="utf-8") as f: f.write(json.dumps(s,ensure_ascii=False)+"\n")
    def تشغيل_دورة_مراقبة(self, الآن=None):
        x=self.المجدول.دورة(الآن); self.المجدول.حفظ_الحالة(); return x
