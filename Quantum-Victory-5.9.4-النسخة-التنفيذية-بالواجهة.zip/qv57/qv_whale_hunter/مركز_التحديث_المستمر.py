# كوانتوم فيكتوري 4.17 — مركز التحديث المستمر
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import json, time, hashlib

@dataclass
class حالة_مصدر:
    الاسم: str
    الدور: str
    الفترة: int
    آخر_نجاح: float | None = None
    آخر_فشل: float | None = None
    عدد_النجاحات: int = 0
    عدد_الإخفاقات: int = 0
    الحالة: str = "جاهز"
    آخر_خطأ: str = ""

class مركز_التحديث_المستمر:
    """يشغل محولات البيانات المصرح بها دوريًا، مع حارس للتقادم وعدم اختلاق النتائج."""
    def __init__(self, مجلد="حالة_التحديث_المستمر"):
        self.مجلد=Path(مجلد); self.مجلد.mkdir(parents=True,exist_ok=True)
        self.المصادر={}
        self.الوظائف={}
    def تسجيل_مصدر(self, الاسم, الدور, الفترة, وظيفة=None):
        if الفترة<=0: raise ValueError("الفترة يجب أن تكون موجبة")
        self.المصادر[الاسم]=حالة_مصدر(الاسم,الدور,الفترة)
        if وظيفة: self.الوظائف[الاسم]=وظيفة
    def مستحق(self, الاسم, الآن=None):
        الآن=time.time() if الآن is None else الآن
        s=self.المصادر[الاسم]
        return s.آخر_نجاح is None or الآن-s.آخر_نجاح>=s.الفترة
    def تشغيل(self, الاسم, الآن=None):
        الآن=time.time() if الآن is None else الآن
        s=self.المصادر[الاسم]
        if not self.مستحق(الاسم,الآن): return {"الحالة":"مؤجل","الاسم":الاسم}
        f=self.الوظائف.get(الاسم)
        if f is None:
            s.الحالة="غير موصول"; s.آخر_خطأ="لا يوجد محول مصدر فعلي موصول"
            s.آخر_فشل=الآن; self._حفظ(); return {"الحالة":s.الحالة,"الاسم":الاسم}
        try:
            result=f()
            if result is None: raise ValueError("المحول أعاد نتيجة فارغة")
            s.آخر_نجاح=الآن; s.عدد_النجاحات+=1; s.الحالة="نجح"; s.آخر_خطأ=""
            self._حفظ(); return {"الحالة":"نجح","الاسم":الاسم,"النتيجة":result}
        except Exception as e:
            s.آخر_فشل=الآن; s.عدد_الإخفاقات+=1; s.الحالة="فشل"; s.آخر_خطأ=str(e)
            self._حفظ(); return {"الحالة":"فشل","الاسم":الاسم,"الخطأ":str(e)}
    def تشغيل_المستحق(self, الآن=None):
        return [self.تشغيل(n,الآن) for n in self.المصادر if self.مستحق(n,الآن)]
    def تقرير(self):
        payload={"الإصدار":"4.17","وقت":datetime.now(timezone.utc).isoformat(),
                 "المصادر":[asdict(s) for s in self.المصادر.values()],"الإنتاج_مصرح":False}
        raw=json.dumps(payload,ensure_ascii=False,sort_keys=True)
        payload["بصمة"]=hashlib.sha256(raw.encode()).hexdigest()
        return payload
    def _حفظ(self):
        p=self.مجلد/"حالة_مركز_التحديث.json"; t=p.with_suffix('.tmp')
        t.write_text(json.dumps(self.تقرير(),ensure_ascii=False,indent=2),encoding='utf-8'); t.replace(p)

def إنشاء_المركز_الافتراضي():
    c=مركز_التحديث_المستمر()
    c.تسجيل_مصدر("البيانات_الرسمية_للسوق","السوق والصفقات والعمق",15)
    c.تسجيل_مصدر("ياهو_للتمويل","التاريخ اليومي والتحقق",3600)
    c.تسجيل_مصدر("الأخبار_والإفصاحات","الأحداث",60)
    c.تسجيل_مصدر("المؤشرات_والقطاعات","السوق والقطاعات",60)
    c.تسجيل_مصدر("صحة_المصادر","المراقبة",60)
    return c
