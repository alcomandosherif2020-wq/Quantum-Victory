"""Quantum Victory 5.6 — Global Release Gate.
A deterministic final gate: software integrity may PASS, but production cannot PASS
without independent market evidence for all required scientific gates.
"""
from __future__ import annotations
import hashlib, json, pathlib, subprocess, sys

REQUIRED = [
    "data_qualification", "leakage_audit", "oos", "walk_forward",
    "sample_size", "regime_stability", "oos_calibration",
    "champion_challenger", "shadow",
]

MODULES = {
    "data_qualification": "data_qualification.py",
    "leakage_audit": "adversarial_guard.py",
    "oos": "oos_walk_forward.py",
    "walk_forward": "oos_walk_forward.py",
    "sample_size": "research_lab.py",
    "regime_stability": "regime_stability.py",
    "oos_calibration": "calibration.py",
    "champion_challenger": "champion_challenger.py",
    "shadow": "shadow_mode.py",
}

ROOT = pathlib.Path(__file__).resolve().parent

def sha256(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()

def main() -> int:
    repo = ROOT.parent
    files = sorted(p for p in repo.rglob("*.py") if ".pytest_cache" not in p.parts and "__pycache__" not in p.parts)
    missing = [k for k,v in MODULES.items() if not (ROOT / v).exists()]
    compile_ok = subprocess.run([sys.executable, "-m", "compileall", "-q", str(ROOT)]).returncode == 0
    pytest = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=repo, capture_output=True, text=True)
    result = {
        "product": "Quantum Victory",
        "version": "5.6.0",
        "software_integrity": {"compile": compile_ok, "pytest_returncode": pytest.returncode,
                               "pytest_tail": pytest.stdout[-1000:]},
        "required_scientific_gates": REQUIRED,
        "gate_implementation": {k: {"module": v, "present": (ROOT/v).exists()} for k,v in MODULES.items()},
        "missing_implementation": missing,
        "production_approved": False,
        "status": "BLOCKED",
        "blocking_reasons": [
            "independent_market_evidence_not_supplied_or_verified",
            "production_approval_must_be_explicit_and_external_to_software_tests",
        ],
        "release_manifest": {str(p.relative_to(repo)): sha256(p) for p in files},
        "principle": "Software tests are not evidence of profitability or future returns.",
    }
    out = repo / "run_out" / "QV-5.6-GLOBAL-RELEASE-GATE.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": result["status"], "production_approved": False,
                      "pytest_returncode": pytest.returncode, "missing_implementation": missing}, ensure_ascii=False))
    return 0 if compile_ok and pytest.returncode == 0 and not missing else 1

if __name__ == "__main__":
    raise SystemExit(main())
