from __future__ import annotations
import json,os,time
from urllib.request import Request,urlopen
class TelegramGateway:
    def __init__(self,token=None,chat_id=None,timeout=10,retries=3): self.token=token or os.getenv('QV_TELEGRAM_BOT_TOKEN'); self.chat_id=chat_id or os.getenv('QV_TELEGRAM_CHAT_ID'); self.timeout=timeout; self.retries=retries
    @property
    def configured(self): return bool(self.token and self.chat_id)
    def send(self,text,parse_mode=None):
        if not self.configured: return {'status':'BLOCKED','reason':'TELEGRAM_CREDENTIALS_NOT_CONFIGURED','sent':False}
        payload={'chat_id':self.chat_id,'text':str(text)}
        if parse_mode: payload['parse_mode']=parse_mode
        data=json.dumps(payload).encode(); url=f'https://api.telegram.org/bot{self.token}/sendMessage'; last='UNKNOWN'
        for attempt in range(self.retries):
            try:
                req=Request(url,data=data,headers={'Content-Type':'application/json'},method='POST')
                with urlopen(req,timeout=self.timeout) as r: body=json.loads(r.read().decode())
                if body.get('ok'): return {'status':'SENT','sent':True,'telegram':body}
                last=str(body)
            except Exception as e: last=str(e)
            time.sleep(min(2**attempt,5))
        return {'status':'FAILED','sent':False,'reason':last}
