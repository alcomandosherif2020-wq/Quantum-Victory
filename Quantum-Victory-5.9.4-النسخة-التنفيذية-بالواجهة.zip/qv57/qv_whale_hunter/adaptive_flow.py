from __future__ import annotations
import numpy as np
import pandas as pd

ENGINE='QV-ADAPTIVE-FLOW-INTELLIGENCE'; VERSION='1.0.0'


def enrich(scored: pd.DataFrame, market_context: pd.DataFrame|None=None) -> pd.DataFrame:
    """Turn raw liquidity evidence into an adaptive, trap-aware conviction layer.
    It never identifies an actor and never emits probability or price targets."""
    if scored is None or scored.empty: return pd.DataFrame()
    x=scored.copy().sort_values(['symbol','timestamp']).reset_index(drop=True)
    g=x.groupby('symbol',group_keys=False)
    score=pd.to_numeric(x.get('sniper_score',0),errors='coerce').fillna(0)
    bp=pd.to_numeric(x.get('buy_pressure',.5),errors='coerce').fillna(.5)
    sess=pd.to_numeric(x.get('session_rvol',np.nan),errors='coerce')
    turn=pd.to_numeric(x.get('turnover_rv',np.nan),errors='coerce')
    trade=pd.to_numeric(x.get('trade_intensity_rv',np.nan),errors='coerce')
    book=pd.to_numeric(x.get('book_imbalance',np.nan),errors='coerce')
    ret=pd.to_numeric(x.get('price_ret',0),errors='coerce').fillna(0)
    # Persistence is deliberately based on prior observations, not future data.
    active=(score>=55)&(bp>=.60)
    x['flow_persistence_3']=active.groupby(x['symbol']).transform(lambda s:s.rolling(3,min_periods=1).mean())
    x['flow_persistence_6']=active.groupby(x['symbol']).transform(lambda s:s.rolling(6,min_periods=1).mean())
    x['price_response_3']=ret.groupby(x['symbol']).transform(lambda s:s.rolling(3,min_periods=1).sum())
    # Absorption: heavy buy pressure + abnormal flow + weak price response.
    x['absorption_risk']=((bp>=.70)&(sess.fillna(1)>=2)&(x['price_response_3']<0.001)).astype(int)
    # Flow/price divergence: large flow without supportive price movement.
    x['flow_price_divergence']=((score>=65)&(bp>=.65)&(x['price_response_3']<0)).astype(int)
    # Book imbalance is a supporting feature only; missing depth is neutral.
    x['book_support']=book.fillna(0).clip(-1,1)
    x['turnover_support']=((turn.fillna(1)-1)/2).clip(-1,1)
    x['trade_support']=((trade.fillna(1)-1)/2).clip(-1,1)
    x['data_quality_ok']=np.isfinite(pd.to_numeric(x['price'],errors='coerce')) & (pd.to_numeric(x['volume'],errors='coerce')>=0)
    # Adaptive conviction: persistence adds confidence, traps subtract it.
    x['hunter_conviction']=(
        score + 12*x['flow_persistence_3'] + 8*x['flow_persistence_6']
        + 7*x['book_support'].clip(lower=0) + 4*x['turnover_support'].clip(lower=0)
        + 3*x['trade_support'].clip(lower=0)
        - 14*x['absorption_risk'] - 12*x['flow_price_divergence']
    ).clip(0,100)
    x['trap_risk_score']=(35*x['absorption_risk']+35*x['flow_price_divergence']+15*(x['book_support']<-.2).astype(int)).clip(0,100)
    x['hunter_state']=np.select([
        (x['trap_risk_score']>=50)&(x['hunter_conviction']>=55),
        x['hunter_conviction']>=78,
        x['hunter_conviction']>=62,
        x['hunter_conviction']>=50,
        x['flow_persistence_3']<.34
    ],['TRAP_RISK','HUNTER_LOCK','HUNTER_ARMED','WATCH','FADE'],default='WATCH')
    x['hunter_reason_code']='LIQUIDITY_WATCH'
    x.loc[x['flow_price_divergence'].astype(bool),'hunter_reason_code']='FLOW_PRICE_DIVERGENCE'
    x.loc[(x['hunter_conviction']>=62)&(~x['flow_price_divergence'].astype(bool)),'hunter_reason_code']='BUILDING_PERSISTENT_FLOW'
    x.loc[(x['hunter_conviction']>=78)&(~x['flow_price_divergence'].astype(bool)),'hunter_reason_code']='MULTI_FACTOR_PERSISTENT_FLOW'
    x.loc[x['trap_risk_score']>=50,'hunter_reason_code']='TRAP_RISK'
    x['evidence_only']=True; x['identity_claim']=False; x['probability']=np.nan; x['fixed_price_target']=np.nan
    return x
