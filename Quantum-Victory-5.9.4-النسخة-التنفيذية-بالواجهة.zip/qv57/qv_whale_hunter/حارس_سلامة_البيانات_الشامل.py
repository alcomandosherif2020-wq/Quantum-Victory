# -*- coding: utf-8 -*-
"""حارس سلامة بيانات كوانتوم فيكتوري — طبقة دفاع شاملة.

لا يفترض معنى الحقول من الاسم وحده، ولا يرفض مقارنة القمة/القاع بإغلاق الجلسة السابقة.
يفصل بين دلالة السعر، سلامة الشمعة، الزمن، التكرار، المصدر، والمصالحة بين المصادر.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Iterable, Mapping
from datetime import datetime, timezone
import hashlib, json, math, re
import pandas as pd

VERSION = "1.0.0"
الحالات = {"مُثبت","تحذير","محجوب","غير_معروف"}

def _norm(x: Any) -> str:
    return str(x if x is not None else "").strip().lower().replace("_"," ").replace("-"," ")

def _num(x):
    return pd.to_numeric(x, errors="coerce")

def _parse_ts(x):
    return pd.to_datetime(x, errors="coerce", utc=True)

def _hash_obj(obj):
    raw=json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()
    return hashlib.sha256(raw).hexdigest()

@dataclass(frozen=True)
class نتيجة_الحارس:
    صالح: bool
    الحالة: str
    الأسباب: tuple[str,...]
    التحذيرات: tuple[str,...]
    الفحوص: dict[str,bool]
    عدد_السجلات: int
    بصمة: str|None = None

def _find_col(df, aliases):
    norm={_norm(c):c for c in df.columns}
    for a in aliases:
        if _norm(a) in norm: return norm[_norm(a)]
    return None

def _semantic_value(v):
    n=_norm(v)
    if n in {"open","opening","session open","افتتاح","الافتتاح","افتتاح الجلسة","سعر افتتاح الجلسة","session open price"}:
        return "افتتاح_الجلسة"
    if n in {"previous close","prev close","prior close","previous session close","close previous session","إغلاق سابق","إغلاق الجلسة السابقة","إغلاق أمس","سعر الإغلاق السابق","previous session"}:
        return "إغلاق_سابق"
    if n in {"reference","reference price","سعر مرجعي","مرجعي","reference price"}:
        return "سعر_مرجعي"
    if n in {"high","session high","day high","intraday high","الأعلى","اعلى","أعلى الجلسة"}:
        return "أعلى_الجلسة"
    if n in {"low","session low","day low","intraday low","الأدنى","ادنى","أدنى الجلسة"}:
        return "أدنى_الجلسة"
    if n in {"close","last close","session close","day close","الإغلاق","إغلاق الجلسة"}:
        return "إغلاق_الجلسة"
    return n

def تحقق_دلالة_الحقول(df: pd.DataFrame, خريطة: Mapping[str,str]|None=None):
    """يعيد دلالة صريحة. لا يخمّن أن open يعني افتتاح الجلسة إذا صرّح المصدر بعكس ذلك."""
    if خريطة:
        return {_norm(k):_semantic_value(v) for k,v in خريطة.items()}
    # دعم أعمدة الدلالة المرافقة لكل صف
    return None

def فحص_الشموع(
    df: pd.DataFrame,
    *,
    دلالة_الافتتاح: str|None = None,
    دلالة_الحقول: Mapping[str,str]|None = None,
    السماح_بحجم_صفر: bool = True,
    منع_تواريخ_مستقبلية: bool = True,
    فحص_التكرار: bool = True,
    الترتيب_الزمني: bool = True,
) -> dict:
    x=df.copy()
    الأسباب=[]; تحذيرات=[]; checks={}
    date=_find_col(x,["التاريخ","date","session_date","datetime"])
    op=_find_col(x,["الافتتاح","open","opening"])
    hi=_find_col(x,["الأعلى","high","session high","day high"])
    lo=_find_col(x,["الأدنى","low","session low","day low"])
    cl=_find_col(x,["الإغلاق","close","session close","day close"])
    vol=_find_col(x,["الحجم","volume","vol"])
    الرمز=_find_col(x,["الرمز","symbol","ticker","code"])
    checks["schema"]=all(v is not None for v in [date,op,hi,lo,cl,vol])
    if not checks["schema"]:
        الأسباب.append("أعمدة OHLCV أو التاريخ الأساسية غير مكتملة")
        return {"engine":"QV-DATA-INTEGRITY-GUARD","version":VERSION,"status":"محجوب","checks":checks,"reasons":الأسباب,"warnings":تحذيرات,"rows":len(x)}

    ds=pd.to_datetime(x[date],errors="coerce",utc=True)
    o,h,l,c,v=[_num(x[col]) for col in [op,hi,lo,cl,vol]]
    checks["numeric"]=not bool(pd.concat([o,h,l,c,v],axis=1).isna().any(axis=1).any())
    if not checks["numeric"]: الأسباب.append("قيم غير رقمية أو مفقودة في OHLCV")

    checks["positive_prices"]=bool(((o>0)&(h>0)&(l>0)&(c>0)).all()) if checks["numeric"] else False
    if not checks["positive_prices"]: الأسباب.append("يوجد سعر غير موجب")

    checks["volume_nonnegative"]=bool((v>=0).all()) if checks["numeric"] else False
    if not checks["volume_nonnegative"]: الأسباب.append("يوجد حجم سالب")
    if not السماح_بحجم_صفر and checks["numeric"] and bool((v==0).any()):
        checks["volume_nonzero"]=False; الأسباب.append("الحجم الصفري غير مسموح لهذا المصدر")
    else: checks["volume_nonzero"]=True

    # القاعدة الأساسية: H/L يجب أن يحتويا O/C فقط إذا كان O افتتاح جلسة فعليًا.
    checks["high_low_order"]=bool((h>=l).all()) if checks["numeric"] else False
    checks["close_inside_range"]=bool(((c>=l)&(c<=h)).all()) if checks["numeric"] else False
    if not checks["high_low_order"]: الأسباب.append("الأعلى أقل من الأدنى")
    if not checks["close_inside_range"]: الأسباب.append("الإغلاق خارج نطاق أعلى/أدنى الجلسة")

    semantic=_semantic_value(دلالة_الافتتاح) if دلالة_الافتتاح else None
    if دلالة_الحقول:
        m={_norm(k):_semantic_value(val) for k,val in دلالة_الحقول.items()}
        for col, meaning in m.items():
            if col==_norm(op): semantic=meaning
    if semantic is None:
        # لا نفترض إلا إذا لم يوجد تصريح معاكس. الاسم Open وحده لا يكفي كإثبات دلالة.
        semantic="غير_معروف"
        تحذيرات.append("دلالة الافتتاح غير موثقة؛ لم يُفرض شرط احتواء الافتتاح داخل النطاق")
    checks["opening_semantics_known"]=semantic!="غير_معروف"
    checks["open_inside_range"]=True
    if semantic=="افتتاح_الجلسة":
        checks["open_inside_range"]=bool(((o>=l)&(o<=h)).all())
        if not checks["open_inside_range"]: الأسباب.append("افتتاح الجلسة الفعلي خارج نطاق الأعلى/الأدنى")
    elif semantic in {"إغلاق_سابق","سعر_مرجعي"}:
        تحذيرات.append("السعر المسمى افتتاحًا ليس افتتاح جلسة؛ لم يُستخدم في تحقق نطاق الشمعة")
    elif semantic!="غير_معروف":
        تحذيرات.append("دلالة افتتاح غير قياسية؛ لم يُفرض عليها شرط النطاق")

    checks["dates_valid"]=not bool(ds.isna().any())
    if not checks["dates_valid"]: الأسباب.append("تاريخ جلسة غير صالح")

    if منع_تواريخ_مستقبلية and checks["dates_valid"]:
        now=pd.Timestamp.now(tz="UTC")
        future=ds>now+pd.Timedelta(minutes=2)
        checks["no_future_dates"]=not bool(future.any())
        if future.any(): الأسباب.append("يوجد سجل بتاريخ مستقبلي")
    else: checks["no_future_dates"]=True

    if فحص_التكرار and checks["dates_valid"]:
        key_cols=[date]+([الرمز] if الرمز else [])
        dup=x.duplicated(key_cols,keep=False)
        checks["unique_business_key"]=not bool(dup.any())
        if dup.any(): الأسباب.append("تكرار مفتاح الرمز/جلسة")
    else: checks["unique_business_key"]=True

    if الترتيب_الزمني and checks["dates_valid"]:
        if الرمز:
            tmp=pd.DataFrame({"d":ds,"s":x[الرمز].astype(str)})
            ordered=True
            for _,g in tmp.groupby("s"):
                ordered &= g["d"].is_monotonic_increasing
        else: ordered=ds.is_monotonic_increasing
        checks["chronological"]=bool(ordered)
        if not ordered: الأسباب.append("السجلات ليست مرتبة زمنيًا")
    else: checks["chronological"]=True

    # انفصال صريح بين إغلاق الأمس وقواعد شمعة اليوم.
    checks["previous_close_not_used_as_open"]=semantic != "إغلاق_سابق"

    # نطاق يومي إضافي: لا نفرض أي علاقة بين جلسة اليوم وإغلاق الأمس.
    valid=not الأسباب
    status="مُثبت" if valid else "محجوب"
    if valid and تحذيرات: status="تحذير"
    return {"engine":"QV-DATA-INTEGRITY-GUARD","version":VERSION,"status":status,"checks":checks,"reasons":الأسباب,"warnings":تحذيرات,"rows":len(x),"opening_semantics":semantic}

def فحص_المصالحة(إطارات: Mapping[str,pd.DataFrame], حقول=("التاريخ","date","session_date"), نسب_السعر=1e-8, نسب_الحجم=0.0):
    """يقارن مصادر متعددة على مفاتيح الرمز/الجلسة دون افتراض أن المصدرين لهما نفس الدلالة."""
    مصادر={}; تعارضات=[]; مثبتة=[]
    for source,df in إطارات.items():
        if df is None or len(df)==0: continue
        d=df.copy()
        date=_find_col(d,["التاريخ","date","session_date"])
        sym=_find_col(d,["الرمز","symbol","ticker","code"])
        cl=_find_col(d,["الإغلاق","close","session close","day close"])
        if not all([date,sym,cl]):
            مصادر[source]="بيانات_ناقصة"; continue
        d["_date"]=pd.to_datetime(d[date],errors="coerce").dt.date
        d["_sym"]=d[sym].astype(str).str.upper().str.replace(r"\.CA$","",regex=True)
        d["_close"]=_num(d[cl])
        d=d.dropna(subset=["_date","_sym","_close"]).drop_duplicates(["_sym","_date"],keep="last")
        مصادر[source]=d.set_index(["_sym","_date"])["_close"]
    allkeys=sorted(set().union(*(set(s.index) for s in مصادر.values() if hasattr(s,"index"))))
    for key in allkeys:
        vals=[(src,float(s.loc[key])) for src,s in مصادر.items() if key in s.index]
        if len(vals)>=2:
            base=vals[0][1]
            if any(not math.isclose(base,v,rel_tol=نسب_السعر,abs_tol=نسب_السعر) for _,v in vals[1:]):
                تعارضات.append({"key":list(key),"values":dict(vals)})
            else: مثبتة.append({"key":list(key),"sources":[s for s,_ in vals],"value":base})
    return {"status":"متعارض" if تعارضات else ("مُثبت" if مثبتة else "غير_معروف"),"sources":مصادر.keys(),"confirmed":مثبتة,"conflicts":تعارضات}

def بصمة_بيانات(df: pd.DataFrame)->str:
    x=df.copy().sort_index(axis=1)
    raw=x.to_json(orient="records",date_format="iso",force_ascii=False)
    return hashlib.sha256(raw.encode()).hexdigest()
