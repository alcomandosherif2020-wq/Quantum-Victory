from __future__ import annotations
import json, time
from pathlib import Path
from typing import Callable, Iterable
import pandas as pd

ENGINE='QV-LIVE-FEED-BRIDGE'; VERSION='1.0.0'
REQUIRED=['symbol','timestamp','price','volume']


def normalize(records: Iterable[dict]) -> pd.DataFrame:
    rows=[]
    for r in records:
        if not isinstance(r,dict): continue
        rows.append({
            'symbol': r.get('symbol') or r.get('ticker') or r.get('code'),
            'timestamp': r.get('timestamp') or r.get('time') or r.get('datetime'),
            'price': r.get('price') if r.get('price') is not None else r.get('last'),
            'volume': r.get('volume') if r.get('volume') is not None else r.get('qty'),
            'bid': r.get('bid'), 'ask': r.get('ask'),
            'turnover': r.get('turnover') if r.get('turnover') is not None else r.get('value'),
        })
    df=pd.DataFrame(rows)
    if df.empty: return pd.DataFrame(columns=REQUIRED)
    df['timestamp']=pd.to_datetime(df['timestamp'],errors='coerce')
    for c in ['price','volume','bid','ask','turnover']:
        if c in df: df[c]=pd.to_numeric(df[c],errors='coerce')
    return df.dropna(subset=REQUIRED).sort_values(['symbol','timestamp']).reset_index(drop=True)


def normalize_payload(payload):
    if isinstance(payload,list): return normalize(payload)
    if isinstance(payload,dict):
        for k in ('data','results','quotes','trades','items','marketWatch'):
            if isinstance(payload.get(k),list): return normalize(payload[k])
        return normalize([payload])
    return pd.DataFrame(columns=REQUIRED)


def poll_json(fetch: Callable[[],object], seconds: float=2.0, duration: float|None=None,
              on_batch: Callable[[pd.DataFrame],None]|None=None):
    """Generic polling loop. fetch() is supplied by the chosen provider/app bridge."""
    started=time.monotonic(); batches=[]
    while duration is None or time.monotonic()-started < duration:
        batch=normalize_payload(fetch())
        if not batch.empty:
            batches.append(batch)
            if on_batch: on_batch(batch)
        time.sleep(max(0.05,seconds))
    return pd.concat(batches,ignore_index=True) if batches else pd.DataFrame(columns=REQUIRED)


def save_bridge_manifest(out_dir='QV-LIVE-BRIDGE-RUN', provider='UNSPECIFIED', mode='polling'):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    manifest={'engine':ENGINE,'version':VERSION,'provider':provider,'mode':mode,
              'supported_inputs':['REST/JSON polling','WebSocket message callback','CSV append/file tail'],
              'normalized_schema':REQUIRED+['bid','ask','turnover'],
              'production_approved':False,'identity_claim':False}
    (out/'QV-LIVE-FEED-BRIDGE-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest
