from __future__ import annotations
import hashlib, json
from typing import Mapping, Optional
import pandas as pd

ENGINE='QV-HISTORICAL-EVIDENCE-ENGINE'; VERSION='1.0.0'
KEY=['symbol','session_date']
REQUIRED=['open','high','low','close','volume']

def _norm(df: pd.DataFrame, aliases: Optional[Mapping[str,str]]=None) -> pd.DataFrame:
    x=df.copy()
    if aliases:
        x['symbol']=x.get('symbol','').astype(str).str.strip().replace(dict(aliases))
    else:
        x['symbol']=x.get('symbol','').astype(str).str.strip()
    x['session_date']=pd.to_datetime(x.get('session_date'),errors='coerce').dt.strftime('%Y-%m-%d')
    for c in REQUIRED+['turnover']:
        if c in x: x[c]=pd.to_numeric(x[c],errors='coerce')
    return x

def _fingerprint(row):
    fields=['symbol','session_date']+REQUIRED+['turnover','source_id','source_version']
    payload='|'.join('' if pd.isna(row.get(c)) else str(row.get(c)) for c in fields)
    return hashlib.sha256(payload.encode()).hexdigest()

def _chain_hash(fps):
    h=''
    for fp in fps: h=hashlib.sha256((h+fp).encode()).hexdigest()
    return h

def build_evidence(sources: Mapping[str,pd.DataFrame], *, aliases=None, universe_history=None,
                   corporate_actions=None, expected_sessions=None, decision_time=None):
    findings=[]; normalized={}; all_rows=[]
    for source, df in sources.items():
        x=_norm(df, aliases)
        x['source_id']=x.get('source_id',source)
        x['source_version']=x.get('source_version','unknown')
        x['evidence_fingerprint']=x.apply(_fingerprint,axis=1)
        x['_source']=source
        normalized[source]=x
        all_rows.append(x)
        dup=x.duplicated(KEY,keep=False)
        if dup.any(): findings.append({'type':'DUPLICATE_BUSINESS_KEY','severity':'CRITICAL','source':source,'rows':int(dup.sum())})
    data=pd.concat(all_rows,ignore_index=True) if all_rows else pd.DataFrame(columns=KEY+REQUIRED)
    if decision_time is not None and 'eligibility_time' in data:
        t=pd.to_datetime(data['eligibility_time'],errors='coerce'); d=pd.Timestamp(decision_time)
        bad=t.notna() & (t>d)
        if bad.any(): findings.append({'type':'POINT_IN_TIME_VIOLATION','severity':'CRITICAL','rows':int(bad.sum())})
    for c in REQUIRED:
        if c not in data: findings.append({'type':'MISSING_FIELD','severity':'CRITICAL','field':c})
    if not data.empty:
        inv=(data['high']<data[['open','close']].max(axis=1)) | (data['low']>data[['open','close']].min(axis=1)) | (data['low']>data['high']) | (data[['open','high','low','close']]<=0).any(axis=1) | (data['volume']<0)
        if inv.any(): findings.append({'type':'OHLCV_INVARIANT_VIOLATION','severity':'CRITICAL','rows':int(inv.sum())})
    adjusted=('adjusted' in data.columns and data['adjusted'].fillna(False).any())
    if adjusted:
        has_lineage=corporate_actions is not None and all(c in corporate_actions.columns for c in ['symbol','effective_date'])
        if not has_lineage: findings.append({'type':'ADJUSTED_DATA_WITHOUT_ACTION_LINEAGE','severity':'CRITICAL'})
    # Session continuity is evidence, not an assertion that every calendar day must trade.
    gaps=[]
    if expected_sessions is not None:
        es=pd.to_datetime(pd.Series(expected_sessions),errors='coerce').dt.strftime('%Y-%m-%d').dropna().tolist()
        for sym,g in data.groupby('symbol'):
            actual=set(g['session_date'].dropna()); miss=sorted(set(es)-actual)
            if miss: gaps.append({'symbol':sym,'missing_sessions':miss[:100],'count':len(miss)})
        if gaps: findings.append({'type':'EXPECTED_SESSION_GAPS','severity':'WARNING','symbols':len(gaps)})
    # Universe continuity: supplied history can distinguish genuine delisting from missing data.
    universe_issues=[]
    if universe_history is not None:
        u=_norm(universe_history)
        if 'symbol' in u:
            known=set(u['symbol'].dropna())
            unknown=sorted(set(data['symbol'].dropna())-known)
            if unknown: universe_issues.append({'type':'SYMBOL_ABSENT_FROM_UNIVERSE_HISTORY','symbols':unknown[:100]})
            if universe_issues: findings.extend({'type':x['type'],'severity':'WARNING','symbols':x['symbols']} for x in universe_issues)
    # Deterministic evidence ledger; no consensus values are fabricated here.
    ledger=data[KEY+['source_id','source_version','evidence_fingerprint']].drop_duplicates().sort_values(KEY+['source_id']).reset_index(drop=True)
    chain=_chain_hash(ledger['evidence_fingerprint'].tolist()) if not ledger.empty else hashlib.sha256(b'').hexdigest()
    source_counts=ledger['source_id'].value_counts().to_dict() if not ledger.empty else {}
    critical=sum(1 for f in findings if f.get('severity')=='CRITICAL')
    status='BLOCKED' if critical else 'PASS_WITH_WARNINGS' if findings else 'PASS'
    report={'engine':ENGINE,'version':VERSION,'status':status,'rows':len(ledger),'sources':source_counts,
            'critical_findings':critical,'findings':findings,'missing_session_groups':gaps,
            'universe_issues':universe_issues,'evidence_chain_sha256':chain,
            'fabricated_rows':0,'consensus_values_invented':0,'production_approved':False}
    return report, ledger
