from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .oos_walk_forward import *
from .v25_pipeline import run as run_v25

VERSION='2.6.0'

def run(df, out_dir, train_sessions=60, test_sessions=20, step=20, embargo_sessions=1, purge_sessions=1, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    audit=audit_information_set(df)
    splits=make_splits(df,train_sessions,test_sessions,step,embargo_sessions,purge_sessions)
    split_audit=validate_splits(splits)
    splits.to_csv(out/'QV-OOS-V26-WALK-FORWARD-SPLITS-001.csv',index=False)
    oos=evaluate_frozen_oos(df,splits)
    oos.to_csv(out/'QV-OOS-V26-FROZEN-OOS-RESULTS-001.csv',index=False)
    h=evidence_hash(splits,audit)
    cert={'engine':'QV-OOS-WALK-FORWARD-EVIDENCE-ENGINE','version':VERSION,'information_set_audit':audit,'split_audit':split_audit,'purge_sessions':purge_sessions,'embargo_sessions':embargo_sessions,'frozen_rules_only':True,'score_is_not_probability':True,'oos_calibration_not_run_here':True,'production_approved':False,'evidence_hash':h}
    (out/'QV-OOS-V26-EVIDENCE-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    # Continue the full linked stack only when the decision information set is clean.
    if audit['status']=='PASS' and split_audit['status']=='PASS': run_v25(df,out,**kwargs)
    return cert,splits,oos
