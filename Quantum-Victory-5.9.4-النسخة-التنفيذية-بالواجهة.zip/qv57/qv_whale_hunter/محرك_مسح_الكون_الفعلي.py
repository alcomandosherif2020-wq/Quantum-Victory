from __future__ import annotations
import json, hashlib
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass
class نتيجة_سهم:
    الرمز: str
    الحالة: str
    الإغلاق: float | None
    الحجم: int | None
    قيمة_التداول_التقديرية: float | None
    التغير_المئوي: float | None
    الأسباب: list[str]
    المصدر: str

class محرك_مسح_الكون_الفعلي:
    """مسح فعلي للقطات OHLCV المنشورة؛ لا يتجاوز أخطاء البيانات ولا يصنع بدائل."""
    def __init__(self, ملف: str | Path):
        self.ملف = Path(ملف)
        self.لقطة = json.loads(self.ملف.read_text(encoding='utf-8'))

    @staticmethod
    def تحقق(صف):
        مطلوب = ['الرمز','التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم']
        if any(k not in صف or صف[k] is None for k in مطلوب):
            return False, ['حقول ناقصة']
        try:
            o,h,l,c,v = map(float,[صف['الافتتاح'],صف['الأعلى'],صف['الأدنى'],صف['الإغلاق'],صف['الحجم']])
        except Exception:
            return False, ['قيم غير رقمية']
        أسباب=[]
        if min(o,h,l,c) <= 0: أسباب.append('سعر غير موجب')
        if v < 0: أسباب.append('حجم سالب')
        # لا نفترض أن الحقل المسمى «الافتتاح» هو افتتاح الجلسة دائمًا.
        # بعض المزودين يعرضون إغلاق الجلسة السابقة في خانة افتتاحية/مرجعية.
        # في هذه الحالة يجوز أن يكون أعلى سعر الجلسة أقل من هذا الرقم،
        # وكذلك أدنى سعر الجلسة قد يكون أعلى/أقل منه؛ لذلك نتحقق فقط من
        # العلاقات التي لا تعتمد على دلالة الافتتاح.
        دلالة_الافتتاح = str(صف.get('دلالة_الافتتاح', صف.get('نوع_الافتتاح', 'غير_محدد'))).strip()
        افتتاح_جلسة = دلالة_الافتتاح in {'افتتاح_الجلسة', 'سعر_افتتاح_الجلسة', 'session_open'}
        if افتتاح_جلسة:
            if h < o: أسباب.append('الأعلى أقل من افتتاح الجلسة')
            if l > o: أسباب.append('الأدنى أعلى من افتتاح الجلسة')
        elif دلالة_الافتتاح in {'غير_محدد', '', 'None'}:
            أسباب.append('دلالة حقل الافتتاح غير محددة؛ لا يجوز اعتباره افتتاح الجلسة')
        if h < c: أسباب.append('الأعلى أقل من الإغلاق')
        if l > c: أسباب.append('الأدنى أعلى من الإغلاق')
        if l > h: أسباب.append('الأدنى أعلى من الأعلى')
        return (not أسباب), أسباب

    def شغل(self):
        النتائج=[]
        for صف in self.لقطة['الأسهم']:
            صالح, أسباب = self.تحقق(صف)
            close=float(صف['الإغلاق']) if صف.get('الإغلاق') is not None else None
            volume=int(float(صف['الحجم'])) if صف.get('الحجم') is not None else None
            turnover=close*volume if صالح else None
            النتائج.append(نتيجة_سهم(
                الرمز=صف['الرمز'], الحالة='مثبت' if صالح else 'مرفوض_جودة',
                الإغلاق=close, الحجم=volume, قيمة_التداول_التقديرية=turnover,
                التغير_المئوي=float(صف['التغير_المئوي']) if صف.get('التغير_المئوي') is not None else None,
                الأسباب=أسباب if أسباب else ['اجتاز حارس OHLCV'], المصدر=صف.get('المصدر','غير محدد')))
        مثبت=[x for x in النتائج if x.الحالة=='مثبت']
        مثبت.sort(key=lambda x: (x.قيمة_التداول_التقديرية or 0), reverse=True)
        return {
            'الإصدار':'4.27', 'تاريخ_اللقطة':self.لقطة['تاريخ_اللقطة'],
            'عدد_الأسهم':len(النتائج), 'عدد_المثبت':len(مثبت),
            'عدد_المرفوض_جودة':len(النتائج)-len(مثبت),
            'ترتيب_السيولة_التقديرية':[asdict(x) for x in مثبت],
            'المرفوضة':[asdict(x) for x in النتائج if x.الحالة!='مثبت'],
            'ملاحظة':'قيمة التداول تقديرية = الإغلاق × الحجم، وليست قيمة تداول رسمية. لا يوجد ادعاء بتحديد هوية حوت. حارس OHLC يفرق بين افتتاح الجلسة وإغلاق الجلسة السابقة/السعر المرجعي.'
        }

    def احفظ(self, مسار):
        out=self.شغل(); raw=json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8')
        out['بصمة_النتيجة']=hashlib.sha256(raw).hexdigest()
        Path(مسار).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
        return out
