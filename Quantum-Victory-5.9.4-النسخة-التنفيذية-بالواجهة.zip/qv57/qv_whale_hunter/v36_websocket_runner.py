from __future__ import annotations
from .live_feed_adapters import websocket_messages, adapt_provider_records
from .live_session_engine import LiveSessionEngine

def run(url, provider='CUSTOM_EGX_WS', subscribe_message=None, headers=None, out_dir='QV-LIVE-V36-WS-RUN', **kwargs):
    engine=LiveSessionEngine(out_dir=out_dir, **kwargs)
    emitted=0; received=0
    for msg in websocket_messages(url, subscribe_message=subscribe_message, headers=headers):
        received += 1
        batch=adapt_provider_records([msg], provider)
        if batch.empty: continue
        alerts=engine.process(batch)
        if not alerts.empty:
            emitted += len(alerts)
            yield alerts
