from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .adapter import adapt_canonical
from .sequence_engine import add_sequence_features, build_sequence_events
from .market_context import add_relative_flow
from .research_lab import add_forward_excursions, build_event_ledger, summarize_ledger

def run(df, out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    x=adapt_canonical(df,require_provenance=False)
    if (x.adapter_status=="REJECT").any(): raise ValueError("DATA_ADMISSION_FAILED")
    x=add_sequence_features(x); x=add_relative_flow(x)
    seq=build_sequence_events(x)
    merged=x.merge(seq,on=["symbol","session_date"],how="left")
    merged=add_forward_excursions(merged)
    ledger=build_event_ledger(merged)
    summary=summarize_ledger(ledger)
    merged.to_csv(out/"QV-WHALE-FEATURES-001.csv",index=False)
    seq.to_csv(out/"QV-WHALE-SEQUENCES-001.csv",index=False)
    ledger.to_csv(out/"QV-WHALE-EVENT-LEDGER-001.csv",index=False)
    summary.to_csv(out/"QV-WHALE-RESEARCH-SUMMARY-001.csv",index=False)
    report={"engine":"QV-WHALE-HUNTER-RESEARCH-LAB","version":"1.2.0","status":"PASS","production_approved":False,"purpose":"research_and_oos_validation","score_is_not_probability":True,"event_ledger_rows":len(ledger),"summary_rows":len(summary),"required_gate":"REAL_EGX_QUALIFICATION_OOS_WALK_FORWARD_AND_CALIBRATION"}
    (out/"QV-WHALE-RESEARCH-REPORT-001.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    return report
