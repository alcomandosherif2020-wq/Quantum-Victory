from __future__ import annotations
import hashlib
from typing import Mapping
import numpy as np
import pandas as pd

ENGINE='QV-SOURCE-RECONCILIATION-ENGINE'; VERSION='1.0.0'
KEY=['symbol','session_date']
FIELDS=['open','high','low','close','volume','turnover']

def _norm(df):
    x=df.copy()
    for c in KEY:
        if c not in x: x[c]=''
        x[c]=x[c].astype(str).str.strip()
    x['session_date']=pd.to_datetime(x['session_date'],errors='coerce').dt.strftime('%Y-%m-%d')
    for c in FIELDS:
        if c in x: x[c]=pd.to_numeric(x[c],errors='coerce')
    return x

def _sha_obj(x):
    payload='|'.join('' if pd.isna(v) else str(v) for v in x)
    return hashlib.sha256(payload.encode()).hexdigest()

def reconcile(sources: Mapping[str,pd.DataFrame], *, tolerances=None):
    """Cross-source reconciliation. It proves agreement/disagreement, never invents a consensus value."""
    tol={'price_abs':1e-9,'price_rel':1e-6,'volume_rel':1e-6,'turnover_rel':1e-6}; tol.update(tolerances or {})
    findings=[]; keys=set(); norm={}
    for name,df in sources.items():
        x=_norm(df); norm[name]=x
        if not x.empty: keys.update(map(tuple,x[KEY].dropna().itertuples(index=False,name=None)))
    rows=[]
    for key in sorted(keys):
        vals={name: norm[name].set_index(KEY).loc[key] if key in norm[name].set_index(KEY).index else None for name in norm}
        available=[n for n,r in vals.items() if r is not None]
        conflicts=[]
        field_status={}
        for f in FIELDS:
            arr=[]
            for n in available:
                if f in vals[n] and pd.notna(vals[n][f]): arr.append((n,float(vals[n][f])))
            if len(arr)<2: field_status[f]='SINGLE_SOURCE'
            else:
                base=arr[0][1]; ok=True
                for _,v in arr[1:]:
                    scale=max(abs(base),abs(v),1.0)
                    allowed=tol['volume_rel'] if f=='volume' else tol['turnover_rel'] if f=='turnover' else tol['price_rel']
                    if abs(v-base)>tol['price_abs'] and abs(v-base)/scale>allowed: ok=False
                field_status[f]='AGREE' if ok else 'CONFLICT'
                if not ok: conflicts.append(f)
        status='VERIFIED_CROSS_SOURCE' if len(available)>=2 and not conflicts else ('CONFLICT' if conflicts else 'SINGLE_SOURCE')
        rows.append({'symbol':key[0],'session_date':key[1],'sources_available':len(available),'source_names':'|'.join(available),'reconciliation_status':status,'conflicting_fields':'|'.join(conflicts),'field_status':str(field_status)})
        if conflicts: findings.append({'symbol':key[0],'session_date':key[1],'type':'CROSS_SOURCE_FIELD_CONFLICT','severity':'CRITICAL','fields':conflicts})
    out=pd.DataFrame(rows)
    counts=out.reconciliation_status.value_counts().to_dict() if not out.empty else {}
    return {'engine':ENGINE,'version':VERSION,'status':'BLOCKED' if findings else 'PASS','rows_reconciled':len(out),'counts':counts,'critical_findings':len(findings),'findings':findings,'production_approved':False}, out
