from __future__ import annotations
import json
from pathlib import Path
from .historical_evidence import build_evidence
VERSION='2.4.0'

def run(sources, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    rep, ledger=build_evidence(sources, **kwargs)
    ledger.to_csv(out/'QV-DATA-V24-HISTORICAL-EVIDENCE-LEDGER-001.csv',index=False)
    (out/'QV-DATA-V24-HISTORICAL-EVIDENCE-REPORT-001.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
    manifest={'engine':'QV-DATA-EVIDENCE-PIPELINE','version':VERSION,'status':rep['status'],'rows':rep['rows'],
              'critical_findings':rep['critical_findings'],'evidence_chain_sha256':rep['evidence_chain_sha256'],
              'fabricated_rows':0,'production_approved':False,'next_gate':'POINT_IN_TIME_REPLAY_AND_OOS_VALIDATION'}
    (out/'QV-DATA-V24-MANIFEST-001.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest, ledger
