from __future__ import annotations
import pandas as pd
import numpy as np

VERSION='1.5.0'

def evaluate_challengers(results: pd.DataFrame, champion='champion', challenger='challenger', min_oos_rows=100):
    if results.empty or not {'model','oos_return'}.issubset(results.columns):
        return {'status':'BLOCKED_MISSING_OOS_RESULTS'}
    x=results.copy(); x['oos_return']=pd.to_numeric(x['oos_return'],errors='coerce'); x=x.dropna(subset=['oos_return'])
    c=x[x.model==champion]['oos_return']; h=x[x.model==challenger]['oos_return']
    n=min(len(c),len(h))
    if n<min_oos_rows: return {'status':'BLOCKED_INSUFFICIENT_OOS_SAMPLE','paired_rows':int(n),'min_oos_rows':min_oos_rows}
    diff=(h.iloc[:n].to_numpy()-c.iloc[:n].to_numpy())
    return {'status':'PASS' if float(np.mean(diff))>0 else 'REJECT','paired_rows':int(n),'champion_mean_oos_return':float(c.iloc[:n].mean()),'challenger_mean_oos_return':float(h.iloc[:n].mean()),'mean_improvement':float(diff.mean())}
