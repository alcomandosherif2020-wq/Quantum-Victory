from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .source_reconciliation import reconcile

VERSION='2.3.0'

def run(sources, out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    rep, ledger=reconcile(sources)
    ledger.to_csv(out/'QV-DATA-V23-RECONCILIATION-LEDGER-001.csv',index=False)
    manifest={'engine':'QV-DATA-EVIDENCE-PIPELINE','version':VERSION,'status':rep['status'],'rows_reconciled':rep['rows_reconciled'],'critical_findings':rep['critical_findings'],'production_approved':False,'next_gate':'POINT_IN_TIME_HISTORICAL_SNAPSHOT'}
    (out/'QV-DATA-V23-RECONCILIATION-REPORT-001.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-DATA-V23-MANIFEST-001.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest, ledger
