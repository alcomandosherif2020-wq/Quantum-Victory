from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v20_pipeline import run as run_v20
from .final_recommendation import build_final_recommendation

VERSION='2.1.0'

def run(df,out_dir,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    run_v20(df,out,**kwargs)
    scenario=pd.read_csv(out/'QV-WHALE-V20-SCENARIO-FUSION-001.csv')
    rec=build_final_recommendation(scenario)
    rec.to_csv(out/'QV-WHALE-V21-FINAL-RECOMMENDATION-EVIDENCE-001.csv',index=False)
    summary=(rec.groupby(['recommendation_posture','risk_level'],dropna=False).size().reset_index(name='rows'))
    summary.to_csv(out/'QV-WHALE-V21-RECOMMENDATION-SUMMARY-001.csv',index=False)
    report={'engine':'QV-WHALE-HUNTER-FINAL-RECOMMENDATION-EVIDENCE','version':VERSION,'status':'PASS','production_approved':False,
            'rows':len(rec),'probability_output':None,'calibration_status':'NOT_CALIBRATED','fixed_price_targets':False,
            'identity_claim':False,'recommendation_role':'EVIDENCE_ONLY','human_risk_check_required':True,
            'principle':'The final layer converts fused scenario evidence into an explicit action posture without converting score to probability or claiming certainty. It remains non-production until real EGX qualification, OOS, walk-forward, calibration and shadow gates pass.',
            'remaining_gates':['REAL_EGX_DATA_QUALIFICATION','OOS_VALIDATION','WALK_FORWARD','SAMPLE_SIZE','REGIME_STABILITY','OOS_CALIBRATION','CHAMPION_CHALLENGER','SHADOW','FINAL_PRODUCTION_GATE']}
    (out/'QV-WHALE-V21-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-WHALE-V21-FINAL-CONTRACT-001.json').write_text(json.dumps({'version':VERSION,'probability':None,'fixed_price_target':None,'production_approved':False,'recommendation_role':'EVIDENCE_ONLY','human_risk_check_required':True,'identity_claim':False},ensure_ascii=False,indent=2),encoding='utf-8')
    return report
