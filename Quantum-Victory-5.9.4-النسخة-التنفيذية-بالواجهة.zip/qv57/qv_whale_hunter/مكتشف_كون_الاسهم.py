from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable, Mapping
import pandas as pd

@dataclass(frozen=True)
class تعريف_المصدر:
    الاسم: str
    الفئة: str
    الرابط: str
    حالة_البيانات: str
    بيانات_يومية: bool
    بيانات_لحظية: bool
    صفقات: bool
    عمق: bool
    أخبار: bool
    تاريخ: bool
    يحتاج_مفتاح: bool
    ملاحظة: str

المصادر = (
    تعريف_المصدر('البورصة المصرية','رسمي','https://beta.egx.com.eg/ar','أساسي للسياق الرسمي',True,False,False,False,True,True,False,'المرجع الرسمي؛ حالة السوق والتقويم يجب التحقق منهما قبل التحليل.'),
    تعريف_المصدر('مزود بيانات البورصة المصرية الرسمي','رسمي/مرخص','https://ticker.egidegypt.com','مرشح المصدر الرئيسي',True,True,True,True,True,True,True,'يتطلب اعتمادًا/رمز وصول؛ لا اعتماد إنتاجي دون اختبار فعلي.'),
    تعريف_المصدر('ياهو للتمويل','عام','https://finance.yahoo.com','تحقق يومي ثانوي',True,False,False,False,False,True,False,'رموز مصرية بصيغة .CA لبعض الأدوات؛ التغطية ليست شاملة والوصول البرمجي غير رسمي.'),
    تعريف_المصدر('منصة التحليل المرئي','عام','https://www.tradingview.com/markets/stocks-egypt/','اكتشاف/تحقق مرئي',True,False,False,False,False,True,False,'لا نفترض واجهة برمجية مجانية غير موثقة أو حق إعادة التوزيع.'),
    تعريف_المصدر('EGXAPI','مزود مستقل','https://egxapi.com/','مرشح يحتاج تحقق',True,True,True,True,False,True,True,'التغطية والعقد وشروط الاستخدام تحتاج اختبارًا فعليًا.'),
    تعريف_المصدر('EGX.news','مزود مستقل','https://www.egx.news/en/our-data','مرشح يحتاج تحقق',True,True,True,True,True,True,True,'يوفر منتجات واسعة بحسب الخطة؛ ليس مصدرًا مجانيًا كاملًا مثبتًا.'),
    تعريف_المصدر('بورصة — برنامج توحيد','برنامج مفتوح المصدر','https://github.com/7ashraf/borsa','أداة تكامل',True,False,False,False,False,True,False,'البرنامج مجاني، لكن مصادر البيانات التي يستدعيها لها شروط مستقلة.'),
    تعريف_المصدر('EODHD','مزود عالمي','https://eodhd.com/','مرشح تحقق محدود',True,True,False,False,False,True,True,'الخطة المجانية محدودة؛ يجب إثبات تغطية EGX قبل الاعتماد.'),
    تعريف_المصدر('ألفا فانتج','مزود عالمي','https://www.alphavantage.co/','مرشح تحقق محدود',True,True,False,False,False,True,True,'التغطية المصرية تحتاج اختبار رمزًا برمز؛ المجاني محدود.'),
    تعريف_المصدر('اثنا عشر داتا','مزود عالمي','https://twelvedata.com/','مرشح تحقق محدود',True,True,False,False,False,True,True,'التغطية والشروط تختلف حسب السوق والخطة.'),
    تعريف_المصدر('فنهب','مزود عالمي','https://finnhub.io/','غير مثبت لـEGX',True,True,False,False,False,True,True,'لا نعتبر وجود واجهة عالمية دليلًا على تغطية EGX.'),
    تعريف_المصدر('الاستثمار دوت كوم','عام','https://www.investing.com/','مرجع مقارنة',True,False,False,False,True,True,False,'مفيد للمقارنة التاريخية؛ لا نعتمد طرق وصول تتجاوز الحماية.'),
    تعريف_المصدر('ستوك أناليسس','عام','https://stockanalysis.com/','مرجع مقارنة مشروط',True,False,False,False,False,True,False,'يجب فحص منطق OHLC قبل استخدام أي عينة.'),
    تعريف_المصدر('ستوكو','عام','https://stooq.com/','غير مثبت لـEGX',True,False,False,False,False,True,False,'لا يدخل الشبكة النشطة قبل إثبات تغطية الرموز المصرية.'),
    تعريف_المصدر('جوجل للتمويل','عام','https://www.google.com/finance/','استكشاف/تحقق يدوي',True,False,False,False,False,True,False,'مصدر عرض عام؛ لا نعتمد واجهة غير موثقة للتشغيل الآلي.'),
    تعريف_المصدر('ماركت ووتش','عام','https://www.marketwatch.com/','مرجع عالمي مشروط',True,False,False,False,True,True,False,'التغطية المصرية وإعادة الاستخدام تحتاج تحققًا قبل الاعتماد.'),
    تعريف_المصدر('موني كنترول','عام','https://www.moneycontrol.com/','مرجع عالمي مشروط',True,False,False,False,True,True,False,'وجود محتوى سوقي لا يساوي ترخيص تغذية بيانات.'),
)

ALIASES = {
    'COMI':'COMI','COMI.CA':'COMI','EGS60121C018':'COMI',
}

def توحيد_الرمز(الرمز: str) -> str:
    s = str(الرمز).strip().upper()
    return ALIASES.get(s, s[:-3] if s.endswith('.CA') else s)

def رموز_ياهو(الرمز: str) -> str:
    return f'{توحيد_الرمز(الرمز)}.CA'

def بناء_مصفوفة_التغطية(الرموز: Iterable[str]) -> pd.DataFrame:
    rows=[]
    for raw in الرموز:
        canonical=توحيد_الرمز(raw)
        for src in المصادر:
            rows.append({
                'الرمز_المدخل': raw, 'الرمز_الموحد': canonical, 'المصدر': src.الاسم,
                'الرابط': src.الرابط, 'الحالة': src.حالة_البيانات,
                'يومي': src.بيانات_يومية, 'لحظي': src.بيانات_لحظية,
                'صفقات': src.صفقات, 'عمق': src.عمق, 'أخبار': src.أخبار,
                'تاريخ': src.تاريخ, 'يحتاج_مفتاح': src.يحتاج_مفتاح,
            })
    return pd.DataFrame(rows)

def ملخص_التغطية(مصفوفة: pd.DataFrame) -> pd.DataFrame:
    if مصفوفة.empty: return pd.DataFrame(columns=['الرمز_الموحد','عدد_المصادر','مصادر_يومية','مصادر_لحظية','مصادر_صفقات','مصادر_عمق'])
    g=مصفوفة.groupby('الرمز_الموحد', dropna=False)
    return g.agg(
        عدد_المصادر=('المصدر','nunique'),
        مصادر_يومية=('يومي','sum'), مصادر_لحظية=('لحظي','sum'),
        مصادر_صفقات=('صفقات','sum'), مصادر_عمق=('عمق','sum'),
    ).reset_index()

def فحص_التغطية(الرموز: Iterable[str]) -> dict:
    matrix=بناء_مصفوفة_التغطية(الرموز)
    summary=ملخص_التغطية(matrix)
    return {
        'عدد_الرموز': int(summary['الرمز_الموحد'].nunique()) if not summary.empty else 0,
        'عدد_المصادر_المسجلة': len(المصادر),
        'المصفوفة': matrix.to_dict(orient='records'),
        'الملخص': summary.to_dict(orient='records'),
        'تنبيه': 'هذه خريطة قدرة للمصادر وليست إثباتًا أن كل مصدر يغطي كل رمز. الإثبات يتطلب اختبارًا فعليًا للرمز وشروط الاستخدام.',
    }
