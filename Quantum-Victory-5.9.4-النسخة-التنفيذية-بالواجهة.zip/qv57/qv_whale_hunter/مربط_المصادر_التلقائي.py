# كوانتوم فيكتوري 4.18 — مربط المصادر التلقائي
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
import hashlib, json, math, time

@dataclass
class تعريف_مصدر:
    الاسم: str
    الدور: str
    الفترة_ثانية: int
    الحالة_الاعتمادية: str = "غير موصول"
    نوع_البيانات: str = ""
    موثوقية_المصدر: str = "غير مقيمة"
    الحد_الأقصى_للفشل: int = 3
    أقصى_تأخير_ثوان: int = 120
    فترة_التهدئة_الأقصى: int = 1800

@dataclass
class حالة_مصدر:
    الاسم: str
    آخر_تشغيل: str | None = None
    آخر_نجاح: str | None = None
    عدد_النجاح: int = 0
    عدد_الفشل: int = 0
    الحالة: str = "غير موصول"
    المحاولات_التالية: int = 0
    التراجع_حتى: str | None = None
    آخر_خطأ: str | None = None
    آخر_نتيجة: dict | None = None

class مربط_المصادر_التلقائي:
    """ربط آمن للمصادر مع تراجع أسي، قاطع دائرة، تعافٍ، وتقادم/تعارض يمنعان التنبيه."""
    def __init__(self, مجلد="حالة_التحديث_المستمر"):
        self.مجلد = Path(مجلد); self.مجلد.mkdir(parents=True, exist_ok=True)
        self.state_path = self.مجلد / "حالة_مربط_المصادر.json"
        self.defs: dict[str, تعريف_مصدر] = {}
        self.states: dict[str, حالة_مصدر] = {}
        self.functions = {}
        self._تحميل()

    @staticmethod
    def _iso(ts):
        return datetime.fromtimestamp(ts, timezone.utc).isoformat()

    @staticmethod
    def _ts(value):
        if value is None: return None
        return datetime.fromisoformat(value).timestamp()

    def تسجيل_مصدر(self, تعريف: تعريف_مصدر, وظيفة=None):
        if تعريف.الفترة_ثانية <= 0 or تعريف.الحد_الأقصى_للفشل <= 0:
            raise ValueError("إعدادات المصدر يجب أن تكون موجبة")
        self.defs[تعريف.الاسم] = تعريف
        self.states.setdefault(تعريف.الاسم, حالة_مصدر(تعريف.الاسم))
        if وظيفة is not None: self.functions[تعريف.الاسم] = وظيفة
        self._حفظ()

    def ربط_وظيفة(self, الاسم, وظيفة):
        if الاسم not in self.defs: raise KeyError(الاسم)
        self.functions[الاسم] = وظيفة

    def مستحق(self, الاسم, الآن=None):
        الآن = time.time() if الآن is None else الآن
        s, d = self.states[الاسم], self.defs[الاسم]
        if s.التراجع_حتى and الآن < self._ts(s.التراجع_حتى): return False
        return s.آخر_نجاح is None or الآن - self._ts(s.آخر_نجاح) >= d.الفترة_ثانية

    def جاهز_للمحاولة(self, الاسم, الآن=None):
        الآن = time.time() if الآن is None else الآن
        s = self.states[الاسم]
        return not s.التراجع_حتى or الآن >= self._ts(s.التراجع_حتى)

    def تشغيل(self, الاسم, الآن=None, تحقق_من_النتيجة=None):
        الآن = time.time() if الآن is None else الآن
        s, d = self.states[الاسم], self.defs[الاسم]
        if not self.جاهز_للمحاولة(الاسم, الآن): return {"الحالة":"متراجع", "الاسم":الاسم}
        if not self.مستحق(الاسم, الآن): return {"الحالة":"مؤجل", "الاسم":الاسم}
        f = self.functions.get(الاسم)
        s.آخر_تشغيل = self._iso(الآن)
        if f is None:
            return self._فشل(الاسم, الآن, "لا يوجد محول مصدر فعلي موصول")
        try:
            result = f()
            if result is None: raise ValueError("المحول أعاد نتيجة فارغة")
            if تحقق_من_النتيجة is not None:
                ok, reason = تحقق_من_النتيجة(result)
                if not ok: raise ValueError(reason or "فشل فحص جودة النتيجة")
            s.آخر_نجاح = self._iso(الآن); s.عدد_النجاح += 1; s.الحالة = "نجح"
            s.آخر_خطأ = None; s.التراجع_حتى = None; s.المحاولات_التالية = 0
            s.آخر_نتيجة = self._ملخص_نتيجة(result)
            self._حفظ()
            return {"الحالة":"نجح", "الاسم":الاسم, "النتيجة":result}
        except Exception as e:
            return self._فشل(الاسم, الآن, str(e))


    def _فشل(self, الاسم, الآن, خطأ):
        s, d = self.states[الاسم], self.defs[الاسم]
        s.عدد_الفشل += 1; s.آخر_خطأ = str(خطأ)
        if s.عدد_الفشل >= d.الحد_الأقصى_للفشل:
            n = s.عدد_الفشل - d.الحد_الأقصى_للفشل + 1
            delay = min(d.أقصى_تأخير_ثوان, 2 ** min(n, 20) * 5)
            s.الحالة = "قاطع_دائرة"; s.التراجع_حتى = self._iso(الآن + delay)
        else:
            delay = min(d.أقصى_تأخير_ثوان, 2 ** (s.عدد_الفشل - 1) * 5)
            s.الحالة = "فشل"; s.التراجع_حتى = self._iso(الآن + delay)
        s.المحاولات_التالية += 1
        self._حفظ()
        return {"الحالة":s.الحالة, "الاسم":الاسم, "الخطأ":str(خطأ), "إعادة_المحاولة_بعد_ثوان":delay}

    @staticmethod
    def _ملخص_نتيجة(result):
        if isinstance(result, dict):
            return {"نوع":"قاموس", "المفاتيح":list(result.keys())[:30]}
        if hasattr(result, "shape"):
            return {"نوع":"جدول", "الشكل":list(result.shape)}
        return {"نوع":type(result).__name__}

    def فتح_الدائرة(self, الاسم):
        s = self.states[الاسم]; s.الحالة="جاهز"; s.التراجع_حتى=None; s.عدد_الفشل=0; s.آخر_خطأ=None; self._حفظ()

    def فحص_التقادم(self, الاسم, وقت_البيانات, الآن=None):
        الآن = time.time() if الآن is None else الآن
        if وقت_البيانات is None: return {"الحالة":"غير_معروف", "صالح_للتنبيه":False}
        age = الآن - self._ts(وقت_البيانات) if isinstance(وقت_البيانات, str) else الآن - float(وقت_البيانات)
        max_age = self.defs[الاسم].أقصى_تأخير_ثوان
        return {"الحالة":"سليم" if age <= max_age else "متقادم", "العمر_ثانية":max(0, age), "صالح_للتنبيه":age <= max_age}

    def فحص_التعارض(self, قيم, سماحية=1e-9):
        vals = [float(x) for x in قيم if x is not None and math.isfinite(float(x))]
        conflict = len(vals) > 1 and max(vals) - min(vals) > سماحية
        return {"الحالة":"متعارض" if conflict else "متسق", "صالح_للتنبيه":not conflict}

    def تقرير(self):
        return {"الإصدار":"4.18", "وقت":datetime.now(timezone.utc).isoformat(),
                "المصادر":[asdict(x) for x in self.defs.values()],
                "الحالات":{k:asdict(v) for k,v in self.states.items()}, "الإنتاج_مصرح":False}

    def _حفظ(self):
        payload=self.تقرير(); raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2).encode()
        payload["بصمة_الحالة"]=hashlib.sha256(raw).hexdigest()
        tmp=self.state_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(self.state_path)

    def _تحميل(self):
        if not self.state_path.exists(): return
        try:
            p=json.loads(self.state_path.read_text(encoding='utf-8'))
            for x in p.get('المصادر',[]):
                vals={k:v for k,v in x.items() if k in تعريف_مصدر.__dataclass_fields__}
                self.defs[x['الاسم']]=تعريف_مصدر(**vals)
            for k,v in p.get('الحالات',{}).items():
                vals={a:b for a,b in v.items() if a in حالة_مصدر.__dataclass_fields__}
                self.states[k]=حالة_مصدر(**vals)
            for name in self.defs: self.states.setdefault(name,حالة_مصدر(name))
        except Exception:
            # ملف حالة تالف لا يمنع الإقلاع ولا يولد بيانات.
            self.defs={}; self.states={}

def إنشاء_مربط_افتراضي():
    m=مربط_المصادر_التلقائي()
    m.تسجيل_مصدر(تعريف_مصدر("البيانات_الرسمية_للسوق","السوق والصفقات والعمق",15,"مصرح_مشروط","لحظي","رسمية"))
    m.تسجيل_مصدر(تعريف_مصدر("ياهو_للتمويل","التاريخ اليومي والتحقق",3600,"ثانوي","يومي","غير رسمية"))
    m.تسجيل_مصدر(تعريف_مصدر("الأخبار_والإفصاحات","الأحداث",60,"مفتوح_عام","أحداث","رسمية"))
    m.تسجيل_مصدر(تعريف_مصدر("المؤشرات_والقطاعات","السوق والقطاعات",60,"مشروط","مؤشرات","غير مقيمة"))
    return m
