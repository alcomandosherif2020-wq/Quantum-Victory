# -*- coding: utf-8 -*-
"""طبقة تجميع آمنة لحالة التشغيل والمراقب، دون اختراع بيانات سوق."""
from __future__ import annotations
from typing import Any
from datetime import datetime, timezone

class لوحة_التشغيل_الحية:
    def __init__(self, مراقب=None, محرك=None, مركز=None):
        self.مراقب=مراقب; self.محرك=محرك; self.مركز=مركز

    def لقطة(self) -> dict[str, Any]:
        الآن=datetime.now(timezone.utc).isoformat()
        مراقب=self.مراقب.تقرير() if self.مراقب else {}
        محرك=self.محرك.ملخص() if self.محرك else {}
        مركز=self.مركز.تقرير() if self.مركز and hasattr(self.مركز,'تقرير') else {}
        return {
            'وقت_التجميع': الآن,
            'المراقب': مراقب,
            'المحرك': محرك,
            'المركز': مركز,
            'الإنتاج_مصرح': False,
            'رسالة_السلامة': 'الحالة المعروضة وصف تشغيلي فقط؛ لا يثبت اتصالًا حيًا ولا يفتح الإنتاج.'
        }
