from __future__ import annotations
import hashlib, json
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, timezone

REQUIRED_ARTIFACTS = (
    'data_qualification', 'leakage_audit', 'oos', 'walk_forward',
    'sample_size', 'regime_stability', 'oos_calibration',
    'champion_challenger', 'shadow'
)

@dataclass(frozen=True)
class Evidence:
    gate: str
    status: str
    artifact_sha256: str | None = None
    independent: bool = False
    notes: str = ''


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_json(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode('utf-8')


def build_experiment_lock(*, dataset_sha256: str, code_sha256: str, config: dict, seed: int) -> dict:
    payload = {
        'dataset_sha256': dataset_sha256,
        'code_sha256': code_sha256,
        'config': config,
        'seed': int(seed),
    }
    return {**payload, 'experiment_lock_sha256': sha256_bytes(canonical_json(payload))}


def verify_experiment_lock(lock: dict) -> dict:
    required = ('dataset_sha256', 'code_sha256', 'config', 'seed', 'experiment_lock_sha256')
    missing = [k for k in required if k not in lock]
    if missing:
        return {'status': 'BLOCKED', 'reason': 'MISSING_LOCK_FIELDS', 'missing': missing}
    payload = {k: lock[k] for k in required[:-1]}
    expected = sha256_bytes(canonical_json(payload))
    ok = expected == lock.get('experiment_lock_sha256')
    return {'status': 'PASS' if ok else 'BLOCKED', 'reason': 'OK' if ok else 'LOCK_HASH_MISMATCH', 'expected': expected, 'observed': lock.get('experiment_lock_sha256')}


def evaluate_evidence(evidence: list[dict]) -> dict:
    by_gate = {e.get('gate'): e for e in evidence if isinstance(e, dict)}
    missing = [g for g in REQUIRED_ARTIFACTS if g not in by_gate]
    invalid = [g for g in REQUIRED_ARTIFACTS if g in by_gate and by_gate[g].get('status') != 'PASS']
    non_independent = [g for g in REQUIRED_ARTIFACTS if g in by_gate and by_gate[g].get('independent') is not True]
    return {
        'status': 'PASS' if not missing and not invalid and not non_independent else 'BLOCKED',
        'missing': missing,
        'failed': invalid,
        'non_independent': non_independent,
        'required_gate_count': len(REQUIRED_ARTIFACTS),
    }


def create_promotion_decision(*, evidence: list[dict], experiment_lock: dict, production_approved: bool = False) -> dict:
    ev = evaluate_evidence(evidence)
    lock = verify_experiment_lock(experiment_lock)
    approved = bool(ev['status'] == 'PASS' and lock['status'] == 'PASS' and production_approved is True)
    reasons = []
    if ev['status'] != 'PASS': reasons.append('evidence_contract_not_satisfied')
    if lock['status'] != 'PASS': reasons.append('experiment_lock_invalid')
    if production_approved is not True: reasons.append('explicit_production_approval_missing')
    payload = {
        'evidence': evidence, 'experiment_lock': experiment_lock,
        'evidence_audit': ev, 'lock_audit': lock,
        'production_approved_input': bool(production_approved), 'effective_approval': approved,
    }
    return {
        'product': 'Quantum Victory', 'engine': 'QV-E2E-VERIFICATION', 'version': '5.5.0',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'APPROVED' if approved else 'BLOCKED',
        'production_approved': approved,
        'blocking_reasons': reasons,
        'evidence_audit': ev, 'experiment_lock_audit': lock,
        'decision_sha256': sha256_bytes(canonical_json(payload)),
        'scientific_note': 'Promotion control is not evidence of profitability or future returns.'
    }


def write_decision(path: Path, decision: dict) -> None:
    Path(path).write_text(json.dumps(decision, ensure_ascii=False, indent=2), encoding='utf-8')
