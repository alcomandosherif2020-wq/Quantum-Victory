from __future__ import annotations
import numpy as np
import pandas as pd

SIZE_ORDER = {'MICRO_FLOW':1,'SMALL_FLOW':2,'MEDIUM_FLOW':3,'LARGE_WHALE':4,'MEGA_WHALE':5}


def build_market_radar(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    x=df.copy()
    if x.empty:
        return pd.DataFrame(), pd.DataFrame()
    num_cols=['whale_radar_score','defended_radar_score','flow_intensity','confirmation_score','uncertainty_score','false_whale_trap_score','relative_flow_to_market','relative_flow_to_sector']
    for c in num_cols:
        if c in x: x[c]=pd.to_numeric(x[c],errors='coerce')
    x['date']=x.get('session_date',pd.Series(index=x.index,dtype=str)).astype(str)
    direction=x['radar_direction'] if 'radar_direction' in x.columns else pd.Series('',index=x.index); x['direction_sign']=np.select([direction.eq('BUY_SIDE'),direction.eq('SELL_SIDE')],[1,-1],default=0)
    trap=x['false_whale_trap_score'] if 'false_whale_trap_score' in x.columns else pd.Series(0.0,index=x.index); x['clean_factor']=(1-trap.fillna(0)/100).clip(0,1)
    unc=x['uncertainty_score'] if 'uncertainty_score' in x.columns else pd.Series(0.0,index=x.index); x['uncertainty_factor']=(1-unc.fillna(0)/100).clip(0,1)
    phase_age=x['lifecycle_phase_age'] if 'lifecycle_phase_age' in x.columns else (x['phase_age'] if 'phase_age' in x.columns else pd.Series(0.0,index=x.index)); x['persistence_factor']=(phase_age.fillna(0).clip(0,10)/10).clip(0,1)
    x['radar_strength']=(0.45*(x['defended_radar_score'] if 'defended_radar_score' in x.columns else (x['whale_radar_score'] if 'whale_radar_score' in x.columns else pd.Series(0.0,index=x.index))).fillna(0).clip(0,100)
                         +0.20*(x['flow_intensity'] if 'flow_intensity' in x.columns else pd.Series(0.0,index=x.index)).fillna(0).clip(0,100)
                         +0.15*(x['confirmation_score'] if 'confirmation_score' in x.columns else pd.Series(0.0,index=x.index)).fillna(0).clip(0,100)
                         +0.10*100*x['clean_factor']+0.10*100*x['uncertainty_factor']).clip(0,100)
    # Signed evidence: positive accumulation pressure, negative distribution/exit pressure.
    x['signed_strength']=x['radar_strength']*x['direction_sign']
    x['size_weight']=x.get('whale_size_class','MICRO_FLOW').map(SIZE_ORDER).fillna(1)
    # Concentration: prevents a large number of weak observations from looking like one dominant flow.
    x['weighted_flow']=x['signed_strength']*x['size_weight']

    stock=x[['symbol','date','whale_size_class','radar_strength','signed_strength','defended_radar_score','false_whale_trap_score','direction_sign']].copy()
    stock['radar_rank']=stock.groupby('date')['radar_strength'].rank(method='dense',ascending=False).astype(int)
    stock['direction']=np.select([stock.direction_sign>0,stock.direction_sign<0],['BUY_SIDE','SELL_SIDE'],default='NEUTRAL_OR_MIXED')
    stock['attention_flag']=np.where((stock.radar_strength>=70)&(stock.false_whale_trap_score<50),'HIGH_ATTENTION',np.where(stock.radar_strength>=50,'WATCH','LOW_SIGNAL'))

    def agg(g):
        buy=g.loc[g.direction_sign>0,'signed_strength'].sum(); sell=-g.loc[g.direction_sign<0,'signed_strength'].sum()
        gross=buy+sell
        net=(buy-sell)/gross*100 if gross else 0.0
        return pd.Series({
            'stocks_scanned':g.symbol.nunique(),'mean_strength':g.radar_strength.mean(),'max_strength':g.radar_strength.max(),
            'buy_pressure':buy,'sell_pressure':sell,'net_flow_pressure':net,
            'high_attention_count':int(((g.radar_strength>=70)&(g.false_whale_trap_score<50)).sum()),
            'trap_block_count':int((g.false_whale_trap_score>=70).sum()),
            'large_or_mega_count':int(g.whale_size_class.isin(['LARGE_WHALE','MEGA_WHALE']).sum()),
            'mega_count':int((g.whale_size_class=='MEGA_WHALE').sum())})
    def aggregate_groups(frame, keys):
        rows=[]
        for key, group in frame.groupby(keys, sort=True):
            if not isinstance(key, tuple): key=(key,)
            row=dict(zip(keys,key)); row.update(agg(group).to_dict()); rows.append(row)
        return pd.DataFrame(rows)
    market=aggregate_groups(x,['date'])
    market['market_flow_state']=np.select([market.net_flow_pressure>=25,market.net_flow_pressure<=-25],['BUY_DOMINANT','SELL_DOMINANT'],default='MIXED_FLOW')

    sector=pd.DataFrame()
    if 'sector' in x.columns:
        sec=x.copy(); sec['sector']=sec['sector'].fillna('UNKNOWN').astype(str)
        sector=aggregate_groups(sec,['date','sector'])
        sector['sector_flow_state']=np.select([sector.net_flow_pressure>=25,sector.net_flow_pressure<=-25],['BUY_DOMINANT','SELL_DOMINANT'],default='MIXED_FLOW')
    return stock, market if sector.empty else market
