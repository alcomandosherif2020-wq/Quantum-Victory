from __future__ import annotations
import hashlib, json
from pathlib import Path
import pandas as pd


فئات_الأثر = {'عالٍ': 3, 'متوسط': 2, 'غير محدد': 1}


def _تاريخ_فقط(x):
    
    t = pd.to_datetime(x, errors='coerce')
    return t.dt.normalize() if isinstance(t, pd.Series) else t.normalize()


def بصمة_الحدث(الحدث: dict) -> str:
    مادة = '|'.join(str(الحدث.get(k, '')) for k in ('العنوان','الرابط','الرمز','تاريخ_النشر'))
    return hashlib.sha256(مادة.encode('utf-8')).hexdigest()


def توحيد_الأحداث(الأحداث):
    out=[]; seen=set()
    for e in الأحداث or []:
        x=dict(e)
        x['الرمز'] = x.get('الرمز') or None
        x['تاريخ_النشر'] = x.get('تاريخ_النشر') or x.get('التاريخ')
        x['درجة_الأثر_الرقمية'] = فئات_الأثر.get(x.get('درجة_الأثر','غير محدد'), 1)
        x['بصمة'] = x.get('بصمة') or بصمة_الحدث(x)
        if x['بصمة'] in seen: continue
        seen.add(x['بصمة']); out.append(x)
    return out


def ربط_الأحداث_بالتاريخ(بيانات_يومية: pd.DataFrame, أحداث, هامش_أيام=3):
    """يربط الحدث بتاريخ التداول دون تسريب المستقبل: الحدث لا يظهر قبل تاريخ نشره."""
    if بيانات_يومية is None or len(بيانات_يومية)==0:
        return pd.DataFrame(), {'الحالة':'لا توجد بيانات سعرية'}
    x=بيانات_يومية.copy()
    x['التاريخ']=_تاريخ_فقط(x['التاريخ'])
    if 'الرمز' not in x.columns: x['الرمز']=None
    x['الرمز']=x['الرمز'].astype('string')
    أحداث_موحدة=توحيد_الأحداث(أحداث)
    rows=[]
    for e in أحداث_موحدة:
        d=_تاريخ_فقط(e.get('تاريخ_النشر'))
        if pd.isna(d): continue
        الرمز=e.get('الرمز')
        candidates=x[x['التاريخ']>=d].copy()
        if الرمز: candidates=candidates[candidates['الرمز'].isna() | (candidates['الرمز']==الرمز)]
        if candidates.empty: continue
        candidates['فرق_الأيام']=(candidates['التاريخ']-d).dt.days
        candidates=candidates[candidates['فرق_الأيام']<=هامش_أيام]
        if candidates.empty: continue
        r=candidates.sort_values(['فرق_الأيام','التاريخ']).iloc[0]
        row=dict(e); row.update({'تاريخ_التداول_المرتبط':r['التاريخ'].date().isoformat(),'فرق_الأيام':int(r['فرق_الأيام'])})
        rows.append(row)
    linked=pd.DataFrame(rows)
    return linked, {'الحالة':'تم الربط','عدد_الأحداث':len(أحداث_موحدة),'عدد_الأحداث_المرتبطة':len(linked),'منع_التسريب':True}


def دمج_ملخص_فني(تحليل_فني: dict, الأحداث_المرتبطة: pd.DataFrame):
    """ينشئ بطاقة أدلة عربية واحدة؛ لا يحول الدرجة إلى احتمال."""
    out=dict(تحليل_فني or {})
    if الأحداث_المرتبطة is None or len(الأحداث_المرتبطة)==0:
        out.update({'الأحداث_المؤثرة':0,'أعلى_درجة_أثر':0,'حالة_الأخبار':'لا توجد أحداث مرتبطة'})
        return out
    أعلى=int(pd.to_numeric(الأحداث_المرتبطة['درجة_الأثر_الرقمية'],errors='coerce').fillna(0).max())
    out.update({'الأحداث_المؤثرة':int(len(الأحداث_المرتبطة)),'أعلى_درجة_أثر':أعلى,'حالة_الأخبار':'يوجد حدث/أحداث تحتاج قراءة المحتوى قبل القرار'})
    if أعلى>=3: out['تنبيه_خبري']='حدث مرتفع الأثر مرتبط زمنياً؛ لا يصدر قرار آلي من العنوان وحده.'
    return out


def حفظ_سجل(بيانات, مسار='تشغيل-كوانتوم-فيكتوري/سجل_الأدلة_الموحد.json'):
    p=Path(مسار); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(بيانات,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    return p
