from __future__ import annotations
import hashlib, json
import numpy as np
import pandas as pd

VERSION='2.9.0'

REQUIRED={'decision_date','symbol','scenario_score'}

def build_shadow_ledger(df: pd.DataFrame, score_col='scenario_score', threshold=0.0):
    if df is None or not REQUIRED.issubset(df.columns):
        return pd.DataFrame(), {'status':'BLOCKED_MISSING_DECISION_FIELDS','rows':0}
    x=df.copy()
    x['decision_date']=pd.to_datetime(x['decision_date'],errors='coerce')
    x['scenario_score']=pd.to_numeric(x[score_col],errors='coerce')
    x=x.dropna(subset=['decision_date','scenario_score','symbol']).copy()
    x=x.sort_values(['decision_date','symbol'],kind='mergesort')
    x['shadow_action']=np.where(x['scenario_score']>threshold,'LONG_BIAS',np.where(x['scenario_score']< -threshold,'BEARISH_BIAS','WAIT'))
    x['shadow_only']=True
    # Outcome columns are deliberately copied only as evaluation fields, never used to create action.
    # Keeping the observed outcome in the ledger allows a genuine post-hoc shadow audit;
    # it is never an input to shadow_action.
    cols=['decision_date','symbol','scenario_score','shadow_action','shadow_only']
    if 'outcome_binary' in x.columns:
        y=pd.to_numeric(x['outcome_binary'],errors='coerce')
        x['outcome_binary']=y.where(y.isin([0,1]))
        cols.append('outcome_binary')
    return x[cols].reset_index(drop=True), {'status':'PASS','rows':int(len(x)),'outcome_embedded_for_evaluation':'outcome_binary' in x.columns}

def shadow_evaluation(ledger: pd.DataFrame, outcome_col='outcome_binary'):
    if ledger is None or ledger.empty:
        return {'status':'BLOCKED_NO_SHADOW_ROWS','n':0}
    if outcome_col not in ledger.columns:
        return {'status':'OBSERVATION_ONLY','n':int(len(ledger)),'outcome_available':False}
    y=pd.to_numeric(ledger[outcome_col],errors='coerce')
    valid=y.notna();
    if not valid.any(): return {'status':'OBSERVATION_ONLY','n':int(len(ledger)),'outcome_available':False}
    a=ledger.loc[valid,'shadow_action']; yy=y[valid]
    actionable=a!='WAIT'
    if actionable.sum()==0: return {'status':'OBSERVATION_ONLY','n':int(valid.sum()),'actionable_n':0,'outcome_available':True}
    pred=(a[actionable]=='LONG_BIAS').astype(int)
    acc=float((pred.to_numpy()==yy[actionable].to_numpy()).mean())
    return {'status':'PASS','n':int(valid.sum()),'actionable_n':int(actionable.sum()),'directional_accuracy':acc,'outcome_available':True}

def drift_check(current, reference, score_col='scenario_score', max_abs_mean_shift=0.25):
    a=pd.to_numeric(pd.Series(current.get(score_col,[])),errors='coerce').dropna()
    b=pd.to_numeric(pd.Series(reference.get(score_col,[])),errors='coerce').dropna()
    if len(a)==0 or len(b)==0: return {'status':'BLOCKED_INSUFFICIENT_REFERENCE','current_n':len(a),'reference_n':len(b)}
    shift=float(a.mean()-b.mean())
    return {'status':'PASS' if abs(shift)<=max_abs_mean_shift else 'BLOCKED_DRIFT','current_mean':float(a.mean()),'reference_mean':float(b.mean()),'mean_shift':shift,'limit':max_abs_mean_shift}

def shadow_certificate(ledger_status,evaluation,drift):
    payload={'version':VERSION,'ledger':ledger_status,'evaluation':evaluation,'drift':drift,'shadow_only':True,'production_approval_not_granted':True}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
