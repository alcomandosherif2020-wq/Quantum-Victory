from __future__ import annotations
import math
import numpy as np
VERSION='5.4.0'

def psi(reference, current, bins=10, epsilon=1e-9):
    a=np.asarray(reference,dtype=float); b=np.asarray(current,dtype=float)
    if len(a)<20 or len(b)<20: return {'status':'BLOCKED','reason':'insufficient_samples'}
    edges=np.quantile(a,np.linspace(0,1,bins+1)); edges=np.unique(edges)
    if len(edges)<3: return {'status':'PASS','psi':0.0,'note':'constant_reference'}
    pa,_=np.histogram(a,bins=edges); pb,_=np.histogram(b,bins=edges)
    pa=(pa+epsilon)/(pa.sum()+epsilon*len(pa)); pb=(pb+epsilon)/(pb.sum()+epsilon*len(pb))
    value=float(np.sum((pb-pa)*np.log(pb/pa)))
    return {'status':'PASS','psi':value,'thresholds':{'watch':0.10,'block':0.25},'state':'BLOCK' if value>=.25 else ('WATCH' if value>=.10 else 'STABLE')}

def distribution_summary(x):
    a=np.asarray(x,dtype=float)
    if len(a)==0: return {'status':'BLOCKED'}
    return {'status':'PASS','n':int(len(a)),'mean':float(np.mean(a)),'std':float(np.std(a,ddof=1)) if len(a)>1 else 0.0,
            'q05':float(np.quantile(a,.05)),'q50':float(np.quantile(a,.5)),'q95':float(np.quantile(a,.95))}
