from __future__ import annotations
import numpy as np
import pandas as pd

BUY_SCENARIOS={'BULLISH_INSTITUTIONAL_ACCUMULATION_OR_CONTINUATION','EARLY_BULLISH_ACCUMULATION'}
SELL_SCENARIOS={'BEARISH_DISTRIBUTION_EXIT_PRESSURE','LIQUIDITY_TRAP_OR_DISTRIBUTION_RISK'}

def build_final_recommendation(df: pd.DataFrame) -> pd.DataFrame:
    x=df.copy()
    rows=[]
    for _,r in x.iterrows():
        sc=str(r.get('primary_scenario','UNCERTAIN_MIXED_FLOW'))
        score=float(pd.to_numeric(pd.Series([r.get('scenario_score',0)]),errors='coerce').fillna(0).iloc[0])
        conf=float(pd.to_numeric(pd.Series([r.get('confirmation_score',0)]),errors='coerce').fillna(0).iloc[0])
        unc=float(pd.to_numeric(pd.Series([r.get('uncertainty_score',100)]),errors='coerce').fillna(100).iloc[0])
        trap=float(pd.to_numeric(pd.Series([r.get('trap_penalty',0)]),errors='coerce').fillna(0).iloc[0])
        blocked=trap>=70 or 'LIQUIDITY_TRAP_RISK_HIGH' in str(r.get('warnings',''))
        if blocked:
            posture='BLOCKED_HIGH_TRAP_RISK'; action='NO_ACTION'
        elif sc in BUY_SCENARIOS and score>=55 and conf>=45 and unc<65:
            posture='BULLISH_EVIDENCE'; action='CONSIDER_LONG_BIAS_AFTER_INDEPENDENT_RISK_CHECK'
        elif sc in SELL_SCENARIOS and score>=55 and conf>=45 and unc<65:
            posture='BEARISH_EVIDENCE'; action='CONSIDER_EXIT_OR_AVOIDANCE_BIAS_AFTER_INDEPENDENT_RISK_CHECK'
        elif sc=='NEUTRAL_MIXED_FLOW':
            posture='NEUTRAL_EVIDENCE'; action='WAIT_FOR_CONFIRMATION'
        else:
            posture='UNCONFIRMED'; action='WAIT_FOR_CONFIRMATION'
        rows.append({
            'recommendation_posture':posture,'action_evidence':action,
            'risk_level':'HIGH' if blocked or unc>=75 else ('MEDIUM' if unc>=60 or trap>=50 else 'NORMAL'),
            'recommendation_confidence_state':'CONFIRMED_EVIDENCE' if score>=70 and conf>=60 and unc<50 and not blocked else 'UNCONFIRMED',
            'probability':None,'calibration_status':'NOT_CALIBRATED','production_approved':False,
            'recommendation_role':'EVIDENCE_ONLY','fixed_price_target':None,
            'human_risk_check_required':True,'identity_claim':False
        })
    return pd.concat([x.reset_index(drop=True),pd.DataFrame(rows)],axis=1)
