from __future__ import annotations
import os,time,json
from pathlib import Path
import pandas as pd
from .live_feed_adapters import ProviderConfig,http_poll,adapt_provider_records
from .v42_pipeline import run as run_v42
from .secure_telegram_gateway import SecureTelegramGateway

class AutonomousQVService:
    """Provider-neutral autonomous loop: EGX feed -> QV v4.2 -> Telegram.
    Credentials/configuration stay outside source code. It does not require ChatGPT.
    """
    def __init__(self, provider_url, provider_name='EGX_PROVIDER', interval=2.0, out_dir='QV-AUTONOMOUS-RUN', recommendation_csv=None, headers=None):
        self.config=ProviderConfig(provider_name,provider_url,headers=headers or {},timeout=float(os.getenv('QV_FEED_TIMEOUT','8')))
        self.interval=max(.2,float(interval)); self.out=Path(out_dir); self.out.mkdir(parents=True,exist_ok=True)
        self.recommendation_csv=recommendation_csv; self.telegram=SecureTelegramGateway(state_dir=self.out/'telegram_state'); self.seen=set()
    def _recommendations(self):
        if self.recommendation_csv and Path(self.recommendation_csv).exists(): return pd.read_csv(self.recommendation_csv)
        return None
    def process_batch(self, records):
        df=adapt_provider_records(records,self.config.name)
        if df.empty: return {'status':'NO_DATA','alerts':0}
        cert,integrated,alerts=run_v42(df,recommendation_df=self._recommendations(),out_dir=self.out/'engine',top_n=50)
        sent=0
        for _,a in alerts.iterrows():
            if not bool(cert.get('production_approved', False)):
                continue
            aid=str(a.alert_id)
            if aid in self.seen: continue
            result=self.telegram.send(str(a.message), alert_id=aid)
            if result.get('sent'): self.seen.add(aid); sent+=1
        state={'timestamp':pd.Timestamp.utcnow().isoformat(),'provider':self.config.name,'rows':len(df),'alerts':len(alerts),'telegram_sent':sent,'telegram_configured':self.telegram.configured,'production_approved':False}
        with (self.out/'service_events.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(state,ensure_ascii=False)+'\n')
        return state
    def run(self,duration=None):
        started=time.monotonic(); cycles=0
        while duration is None or time.monotonic()-started<duration:
            records=http_poll(self.config); self.process_batch(records); cycles+=1; time.sleep(self.interval)
        return {'status':'STOPPED','cycles':cycles,'telegram_configured':self.telegram.configured,'production_approved':False}
