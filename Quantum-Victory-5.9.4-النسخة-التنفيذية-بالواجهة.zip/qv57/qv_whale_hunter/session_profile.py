from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

ENGINE='QV-SESSION-PROFILE'; VERSION='1.0.0'


def _prepare(df: pd.DataFrame, session_start='10:00') -> pd.DataFrame:
    x=df.copy()
    x['timestamp']=pd.to_datetime(x['timestamp'], errors='coerce')
    x['volume']=pd.to_numeric(x['volume'], errors='coerce')
    if 'price' in x: x['price']=pd.to_numeric(x['price'], errors='coerce')
    if 'turnover' in x: x['turnover']=pd.to_numeric(x['turnover'], errors='coerce')
    x=x.dropna(subset=['symbol','timestamp','volume']).copy()
    start_h,start_m=map(int,session_start.split(':'))
    x['session_date']=x['timestamp'].dt.date
    mins=(x['timestamp'].dt.hour*60+x['timestamp'].dt.minute)-(start_h*60+start_m)
    x['session_minute']=mins.astype(int)
    return x[x.session_minute>=0].sort_values(['symbol','session_date','session_minute','timestamp'])


def build_profile(df: pd.DataFrame, session_start='10:00', min_history_sessions=3) -> pd.DataFrame:
    """Build same-minute historical baselines using prior completed sessions only.
    If multiple observations share a minute, aggregate first. The resulting row at
    session D/minute m contains only sessions < D when used via apply_profile()."""
    x=_prepare(df,session_start)
    if x.empty: return pd.DataFrame()
    x['volume_per_min']=x['volume']
    if 'turnover' in x: x['turnover_per_min']=x['turnover']
    minute=x.groupby(['symbol','session_date','session_minute'],as_index=False).agg(
        volume_per_min=('volume_per_min','sum'),
        turnover_per_min=('turnover_per_min','sum') if 'turnover_per_min' in x else ('volume_per_min','sum'))
    # expanding history excludes the current session by shifting after date grouping
    minute=minute.sort_values(['symbol','session_minute','session_date'])
    g=minute.groupby(['symbol','session_minute'],group_keys=False)
    for col in ['volume_per_min','turnover_per_min']:
        minute[f'baseline_{col}']=g[col].transform(lambda s:s.shift(1).expanding(min_periods=min_history_sessions).median())
        minute[f'p25_{col}']=g[col].transform(lambda s:s.shift(1).expanding(min_periods=min_history_sessions).quantile(.25))
        minute[f'p75_{col}']=g[col].transform(lambda s:s.shift(1).expanding(min_periods=min_history_sessions).quantile(.75))
    return minute


def apply_profile(intraday: pd.DataFrame, profile: pd.DataFrame, session_start='10:00') -> pd.DataFrame:
    x=_prepare(intraday,session_start)
    if x.empty: return x
    if profile is None or profile.empty:
        x['session_baseline_volume']=np.nan; x['session_rvol']=np.nan; x['session_baseline_available']=False
        return x
    p=profile[['symbol','session_date','session_minute','volume_per_min','baseline_volume_per_min','p25_volume_per_min','p75_volume_per_min']].copy()
    p['session_date']=pd.to_datetime(p['session_date']).dt.date
    # As-of join: for every live row, choose the newest profile date strictly before
    # the row's session date. This also works when the live date is not present in
    # the historical profile (the common real-time case).
    p=p.dropna(subset=['symbol','session_date']).sort_values(['symbol','session_minute','session_date'])
    out=[]
    for (sym, minute), g in x.groupby(['symbol','session_minute'], sort=False):
        pg=p[(p.symbol.astype(str)==str(sym)) & (p.session_minute==minute)].sort_values('session_date')
        if pg.empty:
            z=g.copy(); z['baseline_volume_per_min']=np.nan; z['p25_volume_per_min']=np.nan; z['p75_volume_per_min']=np.nan
        else:
            dates=pg['session_date'].tolist(); rows=[]
            for _,r in g.iterrows():
                prior=[i for i,d in enumerate(dates) if d < r.session_date]
                if prior:
                    
                    chosen=pg.iloc[prior[-1]].copy()
                    if pd.isna(chosen.get('baseline_volume_per_min')):
                        histv=pd.to_numeric(pg.iloc[prior[-min(len(prior),20):]]['volume_per_min'], errors='coerce')
                        chosen['baseline_volume_per_min']=histv.median() if len(histv.dropna()) else np.nan
                    rows.append(chosen)
                else:
                    rows.append(pd.Series({'baseline_volume_per_min':np.nan,'p25_volume_per_min':np.nan,'p75_volume_per_min':np.nan}))
            q=pd.DataFrame(rows).reset_index(drop=True)
            z=g.reset_index(drop=True).copy()
            for c in ['volume_per_min','baseline_volume_per_min','p25_volume_per_min','p75_volume_per_min']:
                z[c]=q[c].to_numpy() if c in q else np.nan
        out.append(z)
    x=pd.concat(out,ignore_index=True)
    x['session_baseline_volume']=pd.to_numeric(x['baseline_volume_per_min'],errors='coerce')
    x['session_rvol']=x['volume']/x['session_baseline_volume'].replace(0,np.nan)
    x['session_baseline_available']=x['session_baseline_volume'].notna()
    x['session_baseline_source']='PRIOR_COMPLETED_SESSIONS_ONLY'
    return x


def save_profile(profile: pd.DataFrame, out_dir='QV-SESSION-PROFILE-RUN'):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    profile.to_csv(out/'QV-SESSION-VOLUME-PROFILE.csv',index=False)
    meta={'engine':ENGINE,'version':VERSION,'rows':len(profile),'production_approved':False,
          'leakage_control':'current session excluded via shift(1); only prior completed sessions contribute'}
    (out/'QV-SESSION-PROFILE-MANIFEST.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    return meta
