# -*- coding: utf-8 -*-
"""كوانتوم فيكتوري 4.20 — بوابة الجاهزية التشغيلية.
تفصل بين اكتمال دورة التشغيل وبين صلاحية إطلاق تنبيه.
لا تمنح اعتماداً إنتاجياً ولا تخترع دليلاً مفقوداً.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
import hashlib, json
from pathlib import Path

@dataclass
class نتيجة_الجاهزية:
    جاهز_للمعالجة: bool
    جاهز_للتنبيه: bool
    الحالة: str
    الأسباب: list[str]
    الأدلة: dict
    وقت_الفحص: str

class بوابة_الجاهزية_التشغيلية:
    """بوابة حتمية: أي دليل إلزامي مفقود/متقادم/متعارض يمنع التنبيه."""
    الأدلة_الإلزامية = (
        "سلامة_البيانات",
        "حداثة_البيانات",
        "عدم_التعارض",
        "اكتمال_التحليل",
        "سلامة_سجل_الأدلة",
    )

    def __init__(self, state_path="حالة_الجاهزية_التشغيلية.json"):
        self.state_path = Path(state_path)
        self.آخر_نتيجة = None

    def فحص(self, أدلة: dict, السماح_بالإنتاج: bool = False) -> نتيجة_الجاهزية:
        أسباب=[]
        normalized=dict(أدلة or {})
        for key in self.الأدلة_الإلزامية:
            if normalized.get(key) is not True:
                أسباب.append(f"الدليل الإلزامي غير مجتاز: {key}")
        if normalized.get("حالة_المصدر") in {"فشل", "قاطع_دائرة", "غير موصول", "متقادم"}:
            أسباب.append(f"حالة المصدر غير صالحة: {normalized.get('حالة_المصدر')}")
        if normalized.get("تعارض_مصادر") is True:
            أسباب.append("تعارض بين المصادر")
        if normalized.get("بيانات_وهمية") is True:
            أسباب.append("تم رصد وسم بيانات وهمية")
        جاهز_للمعالجة = all(normalized.get(k) is True for k in self.الأدلة_الإلزامية[:2]) and not normalized.get("بيانات_وهمية", False)
        # حتى لو اكتملت المعالجة، التنبيه يتطلب كل الأدلة + فتح بوابة الإنتاج العلمية.
        جاهز_للتنبيه = (not أسباب) and bool(السماح_بالإنتاج)
        الحالة = "جاهز_للتنبيه" if جاهز_للتنبيه else ("جاهز_للمعالجة" if جاهز_للمعالجة else "محجوب")
        النتيجة=نتيجة_الجاهزية(جاهز_للمعالجة, جاهز_للتنبيه, الحالة, أسباب, normalized, datetime.now(timezone.utc).isoformat())
        self.آخر_نتيجة=النتيجة
        self._حفظ(النتيجة)
        return النتيجة

    def _حفظ(self, النتيجة):
        payload=asdict(النتيجة)
        raw=json.dumps(payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
        payload["بصمة_النتيجة"]=hashlib.sha256(raw).hexdigest()
        self.state_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
