from __future__ import annotations
import numpy as np
import pandas as pd

TRAP_LABELS={'LIQUIDITY_TRAP','FAILED_BREAKOUT','DISTRIBUTION_RISK','WEAK_FOLLOW_THROUGH','MARKET_DRIVEN','NOISE'}

def apply_false_whale_defense(df: pd.DataFrame) -> pd.DataFrame:
    x=df.copy()
    def col(c, default=0.0):
        return pd.to_numeric(x[c],errors='coerce').fillna(default) if c in x else pd.Series(default,index=x.index,dtype=float)
    intensity=col('flow_intensity')
    confirm=col('confirmation_score')
    uncertainty=col('uncertainty_score')
    radar=col('whale_radar_score')
    buy=col('buy_event_count')
    sell=col('sell_event_count')
    close_loc=col('close_loc',0.5)
    follow=col('forward_follow_through',np.nan)
    market_rel=col('relative_flow_to_market',np.nan)
    sector_rel=col('relative_flow_to_sector',np.nan)
    breakout=col('breakout_volume',0)
    failed=col('failed_breakout',0)
    # Current/prior evidence only. Optional outcome-like columns are accepted only as research diagnostics,
    # never as inputs to the defense decision when they are explicitly marked future.
    trap_score=np.zeros(len(x),dtype=float)
    trap_score += np.where((failed>0),35,0)
    trap_score += np.where((breakout>0)&(close_loc<0.45),20,0)
    trap_score += np.where((intensity>60)&(confirm<35),20,0)
    trap_score += np.where((intensity>60)&(uncertainty>60),15,0)
    trap_score += np.where((sell>buy)&(radar>50),20,0)
    trap_score += np.where((market_rel.notna())&(market_rel< -20),10,0)
    trap_score += np.where((sector_rel.notna())&(sector_rel< -20),10,0)
    trap_score=np.clip(trap_score,0,100)
    label=np.where(trap_score>=70,'LIQUIDITY_TRAP',
           np.where(trap_score>=50,'DISTRIBUTION_RISK',
           np.where((intensity>=60)&(confirm<40),'WEAK_FOLLOW_THROUGH',
           np.where((market_rel.notna())&(market_rel<-35),'MARKET_DRIVEN','CLEAN_FOOTPRINT'))))
    defense_score=np.clip(radar - 0.55*trap_score + 0.20*confirm - 0.15*uncertainty, -100,100)
    x['false_whale_trap_score']=trap_score.round(4)
    x['false_whale_label']=label
    x['defended_radar_score']=defense_score.round(4)
    x['defense_action']=np.where(trap_score>=70,'BLOCK',np.where(trap_score>=50,'DOWNGRADE','PASS'))
    return x
