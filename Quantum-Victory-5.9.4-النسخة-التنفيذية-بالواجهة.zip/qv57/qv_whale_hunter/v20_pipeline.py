from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v19_pipeline import run as run_v19
from .scenario_fusion import fuse_scenarios, prior_reliability

VERSION='2.0.0'

def _drop_future(df):
    cols=[]
    for c in df.columns:
        lc=c.lower()
        if lc.startswith(('fwd_','forward_','mfe_','mae_','outcome_','label_')): cols.append(c)
        if c in {'forward_follow_through'}: cols.append(c)
    return df.drop(columns=sorted(set(cols)),errors='ignore'), sorted(set(cols))

def run(df, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    run_v19(df,out,**kwargs)
    defended=pd.read_csv(out/'QV-WHALE-V18-DEFENSE-001.csv')
    stock=pd.read_csv(out/'QV-WHALE-V19-STOCK-RADAR-001.csv')
    base=defended.merge(stock[['symbol','date','radar_rank','attention_flag']],left_on=['symbol','session_date'],right_on=['symbol','date'],how='left').drop(columns=['date'],errors='ignore')
    decision, excluded=_drop_future(base)
    memory=pd.read_csv(out/'QV-WHALE-V14-MEMORY-001.csv') if (out/'QV-WHALE-V14-MEMORY-001.csv').exists() else pd.DataFrame()
    rel=prior_reliability(memory,decision,min_samples=30)
    fused=fuse_scenarios(decision,rel)
    fused.to_csv(out/'QV-WHALE-V20-SCENARIO-FUSION-001.csv',index=False)
    market=pd.read_csv(out/'QV-WHALE-V19-MARKET-RADAR-001.csv')
    market.to_csv(out/'QV-WHALE-V20-MARKET-CONTEXT-001.csv',index=False)
    report={
      'engine':'QV-WHALE-HUNTER-SCENARIO-FUSION','version':VERSION,'status':'PASS','production_approved':False,
      'rows_fused':len(fused),'market_sessions':len(market),'future_fields_excluded':excluded,'future_outcomes_used':False,
      'probability_output':None,'calibration_status':'NOT_CALIBRATED','identity_claim':False,
      'principle':'Scenario score is evidence strength, not probability. Whale footprint is evidence only and never a standalone recommendation.',
      'scenario_components':['observable liquidity footprint','technical evidence','market context','sector context','lifecycle','false-whale defense','prior-only historical reliability','uncertainty'],
      'required_gates':['REAL_EGX_DATA_QUALIFICATION','OOS_VALIDATION','WALK_FORWARD','SAMPLE_SIZE','REGIME_STABILITY','OOS_CALIBRATION','CHAMPION_CHALLENGER','SHADOW','FINAL_PRODUCTION_GATE']
    }
    (out/'QV-WHALE-V20-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-WHALE-V20-SCENARIO-CONTRACT-001.json').write_text(json.dumps({
      'version':VERSION,'probability':None,'calibration_status':'NOT_CALIBRATED','no_fixed_price_prediction':True,
      'decision_rule':'Evidence fusion only; no score-to-probability conversion.','identity_claim':False,
      'invalidation_required':True,'warnings_required':True,'recommendation_role':'EVIDENCE_ONLY'
    },ensure_ascii=False,indent=2),encoding='utf-8')
    return report
