from __future__ import annotations
import numpy as np
import pandas as pd

def build_radar(scores, sequences=None):
    r=scores.copy()
    if sequences is not None:
        r=r.merge(sequences,on=["symbol","session_date"],how="left")
    for c in ["institutional_flow_score","confirmation_score"]:
        if c not in r: r[c]=0.0
    r["radar_score"]=0.60*r.institutional_flow_score.fillna(0)+0.25*r.confirmation_score.fillna(0)-0.15*r.get("uncertainty_score",0).fillna(0)
    r["radar_rank"]=r.groupby("session_date")["radar_score"].rank(method="min",ascending=False)
    return r.sort_values(["session_date","radar_rank","symbol"])
