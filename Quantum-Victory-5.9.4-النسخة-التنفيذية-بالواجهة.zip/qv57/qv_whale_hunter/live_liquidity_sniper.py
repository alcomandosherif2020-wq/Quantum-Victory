from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

ENGINE='QV-LIVE-LIQUIDITY-SNIPER'; VERSION='1.1.0'

REQUIRED=['symbol','timestamp','price','volume']

def _z(s,w=20):
    m=s.rolling(w,min_periods=max(5,w//2)).mean(); sd=s.rolling(w,min_periods=max(5,w//2)).std(ddof=0)
    return (s-m)/sd.replace(0,np.nan)

def scan(df: pd.DataFrame, daily_baseline: pd.DataFrame|None=None, session_profile: pd.DataFrame|None=None,
         lookback=20, burst_window_minutes=5, min_rvol=2.0,
         min_acceleration=1.5, min_buy_pressure=0.65):
    """Intraday evidence scanner. No identity/price-target/probability claims."""
    missing=[c for c in REQUIRED if c not in df.columns]
    if missing: raise ValueError(f'missing columns: {missing}')
    x=df.copy(); x['timestamp']=pd.to_datetime(x['timestamp'],errors='coerce'); x['price']=pd.to_numeric(x['price'],errors='coerce'); x['volume']=pd.to_numeric(x['volume'],errors='coerce')
    x=x.dropna(subset=REQUIRED).sort_values(['symbol','timestamp']).reset_index(drop=True)
    if x.empty: return pd.DataFrame()
    g=x.groupby('symbol',group_keys=False)
    x['dv']=x.price*x.volume
    x['intervals_elapsed']=g['timestamp'].diff().dt.total_seconds().div(60).fillna(1).clip(lower=1)
    x['vol_per_min']=x.volume/x.intervals_elapsed
    x['baseline_vol_per_min']=g['vol_per_min'].transform(lambda s:s.rolling(lookback,min_periods=5).median())
    if daily_baseline is not None and not daily_baseline.empty:
        b=daily_baseline.copy(); b['avg_daily_volume']=pd.to_numeric(b['avg_daily_volume'],errors='coerce')
        x=x.merge(b[['symbol','avg_daily_volume']].drop_duplicates('symbol'),on='symbol',how='left')
        # compare projected current pace to normal daily volume, using elapsed session minutes when supplied
        session_minutes=x.get('session_minutes_elapsed',pd.Series(1,index=x.index)).astype(float).clip(lower=1)
        x['pace_vs_daily']=x['vol_per_min']*session_minutes/x['avg_daily_volume'].replace(0,np.nan)
    else:
        x['avg_daily_volume']=np.nan; x['pace_vs_daily']=np.nan
    x['rvol_local']=x['vol_per_min']/x['baseline_vol_per_min'].replace(0,np.nan)
    x['vol_z']=g['vol_per_min'].transform(lambda s:_z(s,lookback))
    if session_profile is not None and not session_profile.empty:
        from .session_profile import apply_profile
        prof=apply_profile(x[['symbol','timestamp','volume','price']].copy(), session_profile)
        x['session_baseline_volume']=prof['session_baseline_volume'].to_numpy()
        x['session_rvol']=prof['session_rvol'].to_numpy()
        x['session_baseline_available']=prof['session_baseline_available'].to_numpy()
    else:
        x['session_baseline_volume']=np.nan; x['session_rvol']=np.nan; x['session_baseline_available']=False
    x['price_ret']=g['price'].pct_change().fillna(0)
    x['buy_volume']=np.where(x.price_ret>0,x.volume,np.where(x.price_ret<0,0,x.volume*.5))
    x['sell_volume']=np.where(x.price_ret<0,x.volume,np.where(x.price_ret>0,0,x.volume*.5))
    x['buy_pressure']=x['buy_volume']/(x['buy_volume']+x['sell_volume']).replace(0,np.nan)
    x['buy_pressure_accel']=g['buy_pressure'].transform(lambda s:s.ewm(span=5,adjust=False).mean()).groupby(x.symbol).diff().fillna(0)
    x['volume_accel']=g['vol_per_min'].transform(lambda s:s.ewm(span=3,adjust=False).mean()).groupby(x.symbol).pct_change().replace([np.inf,-np.inf],np.nan).fillna(0)
    x['burst_volume']=g['volume'].transform(lambda s:s.rolling(5,min_periods=1).sum())
    x['burst_rvol']=x['burst_volume']/g['burst_volume'].transform(lambda s:s.rolling(lookback,min_periods=5).median()).replace(0,np.nan)
    # Optional microstructure: order-book imbalance and trade intensity. Missing fields remain neutral.
    bid_size=pd.to_numeric(x['bid_size'],errors='coerce') if 'bid_size' in x.columns else pd.Series(np.nan,index=x.index)
    ask_size=pd.to_numeric(x['ask_size'],errors='coerce') if 'ask_size' in x.columns else pd.Series(np.nan,index=x.index)
    denom=(bid_size+ask_size).replace(0,np.nan)
    x['book_imbalance']=((bid_size-ask_size)/denom).clip(-1,1)
    if 'trade_count' in x.columns:
        x['trade_count']=pd.to_numeric(x['trade_count'],errors='coerce')
    else:
        x['trade_count']=1.0
    x['trade_count_per_min']=x['trade_count']/x['intervals_elapsed']
    x['trade_intensity_rv']=x['trade_count_per_min']/g['trade_count_per_min'].transform(lambda s:s.rolling(lookback,min_periods=5).median()).replace(0,np.nan)
    x['turnover']=pd.to_numeric(x.get('turnover',x['dv']),errors='coerce')
    x['turnover_per_min']=x['turnover']/x['intervals_elapsed']
    x['turnover_rv']=x['turnover_per_min']/g['turnover_per_min'].transform(lambda s:s.rolling(lookback,min_periods=5).median()).replace(0,np.nan)
    session_signal=x['session_rvol'].fillna(x['rvol_local'])
    x['unusual']=((session_signal>=min_rvol)|(x.rvol_local>=min_rvol)|(x.vol_z>=2)) & (x.volume_accel>=min_acceleration-1)
    x['buying_burst']=(x.unusual & (x.buy_pressure>=min_buy_pressure) & (x.buy_pressure_accel>0))
    book_component=np.clip((x['book_imbalance'].fillna(0)+1)/2,0,1)
    trade_component=np.clip((x['trade_intensity_rv'].fillna(1)-1)/2,0,1)
    x['sniper_score']=(28*np.clip((session_signal-1)/3,0,1)+22*np.clip(x.volume_accel/1.5,0,1)+23*np.clip((x.buy_pressure-.5)/.5,0,1)+12*np.clip((x.burst_rvol-1)/3,0,1)+10*book_component+5*trade_component).clip(0,100)
    x['signal']=np.select([x.buying_burst & (x.sniper_score>=70),x.buying_burst & (x.sniper_score>=55),x.unusual],['HIGH_PRIORITY_BUY_FLOW','BUY_FLOW_WATCH','UNUSUAL_LIQUIDITY'],default='NO_ALERT')
    x['evidence_only']=True; x['identity_claim']=False; x['probability']=np.nan; x['fixed_price_target']=np.nan
    return x

def latest_alerts(df:pd.DataFrame)->pd.DataFrame:
    if df.empty:return df
    return df[df.signal!='NO_ALERT'].sort_values(['timestamp','sniper_score'],ascending=[False,False]).groupby('symbol',as_index=False).head(1).sort_values('sniper_score',ascending=False)

def run(df:pd.DataFrame,out_dir='QV-LIVE-SNIPER-RUN',daily_baseline=None,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    r=scan(df,daily_baseline=daily_baseline,**kwargs)
    alerts=latest_alerts(r)
    r.to_csv(out/'QV-LIVE-LIQUIDITY-SCORES.csv',index=False); alerts.to_csv(out/'QV-LIVE-LIQUIDITY-ALERTS.csv',index=False)
    report={'engine':ENGINE,'version':VERSION,'status':'PASS','rows_scored':len(r),'symbols_scored':int(r.symbol.nunique()) if not r.empty else 0,'alerts':int(len(alerts)),'high_priority':int((alerts.signal=='HIGH_PRIORITY_BUY_FLOW').sum()) if not alerts.empty else 0,'evidence_only':True,'identity_claim':False,'probability_output':None,'fixed_price_target':None,'production_approved':False,'purpose':'intraday abnormal liquidity and accelerating buy-flow detection'}
    (out/'QV-LIVE-LIQUIDITY-REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report,r,alerts
