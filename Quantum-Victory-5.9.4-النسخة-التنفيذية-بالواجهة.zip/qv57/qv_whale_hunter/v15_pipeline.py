from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v14_pipeline import run as run_v14
from .calibration import empirical_oos_calibration
from .production_gate import final_production_gate

VERSION='1.5.0'

def run(df, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    report14=run_v14(df,out,**kwargs)
    # Calibration is intentionally blocked unless the caller supplies enough real OOS labels.
    # The current pipeline never converts evidence score into probability.
    cal={'status':'BLOCKED_NO_VALIDATED_REAL_EGX_OOS_LABELS','n':0,'min_samples':100,'score_is_not_probability':True}
    gate=final_production_gate(real_egx=False,leakage_clean=False,oos_pass=False,walk_forward_pass=False,sample_pass=False,regime_pass=False,calibration_pass=False,champion_pass=False,shadow_pass=False)
    report={'engine':'QV-WHALE-HUNTER-QUANTUM-INSTITUTIONAL-INTELLIGENCE','version':VERSION,'status':'PASS','production_approved':False,'upstream_v14':report14,'calibration':cal,'production_gate':gate,'principle':'Whale Hunter detects statistically consistent large-liquidity footprints; it does not identify the actor or guarantee a trade outcome.','recommendation_role':'EVIDENCE_TO_SCENARIO_BRIDGE'}
    (out/'QV-WHALE-V15-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
