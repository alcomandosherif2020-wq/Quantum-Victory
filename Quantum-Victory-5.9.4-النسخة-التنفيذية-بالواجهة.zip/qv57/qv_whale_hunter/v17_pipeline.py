from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v16_pipeline import run as run_v16
from .lifecycle import build_lifecycle, summarize_lifecycles

VERSION='1.7.0'

def run(df, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    run_v16(df,out,**kwargs)
    size=pd.read_csv(out/'QV-WHALE-V16-SIZE-CLASSIFICATION-001.csv')
    radar=pd.read_csv(out/'QV-WHALE-V16-MULTISIZE-RADAR-001.csv')
    seq=pd.read_csv(out/'QV-WHALE-V14-SEQUENCES-001.csv')
    base=size.merge(radar[['symbol','session_date','whale_radar_score','radar_direction']],on=['symbol','session_date'],how='left')
    base=base.merge(seq[['symbol','session_date','sequence_state','buy_event_count','sell_event_count']],on=['symbol','session_date'],how='left')
    lifecycle=build_lifecycle(base)
    summary=summarize_lifecycles(lifecycle)
    lifecycle.to_csv(out/'QV-WHALE-V17-LIFECYCLE-001.csv',index=False)
    summary.to_csv(out/'QV-WHALE-V17-LIFECYCLE-SUMMARY-001.csv',index=False)
    report={
      'engine':'QV-WHALE-HUNTER-FLOW-LIFECYCLE','version':VERSION,'status':'PASS','production_approved':False,
      'rows_tracked':len(lifecycle),'episodes':int(lifecycle['lifecycle_episode_id'].nunique()) if not lifecycle.empty else 0,
      'phase_changes':int(lifecycle['phase_changed'].sum()) if not lifecycle.empty else 0,
      'size_classes_tracked':sorted(lifecycle['size_class'].dropna().unique().tolist()) if not lifecycle.empty else [],
      'identity_claim':False,
      'principle':'Episode IDs track continuity of observable market behavior; they do not identify an actor.',
      'leakage_rule':'Lifecycle state uses only current and prior observations; no future outcomes or labels are used.',
      'next_gates':['FALSE_WHALE_TRAP_ENGINE','MARKET_SECTOR_FUSION','SCENARIO_FUSION','REAL_EGX_OOS','CALIBRATION','SHADOW','PRODUCTION_GATE']
    }
    (out/'QV-WHALE-V17-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
