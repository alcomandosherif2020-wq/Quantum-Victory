from __future__ import annotations
import pandas as pd
ENGINE='QV-FLOW-OUTCOME-REPLAY'; VERSION='1.0.0'

def attach_future_outcomes(alerts: pd.DataFrame, tape: pd.DataFrame, horizons=(5,10,20,30)) -> pd.DataFrame:
    if alerts is None or alerts.empty or tape is None or tape.empty: return pd.DataFrame()
    a=alerts.copy(); t=tape.copy()
    a['timestamp']=pd.to_datetime(a['timestamp'],errors='coerce'); t['timestamp']=pd.to_datetime(t['timestamp'],errors='coerce')
    t['price']=pd.to_numeric(t['price'],errors='coerce'); t=t.dropna(subset=['symbol','timestamp','price']).sort_values(['symbol','timestamp'])
    out=[]
    for _,r in a.iterrows():
        row=r.to_dict(); sym=r['symbol']; ts=r['timestamp']; px=float(r['price'])
        future=t[(t.symbol==sym)&(t.timestamp>ts)]
        for h in horizons:
            target=ts+pd.Timedelta(minutes=h)
            cand=future[future.timestamp>=target]
            if cand.empty: row[f'return_{h}m']=None; row[f'outcome_{h}m']='PENDING'; continue
            fp=float(cand.iloc[0].price); ret=fp/px-1 if px else None
            row[f'return_{h}m']=ret; row[f'outcome_{h}m']='POSITIVE' if ret is not None and ret>0 else ('NEGATIVE' if ret is not None and ret<0 else 'FLAT')
        out.append(row)
    return pd.DataFrame(out)
