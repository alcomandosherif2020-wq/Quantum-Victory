# -*- coding: utf-8 -*-
"""كوانتوم فيكتوري 4.21 — مراقب الجاهزية الحي.
يوحّد صحة المصادر، عمر البيانات، التعارضات، جاهزية التحليل والتنبيه في حالة واحدة.
لا ينشئ بيانات سوق ولا يفتح بوابة الإنتاج.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import hashlib, json, time

@dataclass
class لقطة_الجاهزية:
    الوقت: str
    حالة_المصادر: dict
    صحة_البيانات: dict
    التعارضات: list
    جاهزية_المعالجة: bool
    جاهزية_التنبيه: bool
    الأسباب_المانعة: list
    الإنتاج_مصرح: bool = False

class مراقب_الجاهزية_الحي:
    def __init__(self, مسار_الحالة="حالة_التحديث_المستمر/حالة_المراقب_الحي.json", حد_السجل=200):
        self.مسار_الحالة = Path(مسار_الحالة)
        self.مسار_الحالة.parent.mkdir(parents=True, exist_ok=True)
        self.حد_السجل = max(10, int(حد_السجل))
        self.السجل = []
        self.آخر_لقطة = None
        self._تحميل()

    @staticmethod
    def _الآن():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _عمر(وقت_البيانات, الآن):
        if وقت_البيانات is None:
            return None
        try:
            if isinstance(وقت_البيانات, (int, float)):
                return max(0.0, الآن - float(وقت_البيانات))
            return max(0.0, الآن - datetime.fromisoformat(str(وقت_البيانات)).timestamp())
        except (TypeError, ValueError, OverflowError):
            return None

    def بناء_اللقطة(self, المصادر, البيانات=None, التعارضات=None, متطلبات_التحليل=None):
        """المصادر: قاموس اسم -> حالة/قاموس. البيانات: اسم -> وقت آخر بيانات.
        متطلبات_التحليل: قاموس اسم -> صحيح/خطأ. لا يُفترض اكتمالها تلقائيًا.
        """
        الآن = time.time()
        المصادر = المصادر or {}
        البيانات = البيانات or {}
        التعارضات = list(التعارضات or [])
        متطلبات_التحليل = متطلبات_التحليل or {}
        حالة_المصادر = {}
        أسباب = []
        for الاسم, الحالة in المصادر.items():
            if isinstance(الحالة, dict):
                حالة_المصادر[الاسم] = dict(الحالة)
                ح = الحالة.get("الحالة", "غير_معروف")
                if ح not in ("نجح", "جاهز", "سليم"):
                    أسباب.append(f"المصدر {الاسم}: {ح}")
            else:
                حالة_المصادر[الاسم] = {"الحالة": str(الحالة)}
                if str(الحالة) != "نجح": أسباب.append(f"المصدر {الاسم}: {الحالة}")
        صحة = {}
        for الاسم, info in البيانات.items():
            if isinstance(info, dict):
                وقت = info.get("وقت") or info.get("آخر_بيانات")
                حد = float(info.get("حد_العمر_ثانية", 120))
            else:
                وقت, حد = info, 120.0
            عمر = self._عمر(وقت, الآن)
            سليم = عمر is not None and عمر <= حد
            صحة[الاسم] = {"العمر_ثانية": عمر, "الحد_الأقصى": حد, "الحالة": "سليم" if سليم else ("متقادم" if عمر is not None else "غير_معروف"), "صالح_للتنبيه": سليم}
            if not سليم: أسباب.append(f"بيانات {الاسم}: {صحة[الاسم]['الحالة']}")
        for x in التعارضات:
            أسباب.append(f"تعارض: {x}")
        for الاسم, ok in متطلبات_التحليل.items():
            if not bool(ok): أسباب.append(f"التحليل غير مكتمل: {الاسم}")
        جاهز_للمعالجة = not any("متقادم" in x or "غير_معروف" in x or "غير_مكتمل" in x for x in أسباب)
        جاهز_للتنبيه = جاهز_للمعالجة and not أسباب and False  # الإنتاج لا يُفتح من المراقب
        لقطة = لقطة_الجاهزية(self._الآن(), حالة_المصادر, صحة, التعارضات, جاهز_للمعالجة, جاهز_للتنبيه, أسباب, False)
        self.آخر_لقطة = asdict(لقطة)
        self.السجل.append(self.آخر_لقطة)
        self.السجل = self.السجل[-self.حد_السجل:]
        self._حفظ()
        return لقطة

    def حالة_مختصرة(self):
        if not self.آخر_لقطة:
            return {"الحالة":"لا توجد لقطة", "جاهزية_المعالجة":False, "جاهزية_التنبيه":False, "الإنتاج_مصرح":False}
        return {
            "الحالة": "جاهز_للمعالجة" if self.آخر_لقطة["جاهزية_المعالجة"] else "محجوب",
            "جاهزية_المعالجة": self.آخر_لقطة["جاهزية_المعالجة"],
            "جاهزية_التنبيه": False,
            "عدد_الموانع": len(self.آخر_لقطة["الأسباب_المانعة"]),
            "الإنتاج_مصرح": False,
            "الوقت": self.آخر_لقطة["الوقت"],
        }

    def تقرير(self):
        payload={"الإصدار":"4.21", "وقت":self._الآن(), "آخر_لقطة":self.آخر_لقطة, "عدد_اللقطات":len(self.السجل), "الإنتاج_مصرح":False}
        return payload

    def _حفظ(self):
        payload=self.تقرير(); raw=json.dumps(payload,ensure_ascii=False,sort_keys=True).encode()
        payload["بصمة_الحالة"]=hashlib.sha256(raw).hexdigest()
        tmp=self.مسار_الحالة.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); tmp.replace(self.مسار_الحالة)

    def _تحميل(self):
        if not self.مسار_الحالة.exists(): return
        try:
            p=json.loads(self.مسار_الحالة.read_text(encoding='utf-8'))
            self.آخر_لقطة=p.get("آخر_لقطة")
            self.السجل=p.get("السجل", [])[-self.حد_السجل:]
        except Exception:
            self.آخر_لقطة=None; self.السجل=[]
