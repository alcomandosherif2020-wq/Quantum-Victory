from __future__ import annotations
import hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd

ENGINE='QV-DATA-QUALIFICATION-ENGINE'
VERSION='1.0.0'
REQ=['session_date','symbol','open','high','low','close','volume']
FUTURE_PREFIXES=('fwd_','forward_','mfe_','mae_','outcome_','label_')
TIME_FIELDS=('session_timestamp','source_event_time','source_publication_time','source_arrival_time','eligibility_time','decision_time')


def _sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def _num(s): return pd.to_numeric(s, errors='coerce')

def _check_ohlcv(df):
    findings=[]
    for i,r in df.iterrows():
        vals={k:pd.to_numeric(pd.Series([r.get(k)]),errors='coerce').iloc[0] for k in ['open','high','low','close','volume']}
        if any(pd.isna(v) for v in vals.values()): findings.append({'row':int(i)+2,'type':'NON_NUMERIC_OHLCV','severity':'CRITICAL'}); continue
        if vals['volume']<0: findings.append({'row':int(i)+2,'type':'NEGATIVE_VOLUME','severity':'CRITICAL'})
        if vals['open']<=0 or vals['high']<=0 or vals['low']<=0 or vals['close']<=0: findings.append({'row':int(i)+2,'type':'NON_POSITIVE_PRICE','severity':'CRITICAL'})
        if vals['high'] < max(vals['open'],vals['close']) or vals['low'] > min(vals['open'],vals['close']) or vals['low']>vals['high']:
            findings.append({'row':int(i)+2,'type':'OHLC_INVARIANT_FAIL','severity':'CRITICAL'})
    return findings

def _anomaly_scan(df):
    """Robust, non-parametric anomaly screen; flags for review, never labels manipulation."""
    f=[]
    if len(df)<8: return f
    x=df.copy(); x['close_n']=_num(x.close); x['volume_n']=_num(x.volume)
    for sym,g in x.groupby('symbol',dropna=False):
        g=g.sort_values('session_date').copy()
        ret=g.close_n.pct_change(); lv=np.log1p(g.volume_n)
        med=ret.median(); mad=(ret-med).abs().median()
        if pd.notna(mad) and mad>0:
            rz=(ret-med)/(1.4826*mad)
            for idx,v in rz.items():
                if pd.notna(v) and abs(v)>8:
                    f.append({'row':int(idx)+2,'symbol':sym,'type':'ROBUST_RETURN_OUTLIER','severity':'WARNING','robust_z':float(v)})
        lmed=lv.median(); lmad=(lv-lmed).abs().median()
        if pd.notna(lmad) and lmad>0:
            lz=(lv-lmed)/(1.4826*lmad)
            for idx,v in lz.items():
                if pd.notna(v) and v>8:
                    f.append({'row':int(idx)+2,'symbol':sym,'type':'ROBUST_VOLUME_OUTLIER','severity':'WARNING','robust_z':float(v)})
    return f

def qualify(df: pd.DataFrame, *, decision_time=None, source_columns_required=False, expected_sessions=None, cross_source=None):
    x=df.copy(); findings=[]; checks={}
    missing=[c for c in REQ if c not in x.columns]
    checks['schema']=not missing
    if missing: findings.append({'type':'MISSING_REQUIRED_COLUMNS','severity':'CRITICAL','columns':missing})
    if not x.empty and 'symbol' in x and 'session_date' in x:
        key=x[['symbol','session_date']].astype(str).agg('|'.join,axis=1)
        dup=key.duplicated(keep=False)
        checks['duplicates']=not bool(dup.any())
        if dup.any(): findings.append({'type':'DUPLICATE_BUSINESS_KEY','severity':'CRITICAL','rows':list((np.where(dup)[0]+2)[:20])})
    else: checks['duplicates']=True
    if checks['schema']:
        x['session_date_parsed']=pd.to_datetime(x.session_date,errors='coerce')
        bad=x.session_date_parsed.isna()
        checks['chronology']=not bool(bad.any())
        if bad.any(): findings.append({'type':'INVALID_SESSION_DATE','severity':'CRITICAL','rows':list((np.where(bad)[0]+2)[:20])})
        findings.extend(_check_ohlcv(x))
        checks['ohlcv']=not any(f['severity']=='CRITICAL' and f['type'] in {'NON_NUMERIC_OHLCV','NEGATIVE_VOLUME','NON_POSITIVE_PRICE','OHLC_INVARIANT_FAIL'} for f in findings)
    else: checks['chronology']=checks['ohlcv']=False
    # Provenance and point-in-time checks.
    if source_columns_required:
        prov=['source_id','source_version','eligibility_time','row_fingerprint']
        miss=[c for c in prov if c not in x.columns]
        checks['provenance_schema']=not miss
        if miss: findings.append({'type':'MISSING_PROVENANCE_COLUMNS','severity':'CRITICAL','columns':miss})
    else: checks['provenance_schema']=True
    if decision_time and 'eligibility_time' in x.columns:
        dec=pd.Timestamp(decision_time)
        et=pd.to_datetime(x.eligibility_time,errors='coerce')
        bad=et.isna() | (et>dec)
        checks['point_in_time']=not bool(bad.any())
        if bad.any(): findings.append({'type':'POINT_IN_TIME_VIOLATION','severity':'CRITICAL','rows':list((np.where(bad)[0]+2)[:20])})
    else: checks['point_in_time']=not bool(decision_time)
    future=[c for c in x.columns if str(c).lower().startswith(FUTURE_PREFIXES)]
    checks['decision_input_clean']=not bool(future)
    if future: findings.append({'type':'FUTURE_OR_OUTCOME_FIELDS_PRESENT','severity':'CRITICAL','columns':future})
    # adjusted/unadjusted separation
    if 'adjusted_close' in x.columns and 'is_adjusted' in x.columns:
        adj=x.is_adjusted.astype(str).str.lower().isin(['true','1','yes'])
        checks['adjusted_lineage']=bool(('corporate_action_id' in x.columns) or not adj.any())
        if adj.any() and 'corporate_action_id' not in x.columns: findings.append({'type':'ADJUSTED_DATA_WITHOUT_CORPORATE_ACTION_LINEAGE','severity':'CRITICAL'})
    else: checks['adjusted_lineage']=True
    # expected sessions: diagnostic only unless explicit expectation supplied.
    if expected_sessions is not None:
        expected=set(pd.to_datetime(expected_sessions).date); actual=set(x.session_date_parsed.dt.date) if 'session_date_parsed' in x else set()
        missing_sessions=sorted(expected-actual)
        checks['session_coverage']=not bool(missing_sessions)
        if missing_sessions: findings.append({'type':'MISSING_EXPECTED_SESSIONS','severity':'WARNING','count':len(missing_sessions),'sample':[str(v) for v in missing_sessions[:20]]})
    else: checks['session_coverage']=True
    # fingerprints: verify uniqueness when present; recomputation is performed by downstream snapshot engine.
    if 'row_fingerprint' in x.columns:
        fp=x.row_fingerprint.astype(str)
        checks['fingerprints']=not fp.duplicated().any() and not fp.isin(['','nan','None']).any()
        if not checks['fingerprints']: findings.append({'type':'INVALID_OR_DUPLICATE_FINGERPRINT','severity':'CRITICAL'})
    else: checks['fingerprints']=not source_columns_required
    findings.extend(_anomaly_scan(x) if checks['schema'] else [])
    critical=sum(f.get('severity')=='CRITICAL' for f in findings)
    status='BLOCKED' if critical else ('WARNING' if findings else 'PASS')
    # Quality grade intentionally reflects evidence completeness, not market correctness.
    hard=['schema','duplicates','chronology','ohlcv','provenance_schema','point_in_time','decision_input_clean','adjusted_lineage','fingerprints']
    grade='A' if status=='PASS' and all(checks.get(k,False) for k in hard) else ('B' if status!='BLOCKED' and all(checks.get(k,True) for k in hard) else ('C' if status!='BLOCKED' else 'D'))
    return {'engine':ENGINE,'version':VERSION,'status':status,'quality_grade':grade,'rows':len(x),'critical_findings':critical,'checks':checks,'findings':findings,'input_sha256':None,'production_approved':False,'scientific_note':'Qualification establishes data integrity/provenance evidence; it does not prove predictive power.'}

def qualify_file(path, **kwargs):
    p=Path(path); df=pd.read_csv(p)
    rep=qualify(df,**kwargs); rep['input']=str(p); rep['input_sha256']=_sha(p)
    return rep
