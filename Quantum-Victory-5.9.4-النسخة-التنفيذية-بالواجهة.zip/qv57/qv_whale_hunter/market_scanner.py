from __future__ import annotations
import pandas as pd
ENGINE='QV-MARKET-FLOW-SCANNER'; VERSION='1.0.0'

def scan_market(scored: pd.DataFrame, top_n=20) -> pd.DataFrame:
    if scored is None or scored.empty: return pd.DataFrame()
    x=scored.copy()
    x['priority_score']=pd.to_numeric(x.get('sniper_score',0),errors='coerce').fillna(0)
    x['confirmation_bonus']=x.get('confirmation_ready',False).astype(int)*15 if 'confirmation_ready' in x else 0
    x['market_priority']=x['priority_score']+x['confirmation_bonus']
    x['reason_code']=x.apply(lambda r: 'CONFIRMED_BUY_FLOW' if bool(r.get('confirmation_ready',False)) else str(r.get('signal','NO_ALERT')),axis=1)
    cols=['symbol','timestamp','price','volume','sniper_score','signal','confirmation_state','market_priority','reason_code']
    cols=[c for c in cols if c in x.columns]
    return x.sort_values(['market_priority','sniper_score'],ascending=False)[cols].drop_duplicates('symbol').head(top_n).reset_index(drop=True)
