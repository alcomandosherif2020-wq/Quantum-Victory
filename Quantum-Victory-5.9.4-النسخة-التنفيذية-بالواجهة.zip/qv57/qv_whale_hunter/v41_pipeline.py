from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v40_pipeline import run as run_v40
from .flow_graph import build_flow_graph

ENGINE='QV-WHALE-HUNTER-FLOW-PROPAGATION-GRAPH'; VERSION='4.1.0'

def run(intraday_df, historical_intraday_df=None, out_dir='QV-V41-RUN', top_n=20, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    report40,grid,snapshot,base=run_v40(intraday_df,historical_intraday_df=historical_intraday_df,out_dir=out/'v40',top_n=top_n,**kwargs)
    graph,edges,gsnap=build_flow_graph(grid,top_n=top_n,half_life_minutes=kwargs.get('half_life_minutes',8))
    graph.to_csv(out/'QV-V41-FLOW-GRAPH-NODES.csv',index=False); edges.to_csv(out/'QV-V41-FLOW-GRAPH-EDGES.csv',index=False); gsnap.to_csv(out/'QV-V41-GRAPH-SNAPSHOT.csv',index=False)
    latest=graph.sort_values('timestamp').groupby('symbol',as_index=False).tail(1).sort_values('propagation_score',ascending=False) if not graph.empty else graph
    cert={'engine':ENGINE,'version':VERSION,'status':'PASS','base_version':'4.0.0','rows':len(graph),'edges':len(edges),'symbols':int(graph.symbol.nunique()) if not graph.empty else 0,
      'top_symbol':latest.symbol.iloc[0] if not latest.empty else None,'top_propagation_score':float(latest.propagation_score.iloc[0]) if not latest.empty else None,
      'architecture':['V40_DISTRIBUTED_GRID','TEMPORAL_FLOW_EDGES','RECENCY_DECAY','NETWORK_CENTRALITY','LIQUIDITY_PROPAGATION','MIGRATION_DIRECTION','OUTCOME_REPLAY_INHERITED'],
      'graph_semantics':'observable co-movement and flow propagation evidence; edges never identify actors or intent',
      'score_probability_separation':True,'probability_output':None,'fixed_price_target':None,'identity_claim':False,'evidence_only':True,'production_approved':False,'human_risk_check_required':True}
    (out/'QV-V41-CERTIFICATE.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    return cert,graph,edges,gsnap,base
