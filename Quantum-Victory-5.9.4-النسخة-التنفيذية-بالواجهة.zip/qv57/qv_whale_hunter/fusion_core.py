from __future__ import annotations
import numpy as np
import pandas as pd

ENGINE='QV-WHALE-FUSION-CORE'; VERSION='3.9.0'


def _num(df, col, default=0.0):
    if col in df.columns:
        return pd.to_numeric(df[col], errors='coerce').fillna(default)
    return pd.Series(default, index=df.index, dtype=float)


def _robust_rank(s):
    s=pd.to_numeric(s,errors='coerce').fillna(0.0)
    if len(s)<=1: return pd.Series(0.5,index=s.index)
    lo,hi=s.quantile(.05),s.quantile(.95)
    if hi<=lo: return pd.Series(.5,index=s.index)
    return ((s-lo)/(hi-lo)).clip(0,1)


def build_fusion(scored: pd.DataFrame, market_df: pd.DataFrame|None=None, sector_df: pd.DataFrame|None=None,
                 top_n=20, confirmation_bonus=12.0, trap_penalty=18.0):
    """Graph-like evidence fusion. Nodes=symbols; context edges=market/sector/time.
    Scores are evidence-strength indices, never probabilities or price forecasts.
    """
    if scored is None or scored.empty: return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    x=scored.copy().reset_index(drop=True)
    x['timestamp']=pd.to_datetime(x['timestamp'],errors='coerce')
    x['session_key']=x['timestamp'].dt.date.astype(str)
    base=_num(x,'sniper_score')
    confirm=np.where(x.get('confirmation_ready',False),1.0,0.0)
    state=x.get('confirmation_state',pd.Series('WATCH',index=x.index)).astype(str)
    state_factor=state.map({'CONFIRMED_FLOW':1.0,'BUILDING':.65,'WATCH':.35,'FADING':.15,'INVALIDATED':0.0}).fillna(.25)
    book=_num(x,'book_imbalance').clip(-1,1)
    buy=_num(x,'buy_pressure',.5).clip(0,1)
    trap=_num(x,'false_whale_trap_score',0).clip(0,100)
    session_rv=_num(x,'session_rvol',_num(x,'rvol_local',1)).clip(0,20)
    intensity=_num(x,'trade_intensity_rv',1).clip(0,20)
    turnover=_num(x,'turnover_rv',1).clip(0,20)
    # Node evidence: local liquidity + microstructure + persistence.
    local=(.42*base + .13*(book+1)*50 + .13*buy*100 + .12*np.minimum(session_rv/4,1)*100
           + .10*np.minimum(intensity/3,1)*100 + .10*np.minimum(turnover/3,1)*100)
    local=local.clip(0,100)
    # Context edges are computed cross-sectionally at the same observation time/session.
    key=x['timestamp'].dt.floor('min')
    x['_time_key']=key
    x['_local_evidence']=local
    x['_buy_pressure']=buy
    x['_trap']=trap
    x['market_relative_edge']=0.5
    x['sector_relative_edge']=0.5
    for k,g in x.groupby('_time_key',dropna=False):
        idx=g.index
        x.loc[idx,'market_relative_edge']=_robust_rank(g['_local_evidence']).to_numpy()
        if 'sector' in g.columns:
            for _,sg in g.groupby(g['sector'].fillna('UNKNOWN').astype(str)):
                x.loc[sg.index,'sector_relative_edge']=_robust_rank(sg['_local_evidence']).to_numpy()
    # If precomputed market/sector aggregates exist, inject their directional context.
    if market_df is not None and not market_df.empty and 'date' in market_df.columns:
        m=market_df.copy(); m['date']=m['date'].astype(str)
        if 'net_flow_pressure' in m:
            md=m[['date','net_flow_pressure']].drop_duplicates('date')
            x=x.merge(md,left_on='session_key',right_on='date',how='left')
        else: x['net_flow_pressure']=np.nan
    else: x['net_flow_pressure']=np.nan
    market_bias=((_num(x,'net_flow_pressure',0).clip(-100,100)+100)/200)
    # Context should help, not dominate local evidence.
    raw=.60*local + .12*(x.market_relative_edge*100) + .10*(x.sector_relative_edge*100) + .08*(state_factor*100) + .05*(market_bias*100) + .05*(book.add(1).mul(50))
    raw=raw.clip(0,100)
    # Trap/contradiction logic. Penalize only when risk is actually evidenced.
    contradiction=((buy<.52)&(base>=55)).astype(float) + ((book<-.25)&(base>=55)).astype(float)
    penalty=np.minimum(1.0,trap/100)*trap_penalty + contradiction*8
    fusion=(raw + confirmation_bonus*confirm - penalty).clip(0,100)
    x['local_evidence_score']=local.round(4)
    x['fusion_score']=fusion.round(4)
    x['fusion_rank']=x.groupby('session_key')['fusion_score'].rank(method='dense',ascending=False).astype(int)
    x['network_state']=np.select([
        (state.eq('CONFIRMED_FLOW'))&(fusion>=70)&(trap<50),
        (state.isin(['BUILDING','CONFIRMED_FLOW']))&(fusion>=55)&(trap<70),
        state.eq('FADING'),
        state.eq('INVALIDATED')|((trap>=70)),
    ],['CONFIRMED_NETWORK_FLOW','ARMED_NETWORK_FLOW','FADING_NETWORK_FLOW','BLOCKED_NETWORK_RISK'],default='WATCH_NETWORK')
    x['reason_code']=np.select([
        x.network_state.eq('CONFIRMED_NETWORK_FLOW'),
        x.network_state.eq('ARMED_NETWORK_FLOW'),
        x.network_state.eq('FADING_NETWORK_FLOW'),
        x.network_state.eq('BLOCKED_NETWORK_RISK')],
        ['NETWORK_CONFIRMED_BUY_FLOW','NETWORK_ARMED_FLOW','NETWORK_FLOW_FADING','NETWORK_BLOCKED_TRAP'],default='NETWORK_WATCH')
    x['evidence_only']=True; x['identity_claim']=False; x['probability']=np.nan; x['fixed_price_target']=np.nan
    cols=[c for c in ['symbol','timestamp','session_key','sector','sniper_score','local_evidence_score','market_relative_edge','sector_relative_edge','fusion_score','fusion_rank','confirmation_state','confirmation_ready','network_state','reason_code','false_whale_trap_score','book_imbalance','buy_pressure','probability','fixed_price_target'] if c in x.columns]
    latest=x.sort_values(['timestamp','fusion_score'],ascending=[False,False]).groupby('symbol',as_index=False).head(1).sort_values('fusion_score',ascending=False).head(top_n).reset_index(drop=True)
    # Compact network metrics: symbol nodes + context edges at each latest timestamp.
    nodes=x['symbol'].nunique()
    edges=max(0,nodes*(nodes-1)//2)
    network=pd.DataFrame([{'timestamp':x.timestamp.max(),'symbols':nodes,'potential_symbol_edges':edges,
                           'confirmed_nodes':int((x.network_state=='CONFIRMED_NETWORK_FLOW').sum()),
                           'blocked_nodes':int((x.network_state=='BLOCKED_NETWORK_RISK').sum()),
                           'mean_fusion_score':float(x.fusion_score.mean()),
                           'max_fusion_score':float(x.fusion_score.max()),
                           'network_top_symbol':latest.symbol.iloc[0] if not latest.empty else None}])
    return x[cols], latest, network
