from __future__ import annotations
import pandas as pd
import numpy as np

def add_relative_flow(df):
    x=df.copy(); x["turnover_proxy"]=x.get("turnover",x["close"]*x["volume"])
    x["stock_flow_proxy"]=x.get("flow_z20",np.nan)
    if "sector" in x:
        sec=x.groupby(["session_date","sector"],dropna=False)["stock_flow_proxy"].transform("mean")
        x["sector_flow_context"]=sec
        x["relative_to_sector_flow"]=x["stock_flow_proxy"]-sec
    else: x["sector_flow_context"]=np.nan; x["relative_to_sector_flow"]=np.nan
    m=x.groupby("session_date")["stock_flow_proxy"].transform("mean")
    x["market_flow_context"]=m; x["relative_to_market_flow"]=x["stock_flow_proxy"]-m
    return x
