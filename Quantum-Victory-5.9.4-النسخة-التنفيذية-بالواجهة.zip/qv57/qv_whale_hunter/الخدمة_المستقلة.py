from __future__ import annotations
import os,time,json
from pathlib import Path
import pandas as pd
from .source_mesh import SourceMesh
from .source_registry import configured_sources
from .v42_pipeline import run as run_v42
from .secure_telegram_gateway import SecureTelegramGateway
from .حارس_البيانات import حارس_البيانات
from .مصفاة_التحليل import فصل_البيانات

class خدمة_كوانتوم_فيكتوري:
    """الخدمة المستقلة: تجمع البيانات المصرح بها، تتحقق منها، تحللها، ثم ترسل التنبيهات."""
    def __init__(self, interval=10.0, out_dir='تشغيل-كوانتوم-فيكتوري', recommendation_csv=None):
        self.interval=max(1.0,float(interval)); self.out=Path(out_dir); self.out.mkdir(parents=True,exist_ok=True)
        self.mesh=SourceMesh(configured_sources(),state_dir=self.out/'حالة-المصادر')
        self.telegram=SecureTelegramGateway(state_dir=self.out/'حالة-التنبيهات'); self.recommendation_csv=recommendation_csv
        self.آخر_بيانات={}
        self.الحارس=حارس_البيانات(مجلد=self.out/'حارس-البيانات')

    def _توصيات(self):
        if self.recommendation_csv and Path(self.recommendation_csv).exists(): return pd.read_csv(self.recommendation_csv)
        return None

    def دورة_واحدة(self):
        df, تقرير_المصادر=self.mesh.collect()
        for مصدر in تقرير_المصادر.get('sources',[]):
            الاسم=مصدر.get('source','غير معروف')
            self.الحارس.تسجيل_المصدر(الاسم,'بيانات السوق',0)
            (self.الحارس.تسجيل_نجاح if مصدر.get('ok') else self.الحارس.تسجيل_فشل)(الاسم)
        حالة_السوق=self.الحارس.حالة_الجلسة()
        حداثة=self.الحارس.فحص_الحداثة(df)
        self.الحارس.تقرير(حالة_السوق,حداثة)
        if not حالة_السوق['مفتوحة'] and df.empty:
            حالة={'الحالة':'لا توجد بيانات موثوقة حالياً','عدد الصفوف':0,'إرسال_التنبيهات':0,'حالة_السوق':حالة_السوق['السبب'],'اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر}
        elif not حالة_السوق['مفتوحة']:
            حالة={'الحالة':'السوق مغلق ولم يتم تشغيل تحليل لحظي جديد','عدد الصفوف':len(df),'عدد التنبيهات':0,'إرسال_التنبيهات':0,'حالة_السوق':حالة_السوق['السبب'],'اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر}
        elif not حداثة['سليم']:
            حالة={'الحالة':'تم حجب البيانات المتقادمة','عدد الصفوف':len(df),'عدد التنبيهات':0,'إرسال_التنبيهات':0,'حالة_السوق':حالة_السوق['السبب'],'اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر}
        else:
            الشهادة,الدمج,التنبيهات=run_v42(df,recommendation_df=self._توصيات(),out_dir=self.out/'المحرك',top_n=50)
            مرسل=0
            for _,تنبيه in التنبيهات.iterrows():
                if not bool(الشهادة.get('production_approved', False)):
                    continue
                نتيجة=self.telegram.send(str(تنبيه.message),alert_id=str(تنبيه.alert_id))
                if نتيجة.get('sent'): مرسل+=1
            حالة={'الحالة':'تمت دورة التحليل','عدد الصفوف':len(df),'عدد التنبيهات':len(التنبيهات),'إرسال_التنبيهات':مرسل,'حالة_السوق':'بيانات مستلمة','اعتماد_الإنتاج':False,'المصادر':تقرير_المصادر}
        with (self.out/'سجل_الخدمة.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(حالة,ensure_ascii=False,default=str)+'\n')
        return حالة

    def تشغيل(self, مدة=None):
        البداية=time.monotonic(); دورات=0
        while مدة is None or time.monotonic()-البداية<مدة:
            self.دورة_واحدة(); دورات+=1; time.sleep(self.interval)
        return {'الحالة':'توقفت الخدمة','عدد الدورات':دورات,'إعداد التنبيهات':self.telegram.configured,'اعتماد_الإنتاج':False}
