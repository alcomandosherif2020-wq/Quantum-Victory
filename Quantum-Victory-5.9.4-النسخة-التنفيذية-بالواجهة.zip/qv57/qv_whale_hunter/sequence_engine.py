from __future__ import annotations
import numpy as np
import pandas as pd


def _z(s, n=20):
    m=s.rolling(n,min_periods=max(5,n//2)).mean(); sd=s.rolling(n,min_periods=max(5,n//2)).std(ddof=0)
    return (s-m)/(sd.replace(0,np.nan))


def add_sequence_features(df: pd.DataFrame) -> pd.DataFrame:
    x=df.sort_values(["symbol","session_date"]).copy()
    g=x.groupby("symbol",group_keys=False)
    tp=(x.high+x.low+x.close)/3
    pv=tp*x.volume
    x["vwap_proxy"]=pv.groupby(x.symbol).transform(lambda s: s.rolling(20,min_periods=5).sum()) / x.volume.groupby(x.symbol).transform(lambda s: s.rolling(20,min_periods=5).sum()).replace(0,np.nan)
    x["volume_z20"]=_z(x["volume"],20)
    x["turnover_z20"]=_z(x["turnover"],20) if "turnover" in x else np.nan
    x["range"]=(x.high-x.low).clip(lower=0)
    x["body_pct"]=((x.close-x.open)/(x.range.replace(0,np.nan))).fillna(0)
    x["close_loc"]=((x.close-x.low)/(x.range.replace(0,np.nan))).clip(0,1).fillna(.5)
    x["ret1"]=g.close.pct_change(); x["ret5"]=g.close.pct_change(5)
    x["flow_proxy"]=x["ret1"].fillna(0)*x["volume_z20"].fillna(0); x["flow_z20"]=_z(x["flow_proxy"],20)
    x["above_vwap"]=x.close>x.vwap_proxy
    x["breakout20"]=x.close>g.high.transform(lambda s:s.shift(1).rolling(20,min_periods=10).max())
    x["breakdown20"]=x.close<g.low.transform(lambda s:s.shift(1).rolling(20,min_periods=10).min())
    x["volume_shock"]=x.volume_z20>=2.0
    x["liq_accel"]=x.groupby("symbol")["volume_z20"].transform(lambda s:s.diff().rolling(3,min_periods=1).mean())>=0.35
    x["absorption_bull"]=x.volume_shock & (x.close_loc>=.65) & (x.body_pct>=-.25)
    x["absorption_bear"]=x.volume_shock & (x.close_loc<=.35) & (x.body_pct<=.25)
    x["money_flow_confirmation"]=(x.flow_z20>=1.0)&x.above_vwap
    x["money_flow_divergence"]=(x.flow_z20<=-1.0)&(~x.above_vwap)
    prev_above=x.groupby("symbol")["above_vwap"].shift(1).astype("boolean").fillna(False).astype(bool)
    x["vwap_reclaim"]=x.above_vwap.astype(bool) & ~prev_above
    x["vwap_loss"]=~x.above_vwap.astype(bool) & prev_above
    x["breakout_volume"]=x.breakout20 & x.volume_shock & (x.close_loc>=.7)
    x["distribution"]=x.volume_shock & (x.close_loc<=.3) & (x.ret5>0)
    x["exit_pressure"]=x.distribution & x.vwap_loss
    x["continuation"]=g.close.pct_change().transform(lambda s:s.rolling(3,min_periods=3).mean())>0
    buy=["absorption_bull","liq_accel","money_flow_confirmation","vwap_reclaim","breakout_volume","continuation"]
    sell=["absorption_bear","liq_accel","money_flow_divergence","vwap_loss","distribution","exit_pressure"]
    x["sequence_buy_count"]=x[buy].fillna(False).astype(bool).sum(axis=1)
    x["sequence_sell_count"]=x[sell].fillna(False).astype(bool).sum(axis=1)
    return x


def build_sequence_events(df: pd.DataFrame, min_events=3, lookback=5):
    x=add_sequence_features(df); rows=[]
    for sym,g in x.groupby("symbol",sort=False):
        g=g.sort_values("session_date").reset_index(drop=True)
        for i,r in g.iterrows():
            w=g.iloc[max(0,i-lookback+1):i+1]; buy=[]; sell=[]
            for _,q in w.iterrows():
                for flag,name in [("absorption_bull","ABSORPTION_BULL"),("liq_accel","LIQUIDITY_ACCELERATION"),("money_flow_confirmation","MONEY_FLOW_CONFIRMATION"),("vwap_reclaim","VWAP_RECLAIM"),("breakout_volume","BREAKOUT_VOLUME"),("continuation","CONTINUATION")]:
                    if bool(q.get(flag,False)): buy.append(name)
                for flag,name in [("absorption_bear","ABSORPTION_BEAR"),("liq_accel","LIQUIDITY_ACCELERATION"),("money_flow_divergence","MONEY_FLOW_DIVERGENCE"),("vwap_loss","VWAP_LOSS"),("distribution","DISTRIBUTION"),("exit_pressure","EXIT_PRESSURE")]:
                    if bool(q.get(flag,False)): sell.append(name)
            bu=list(dict.fromkeys(buy)); se=list(dict.fromkeys(sell)); state="NO_SEQUENCE"
            if len(bu)>=min_events and len(bu)>len(se): state="ACCUMULATION_SEQUENCE"
            elif len(se)>=min_events and len(se)>len(bu): state="DISTRIBUTION_SEQUENCE"
            elif bu and se: state="MIXED_SEQUENCE"
            rows.append({"symbol":sym,"session_date":r.session_date,"sequence_state":state,"buy_events":"|".join(bu),"sell_events":"|".join(se),"buy_event_count":len(bu),"sell_event_count":len(se)})
    return pd.DataFrame(rows)
