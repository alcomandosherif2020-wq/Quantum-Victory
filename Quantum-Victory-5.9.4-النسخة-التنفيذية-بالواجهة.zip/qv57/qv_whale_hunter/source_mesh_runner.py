from __future__ import annotations
import os
from .source_mesh import SourceMesh
from .source_registry import configured_sources

def run_once(out_dir='QV-SOURCE-MESH-RUN'):
    mesh=SourceMesh(configured_sources(),state_dir=out_dir)
    mesh.manifest()
    return mesh.collect()

if __name__=='__main__':
    df,report=run_once()
    print({'rows':len(df),'sources':report['sources'],'production_approved':False})
