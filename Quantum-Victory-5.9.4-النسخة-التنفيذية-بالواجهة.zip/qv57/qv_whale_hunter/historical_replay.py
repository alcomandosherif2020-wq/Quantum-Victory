from __future__ import annotations
import hashlib, json
from typing import Iterable, Sequence
import pandas as pd

ENGINE='QV-POINT-IN-TIME-HISTORICAL-REPLAY'; VERSION='1.0.0'

FUTURE_PREFIXES=('fwd_','forward_','mfe_','mae_','outcome_','label_')

def _hash_frame(df: pd.DataFrame) -> str:
    if df.empty: return hashlib.sha256(b'').hexdigest()
    cols=sorted(df.columns)
    x=df[cols].copy().fillna('<NA>').astype(str)
    payload='\n'.join('|'.join(row) for row in x.to_numpy())
    return hashlib.sha256(payload.encode()).hexdigest()

def _decision_columns(df: pd.DataFrame) -> list[str]:
    keep=[]
    for c in df.columns:
        lc=c.lower()
        if c in {'fwd_ret_1','fwd_ret_3','fwd_ret_5','fwd_ret_10','forward_follow_through'}: continue
        if lc.startswith(FUTURE_PREFIXES): continue
        keep.append(c)
    return keep

def replay_at(df: pd.DataFrame, decision_time, *, eligibility_col='eligibility_time', date_col='session_date'):
    """Reconstruct the information set available at a historical decision time.
    No future/outcome columns are returned, even if present in the source.
    """
    x=df.copy()
    if date_col not in x: raise ValueError(f'missing {date_col}')
    d=pd.Timestamp(decision_time)
    if eligibility_col in x:
        e=pd.to_datetime(x[eligibility_col],errors='coerce')
        x=x[e.notna() & (e<=d)].copy()
    else:
        s=pd.to_datetime(x[date_col],errors='coerce')
        x=x[s.notna() & (s<=d)].copy()
    return x[_decision_columns(x)].copy()

def build_replay(df: pd.DataFrame, decision_times: Sequence, *, eligibility_col='eligibility_time'):
    rows=[]; violations=[]
    for dt in decision_times:
        snap=replay_at(df,dt,eligibility_col=eligibility_col)
        snap['_decision_time']=pd.Timestamp(dt).isoformat()
        rows.append(snap)
        if eligibility_col in df:
            e=pd.to_datetime(df[eligibility_col],errors='coerce'); d=pd.Timestamp(dt)
            violations.append(int((e.notna() & (e>d)).sum()))
    out=pd.concat(rows,ignore_index=True) if rows else df.iloc[0:0].copy()
    return out, {'engine':ENGINE,'version':VERSION,'decision_times':len(decision_times),
                 'future_rows_excluded':int(sum(violations)),'snapshot_rows':len(out),
                 'replay_hash':_hash_frame(out),'future_outcomes_used':False}
