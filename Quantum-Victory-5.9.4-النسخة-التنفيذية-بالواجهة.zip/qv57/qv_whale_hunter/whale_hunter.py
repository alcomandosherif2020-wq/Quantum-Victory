from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

ENGINE='QV-WHALE-HUNTER-001'; VERSION='1.0.0'
REQ=['symbol','session_date','open','high','low','close','volume']

def sha256_file(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def clip01(x): return float(np.clip(x,0,1))

def validate(df):
    e=[]
    m=[c for c in REQ if c not in df.columns]
    if m: e.append({'gate':'schema','missing':m}); return e
    if df.empty: return [{'gate':'real_data_presence','reason':'EMPTY_DATASET'}]
    if df.duplicated(['symbol','session_date']).any(): e.append({'gate':'duplicates','rows':int(df.duplicated(['symbol','session_date']).sum())})
    for c in ['open','high','low','close','volume']:
        if pd.to_numeric(df[c],errors='coerce').isna().any(): e.append({'gate':'numeric_parse','column':c})
    o,h,l,c,v=[pd.to_numeric(df[x],errors='coerce') for x in ['open','high','low','close','volume']]
    bad=(h<l)|(c>h)|(c<l)|(l<=0)|(h<=0)|(v<0)
    if bad.any(): e.append({'gate':'ohlcv_invariant','rows':int(bad.sum())})
    return e

def rsi(s,n=14):
    d=s.diff(); up=d.clip(lower=0); dn=-d.clip(upper=0)
    au=up.ewm(alpha=1/n,adjust=False,min_periods=n).mean(); ad=dn.ewm(alpha=1/n,adjust=False,min_periods=n).mean()
    return 100-100/(1+au/ad.replace(0,np.nan))

def zscore(s,w=20,mp=10):
    m=s.rolling(w,min_periods=mp).mean(); sd=s.rolling(w,min_periods=mp).std(ddof=0)
    return (s-m)/sd.replace(0,np.nan)

def features(df):
    x=df.copy(); x['session_date']=pd.to_datetime(x['session_date']); x=x.sort_values(['symbol','session_date']).reset_index(drop=True)
    g=x.groupby('symbol',group_keys=False)
    x['ret1']=g['close'].pct_change(); x['ret5']=g['close'].pct_change(5); x['ret20']=g['close'].pct_change(20)
    x['range']=(x.high-x.low).replace(0,np.nan); x['body']=(x.close-x.open).abs()
    x['close_location']=((x.close-x.low)/x['range']).clip(0,1)
    x['upper_wick']=x.high-x[['open','close']].max(axis=1); x['lower_wick']=x[['open','close']].min(axis=1)-x.low
    x['vol_ma20']=g.volume.transform(lambda s:s.rolling(20,min_periods=5).mean()); x['rvol20']=x.volume/x.vol_ma20.replace(0,np.nan)
    x['vol_z20']=g.volume.transform(lambda s:zscore(s,20,10)); x['dollar_volume']=x.close*x.volume
    x['liquidity_z20']=g.dollar_volume.transform(lambda s:zscore(s,20,10)); x['liquidity_accel']=x.rvol20-g.rvol20.shift(3)
    x['ema20']=g.close.transform(lambda s:s.ewm(span=20,adjust=False,min_periods=10).mean()); x['ema50']=g.close.transform(lambda s:s.ewm(span=50,adjust=False,min_periods=20).mean())
    x['rsi14']=g.close.transform(rsi)
    # OBV
    d=np.sign(x.close.groupby(x.symbol).diff()).fillna(0); x['obv_raw']=(d*x.volume).groupby(x.symbol).cumsum(); x['obv_z20']=g.obv_raw.transform(lambda s:zscore(s,20,10))
    # CMF
    mult=(((x.close-x.low)-(x.high-x.close))/x['range']).fillna(0)
    num=(mult*x.volume).groupby(x.symbol).rolling(20,min_periods=5).sum().reset_index(level=0,drop=True)
    den=x.volume.groupby(x.symbol).rolling(20,min_periods=5).sum().reset_index(level=0,drop=True)
    x['cmf20']=num/den.replace(0,np.nan)
    # MFI proxy
    tp=(x.high+x.low+x.close)/3; flow=tp*x.volume; sgn=np.sign(tp.groupby(x.symbol).diff()).fillna(0)
    pos=(flow*sgn.clip(lower=0)).groupby(x.symbol).rolling(14,min_periods=5).sum().reset_index(level=0,drop=True)
    neg=(flow*(-sgn.clip(upper=0))).groupby(x.symbol).rolling(14,min_periods=5).sum().reset_index(level=0,drop=True)
    x['mfi14']=100-100/(1+pos/neg.replace(0,np.nan))
    x['volume_shock']=(x.rvol20>=2)|(x.vol_z20>=2); x['strong_close']=x.close_location>=.75; x['weak_close']=x.close_location<=.25
    x['bull_body']=x.close>x.open; x['bear_body']=x.close<x.open; x['lower_rejection']=(x.lower_wick/x['range']).fillna(0)>=.35; x['upper_rejection']=(x.upper_wick/x['range']).fillna(0)>=.35
    x['above_ema20']=x.close>x.ema20; x['ema_bull']=x.ema20>x.ema50
    return x

def score(r):
    rv=float(r.rvol20) if pd.notna(r.rvol20) else 1; vz=float(r.vol_z20) if pd.notna(r.vol_z20) else 0
    cl=float(r.close_location) if pd.notna(r.close_location) else .5; cmf=float(r.cmf20) if pd.notna(r.cmf20) else 0; mfi=float(r.mfi14) if pd.notna(r.mfi14) else 50
    obv=float(r.obv_z20) if pd.notna(r.obv_z20) else 0; acc=float(r.liquidity_accel) if pd.notna(r.liquidity_accel) else 0
    vol=clip01((rv-1)/2); vzp=clip01((vz+1)/4); accp=clip01((acc+.5)/1.5)
    buy=20*vol+10*vzp+15*cl+12*clip01((cmf+.2)/.4)+10*clip01((mfi-35)/50)+8*clip01((obv+2)/4)+10*accp+5*int(r.bull_body)+5*int(r.lower_rejection)+5*int(r.above_ema20)
    sell=20*vol+10*vzp+15*(1-cl)+12*clip01((-.2-cmf)/.4+0.5)+10*clip01((65-mfi)/50)+8*clip01((-obv+2)/4)+10*clip01((.5-acc)/1.5)+5*int(r.bear_body)+5*int(r.upper_rejection)+5*int(not r.above_ema20)
    if bool(r.volume_shock) and abs(cl-.5)<.1: buy*=.85; sell*=.85
    buy=float(np.clip(buy,0,100)); sell=float(np.clip(sell,0,100)); net=buy-sell
    if buy>=72 and net>=18: state='INSTITUTIONAL_ACCUMULATION'
    elif buy>=60 and net>=10: state='EARLY_ACCUMULATION'
    elif sell>=72 and -net>=18: state='DISTRIBUTION'
    elif sell>=60 and -net>=10: state='PROFIT_TAKING_OR_EXIT_PRESSURE'
    elif max(buy,sell)<45: state='NO_SIGNAL'
    else: state='MIXED_FLOW'
    conf=min(100,40+.8*abs(net)+(10 if r.volume_shock else 0)); unc=100-conf
    return pd.Series([buy,sell,net,conf,unc,state],index=['buy_pressure','sell_pressure','institutional_flow_score','confirmation_score','uncertainty_score','state'])

def scan(df):
    x=features(df); x=pd.concat([x,x.apply(score,axis=1)],axis=1)
    p=(x.institutional_flow_score>10).astype(int); n=(x.institutional_flow_score<-10).astype(int)
    x['buy_flow_persistence_5']=p.groupby(x['symbol']).transform(lambda s: s.rolling(5,min_periods=1).sum())
    x['sell_flow_persistence_5']=n.groupby(x['symbol']).transform(lambda s: s.rolling(5,min_periods=1).sum())
    x['multi_session_confirmed']=((x.buy_flow_persistence_5>=3)|(x.sell_flow_persistence_5>=3))
    x['false_signal_risk']=(35-12*x.multi_session_confirmed.astype(int)+12*(x.volume_shock & x.close_location.between(.4,.6)).astype(int)+10*(x.institutional_flow_score.abs()<10).astype(int)+8*(x.confirmation_score<55).astype(int)).clip(0,100)
    return x

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input'); ap.add_argument('--outdir',default='QV-WHALE-HUNTER-RUN'); ap.add_argument('--decision-time'); a=ap.parse_args()
    inp=Path(a.input); out=Path(a.outdir); out.mkdir(parents=True,exist_ok=True); df=pd.read_csv(inp); errs=validate(df)
    if errs:
        rep={'engine':ENGINE,'version':VERSION,'status':'BLOCKED','production_approved':False,'validation_errors':errs,'input_sha256':sha256_file(inp)}
        (out/'REPORT.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2)); print(json.dumps(rep,ensure_ascii=False,indent=2)); return 2
    if a.decision_time and 'eligibility_time' in df:
        et=pd.to_datetime(df.eligibility_time,utc=True,errors='coerce'); cutoff=pd.Timestamp(a.decision_time)
        df=df.loc[et<=cutoff].copy(); blocked=int((et>cutoff).sum())
    else: blocked=0
    r=scan(df); r.to_csv(out/'SCORES.csv',index=False)
    latest=r.sort_values('session_date').groupby('symbol',as_index=False).tail(1).sort_values('institutional_flow_score',ascending=False)
    cols=['symbol','session_date','buy_pressure','sell_pressure','institutional_flow_score','confirmation_score','uncertainty_score','false_signal_risk','state','buy_flow_persistence_5','sell_flow_persistence_5']
    latest[cols].to_csv(out/'RADAR.csv',index=False)
    rep={'engine':ENGINE,'version':VERSION,'status':'PASS','production_approved':False,'rows_scored':len(r),'symbols_scored':int(r.symbol.nunique()),'future_rows_blocked':blocked,'promotion_gate':'REAL_EGX_QUALIFICATION_OOS_WALK_FORWARD_REQUIRED','outputs':['SCORES.csv','RADAR.csv']}
    (out/'REPORT.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2)); print(json.dumps(rep,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
