from __future__ import annotations
import os

def health_snapshot(gateway):
    return {
        'configured': gateway.configured,
        'token_present': bool(os.getenv('QV_TELEGRAM_BOT_TOKEN')),
        'chat_id_present': bool(os.getenv('QV_TELEGRAM_CHAT_ID')),
        'signing_secret_present': bool(os.getenv('QV_ALERT_SIGNING_SECRET')),
        'outbound_only': True,
        'chatgpt_required': False,
        'production_approved': False,
    }
