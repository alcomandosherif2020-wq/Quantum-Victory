from __future__ import annotations
import json, time
from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, time as dtime
from zoneinfo import ZoneInfo

@dataclass
class حالة_المصدر:
    الاسم: str
    الفئة: str
    الأولوية: int
    متاح: bool = True
    آخر_نجاح: float | None = None
    عدد_الأخطاء: int = 0
    متوقف_مؤقتا_حتى: float = 0.0

class حارس_البيانات:
    """حماية دورة البيانات: جلسة السوق، حداثة البيانات، وتوقف المصدر المتعطل مؤقتا."""
    def __init__(self, مجلد='تشغيل-كوانتوم-فيكتوري/حارس-البيانات', مهلة_البيانات=90.0, عدد_الأخطاء_للتوقف=3, مدة_التوقف=60.0):
        self.المجلد=Path(مجلد); self.المجلد.mkdir(parents=True,exist_ok=True)
        self.مهلة_البيانات=float(مهلة_البيانات); self.عدد_الأخطاء_للتوقف=int(عدد_الأخطاء_للتوقف); self.مدة_التوقف=float(مدة_التوقف)
        self.المصادر={}

    def تسجيل_المصدر(self, الاسم, الفئة, الأولوية):
        self.المصادر[الاسم]=حالة_المصدر(الاسم,الفئة,int(الأولوية))

    def تسجيل_نجاح(self, الاسم):
        s=self.المصادر.setdefault(الاسم,حالة_المصدر(الاسم,'غير محدد',999)); s.متاح=True; s.آخر_نجاح=time.time(); s.عدد_الأخطاء=0; s.متوقف_مؤقتا_حتى=0

    def تسجيل_فشل(self, الاسم):
        s=self.المصادر.setdefault(الاسم,حالة_المصدر(الاسم,'غير محدد',999)); s.عدد_الأخطاء+=1
        if s.عدد_الأخطاء>=self.عدد_الأخطاء_للتوقف:
            s.متوقف_مؤقتا_حتى=time.time()+self.مدة_التوقف; s.متاح=False

    def المصدر_مسموح(self, الاسم):
        s=self.المصادر.get(الاسم)
        if s is None: return True
        if time.time() >= s.متوقف_مؤقتا_حتى: s.متاح=True
        return s.متاح

    @staticmethod
    def وقت_مصر():
        return datetime.now(ZoneInfo('Africa/Cairo'))

    def حالة_الجلسة(self, الآن=None):
        الآن=الآن or self.وقت_مصر(); يوم=الآن.weekday()
        if يوم>=5: return {'مفتوحة':False,'السبب':'السوق مغلق يومي الجمعة والسبت'}
        بداية=dtime(10,0); نهاية=dtime(14,30); ساعة=الآن.timetz().replace(tzinfo=None)
        return {'مفتوحة':بداية<=ساعة<=نهاية,'السبب':'داخل أوقات الجلسة الاعتيادية' if بداية<=ساعة<=نهاية else 'خارج أوقات الجلسة الاعتيادية'}

    def فحص_الحداثة(self, df):
        if df is None or len(df)==0: return {'سليم':False,'السبب':'لا توجد بيانات'}
        if 'timestamp' not in df.columns: return {'سليم':False,'السبب':'لا يوجد توقيت للمشاهدة'}
        ts=df['timestamp'].max()
        try: عمر=(datetime.now(ZoneInfo('Africa/Cairo')).replace(tzinfo=None)-ts.to_pydatetime().replace(tzinfo=None)).total_seconds()
        except Exception: return {'سليم':False,'السبب':'تعذر حساب عمر البيانات'}
        return {'سليم':عمر<=self.مهلة_البيانات,'عمر_بالثواني':round(عمر,2),'السبب':'البيانات حديثة' if عمر<=self.مهلة_البيانات else 'البيانات متقادمة'}

    def تقرير(self, حالة_السوق, حداثة):
        تقرير={'الوقت':self.وقت_مصر().isoformat(),'حالة_الجلسة':حالة_السوق,'حداثة_البيانات':حداثة,'المصادر':[asdict(x) for x in self.المصادر.values()]}
        (self.المجلد/'تقرير_الحماية.json').write_text(json.dumps(تقرير,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
        return تقرير
