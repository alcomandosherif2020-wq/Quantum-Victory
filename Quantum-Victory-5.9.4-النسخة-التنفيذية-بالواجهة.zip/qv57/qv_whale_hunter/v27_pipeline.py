from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .regime_stability import *
from .v26_pipeline import run as run_v26
from .calibration import empirical_oos_calibration, calibration_curve

VERSION='2.7.0'

def run(df,out_dir,regime_col=None,min_regime_samples=30,min_coverage=3,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    regime=assign_regime(df,regime_col=regime_col)
    metrics=regime_metrics(df,regime)
    audit=stability_audit(metrics,min_regime_samples,min_coverage)
    metrics.to_csv(out/'QV-REGIME-V27-STABILITY-METRICS-001.csv',index=False)
    # Calibration is evaluated only from explicit OOS outcome rows; it never feeds back into scoring here.
    cal=empirical_oos_calibration(df.get('scenario_score',pd.Series(dtype=float)),df.get('outcome_binary',pd.Series(dtype=float)))
    curve=calibration_curve(df.get('scenario_score',pd.Series(dtype=float)),df.get('outcome_binary',pd.Series(dtype=float)))
    curve.to_csv(out/'QV-OOS-V27-CALIBRATION-CURVE-001.csv',index=False)
    audit_hash=stability_hash(metrics,audit)
    cert={'engine':'QV-REGIME-STABILITY-OOS-CALIBRATION-GATE','version':VERSION,'regime_audit':audit,'calibration':cal,'calibration_uses_oos_only':True,'score_is_not_probability':True,'no_fixed_price_prediction':True,'production_approved':False,'evidence_hash':audit_hash}
    (out/'QV-V27-EVIDENCE-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    # Upstream execution remains evidence-producing and never grants production approval.
    if audit['status']=='PASS': run_v26(df,out,**kwargs)
    return cert,metrics,curve
