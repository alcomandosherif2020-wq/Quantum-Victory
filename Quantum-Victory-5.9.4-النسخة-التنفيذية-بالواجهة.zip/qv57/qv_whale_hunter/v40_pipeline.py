from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v39_pipeline import run as run_v39
from .distributed_grid import build_grid

ENGINE='QV-WHALE-HUNTER-DISTRIBUTED-GRID'; VERSION='4.0.0'

def run(intraday_df: pd.DataFrame, historical_intraday_df=None, out_dir='QV-V40-RUN', **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    base=run_v39(intraday_df,historical_intraday_df=historical_intraday_df,out_dir=out/'v39',**kwargs)
    _,_,_,_,fusion,radar,network,outcomes=base
    grid,snapshot=build_grid(fusion,top_n=kwargs.get('top_n',20))
    grid.to_csv(out/'QV-V40-DISTRIBUTED-GRID.csv',index=False)
    snapshot.to_csv(out/'QV-V40-GRID-SNAPSHOT.csv',index=False)
    report={'engine':ENGINE,'version':VERSION,'status':'PASS','base_version':'3.9.0',
      'rows':len(grid),'symbols':int(grid.symbol.nunique()) if not grid.empty else 0,
      'grid_confirmed':int((grid.grid_state=='GRID_CONFIRMED_FLOW').sum()) if not grid.empty else 0,
      'grid_armed':int((grid.grid_state=='GRID_ARMED_FLOW').sum()) if not grid.empty else 0,
      'architecture':['V39_NETWORK_FUSION','CROSS_SYMBOL_SYNCHRONIZATION','SECTOR_SYNCHRONIZATION','LIQUIDITY_MIGRATION','GRID_CONFIRMATION','TRAP_DEFENSE','OUTCOME_REPLAY'],
      'graph_semantics':'symbol nodes with temporal, market and sector contextual relationships; no actor identity inference',
      'score_probability_separation':True,'probability_output':None,'fixed_price_target':None,
      'identity_claim':False,'evidence_only':True,'production_approved':False,'human_risk_check_required':True}
    (out/'QV-V40-CERTIFICATE.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report,grid,snapshot,base
