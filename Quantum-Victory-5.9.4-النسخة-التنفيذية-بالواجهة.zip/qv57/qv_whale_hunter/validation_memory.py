from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import pandas as pd

HORIZONS=(1,3,5,10)

def add_forward_metrics(df, horizons=HORIZONS):
    x=df.sort_values(['symbol','session_date']).copy()
    g=x.groupby('symbol', group_keys=False)
    for h in horizons:
        x[f'fwd_ret_{h}']=g['close'].shift(-h)/x['close']-1
        highs=g['high'].shift(-1)
        lows=g['low'].shift(-1)
        x[f'mfe_{h}']=highs.groupby(x['symbol']).transform(lambda s:s.rolling(h,min_periods=1).max())/x['close']-1
        x[f'mae_{h}']=lows.groupby(x['symbol']).transform(lambda s:s.rolling(h,min_periods=1).min())/x['close']-1
    return x

def build_memory(ledger, features=None):
    if ledger is None or ledger.empty: return pd.DataFrame()
    m=ledger.copy()
    m['event_key']=m['event_id'].astype(str)+'|H'+m['horizon'].astype(str)
    m['directional_return']=np.where(m['direction'].eq('BUY'),m['forward_return'],np.where(m['direction'].eq('SELL'),-m['forward_return'],np.nan))
    m['success']=np.where(m['direction'].isin(['BUY','SELL']),m['directional_return']>0,np.nan)
    cols=['event_key','event_id','symbol','session_date','sequence_state','direction','horizon','forward_return','directional_return','success','mfe','mae','evidence_count','evidence_json','false_signal_risk']
    return m[[c for c in cols if c in m.columns]].copy()

def score_memory(memory):
    if memory is None or memory.empty: return pd.DataFrame()
    rows=[]
    for (state,h),g in memory.groupby(['sequence_state','horizon']):
        r=pd.to_numeric(g['directional_return'],errors='coerce').dropna()
        if r.empty: continue
        wins=r[r>0]; losses=r[r<0]
        pf=wins.sum() / abs(losses.sum()) if len(losses) else math.inf
        rows.append({'sequence_state':state,'horizon':int(h),'n':len(r),'hit_rate':float((r>0).mean()),'mean_return':float(r.mean()),'median_return':float(r.median()),'expectancy':float(r.mean()),'mean_mfe':float(pd.to_numeric(g['mfe'],errors='coerce').mean()),'mean_mae':float(pd.to_numeric(g['mae'],errors='coerce').mean()),'profit_factor':float(pf),'best':float(r.max()),'worst':float(r.min())})
    return pd.DataFrame(rows)

def rolling_drawdown(returns):
    r=pd.Series(returns,dtype='float64').fillna(0.0)
    eq=(1+r).cumprod(); peak=eq.cummax(); dd=eq/peak-1
    return float(dd.min()) if len(dd) else 0.0

def false_signal_rate(memory):
    if memory is None or memory.empty: return np.nan
    x=memory.dropna(subset=['success'])
    return float((~x['success'].astype(bool)).mean()) if len(x) else np.nan

def chronological_walk_forward(df, train_sessions=60, test_sessions=20, step=20):
    dates=sorted(pd.to_datetime(df['session_date']).dropna().dt.normalize().unique())
    out=[]
    i=train_sessions
    while i < len(dates):
        test_end=min(i+test_sessions,len(dates))
        out.append({'train_start':str(pd.Timestamp(dates[max(0,i-train_sessions)]).date()),'train_end':str(pd.Timestamp(dates[i-1]).date()),'test_start':str(pd.Timestamp(dates[i]).date()),'test_end':str(pd.Timestamp(dates[test_end-1]).date()),'train_sessions':i-max(0,i-train_sessions),'test_sessions':test_end-i})
        i += step
    return pd.DataFrame(out)

def evaluate_oos(memory, splits, min_train_events=30):
    if memory is None or memory.empty or splits is None or splits.empty: return pd.DataFrame()
    m=memory.copy(); m['date']=pd.to_datetime(m['session_date'])
    rows=[]
    for _,s in splits.iterrows():
        tr=m[(m.date>=pd.Timestamp(s.train_start))&(m.date<=pd.Timestamp(s.train_end))]
        te=m[(m.date>=pd.Timestamp(s.test_start))&(m.date<=pd.Timestamp(s.test_end))]
        if len(tr)<min_train_events or te.empty: continue
        # No parameter fitting: this is a frozen-rule OOS audit. It reports actual OOS outcomes only.
        ret=pd.to_numeric(te.directional_return,errors='coerce').dropna()
        rows.append({'test_start':s.test_start,'test_end':s.test_end,'train_events':len(tr),'test_events':len(te),'oos_events_with_return':len(ret),'oos_hit_rate':float((ret>0).mean()) if len(ret) else np.nan,'oos_expectancy':float(ret.mean()) if len(ret) else np.nan,'oos_max_drawdown':rolling_drawdown(ret) if len(ret) else np.nan})
    return pd.DataFrame(rows)

def persist_memory(memory, path):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); memory.to_csv(p,index=False)

def load_memory(path):
    p=Path(path)
    return pd.read_csv(p) if p.exists() else pd.DataFrame()
