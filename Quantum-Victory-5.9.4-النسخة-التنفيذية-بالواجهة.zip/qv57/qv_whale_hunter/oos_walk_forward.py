from __future__ import annotations
import hashlib, json
from pathlib import Path
import pandas as pd

VERSION='2.6.0'

FORBIDDEN={'fwd_ret','forward_return','outcome','label','mfe','mae','target','future_return'}

def _norm_dates(s): return pd.to_datetime(s, errors='coerce').dt.normalize()

def audit_information_set(df, decision_col='session_date'):
    cols={str(c).lower() for c in df.columns}
    hits=sorted(c for c in cols if any(tok in c for tok in FORBIDDEN))
    return {'status':'BLOCKED_FUTURE_FIELDS' if hits else 'PASS','forbidden_fields':hits}

def make_splits(df, train_sessions=60, test_sessions=20, step=20, embargo_sessions=0, purge_sessions=0):
    dates=sorted(_norm_dates(df['session_date']).dropna().unique())
    rows=[]; i=train_sessions
    while i < len(dates):
        test_start=i; test_end=min(i+test_sessions,len(dates))
        train_end=i-purge_sessions-embargo_sessions
        train_start=max(0, train_end-train_sessions)
        if train_end>train_start and test_end>test_start:
            rows.append({'split_id':len(rows)+1,'train_start':str(pd.Timestamp(dates[train_start]).date()),'train_end':str(pd.Timestamp(dates[train_end-1]).date()),'test_start':str(pd.Timestamp(dates[test_start]).date()),'test_end':str(pd.Timestamp(dates[test_end-1]).date()),'train_sessions':train_end-train_start,'test_sessions':test_end-test_start,'purge_sessions':purge_sessions,'embargo_sessions':embargo_sessions})
        i += step
    return pd.DataFrame(rows)

def validate_splits(splits):
    if splits is None or splits.empty: return {'status':'BLOCKED_NO_SPLITS','violations':[]}
    v=[]
    for _,r in splits.iterrows():
        if pd.Timestamp(r.train_end)>=pd.Timestamp(r.test_start): v.append({'split_id':int(r.split_id),'reason':'TRAIN_TEST_OVERLAP_OR_LEAK'})
    return {'status':'PASS' if not v else 'BLOCKED_SPLIT_LEAKAGE','violations':v,'n_splits':len(splits)}

def evaluate_frozen_oos(df, splits, score_col='scenario_score', outcome_col='forward_return'):
    if not splits is None and not splits.empty:
        x=df.copy(); x['_d']=_norm_dates(x.session_date)
        rows=[]
        for _,s in splits.iterrows():
            te=x[(x._d>=pd.Timestamp(s.test_start))&(x._d<=pd.Timestamp(s.test_end))]
            if te.empty: continue
            score=pd.to_numeric(te[score_col],errors='coerce') if score_col in te else pd.Series(index=te.index,dtype=float)
            out=pd.to_numeric(te[outcome_col],errors='coerce') if outcome_col in te else pd.Series(index=te.index,dtype=float)
            m=score.notna()&out.notna()
            y=out[m]
            rows.append({'split_id':int(s.split_id),'test_start':s.test_start,'test_end':s.test_end,'test_rows':len(te),'oos_rows_with_outcome':int(m.sum()),'oos_mean_return':float(y.mean()) if len(y) else None,'oos_hit_rate':float((y>0).mean()) if len(y) else None})
        return pd.DataFrame(rows)
    return pd.DataFrame()

def evidence_hash(splits, audit):
    payload=json.dumps({'version':VERSION,'splits':splits.to_dict('records'),'audit':audit},sort_keys=True,default=str).encode()
    return hashlib.sha256(payload).hexdigest()
