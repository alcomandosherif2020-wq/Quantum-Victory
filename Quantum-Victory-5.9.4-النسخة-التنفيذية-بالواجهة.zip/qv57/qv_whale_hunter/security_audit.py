from __future__ import annotations
import hashlib, json, os, stat
from pathlib import Path

def audit_environment():
    names=['QV_TELEGRAM_BOT_TOKEN','QV_TELEGRAM_CHAT_ID','QV_ALERT_SIGNING_SECRET']
    return {n: bool(os.getenv(n)) for n in names}

def audit_path(path):
    p=Path(path)
    if not p.exists(): return {'exists':False,'secure_permissions':False}
    mode=stat.S_IMODE(p.stat().st_mode)
    return {'exists':True,'secure_permissions':(mode & 0o077)==0,'mode':oct(mode)}

def fingerprint_config(values):
    safe={k:bool(v) for k,v in values.items()}
    return hashlib.sha256(json.dumps(safe,sort_keys=True).encode()).hexdigest()
