from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v14_pipeline import run as run_v14
from .size_radar import classify_whale_size, build_whale_radar

VERSION='1.6.0'

def run(df, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    # Reuse the qualified upstream pipeline; no replacement of the existing data core.
    run_v14(df,out,**kwargs)
    features=pd.read_csv(out/'QV-WHALE-V14-FEATURES-001.csv')
    sequences=pd.read_csv(out/'QV-WHALE-V14-SEQUENCES-001.csv')
    x=features.merge(sequences[['symbol','session_date','buy_event_count','sell_event_count']],on=['symbol','session_date'],how='left')
    sized=classify_whale_size(x)
    radar=build_whale_radar(sized)
    sized.to_csv(out/'QV-WHALE-V16-SIZE-CLASSIFICATION-001.csv',index=False)
    radar.to_csv(out/'QV-WHALE-V16-MULTISIZE-RADAR-001.csv',index=False)
    counts=radar['whale_size_class'].value_counts().to_dict() if not radar.empty else {}
    report={
      'engine':'QV-WHALE-HUNTER-MULTI-SIZE-QUANTUM-RADAR','version':VERSION,'status':'PASS','production_approved':False,
      'size_classes':list(['MICRO_FLOW','SMALL_FLOW','MEDIUM_FLOW','LARGE_WHALE','MEGA_WHALE']),
      'size_counts':counts,'radar_rows':len(radar),
      'identity_claim':False,
      'principle':'Size class represents statistical footprint intensity relative to the observed symbol history; it does not identify an actor.',
      'probability_status':'NOT_CALIBRATED','recommendation_role':'EVIDENCE_TO_SCENARIO_ONLY',
      'next_gates':['REAL_EGX_DATA_QUALIFICATION','OOS_VALIDATION','REGIME_STABILITY','CALIBRATION','SHADOW','PRODUCTION_GATE']
    }
    (out/'QV-WHALE-V16-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
