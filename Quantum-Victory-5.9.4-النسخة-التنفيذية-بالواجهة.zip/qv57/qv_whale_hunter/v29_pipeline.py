from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .shadow_mode import build_shadow_ledger, shadow_evaluation, drift_check, shadow_certificate
from .production_gate import final_production_gate
from .v28_pipeline import run as run_v28

VERSION='2.9.0'

def run(df,out_dir,reference_df=None,required_checks=None,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    ledger,status=build_shadow_ledger(df)
    evaluation=shadow_evaluation(df)
    drift=drift_check(df, reference_df) if reference_df is not None else {'status':'NO_REFERENCE_SUPPLIED'}
    ledger.to_csv(out/'QV-V29-SHADOW-LEDGER-001.csv',index=False)
    gate_input=required_checks or {}
    gate=final_production_gate(**gate_input)
    # Shadow cannot self-approve production; missing/failed checks remain blocking.
    gate['checks']['shadow']= gate['checks'].get('shadow',False) and evaluation.get('status')=='PASS' and drift.get('status')=='PASS'
    # لا يجوز لوضع الظل أن يفتح الإنتاج تلقائيًا مهما اكتملت القيم.
    gate['production_approved']=False
    gate['status']='BLOCKED'
    gate['blocking_reasons']=list(dict.fromkeys(gate['blocking_reasons']+["SHADOW_MODE_CANNOT_SELF_APPROVE"]))
    gate['blocking_reasons']=[k for k,v in gate['checks'].items() if not v]
    cert={'engine':'QV-SHADOW-MODE-FINAL-PRODUCTION-GATE','version':VERSION,'ledger':status,'evaluation':evaluation,'drift':drift,'production_gate':gate,'shadow_only':True,'production_approved':False,'evidence_hash':shadow_certificate(status,evaluation,drift)}
    (out/'QV-V29-SHADOW-EVALUATION-001.json').write_text(json.dumps(evaluation,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-V29-DRIFT-AUDIT-001.json').write_text(json.dumps(drift,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-V29-PRODUCTION-GATE-001.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-V29-EVIDENCE-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    # Execute upstream evidence generation after the final gate artifact exists.
    run_v28(df,out,**kwargs)
    return cert,ledger
