from __future__ import annotations
import numpy as np, pandas as pd

VERSION='1.5.0'

def _sigmoid(z):
    z=np.clip(np.asarray(z,dtype=float),-30,30)
    return 1/(1+np.exp(-z))

def empirical_oos_calibration(scores, outcomes, min_samples=100, bins=10):
    """Calibration audit only. Fits nothing when sample is insufficient; uses OOS rows only."""
    s=pd.to_numeric(pd.Series(scores),errors='coerce'); y=pd.to_numeric(pd.Series(outcomes),errors='coerce')
    m=s.notna() & y.notna() & y.isin([0,1])
    s=s[m].to_numpy(float); y=y[m].to_numpy(float)
    if len(s)<min_samples:
        return {'status':'BLOCKED_INSUFFICIENT_OOS_SAMPLE','n':int(len(s)),'min_samples':min_samples}
    # rank/percentile mapping avoids pretending score itself is a probability
    order=np.argsort(s); ranked=np.empty(len(s)); ranked[order]=np.arange(len(s))/(len(s)-1)
    pred=_sigmoid(8*(ranked-0.5))
    brier=float(np.mean((pred-y)**2)); mae=float(np.mean(np.abs(pred-y)))
    return {'status':'PASS','n':int(len(s)),'brier':brier,'calibration_mae':mae,'method':'OOS_RANK_LOGISTIC_AUDIT','bins':bins}

def calibration_curve(scores, outcomes, bins=10):
    s=pd.to_numeric(pd.Series(scores),errors='coerce'); y=pd.to_numeric(pd.Series(outcomes),errors='coerce')
    m=s.notna() & y.notna() & y.isin([0,1])
    x=pd.DataFrame({'score':s[m],'outcome':y[m]})
    if x.empty: return pd.DataFrame(columns=['bin','n','mean_score','observed_rate'])
    x['bin']=pd.qcut(x['score'].rank(method='first'),q=min(bins,len(x)),labels=False,duplicates='drop')
    return x.groupby('bin',as_index=False).agg(n=('outcome','size'),mean_score=('score','mean'),observed_rate=('outcome','mean'))
