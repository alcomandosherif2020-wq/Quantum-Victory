from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .robustness_gate import compare_models, multiple_comparison_guard, robustness_certificate
from .v27_pipeline import run as run_v27

VERSION='2.8.0'

def run(df, out_dir, champion='champion', challenger='challenger', min_oos_rows=100, alpha=.05, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    # This layer consumes explicit OOS model outcomes only; it never mutates signal scores.
    audit=compare_models(df,champion,challenger,min_oos_rows=min_oos_rows,alpha=alpha)
    pvals=[audit.get('permutation_pvalue')]
    mc=multiple_comparison_guard(pvals,alpha=alpha)
    cert={'engine':'QV-CHAMPION-CHALLENGER-STATISTICAL-ROBUSTNESS-GATE','version':VERSION,'audit':audit,'multiple_comparison_guard':mc,'uses_oos_only':True,'score_is_not_probability':True,'no_fixed_price_prediction':True,'production_approved':False,'evidence_hash':robustness_certificate(audit,mc)}
    (out/'QV-V28-ROBUSTNESS-AUDIT-001.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-V28-MULTIPLE-COMPARISON-001.json').write_text(json.dumps(mc,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'QV-V28-EVIDENCE-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    # Upstream evidence chain is executed only after robustness evidence is available; approval remains false.
    run_v27(df,out,**kwargs)
    return cert
