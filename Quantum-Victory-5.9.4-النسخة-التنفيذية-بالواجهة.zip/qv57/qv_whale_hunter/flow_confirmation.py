from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

ENGINE='QV-FLOW-CONFIRMATION'; VERSION='1.0.0'
STATES=('WATCH','BUILDING','CONFIRMED_FLOW','FADING','INVALIDATED')

class FlowConfirmationEngine:
    def __init__(self, confirm_updates=3, fade_updates=2, invalidate_updates=3, min_score=55, strong_score=70):
        self.confirm_updates=confirm_updates; self.fade_updates=fade_updates; self.invalidate_updates=invalidate_updates
        self.min_score=min_score; self.strong_score=strong_score; self.state={}

    def update(self, row: dict) -> dict:
        sym=str(row['symbol']); score=float(row.get('sniper_score',0) or 0)
        signal=str(row.get('signal','NO_ALERT')); pressure=float(row.get('buy_pressure',0.5) or .5)
        active=signal in ('HIGH_PRIORITY_BUY_FLOW','BUY_FLOW_WATCH') and score>=self.min_score and pressure>=.60
        strong=active and score>=self.strong_score
        s=self.state.setdefault(sym,{'state':'WATCH','active':0,'fading':0,'invalid':0,'updates':0})
        s['updates']+=1
        if active:
            s['active']+=1; s['fading']=0; s['invalid']=0
            if s['active']>=self.confirm_updates: s['state']='CONFIRMED_FLOW'
            elif s['state']=='WATCH': s['state']='BUILDING'
        else:
            s['active']=0; s['fading']+=1; s['invalid']+=1
            if s['state']=='CONFIRMED_FLOW': s['state']='FADING'
            if s['state']=='FADING' and s['fading']>=self.invalidate_updates: s['state']='INVALIDATED'
            elif s['state']!='CONFIRMED_FLOW' and s['fading']>=self.invalidate_updates: s['state']='INVALIDATED'
        return {'symbol':sym,'confirmation_state':s['state'],'active_streak':s['active'],'fade_streak':s['fading'],
                'invalid_streak':s['invalid'],'confirmation_ready':s['state']=='CONFIRMED_FLOW',
                'strong_flow':strong,'evidence_only':True,'identity_claim':False}

    def process(self, scored: pd.DataFrame) -> pd.DataFrame:
        if scored is None or scored.empty: return pd.DataFrame()
        rows=[]
        for _,r in scored.sort_values(['symbol','timestamp']).iterrows(): rows.append(self.update(r.to_dict()))
        c=pd.DataFrame(rows)
        return scored.reset_index(drop=True).join(c[['confirmation_state','active_streak','fade_streak','invalid_streak','confirmation_ready','strong_flow']])

    def snapshot(self):
        return {'engine':ENGINE,'version':VERSION,'symbols':len(self.state),'states':{k:v['state'] for k,v in self.state.items()},'production_approved':False}
