from __future__ import annotations
import hashlib, json
import numpy as np, pandas as pd

VERSION='2.7.0'

def assign_regime(df, regime_col=None, ret_col='ret1', vol_col='range'):
    x=df.copy()
    if regime_col and regime_col in x:
        return x[regime_col].fillna('UNKNOWN').astype(str)
    r=pd.to_numeric(x.get(ret_col, pd.Series(index=x.index)), errors='coerce')
    v=pd.to_numeric(x.get(vol_col, pd.Series(index=x.index)), errors='coerce')
    # deterministic, descriptive fallback; never learned from outcomes
    q_r=r.quantile([.33,.67]) if r.notna().sum()>=3 else pd.Series([0,0],index=[.33,.67])
    q_v=v.quantile(.67) if v.notna().sum()>=3 else 0
    out=pd.Series('SIDEWAYS',index=x.index,dtype='object')
    out[r>q_r.loc[.67]]='UP'
    out[r<q_r.loc[.33]]='DOWN'
    if len(v):
        out[(v>q_v)&(out=='SIDEWAYS')]='HIGH_VOL'
    return out

def regime_metrics(df, regime, score_col='scenario_score', outcome_col='forward_return'):
    x=df.copy(); x['_regime']=regime
    rows=[]
    for name,g in x.groupby('_regime',dropna=False):
        s=pd.to_numeric(g[score_col],errors='coerce') if score_col in g else pd.Series(np.nan,index=g.index); y=pd.to_numeric(g[outcome_col],errors='coerce') if outcome_col in g else pd.Series(np.nan,index=g.index)
        m=s.notna()&y.notna(); yy=y[m]
        rows.append({'regime':str(name),'n_rows':int(len(g)),'n_evaluable':int(m.sum()),'mean_return':float(yy.mean()) if len(yy) else None,'hit_rate':float((yy>0).mean()) if len(yy) else None,'score_mean':float(s.mean()) if s.notna().any() else None})
    return pd.DataFrame(rows)

def stability_audit(metrics,min_regime_samples=30,min_coverage=3):
    if metrics.empty: return {'status':'BLOCKED_NO_REGIME_EVIDENCE','reason':'no regime metrics'}
    eligible=metrics[metrics.n_evaluable>=min_regime_samples]
    if len(eligible)<min_coverage: return {'status':'BLOCKED_INSUFFICIENT_REGIME_COVERAGE','eligible_regimes':int(len(eligible)),'required_regimes':min_coverage}
    rates=eligible.hit_rate.dropna()
    dispersion=float(rates.max()-rates.min()) if len(rates) else None
    return {'status':'PASS','eligible_regimes':int(len(eligible)),'min_regime_samples':min_regime_samples,'hit_rate_range':dispersion}

def stability_hash(metrics,audit):
    return hashlib.sha256(json.dumps({'version':VERSION,'metrics':metrics.to_dict('records'),'audit':audit},sort_keys=True,default=str).encode()).hexdigest()
