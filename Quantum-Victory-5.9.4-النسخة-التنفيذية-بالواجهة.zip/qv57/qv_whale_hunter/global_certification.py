from __future__ import annotations
import hashlib, json
from pathlib import Path
from datetime import datetime, timezone

VERSION='5.3.0'
REQUIRED_GATES=(
    'real_egx_qualification','leakage_audit','oos','walk_forward',
    'sample_size','regime_stability','oos_calibration',
    'champion_challenger','shadow'
)


def _sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def audit_evidence_manifest(manifest: dict) -> dict:
    """Audit the *shape* and provenance claims of an evidence manifest.
    This never treats a declaration as proof of predictive power.
    """
    if not isinstance(manifest, dict):
        return {'status':'BLOCKED_INVALID_MANIFEST','missing':['manifest']}
    required=('manifest_version','created_at','dataset_id','dataset_sha256','source_records','attestor')
    missing=[k for k in required if not manifest.get(k)]
    records=manifest.get('source_records')
    if not isinstance(records,list) or not records:
        missing.append('source_records')
    invalid_records=[]
    for i,r in enumerate(records or []):
        if not isinstance(r,dict) or not r.get('source_id') or not r.get('retrieved_at'):
            invalid_records.append(i)
    if invalid_records:
        return {'status':'BLOCKED_INVALID_MANIFEST','missing':missing,'invalid_source_records':invalid_records}
    return {'status':'PASS' if not missing else 'BLOCKED_INVALID_MANIFEST', 'missing':missing, 'source_record_count':len(records)}


def certify(gate: dict, *, evidence_manifest: dict|None=None, release_root: Path|None=None) -> dict:
    checks=(gate or {}).get('checks') if isinstance(gate,dict) else None
    if not isinstance(checks,dict):
        checks={}
    gate_contract={k: checks.get(k) is True for k in REQUIRED_GATES}
    manifest_audit=audit_evidence_manifest(evidence_manifest) if evidence_manifest is not None else {'status':'BLOCKED_NO_MANIFEST'}
    artifacts=[]
    if release_root:
        root=Path(release_root)
        for p in sorted(root.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts:
                artifacts.append({'path':str(p.relative_to(root)),'sha256':_sha256(p),'bytes':p.stat().st_size})
    all_gates=all(gate_contract.values())
    manifest_ok=manifest_audit.get('status')=='PASS'
    # Independent evidence is deliberately required before production approval.
    approved=bool(all_gates and manifest_ok and gate.get('production_approved') is True)
    payload={
        'version':VERSION,'required_gates':REQUIRED_GATES,
        'gate_contract':gate_contract,'manifest_audit':manifest_audit,
        'artifact_count':len(artifacts)
    }
    digest=hashlib.sha256(json.dumps(payload,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    return {
        'product':'Quantum Victory','certification_version':VERSION,
        'created_at_utc':datetime.now(timezone.utc).isoformat(),
        'software_integrity':'PASS','gate_contract':gate_contract,
        'all_required_gates_true':all_gates,
        'evidence_manifest_valid':manifest_ok,
        'production_approved':approved,
        'status':'APPROVED' if approved else 'BLOCKED',
        'blocking_reasons':[k for k,v in gate_contract.items() if not v] + ([] if manifest_ok else ['independent_evidence_manifest']),
        'certificate_sha256':digest,'artifacts':artifacts,
        'scientific_note':'Certification validates evidence structure and release controls; it does not establish profitability or future market performance.'
    }
