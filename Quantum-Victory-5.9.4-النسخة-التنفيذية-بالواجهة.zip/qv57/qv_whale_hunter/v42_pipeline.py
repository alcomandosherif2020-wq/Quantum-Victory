from __future__ import annotations
import json
from pathlib import Path
from .v41_pipeline import run as run_v41
from .integrated_fusion import fuse_recommendation_and_whale,build_alert_payloads
ENGINE='QV-QUANTUM-VICTORY-INTEGRATED-WHALE-RECOMMENDATION'; VERSION='4.2.0'
def run(intraday_df,recommendation_df=None,historical_intraday_df=None,out_dir='QV-V42-INTEGRATED-RUN',top_n=20,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    c,g,e,s,b=run_v41(intraday_df,historical_intraday_df=historical_intraday_df,out_dir=out/'v41',top_n=top_n,**kwargs)
    integrated=fuse_recommendation_and_whale(g,recommendation_df); alerts=build_alert_payloads(integrated,float(kwargs.get('alert_score',70)))
    integrated.to_csv(out/'QV-V42-INTEGRATED-EVIDENCE.csv',index=False); alerts.to_csv(out/'QV-V42-ALERT-QUEUE.csv',index=False)
    cert={'engine':ENGINE,'version':VERSION,'status':'PASS','base_whale_version':'4.1.0','recommendation_attached':bool(recommendation_df is not None and not recommendation_df.empty),'rows':len(integrated),'alerts':len(alerts),'flow':'RECOMMENDATION_ENGINE + WHALE_HUNTER_GRAPH -> EVIDENCE_FUSION -> ALERT_QUEUE','roles':{'recommendation':'strategic_evidence_context','whale_hunter':'intraday_liquidity_and_flow_evidence','fusion':'corroboration_conflict_trap_resolution','telegram':'downstream_transport_only'},'score_probability_separation':True,'probability_output':None,'fixed_price_target':None,'identity_claim':False,'evidence_only':True,'production_approved':False,'human_risk_check_required':True}
    (out/'QV-V42-INTEGRATION-CERTIFICATE.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    return cert,integrated,alerts
