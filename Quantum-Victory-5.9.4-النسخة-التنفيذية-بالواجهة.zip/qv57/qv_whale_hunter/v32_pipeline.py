from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v31_pipeline import run as run_v31
from .qv_core_network import build_network_packet, inspect_core, read_core_sqlite

VERSION='3.2.0'

def run(df=None, out_dir='qv_run', core_path=None, core_df=None, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    source_df = core_df if core_df is not None else df
    core_info=inspect_core(core_path) if core_path else None
    if source_df is None and core_path and str(core_path).lower().endswith('.sqlite'):
        source_df=read_core_sqlite(core_path)
    if source_df is None or len(source_df)==0:
        cert={'engine':'QV-CORE-X-WHALE-NETWORK','version':VERSION,'status':'BLOCKED','reason':'NO_CORE_DATASET_SUPPLIED','production_approved':False}
        (out/'QV-V32-NETWORK-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
        return cert, None
    upstream, normalized = run_v31(source_df,out,**kwargs)
    packet=build_network_packet(core_path or 'CORE_DF', upstream.get('certificate',{}), normalized if normalized is not None else None)
    packet['status']='PASS' if upstream.get('pipeline_status')=='PASS' else 'BLOCKED'
    (out/'QV-V32-NETWORK-CERTIFICATE-001.json').write_text(json.dumps(packet,ensure_ascii=False,indent=2),encoding='utf-8')
    return packet, normalized
