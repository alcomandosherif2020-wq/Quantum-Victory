from __future__ import annotations
import numpy as np
import pandas as pd

SIGNAL_STATES={"ACCUMULATION_SEQUENCE","DISTRIBUTION_SEQUENCE","MIXED_SEQUENCE"}


def add_forward_excursions(df, horizons=(1,3,5,10)):
    x=df.sort_values(["symbol","session_date"]).copy(); g=x.groupby("symbol",group_keys=False)
    for h in horizons:
        x[f"fwd_ret_{h}"]=g.close.shift(-h)/x.close-1
        x[f"fwd_max_{h}"]=g.high.transform(lambda s:s.shift(-1).rolling(h,min_periods=1).max())/x.close-1
        x[f"fwd_min_{h}"]=g.low.transform(lambda s:s.shift(-1).rolling(h,min_periods=1).min())/x.close-1
        x[f"mfe_{h}"]=x[f"fwd_max_{h}"]
        x[f"mae_{h}"]=x[f"fwd_min_{h}"]
    return x


def build_event_ledger(df, horizons=(1,3,5,10), lookback=5):
    x=add_forward_excursions(df,horizons); rows=[]
    for _,r in x.iterrows():
        state=r.get("sequence_state","NO_SEQUENCE")
        if state=="NO_SEQUENCE": continue
        buys=[e for e in str(r.get("buy_events","")).split("|") if e]
        sells=[e for e in str(r.get("sell_events","")).split("|") if e]
        direction="BUY" if state=="ACCUMULATION_SEQUENCE" else ("SELL" if state=="DISTRIBUTION_SEQUENCE" else "MIXED")
        evidence={"buy_events":buys,"sell_events":sells,"buy_count":len(buys),"sell_count":len(sells),"volume_z20":r.get("volume_z20"),"flow_z20":r.get("flow_z20"),"vwap_proxy":r.get("vwap_proxy")}
        base={"event_id":f"WH-{r.symbol}-{pd.Timestamp(r.session_date).strftime('%Y%m%d')}","symbol":r.symbol,"session_date":r.session_date,"sequence_state":state,"direction":direction,"evidence_json":str(evidence),"evidence_count":len(buys)+len(sells),"false_signal_risk":r.get("false_signal_risk",np.nan)}
        for h in horizons:
            z=base.copy(); z.update({"horizon":h,"forward_return":r.get(f"fwd_ret_{h}"),"mfe":r.get(f"mfe_{h}"),"mae":r.get(f"mae_{h}")}); rows.append(z)
    return pd.DataFrame(rows)


def summarize_ledger(ledger):
    if ledger is None or ledger.empty: return pd.DataFrame()
    rows=[]
    for (state,h),g in ledger.groupby(["sequence_state","horizon"]):
        r=pd.to_numeric(g.forward_return,errors="coerce").dropna(); mfe=pd.to_numeric(g.mfe,errors="coerce").dropna(); mae=pd.to_numeric(g.mae,errors="coerce").dropna()
        if r.empty: continue
        direction=1 if state=="ACCUMULATION_SEQUENCE" else (-1 if state=="DISTRIBUTION_SEQUENCE" else 0)
        strat=direction*r if direction else r
        wins=(strat>0).sum(); losses=(strat<0).sum(); gross_win=strat[strat>0].sum(); gross_loss=-strat[strat<0].sum()
        rows.append({"sequence_state":state,"horizon":h,"n":len(r),"mean_return":r.mean(),"median_return":r.median(),"directional_hit_rate":(strat>0).mean(),"mean_mfe":mfe.mean() if not mfe.empty else np.nan,"mean_mae":mae.mean() if not mae.empty else np.nan,"expectancy":strat.mean(),"profit_factor":gross_win/gross_loss if gross_loss>0 else np.inf,"worst":r.min(),"best":r.max()})
    return pd.DataFrame(rows)
