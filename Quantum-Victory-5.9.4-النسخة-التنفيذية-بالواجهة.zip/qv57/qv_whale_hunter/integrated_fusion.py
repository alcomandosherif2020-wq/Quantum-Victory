from __future__ import annotations
import hashlib, json
import numpy as np
import pandas as pd
VERSION='4.2.0'
POSTURE_MAP={'BULLISH_EVIDENCE':'BULLISH','BEARISH_EVIDENCE':'BEARISH','NEUTRAL_EVIDENCE':'NEUTRAL','BLOCKED_HIGH_TRAP_RISK':'BLOCKED','UNCONFIRMED':'UNCONFIRMED'}
def _num(s, default=0.0): return pd.to_numeric(s,errors='coerce').fillna(default)
def _latest_by_symbol(df):
    if df is None or df.empty or 'symbol' not in df.columns: return pd.DataFrame()
    x=df.copy(); t=pd.to_datetime(x.get('timestamp',x.get('session_date')),errors='coerce'); x['_t']=t; x=x.sort_values('_t')
    return x.groupby('symbol',as_index=False).tail(1).drop(columns=['_t'],errors='ignore')
def fuse_recommendation_and_whale(whale_df,recommendation_df=None):
    if whale_df is None or whale_df.empty: return pd.DataFrame()
    w=_latest_by_symbol(whale_df); r=_latest_by_symbol(recommendation_df)
    if not r.empty:
        keep=[c for c in ['symbol','recommendation_posture','action_evidence','risk_level','recommendation_confidence_state','primary_scenario','scenario_score','evidence_score','uncertainty_score','trap_penalty'] if c in r.columns]
        w=w.merge(r[keep].drop_duplicates('symbol'),on='symbol',how='left')
    defaults={'recommendation_posture':'UNCONFIRMED','action_evidence':'WAIT_FOR_CONFIRMATION','risk_level':'MEDIUM','recommendation_confidence_state':'UNCONFIRMED','primary_scenario':'UNAVAILABLE','scenario_score':np.nan,'evidence_score':np.nan,'uncertainty_score':np.nan,'trap_penalty':np.nan}
    for c,v in defaults.items(): w[c]=w[c].fillna(v) if c in w else v
    w['whale_state']=w.get('network_state',w.get('confirmation_state',pd.Series('WATCH',index=w.index))).astype(str)
    w['whale_score']=_num(w.get('propagation_score',w.get('grid_score',w.get('fusion_score',pd.Series(0,index=w.index)))))
    w['whale_direction']=w.get('migration_direction',pd.Series('BALANCED_NETWORK',index=w.index)).astype(str)
    w['trap_risk']=_num(w.get('false_whale_trap_score',pd.Series(0,index=w.index))).clip(0,100)
    rp=w.recommendation_posture.map(POSTURE_MAP).fillna('UNCONFIRMED'); ws=w.whale_state
    wb=ws.isin(['CONFIRMED_NETWORK_FLOW','CONFIRMED_FLOW','GRID_CONFIRMED_FLOW']) & w.whale_direction.isin(['INFLOW_NETWORK','INFLOW','BALANCED_NETWORK']) & (w.whale_score>=70)
    wr=ws.isin(['BLOCKED_NETWORK_RISK','GRID_FLOW_EXIT','FADING_NETWORK_FLOW','FADING','INVALIDATED']) | w.whale_direction.eq('OUTFLOW_NETWORK')
    rows=[]
    for i,row in w.iterrows():
        p=rp.loc[i]; b=bool(wb.loc[i]); q=bool(wr.loc[i]); trap=float(w.trap_risk.loc[i])
        if trap>=70: state,align,action='BLOCKED_HIGH_TRAP_RISK','TRAP_BLOCKED','NO_ACTION'
        elif p=='BULLISH' and b: state,align,action='BULLISH_EVIDENCE_CORROBORATED','BULLISH_ALIGNMENT','CONSIDER_LONG_BIAS_AFTER_INDEPENDENT_RISK_CHECK'
        elif p=='BEARISH' and q: state,align,action='BEARISH_EVIDENCE_CORROBORATED','BEARISH_ALIGNMENT','CONSIDER_EXIT_OR_AVOIDANCE_BIAS_AFTER_INDEPENDENT_RISK_CHECK'
        elif p=='BULLISH' and q: state,align,action='CONFLICTED_EVIDENCE','BULLISH_WHALE_CONFLICT','WAIT_FOR_CONFIRMATION'
        elif p=='BEARISH' and b: state,align,action='CONFLICTED_EVIDENCE','BEARISH_WHALE_CONFLICT','WAIT_FOR_CONFIRMATION'
        elif p=='NEUTRAL' and b: state,align,action='NEUTRAL_WITH_POSITIVE_FLOW_EVIDENCE','WHALE_SUPPORTS_BULLISH_ATTENTION','MONITOR_CONFIRMATION'
        elif p=='NEUTRAL' and q: state,align,action='NEUTRAL_WITH_NEGATIVE_FLOW_EVIDENCE','WHALE_SUPPORTS_RISK','MONITOR_RISK'
        else: state,align,action='UNCONFIRMED','NO_ALIGNMENT','WAIT_FOR_CONFIRMATION'
        eid='QVF42-'+hashlib.sha256(json.dumps({'symbol':row.get('symbol'),'timestamp':str(row.get('timestamp')),'alignment':align,'whale_score':round(float(row.whale_score),4),'posture':row.recommendation_posture},sort_keys=True,default=str).encode()).hexdigest()[:20].upper()
        d=row.to_dict(); d.update({'integration_state':state,'integration_alignment':align,'integration_action':action,'integration_evidence_id':eid,'integration_probability':None,'integration_fixed_price_target':None,'integration_identity_claim':False,'integration_evidence_only':True,'production_approved':False}); rows.append(d)
    return pd.DataFrame(rows)
def build_alert_payloads(integrated,min_score=70):
    if integrated is None or integrated.empty: return pd.DataFrame(columns=['alert_id','timestamp','symbol','integration_state','alignment','whale_score','recommendation_posture','action_evidence','risk_level','trap_risk','message','probability','fixed_price_target','identity_claim','evidence_only'])
    x=integrated.copy(); score=_num(x.get('whale_score',pd.Series(0,index=x.index))); elig=x[(score>=min_score)|x.integration_state.isin(['BULLISH_EVIDENCE_CORROBORATED','BEARISH_EVIDENCE_CORROBORATED','BLOCKED_HIGH_TRAP_RISK'])]
    rows=[]
    for _,r in elig.iterrows(): rows.append({'alert_id':r.integration_evidence_id,'timestamp':str(r.get('timestamp')),'symbol':r.get('symbol'),'integration_state':r.integration_state,'alignment':r.integration_alignment,'whale_score':float(r.whale_score),'recommendation_posture':r.recommendation_posture,'action_evidence':r.integration_action,'risk_level':r.risk_level,'trap_risk':float(r.trap_risk),'message':f"🦈 {r.symbol} | {r.integration_state} | Whale Evidence {float(r.whale_score):.1f}/100 | {r.integration_alignment} | Risk {r.risk_level}",'probability':None,'fixed_price_target':None,'identity_claim':False,'evidence_only':True})
    return pd.DataFrame(rows)
