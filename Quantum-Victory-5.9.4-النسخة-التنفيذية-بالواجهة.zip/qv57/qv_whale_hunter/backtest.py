from __future__ import annotations
import numpy as np
import pandas as pd

def forward_labels(df, horizons=(1,3,5,10)):
    x=df.sort_values(["symbol","session_date"]).copy(); g=x.groupby("symbol",group_keys=False)
    for h in horizons:
        x[f"fwd_ret_{h}"]=g.close.shift(-h)/x.close-1
    return x

def evaluate_signals(df, signal_col="sequence_state", states=None, horizons=(1,3,5,10)):
    x=forward_labels(df,horizons)
    states=states or sorted(x[signal_col].dropna().unique())
    out=[]
    for state in states:
        s=x[x[signal_col]==state]
        for h in horizons:
            r=s[f"fwd_ret_{h}"].dropna()
            if r.empty: continue
            out.append({"signal":state,"horizon":h,"n":len(r),"mean_return":r.mean(),"median_return":r.median(),"hit_rate":(r>0).mean(),"best":r.max(),"worst":r.min()})
    return pd.DataFrame(out)

def walk_forward_splits(df, train=250, test=60, step=60):
    dates=sorted(pd.to_datetime(df.session_date).dropna().unique()); out=[]; i=train
    while i+test<=len(dates):
        out.append((dates[:i],dates[i:i+test])); i+=step
    return out
