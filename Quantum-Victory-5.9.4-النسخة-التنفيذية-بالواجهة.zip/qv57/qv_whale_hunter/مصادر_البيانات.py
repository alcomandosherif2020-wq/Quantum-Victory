from __future__ import annotations
import os
from dataclasses import dataclass, asdict
import pandas as pd

@dataclass(frozen=True)
class مصدر:
    الاسم: str
    الرابط: str
    الأولوية: int
    المفتاح: str|None
    الحالة: str
    نوع_البيانات: str
    الأدوار: tuple[str,...] = ()
    قانوني_حسب_الإعداد: bool = False

مصادر_افتراضية = [
    مصدر('ياهو للتمويل — مصدر تحقق يومي','https://finance.yahoo.com',3,None,'مصدر عام غير رسمي للبورصة المصرية','أسعار يومية وحجم وتاريخ وإجراءات رأسمالية عند توفرها',('التاريخ','الأسعار'),False),
    مصدر('مؤشر السوق عبر منصة التحليل المرئي','https://www.tradingview.com/markets/stocks-egypt/',4,None,'مصدر عام — يحتاج تحقق شروط الاستخدام','رموز الشركات ومعلومات سوقية ومؤشرات فنية بحسب التغطية',('التاريخ','المؤشرات'),False),
    مصدر('مزود بيانات البورصة المصرية الرسمي','https://ticker.egidegypt.com',1,'QV_EGID_TOKEN','يحتاج اعتماد المزود','أسعار وحركة السوق والعمق والصفقات والأخبار والإحصاءات',('الأسعار','الصفقات','العمق','التاريخ','الأخبار','المؤشرات'),False),
    مصدر('البورصة المصرية','https://beta.egx.com.eg/ar',2,None,'مصدر رسمي عام','الأخبار والإفصاحات والمؤشرات وبيانات السوق المنشورة',('الأخبار','الإفصاحات','المؤشرات'),True),
]

def سجل_المصادر():
    extra=[]
    if os.getenv('EGXAPI_URL'): extra.append(مصدر('مزود بيانات مصرح إضافي',os.getenv('EGXAPI_URL'),5,'EGXAPI_KEY','يحتاج اعتماد المزود','لحظي بحسب العقد',('الأسعار','الصفقات','العمق','التاريخ'),False))
    if os.getenv('BORSA_URL'): extra.append(مصدر('خدمة توحيد محلية مصرح بها',os.getenv('BORSA_URL'),6,None,'تحتاج تحقق شروط المزود','بيانات موحدة',('الأسعار','الصفقات','التاريخ'),False))
    return [*مصادر_افتراضية,*extra]

def مصفوفة_الأدوار():
    rows=[]
    for s in سجل_المصادر():
        for دور in s.الأدوار:
            rows.append({'المصدر':s.الاسم,'الدور':دور,'الأولوية':s.الأولوية,'حالة الاعتماد':s.الحالة,'مصرح مبدئيا':s.قانوني_حسب_الإعداد})
    return pd.DataFrame(rows)

def حالة_المصادر():
    return {'تاريخ الفحص':pd.Timestamp.now(tz='Africa/Cairo').isoformat(),'المصادر':[asdict(x) for x in سجل_المصادر()]}
