from __future__ import annotations
import os
from dataclasses import dataclass
from datetime import datetime, time
from zoneinfo import ZoneInfo
from typing import Any

import requests

CAIRO = ZoneInfo("Africa/Cairo")
ENGINE = "QV-EGID-OFFICIAL-FEED-ADAPTER"
VERSION = "1.0.0"
DEFAULT_BASE_URL = "https://ticker.egidegypt.com"
DEFAULT_MARKETWATCH_PATH = "/api/Feed/GetEGXMarketWatch"
DEFAULT_DEPTH_PATH = "/api/Feed/GetMarketDepth"
DEFAULT_STATUS_PATH = "/api/Feed/GetMarketStatus"

@dataclass(frozen=True)
class EGIDConfig:
    base_url: str = DEFAULT_BASE_URL
    marketwatch_path: str = DEFAULT_MARKETWATCH_PATH
    depth_path: str = DEFAULT_DEPTH_PATH
    status_path: str = DEFAULT_STATUS_PATH
    token: str | None = None
    timeout: float = 8.0
    token_header: str = "Authorization"
    token_prefix: str = "Bearer"

    @classmethod
    def from_env(cls) -> "EGIDConfig":
        return cls(
            base_url=os.getenv("QV_EGID_BASE_URL", DEFAULT_BASE_URL).rstrip("/"),
            marketwatch_path=os.getenv("QV_EGID_MARKETWATCH_PATH", DEFAULT_MARKETWATCH_PATH),
            depth_path=os.getenv("QV_EGID_DEPTH_PATH", DEFAULT_DEPTH_PATH),
            status_path=os.getenv("QV_EGID_STATUS_PATH", DEFAULT_STATUS_PATH),
            token=os.getenv("QV_EGID_TOKEN") or None,
            timeout=float(os.getenv("QV_FEED_TIMEOUT", "8")),
            token_header=os.getenv("QV_EGID_TOKEN_HEADER", "Authorization"),
            token_prefix=os.getenv("QV_EGID_TOKEN_PREFIX", "Bearer"),
        )


def market_session_open(now: datetime | None = None) -> bool:
    """Conservative regular-session guard. Holidays/short sessions must be supplied by status feed."""
    now = now or datetime.now(CAIRO)
    if now.tzinfo is None:
        now = now.replace(tzinfo=CAIRO)
    if now.weekday() in (4, 5):  # Friday/Saturday
        return False
    # Regular continuous session. Special EGX calendars are still authoritative.
    return time(10, 0) <= now.timetz().replace(tzinfo=None) < time(14, 30)


def _headers(cfg: EGIDConfig) -> dict[str, str]:
    if not cfg.token:
        return {"Accept": "application/json"}
    value = f"{cfg.token_prefix} {cfg.token}" if cfg.token_prefix else cfg.token
    return {"Accept": "application/json", cfg.token_header: value}


def _get_json(cfg: EGIDConfig, path: str, params: dict[str, Any] | None = None) -> Any:
    url = cfg.base_url + (path if path.startswith("/") else "/" + path)
    r = requests.get(url, headers=_headers(cfg), params=params, timeout=cfg.timeout)
    r.raise_for_status()
    return r.json()


def _records(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("data", "result", "results", "items", "marketWatch", "marketwatch"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
            if isinstance(value, dict):
                nested = _records(value)
                if nested:
                    return nested
        return [payload]
    return []


def fetch_marketwatch(cfg: EGIDConfig | None = None, allow_closed: bool = False) -> list[dict]:
    cfg = cfg or EGIDConfig.from_env()
    if not allow_closed and not market_session_open():
        return []
    return _records(_get_json(cfg, cfg.marketwatch_path))


def fetch_depth(cfg: EGIDConfig | None = None, symbol: str | None = None, allow_closed: bool = False) -> list[dict]:
    cfg = cfg or EGIDConfig.from_env()
    if not allow_closed and not market_session_open():
        return []
    params = {"symbol": symbol} if symbol else None
    return _records(_get_json(cfg, cfg.depth_path, params=params))


def fetch_status(cfg: EGIDConfig | None = None) -> Any:
    cfg = cfg or EGIDConfig.from_env()
    return _get_json(cfg, cfg.status_path)
