from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
VERSION='5.4.0'

def canonical(d): return json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str)

def seal_decision(decision, previous_hash='GENESIS'):
    body={'version':VERSION,'created_at_utc':datetime.now(timezone.utc).isoformat(),'previous_hash':previous_hash,'decision':decision}
    body['record_hash']=hashlib.sha256(canonical(body).encode()).hexdigest()
    return body

def verify_chain(records):
    prev='GENESIS'
    for r in records:
        expected=hashlib.sha256(canonical({k:v for k,v in r.items() if k!='record_hash'}).encode()).hexdigest()
        if r.get('previous_hash')!=prev or r.get('record_hash')!=expected:
            return {'status':'BLOCKED','index':records.index(r)}
        prev=r['record_hash']
    return {'status':'PASS','records':len(records),'head':prev}
