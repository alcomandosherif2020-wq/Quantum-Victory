from __future__ import annotations
import json
from pathlib import Path
from .live_feed_adapters import ProviderConfig,poll_provider
from .live_session_engine import LiveSessionEngine
ENGINE='QV-LIVE-EGX-SNIPER-NETWORK'; VERSION='3.6.0'
def run_http(provider_url,provider_name='CUSTOM_EGX_FEED',headers=None,duration=30,interval=1,out_dir='QV-LIVE-V36-RUN',daily_baseline=None,**kwargs):
    engine=LiveSessionEngine(out_dir=out_dir,**kwargs); batches=[]
    def cb(batch):
        a=engine.process(batch,daily_baseline=daily_baseline)
        if not a.empty: print(a[['symbol','timestamp','signal','sniper_score']].to_string(index=False))
        batches.append(batch)
    poll_provider(ProviderConfig(provider_name,provider_url,headers=headers),seconds=interval,duration=duration,on_batch=cb)
    report=engine.snapshot()|{'provider':provider_name,'mode':'http_polling','batches':len(batches),'rows_received':sum(map(len,batches))}
    Path(out_dir,'QV-V36-LIVE-REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8'); return report
