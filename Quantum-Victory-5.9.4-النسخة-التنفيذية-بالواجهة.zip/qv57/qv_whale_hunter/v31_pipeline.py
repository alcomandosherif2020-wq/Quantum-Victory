from __future__ import annotations
import json
from pathlib import Path
from .egx_evidence_adapter import reconcile_egx
from .v30_pipeline import run as run_v30
VERSION='3.1.0'

def run(df,out_dir,session_calendar=None,universe_history=None,corporate_actions=None,asof=None,source_id='UNSPECIFIED',source_version='UNSPECIFIED',adjusted=False,corporate_action_lineage_present=False,**kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    result,norm=reconcile_egx(df,session_calendar,universe_history,corporate_actions,asof)
    cert={'engine':'QV-EGX-EVIDENCE-ADAPTER','version':VERSION,'status':result.status,'rows':result.rows,'symbols':result.symbols,'missing_sessions':result.missing_sessions,'universe_issues':result.universe_issues,'corporate_action_issues':result.corporate_action_issues,'blocking_reasons':list(result.blocking_reasons),'input_fingerprint':result.fingerprint,'production_approved':False}
    cert['certificate_hash']=__import__('hashlib').sha256(json.dumps(cert,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    (out/'QV-V31-EGX-EVIDENCE-CERTIFICATE-001.json').write_text(json.dumps(cert,ensure_ascii=False,indent=2),encoding='utf-8')
    if result.status!='PASS': return {'version':VERSION,'certificate':cert,'pipeline_status':'BLOCKED','production_approved':False}, norm
    upstream=run_v30(norm,out,asof=asof,source_id=source_id,source_version=source_version,adjusted=adjusted,corporate_action_lineage_present=corporate_action_lineage_present,**kwargs)
    return {'version':VERSION,'certificate':cert,'pipeline_status':'PASS','production_approved':False,'upstream':upstream[0]}, upstream[1]
