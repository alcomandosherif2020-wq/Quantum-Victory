from __future__ import annotations
import hashlib, json, re
from pathlib import Path
from datetime import datetime, timezone

VERSION='5.2.0'

REQUIRED_GATES=(
    'real_egx_qualification','leakage_audit','oos','walk_forward',
    'sample_size','regime_stability','oos_calibration',
    'champion_challenger','shadow'
)

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()

def audit_gate_contract(gate: dict) -> dict:
    checks=gate.get('checks') if isinstance(gate,dict) else None
    if not isinstance(checks,dict):
        return {'status':'BLOCKED_INVALID_GATE_ARTIFACT','missing':list(REQUIRED_GATES)}
    missing=[k for k in REQUIRED_GATES if k not in checks]
    non_bool=[k for k in REQUIRED_GATES if k in checks and not isinstance(checks[k],bool)]
    approved=all(checks.get(k) is True for k in REQUIRED_GATES) and gate.get('production_approved') is True
    return {
        'status':'PASS' if not missing and not non_bool else 'BLOCKED_INVALID_GATE_ARTIFACT',
        'missing':missing,'non_boolean':non_bool,
        'all_required_checks_true':all(checks.get(k) is True for k in REQUIRED_GATES),
        'declared_production_approved':bool(gate.get('production_approved') is True),
        'effective_production_approved':bool(approved)
    }

def build_release_certificate(root: Path, gate_path: Path|None=None) -> dict:
    root=Path(root)
    files=[]
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.name != 'QV-5.2-RELEASE-CERTIFICATE.json' and '.pytest_cache' not in p.parts and '__pycache__' not in p.parts:
            files.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha256_file(p)})
    gate_audit=None
    if gate_path and gate_path.exists():
        gate=json.loads(gate_path.read_text(encoding='utf8'))
        gate_audit=audit_gate_contract(gate)
    payload={'version':VERSION,'file_count':len(files),'files':files,'gate_audit':gate_audit}
    digest=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return {
        'product':'Quantum Victory', 'release':'5.2.0',
        'build_time_utc':datetime.now(timezone.utc).isoformat(),
        'artifact_integrity':'PASS','artifact_count':len(files),
        'evidence_hash':digest,'gate_audit':gate_audit,
        'production_approved':False,
        'release_policy':'Research/release artifact only until independently evidenced production gates pass.',
        'files':files
    }
