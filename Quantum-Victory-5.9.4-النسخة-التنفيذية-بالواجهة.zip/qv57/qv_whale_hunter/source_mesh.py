from __future__ import annotations
import json, os, time, hashlib
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable
import pandas as pd
import requests

ENGINE='QV-SOURCE-MESH'
VERSION='1.0.0'

@dataclass(frozen=True)
class SourceSpec:
    name: str
    url: str
    mode: str='rest'
    priority: int=50
    requires_key: bool=False
    key_env: str|None=None
    enabled: bool=True
    legal_status: str='provider_terms_required'
    coverage: str='quote'
    timeout: float=6.0

class SourceMesh:
    """Lawful multi-source EGX data mesh. No scraping bypass, credential theft, or reverse engineering."""
    def __init__(self, specs: Iterable[SourceSpec], state_dir='QV-SOURCE-MESH-RUN', session=None):
        self.specs=sorted([s for s in specs if s.enabled], key=lambda x:x.priority)
        self.state=Path(state_dir); self.state.mkdir(parents=True, exist_ok=True)
        self.session=session or requests.Session()
        self.last_good={}

    @staticmethod
    def _headers(spec: SourceSpec):
        h={'Accept':'application/json','User-Agent':'QuantumVictory-SourceMesh/1.0'}
        if spec.requires_key and spec.key_env:
            key=os.getenv(spec.key_env)
            if key: h['Authorization']=f'Bearer {key}'
        return h

    def fetch(self, spec: SourceSpec, params=None):
        r=self.session.get(spec.url, headers=self._headers(spec), params=params, timeout=spec.timeout)
        r.raise_for_status()
        return r.json()

    def health(self, spec: SourceSpec):
        started=time.monotonic()
        try:
            payload=self.fetch(spec)
            return {'source':spec.name,'ok':True,'latency_ms':round((time.monotonic()-started)*1000,2),'payload_type':type(payload).__name__}
        except Exception as e:
            return {'source':spec.name,'ok':False,'latency_ms':round((time.monotonic()-started)*1000,2),'error':type(e).__name__,'detail':str(e)[:180]}

    @staticmethod
    def extract_records(payload: Any) -> list[dict]:
        if isinstance(payload,list): return [x for x in payload if isinstance(x,dict)]
        if isinstance(payload,dict):
            for k in ('data','result','results','items','quotes','trades','marketWatch','stocks','symbols'):
                v=payload.get(k)
                if isinstance(v,list): return [x for x in v if isinstance(x,dict)]
                if isinstance(v,dict):
                    nested=SourceMesh.extract_records(v)
                    if nested: return nested
            return [payload]
        return []

    @staticmethod
    def normalize(records: Iterable[dict], source: str) -> pd.DataFrame:
        rows=[]
        for r in records:
            if not isinstance(r,dict): continue
            row={
              'symbol': r.get('symbol') or r.get('ticker') or r.get('code') or r.get('Symbol'),
              'timestamp': r.get('timestamp') or r.get('time') or r.get('datetime') or r.get('dateTime'),
              'price': r.get('price') if r.get('price') is not None else (r.get('last') if r.get('last') is not None else r.get('Last')),
              'volume': r.get('volume') if r.get('volume') is not None else (r.get('qty') if r.get('qty') is not None else r.get('Volume')),
              'bid': r.get('bid') if r.get('bid') is not None else r.get('Bid'),
              'ask': r.get('ask') if r.get('ask') is not None else r.get('Ask'),
              'turnover': r.get('turnover') if r.get('turnover') is not None else r.get('value'),
              'source': source,
            }
            rows.append(row)
        df=pd.DataFrame(rows)
        if df.empty: return pd.DataFrame(columns=['symbol','timestamp','price','volume','bid','ask','turnover','source'])
        df['timestamp']=pd.to_datetime(df['timestamp'],errors='coerce')
        for c in ['price','volume','bid','ask','turnover']:
            df[c]=pd.to_numeric(df[c],errors='coerce')
        df=df.dropna(subset=['symbol','timestamp','price','volume'])
        # Hard data-quality gates: impossible prices/negative volumes are rejected.
        df=df[(df.price>0) & (df.volume>=0)]
        if {'bid','ask'}.issubset(df.columns):
            df=df[(df.bid.isna()) | (df.ask.isna()) | ((df.bid>=0)&(df.ask>=0)&(df.ask>=df.bid))]
        return df.sort_values(['symbol','timestamp']).drop_duplicates(['symbol','timestamp','price','volume','source']).reset_index(drop=True)

    def collect(self, max_sources=None, params=None):
        selected=self.specs[:max_sources] if max_sources else self.specs
        batches=[]; health=[]
        for spec in selected:
            h=self.health(spec); health.append(h)
            if not h['ok']: continue
            try:
                recs=self.extract_records(self.fetch(spec,params=params))
                df=self.normalize(recs,spec.name)
                if not df.empty:
                    batches.append(df); self.last_good[spec.name]=time.time()
            except Exception as e:
                health[-1]['ok']=False; health[-1]['error']=type(e).__name__; health[-1]['detail']=str(e)[:180]
        merged=pd.concat(batches,ignore_index=True) if batches else pd.DataFrame(columns=['symbol','timestamp','price','volume','bid','ask','turnover','source'])
        merged=self.reconcile(merged)
        report={'engine':ENGINE,'version':VERSION,'timestamp':pd.Timestamp.utcnow().isoformat(),'sources':health,'rows':len(merged),'production_approved':False}
        (self.state/'source_health.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        return merged, report

    @staticmethod
    def reconcile(df: pd.DataFrame) -> pd.DataFrame:
        if df.empty: return df
        # Keep every source row for provenance; create a consensus row only when >=2 sources agree closely.
        out=[]
        for (sym,ts), g in df.groupby(['symbol','timestamp'],sort=True):
            g=g.copy()
            if len(g)>1:
                med=float(g.price.median())
                spread=(float(g.price.max())-float(g.price.min()))/med if med else 1.0
                g['cross_source_spread']=spread
                g['consensus']=spread<=0.01
            else:
                g['cross_source_spread']=pd.NA; g['consensus']=pd.NA
            out.append(g)
        return pd.concat(out,ignore_index=True)

    def manifest(self):
        data={'engine':ENGINE,'version':VERSION,'sources':[asdict(s) for s in self.specs],
              'security':['environment_only_secrets','no_reverse_engineering','provider_terms_required','data_validation','cross_source_reconciliation','provenance_preservation'],
              'production_approved':False}
        (self.state/'QV-SOURCE-MESH-MANIFEST.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        return data

    def fingerprint(self, df):
        payload=df.to_json(orient='records',date_format='iso').encode()
        return hashlib.sha256(payload).hexdigest()
