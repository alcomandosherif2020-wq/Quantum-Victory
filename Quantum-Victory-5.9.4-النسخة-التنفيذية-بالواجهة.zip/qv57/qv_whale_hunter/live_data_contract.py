from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
import pandas as pd

REQUIRED = ['symbol','session_date','open','high','low','close','volume']
PROHIBITED = {'future_return','forward_return','label','outcome','mfe','mae','target','prediction_target'}

@dataclass(frozen=True)
class IntakeResult:
    status: str
    blocking_reasons: tuple[str, ...]
    warnings: tuple[str, ...]
    rows: int
    symbols: int
    fingerprint: str


def _sha(obj: Any) -> str:
    raw=json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode()
    return hashlib.sha256(raw).hexdigest()


def validate_intake(df: pd.DataFrame, source_id: str, source_version: str,
                    asof: str | None = None, adjusted: bool = False,
                    corporate_action_lineage_present: bool = False) -> IntakeResult:
    reasons=[]; warnings=[]
    if not source_id or not source_version:
        reasons.append('SOURCE_ID_VERSION_REQUIRED')
    missing=[c for c in REQUIRED if c not in df.columns]
    if missing: reasons.append('MISSING_REQUIRED_COLUMNS:'+','.join(missing))
    prohibited=sorted(set(df.columns)&PROHIBITED)
    if prohibited: reasons.append('PROHIBITED_OUTCOME_FIELDS:'+','.join(prohibited))
    if adjusted and not corporate_action_lineage_present:
        reasons.append('ADJUSTED_DATA_WITHOUT_CORPORATE_ACTION_LINEAGE')
    if not df.empty:
        dup=df.duplicated(['symbol','session_date']).sum() if all(c in df.columns for c in ['symbol','session_date']) else 0
        if dup: reasons.append(f'DUPLICATE_BUSINESS_KEYS:{int(dup)}')
        if all(c in df.columns for c in ['session_date','open','high','low','close','volume']):
            d=pd.to_datetime(df['session_date'],errors='coerce')
            if d.isna().any(): reasons.append('INVALID_SESSION_DATE')
            bad=(df['high']<df[['open','close']].max(axis=1)) | (df['low']>df[['open','close']].min(axis=1)) | (df[['open','high','low','close']]<=0).any(axis=1) | (df['volume']<0)
            if bad.any(): reasons.append(f'OHLCV_INVARIANT_FAILURE:{int(bad.sum())}')
            if asof is not None:
                cutoff=pd.Timestamp(asof)
                if (d>cutoff).any(): reasons.append(f'ROWS_AFTER_ASOF:{int((d>cutoff).sum())}')
    else:
        warnings.append('EMPTY_INTAKE')
    payload={'source_id':source_id,'source_version':source_version,'rows':len(df),'columns':list(df.columns),'symbols':sorted(map(str,df['symbol'].dropna().unique())) if 'symbol' in df else []}
    fp=_sha(payload)
    return IntakeResult('BLOCKED' if reasons else 'PASS',tuple(reasons),tuple(warnings),len(df),int(df['symbol'].nunique()) if 'symbol' in df else 0,fp)


def build_intake_certificate(result: IntakeResult, source_id: str, source_version: str, captured_at: str | None=None) -> dict:
    ts=captured_at or datetime.now(timezone.utc).isoformat()
    cert={'engine':'QV-LIVE-DATA-INTAKE-CONTRACT','version':'3.0.0','source_id':source_id,'source_version':source_version,
          'captured_at_utc':ts,'status':result.status,'blocking_reasons':list(result.blocking_reasons),
          'warnings':list(result.warnings),'rows':result.rows,'symbols':result.symbols,'input_fingerprint':result.fingerprint,
          'production_approved':False,'evidence_only':True}
    cert['certificate_hash']=_sha(cert)
    return cert
