from __future__ import annotations
import pandas as pd

CANONICAL_REQUIRED=["session_date","symbol","open","high","low","close","volume","source_id","source_version","eligibility_time","row_fingerprint"]
OPTIONAL=["session_timestamp","security_name","market","sector","adjusted_close","turnover","currency","price_unit","is_adjusted","corporate_action_id","source_event_time","source_publication_time","source_arrival_time","data_quality_status"]

def adapt_canonical(df, require_provenance=True):
    x=df.copy(); req=CANONICAL_REQUIRED if require_provenance else CANONICAL_REQUIRED[:7]
    missing=[c for c in req if c not in x.columns]
    if missing: raise ValueError("MISSING_CANONICAL_COLUMNS:"+",".join(missing))
    x["session_date"]=pd.to_datetime(x["session_date"],errors="coerce")
    for c in ["open","high","low","close","volume"]: x[c]=pd.to_numeric(x[c],errors="coerce")
    bad=x["session_date"].isna() | x[["open","high","low","close","volume"]].isna().any(axis=1)
    bad |= x.volume<0
    bad |= x.high < x[["open","close"]].max(axis=1)
    bad |= x.low > x[["open","close"]].min(axis=1)
    x["adapter_status"]=bad.map({True:"REJECT",False:"ACCEPT"})
    return x
