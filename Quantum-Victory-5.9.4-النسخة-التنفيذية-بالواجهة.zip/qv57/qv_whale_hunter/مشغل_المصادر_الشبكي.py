from __future__ import annotations
import json, time
from dataclasses import dataclass, asdict
from typing import Callable, Dict, Any

@dataclass
class تعريف_مصدر:
    الاسم: str
    الرابط: str
    الدور: str
    نوع_البيانات: str
    قانوني: bool = True
    موصول: bool = False

class مشغل_المصادر_الشبكي:
    """طبقة تشغيل شبكي قابلة للتركيب؛ لا تتجاوز الحماية ولا تدّعي الاتصال."""
    def __init__(self):
        self.المصادر: Dict[str, تعريف_مصدر] = {}

    def سجل(self, الاسم: str, الرابط: str, الدور: str, نوع_البيانات: str, قانوني: bool = True):
        self.المصادر[الاسم] = تعريف_مصدر(الاسم, الرابط, الدور, نوع_البيانات, قانوني, False)

    def نفذ(self, الاسم: str, دالة: Callable[[], Dict[str, Any]]) -> Dict[str, Any]:
        if الاسم not in self.المصادر:
            return {"الحالة": "غير_مسجل"}
        if not self.المصادر[الاسم].قانوني:
            return {"الحالة": "محظور_قانونيًا"}
        بدأ = time.time()
        try:
            نتيجة = دالة()
            self.المصادر[الاسم].موصول = True
            return {"الحالة": "نجح", "الزمن": time.time()-بدأ, "البيانات": نتيجة}
        except Exception as e:
            self.المصادر[الاسم].موصول = False
            return {"الحالة": "فشل", "الخطأ": str(e), "الزمن": time.time()-بدأ}

    def حالة(self):
        return {k: asdict(v) for k,v in self.المصادر.items()}
