from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v17_pipeline import run as run_v17
from .false_whale import apply_false_whale_defense

VERSION='1.8.0'

def run(df, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    run_v17(df,out,**kwargs)
    life=pd.read_csv(out/'QV-WHALE-V17-LIFECYCLE-001.csv')
    # Reattach the upstream evidence columns so downstream defense/fusion never loses
    # the institutional-flow, technical, market and sequence context.
    size=pd.read_csv(out/'QV-WHALE-V16-SIZE-CLASSIFICATION-001.csv')
    radar=pd.read_csv(out/'QV-WHALE-V16-MULTISIZE-RADAR-001.csv')
    base=size.merge(radar[['symbol','session_date','whale_radar_score','radar_direction','radar_rank']],on=['symbol','session_date'],how='left')
    lifecycle_cols=['symbol','session_date','lifecycle_episode_id','lifecycle_phase','previous_phase','phase_age','episode_age','phase_changed','episode_started','episode_ended','tracking_note']
    lifecycle_cols=[c for c in lifecycle_cols if c in life.columns]
    base=base.merge(life[lifecycle_cols],on=['symbol','session_date'],how='left')
    defended=apply_false_whale_defense(base)
    defended.to_csv(out/'QV-WHALE-V18-DEFENSE-001.csv',index=False)
    summary=(defended.groupby(['symbol','false_whale_label'],dropna=False)
             .agg(rows=('symbol','size'),mean_trap_score=('false_whale_trap_score','mean'),
                  mean_defended_score=('defended_radar_score','mean'),blocks=('defense_action',lambda s:int((s=='BLOCK').sum())),
                  downgrades=('defense_action',lambda s:int((s=='DOWNGRADE').sum())))
             .reset_index())
    summary.to_csv(out/'QV-WHALE-V18-DEFENSE-SUMMARY-001.csv',index=False)
    report={'engine':'QV-WHALE-HUNTER-FALSE-WHALE-DEFENSE','version':VERSION,'status':'PASS','production_approved':False,
            'rows_defended':len(defended),'blocks':int((defended.defense_action=='BLOCK').sum()),
            'downgrades':int((defended.defense_action=='DOWNGRADE').sum()),
            'future_outcomes_used':False,
            'principle':'Defense detects patterns inconsistent with clean institutional-footprint evidence; it does not identify actors.',
            'next_gates':['MARKET_SECTOR_FUSION','SCENARIO_FUSION','REAL_EGX_OOS','CALIBRATION','SHADOW','PRODUCTION_GATE']}
    (out/'QV-WHALE-V18-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
