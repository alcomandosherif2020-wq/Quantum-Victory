from __future__ import annotations
import hashlib, json
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd

الأعمدة_الأساسية=['التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الحجم']

class مجمع_التاريخ:
    """طبقة إدخال تاريخي: توحيد، فحص سلامة، إزالة تكرار، وسجل مصدر قبل التحليل."""
    def __init__(self, مجلد='تشغيل-كوانتوم-فيكتوري/التاريخ'):
        self.المجلد=Path(مجلد); self.المجلد.mkdir(parents=True,exist_ok=True)

    @staticmethod
    def توحيد(df):
        if df is None: return pd.DataFrame(), {'سليم':False,'الأسباب':['لا توجد بيانات']}
        x=df.copy()
        aliases={'date':'التاريخ','datetime':'التاريخ','open':'الافتتاح','high':'الأعلى','low':'الأدنى','close':'الإغلاق','volume':'الحجم','symbol':'الرمز'}
        x=x.rename(columns={k:v for k,v in aliases.items() if k in x.columns})
        missing=[c for c in الأعمدة_الأساسية if c not in x.columns]
        if missing: return pd.DataFrame(), {'سليم':False,'الأسباب':[f'أعمدة مفقودة: {", ".join(missing)}']}
        x['التاريخ']=pd.to_datetime(x['التاريخ'],errors='coerce')
        for c in الأعمدة_الأساسية[1:]: x[c]=pd.to_numeric(x[c],errors='coerce')
        قبل=len(x); x=x.dropna(subset=الأعمدة_الأساسية).copy()
        x=x[(x['الافتتاح']>0)&(x['الأعلى']>0)&(x['الأدنى']>0)&(x['الإغلاق']>0)&(x['الحجم']>=0)]
        x=x[(x['الأعلى']>=x[['الافتتاح','الإغلاق','الأدنى']].max(axis=1)) & (x['الأدنى']<=x[['الافتتاح','الإغلاق','الأعلى']].min(axis=1))]
        مفاتيح=['التاريخ']+(['الرمز'] if 'الرمز' in x.columns else [])
        تكرارات=int(x.duplicated(مفاتيح).sum()); x=x.drop_duplicates(مفاتيح,keep='last').sort_values(مفاتيح).reset_index(drop=True)
        تقرير={'سليم':True,'عدد_المدخلات':قبل,'عدد_السجلات_الصالحة':len(x),'السجلات_المكررة':تكرارات,'الفترة_الأولى':str(x['التاريخ'].min()) if len(x) else None,'الفترة_الأخيرة':str(x['التاريخ'].max()) if len(x) else None,'الأسباب':[]}
        if len(x)==0: تقرير.update({'سليم':False,'الأسباب':['لم تبق سجلات صالحة بعد فحص الأسعار والحجم']})
        return x,تقرير

    def حفظ(self, df, مصدر, نسخة_المصدر=None, مسار='السجل_التاريخي.csv'):
        x,فحص=self.توحيد(df)
        وصول=datetime.now(timezone.utc).isoformat()
        بصمة=hashlib.sha256(x.to_csv(index=False).encode('utf-8')).hexdigest() if len(x) else None
        سجل={'وقت_الوصول':وصول,'المصدر':مصدر,'نسخة_المصدر':نسخة_المصدر,'بصمة_البيانات':بصمة,'الفحص':فحص}
        (self.المجلد/'سجل_المصادر_التاريخية.jsonl').open('a',encoding='utf-8').write(json.dumps(سجل,ensure_ascii=False)+'\n')
        if فحص['سليم']: x.to_csv(self.المجلد/مسار,index=False,encoding='utf-8-sig')
        return x,سجل
