# -*- coding: utf-8 -*-
"""كوانتوم فيكتوري 4.23 — مركز القيادة التشغيلي.
يجمع حالة المصادر والتشغيل والجاهزية والأدلة في لقطة واحدة قابلة للعرض.
لا يفتح الإنتاج ولا يخترع بيانات سوق.
"""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Any

class مركز_القيادة_التشغيلي:
    def __init__(self, لوحة=None, مربط=None, مراقب=None, محرك=None):
        self.لوحة=لوحة
        self.مربط=مربط
        self.مراقب=مراقب
        self.محرك=محرك

    @staticmethod
    def _تصنيف(الموانع: list[str], متصل: bool, انتاج=False) -> str:
        if انتاج:
            return "غير_مسموح"
        if الموانع:
            return "محجوب"
        if not متصل:
            return "غير_موصول"
        return "مراقبة"

    def لقطة(self) -> dict[str, Any]:
        لوحة = self.لوحة.لقطة() if self.لوحة and hasattr(self.لوحة, "لقطة") else {}
        مركز = self.مربط.تقرير() if self.مربط and hasattr(self.مربط, "تقرير") else {}
        مراقب = self.مراقب.تقرير() if self.مراقب and hasattr(self.مراقب, "تقرير") else لوحة.get("المراقب", {})
        محرك = self.محرك.ملخص() if self.محرك and hasattr(self.محرك, "ملخص") else لوحة.get("المحرك", {})
        آخر = مراقب.get("آخر_لقطة", {}) if isinstance(مراقب, dict) else {}
        موانع = list(آخر.get("الأسباب_المانعة", []) or []) if isinstance(آخر, dict) else []
        المصادر = مركز.get("المصادر", {}) if isinstance(مركز, dict) else {}
        متصل = any(isinstance(v, dict) and v.get("الحالة") in {"ناجح", "مراقبة"} for v in المصادر.values()) if المصادر else False
        return {
            "الإصدار": "4.23",
            "وقت_اللقطة": datetime.now(timezone.utc).isoformat(),
            "الحالة_العامة": self._تصنيف(موانع, متصل, False),
            "الإنتاج_مصرح": False,
            "جاهزية_المعالجة": bool(آخر.get("جاهزية_المعالجة", False)),
            "جاهزية_التنبيه": bool(آخر.get("جاهزية_التنبيه", False)),
            "عدد_الموانع": len(موانع),
            "الموانع": موانع,
            "المصادر": المصادر,
            "المراقب": مراقب,
            "المحرك": محرك,
            "رسالة_السلامة": "مركز القيادة يجمع الأدلة التشغيلية فقط؛ لا يثبت اتصالًا حيًا ولا يمنح تصريح الإنتاج."
        }
