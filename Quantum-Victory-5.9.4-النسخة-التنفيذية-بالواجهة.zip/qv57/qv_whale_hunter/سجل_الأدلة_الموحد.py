from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Iterable
import pandas as pd


def _رقم(value, default=0.0):
    try:
        v = float(value)
        return v if pd.notna(v) else default
    except Exception:
        return default


def بصمة_السجل(record: dict) -> str:
    keys = ('الرمز','التاريخ','المصدر','نوع_الدليل','القيمة','حالة_الجودة')
    raw = '|'.join(str(record.get(k,'')) for k in keys)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def بناء_سجل_موحد(بيانات_سعرية: pd.DataFrame|None, تحليلات=None, أحداث=None, أدلة_سيولة=None):
    rows=[]
    price = بيانات_سعرية.copy() if isinstance(بيانات_سعرية, pd.DataFrame) else pd.DataFrame()
    if not price.empty:
        price['التاريخ'] = pd.to_datetime(price.get('التاريخ'), errors='coerce').dt.normalize()
        for _, r in price.dropna(subset=['التاريخ']).iterrows():
            rows.append({'الرمز':r.get('الرمز'), 'التاريخ':r['التاريخ'].date().isoformat(), 'المصدر':r.get('المصدر','بيانات سعرية'),
                         'نوع_الدليل':'سعر وحجم', 'القيمة':_رقم(r.get('الإغلاق')), 'حالة_الجودة':'مقبول'})
    for item in تحليلات or []:
        x=dict(item); d=pd.to_datetime(x.get('التاريخ'),errors='coerce')
        if pd.isna(d): continue
        rows.append({'الرمز':x.get('الرمز'), 'التاريخ':d.normalize().date().isoformat(), 'المصدر':x.get('المصدر','محرك التحليل الفني'),
                     'نوع_الدليل':'تحليل فني', 'القيمة':_رقم(x.get('درجة الأدلة',x.get('درجة_الأدلة'))), 'حالة_الجودة':'مقبول'})
    for e in أحداث or []:
        x=dict(e); d=pd.to_datetime(x.get('تاريخ_النشر') or x.get('التاريخ'),errors='coerce')
        if pd.isna(d): continue
        rows.append({'الرمز':x.get('الرمز'), 'التاريخ':d.normalize().date().isoformat(), 'المصدر':x.get('المصدر','البورصة المصرية'),
                     'نوع_الدليل':'خبر أو إفصاح', 'القيمة':_رقم(x.get('درجة_الأثر_الرقمية')), 'حالة_الجودة':'يحتاج قراءة المحتوى'})
    for item in أدلة_سيولة or []:
        x=dict(item); d=pd.to_datetime(x.get('timestamp') or x.get('التاريخ'),errors='coerce')
        if pd.isna(d): continue
        rows.append({'الرمز':x.get('symbol') or x.get('الرمز'), 'التاريخ':d.isoformat(), 'المصدر':x.get('source','محرك السيولة'),
                     'نوع_الدليل':'سيولة وتدفق', 'القيمة':_رقم(x.get('hunter_conviction',x.get('fusion_score'))), 'حالة_الجودة':'مقبول'})
    seen=set(); out=[]
    for r in rows:
        r['بصمة']=بصمة_السجل(r)
        if r['بصمة'] not in seen:
            seen.add(r['بصمة']); out.append(r)
    out.sort(key=lambda z:(str(z.get('الرمز')),str(z.get('التاريخ')),str(z.get('نوع_الدليل'))))
    return out


def تعارض_الأدلة(السجلات: Iterable[dict]) -> dict:
    rows=list(السجلات or [])
    bullish=0.0; bearish=0.0; warnings=[]
    for r in rows:
        typ=r.get('نوع_الدليل',''); v=_رقم(r.get('القيمة'))
        if typ=='تحليل فني':
            bullish += max(v,0); bearish += max(-v,0)
        elif typ=='سيولة وتدفق':
            bullish += max(v,0); bearish += max(-v,0)
        elif typ=='خبر أو إفصاح' and v>=3:
            warnings.append('حدث مرتفع الأثر يحتاج قراءة الإفصاح الكامل')
    if bullish and bearish:
        الحالة='أدلة متعارضة'
    elif bullish>bearish:
        الحالة='أدلة إيجابية'
    elif bearish>bullish:
        الحالة='أدلة سلبية'
    else:
        الحالة='أدلة غير كافية'
    return {'الحالة':الحالة,'قوة_إيجابية':round(bullish,6),'قوة_سلبية':round(bearish,6),
            'تنبيهات':sorted(set(warnings)),'احتمال':None,'هدف_ثابت':None,
            'قرار_إنتاجي':False,'يتطلب_مراجعة_بشرية':True}


def حفظ_سجل_موحد(السجلات, التعارض, مسار='تشغيل-كوانتوم-فيكتوري/سجل_الأدلة_الموحد.json'):
    p=Path(مسار); p.parent.mkdir(parents=True,exist_ok=True)
    payload={'الإصدار':'4.10','السجلات':list(السجلات or []),'تقييم_التعارض':التعارض,
             'قواعد_السلامة':{'منع_الاحتمال_من_الدرجة':True,'منع_الهدف_الثابت':True,'مراجعة_بشرية':True}}
    p.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    return p
