from __future__ import annotations
import hashlib, json, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

@dataclass
class نتيجة_المصدر:
    المصدر: str
    الحالة: str
    البيانات: Dict[str, Any]
    وقت_الوصول: float
    بصمة: str
    سبب: str = ""

class ممر_البيانات_متعدد_المصادر:
    """ممر موحد للمصادر: لا يختلق بيانات، ويفصل الالتقاط عن المصالحة."""
    def __init__(self, سجل: Optional[Path] = None):
        self.سجل = Path(سجل) if سجل else Path("حالة_البيانات_متعددة_المصادر.json")
        self.النتائج: List[نتيجة_المصدر] = []

    @staticmethod
    def بصمة(بيانات: Dict[str, Any]) -> str:
        خام = json.dumps(بيانات, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(خام.encode("utf-8")).hexdigest()

    def أضف(self, المصدر: str, البيانات: Dict[str, Any], الحالة: str = "نجح", سبب: str = "") -> نتيجة_المصدر:
        نتيجة = نتيجة_المصدر(المصدر, الحالة, البيانات, time.time(), self.بصمة(البيانات), سبب)
        self.النتائج.append(نتيجة)
        return نتيجة

    def احفظ(self) -> Path:
        payload = {"الإصدار": "4.26", "النتائج": [asdict(x) for x in self.النتائج]}
        self.سجل.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return self.سجل

    def المصالحة(self, الرمز: str, التاريخ: str) -> Dict[str, Any]:
        مرشحات = []
        for r in self.النتائج:
            صف = r.البيانات.get("صف", {})
            if r.الحالة == "نجح" and صف.get("الرمز") == الرمز and صف.get("التاريخ") == التاريخ:
                مرشحات.append((r.المصدر, صف))
        if not مرشحات:
            return {"الحالة": "غير مثبت", "الرمز": الرمز, "التاريخ": التاريخ, "الأدلة": []}
        الحقول = ["الافتتاح", "الأعلى", "الأدنى", "الإغلاق", "الحجم"]
        تعارضات = {}
        for حقل in الحقول:
            قيم = {مصدر: float(صف.get(حقل)) for مصدر, صف in مرشحات if صف.get(حقل) is not None}
            vals = list(قيم.values())
            if len(vals) > 1:
                هامش = 0.0005 if حقل != "الحجم" else 0.02
                مرجع_حقل = vals[0]
                if any(abs(v-مرجع_حقل) / max(abs(مرجع_حقل), 1e-9) > هامش for v in vals[1:]):
                    تعارضات[حقل] = قيم
        حالة = "متعارض" if تعارضات else "مثبت"
        مرجع = مرشحات[0][1].copy()
        return {"الحالة": حالة, "الرمز": الرمز, "التاريخ": التاريخ, "المرجع": مرجع,
                "الأدلة": [m[0] for m in مرشحات], "التعارضات": تعارضات}
