from __future__ import annotations

import importlib.util
from dataclasses import dataclass
from typing import Iterable
import pandas as pd

@dataclass(frozen=True)
class نتيجة_ياهو:
    الرمز: str
    رمز_المصدر: str
    الحالة: str
    عدد_الصفوف: int
    بداية: str|None
    نهاية: str|None
    ملاحظات: tuple[str,...] = ()


def رمز_ياهو(الرمز: str) -> str:
    الرمز = str(الرمز).strip().upper()
    return الرمز if الرمز.endswith('.CA') else f'{الرمز}.CA'


def _تسوية_الأعمدة(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
    mapping = {'Date':'التاريخ','Open':'الافتتاح','High':'الأعلى','Low':'الأدنى','Close':'الإغلاق','Adj Close':'الإغلاق_المعدل','Volume':'الحجم'}
    out=df.rename(columns=mapping).reset_index(drop=False)
    if 'التاريخ' not in out.columns and 'index' in out.columns:
        out=out.rename(columns={'index':'التاريخ'})
    for c in ('التاريخ','الافتتاح','الأعلى','الأدنى','الإغلاق','الإغلاق_المعدل','الحجم'):
        if c in out.columns and c!='التاريخ': out[c]=pd.to_numeric(out[c],errors='coerce')
    if 'التاريخ' in out.columns:
        out['التاريخ']=pd.to_datetime(out['التاريخ'],errors='coerce').dt.tz_localize(None)
    return out


def تحميل_يومي(الرمز: str, بداية=None, نهاية=None, فترة='max') -> tuple[pd.DataFrame, نتيجة_ياهو]:
    رمز=رمز_ياهو(الرمز)
    if importlib.util.find_spec('yfinance') is None:
        return pd.DataFrame(), نتيجة_ياهو(الرمز,رمز,'غير متاح — مكتبة yfinance غير مثبتة',0,None,None,('المصدر اختياري وغير رسمي؛ يجب تثبيت المكتبة وفق شروط الاستخدام.','لا يُسمح باعتبار غياب البيانات دليلًا على عدم وجود السهم.'))
    try:
        import yfinance as yf
        df=yf.download(رمز if False else رمز,start=بداية,end=نهاية,period=فترة,interval='1d',auto_adjust=False,progress=False,threads=False)
        df=_تسوية_الأعمدة(df)
        if df.empty:
            return df, نتيجة_ياهو(الرمز,رمز,'لا توجد بيانات',0,None,None,('تغطية ياهو للأسهم المصرية غير شاملة.','يجب تمرير النتيجة عبر فحوص الجودة والمقارنة.'))
        df['الرمز']=الرمز.replace('.CA','')
        df['المصدر']='ياهو للتمويل'
        good=df.dropna(subset=['التاريخ','الإغلاق'])
        return df, نتيجة_ياهو(الرمز,رمز,'تم التحميل',len(df),good['التاريخ'].min().date().isoformat() if not good.empty else None,good['التاريخ'].max().date().isoformat() if not good.empty else None,('بيانات يومية فقط لهذا الموصل.','ليست مصدرًا معتمدًا للتدفق اللحظي.'))
    except Exception as e:
        return pd.DataFrame(), نتيجة_ياهو(الرمز,رمز,'فشل الاتصال',0,None,None,(f'خطأ غير حساس: {type(e).__name__}',))


def فحص_دفعة(الرموز: Iterable[str]) -> pd.DataFrame:
    rows=[]
    for r in الرموز:
        _, meta=تحميل_يومي(r,فترة='1mo')
        rows.append(meta.__dict__)
    return pd.DataFrame(rows)
