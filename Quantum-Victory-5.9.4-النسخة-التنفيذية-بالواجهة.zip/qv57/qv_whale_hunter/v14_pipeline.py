from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .adapter import adapt_canonical
from .sequence_engine import add_sequence_features, build_sequence_events
from .market_context import add_relative_flow
from .research_lab import build_event_ledger
from .validation_memory import add_forward_metrics, build_memory, score_memory, chronological_walk_forward, evaluate_oos, false_signal_rate
from .recommendation_bridge import build_evidence_bridge, build_recommendation_contract, shadow_gate

VERSION='1.4.0'

def run(df, out_dir, train_sessions=60, test_sessions=20, step=20):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    x=adapt_canonical(df,require_provenance=False)
    if (x.adapter_status=='REJECT').any(): raise ValueError('DATA_ADMISSION_FAILED')
    x=add_sequence_features(x); x=add_relative_flow(x)
    seq=build_sequence_events(x)
    merged=x.merge(seq,on=['symbol','session_date'],how='left')
    merged=add_forward_metrics(merged)
    ledger=build_event_ledger(merged)
    memory=build_memory(ledger)
    summary=score_memory(memory)
    splits=chronological_walk_forward(merged,train_sessions,test_sessions,step)
    oos=evaluate_oos(memory,splits)
    bridge=build_evidence_bridge(merged)
    contract=build_recommendation_contract(bridge)
    gate=shadow_gate(bridge)
    merged.to_csv(out/'QV-WHALE-V14-FEATURES-001.csv',index=False)
    seq.to_csv(out/'QV-WHALE-V14-SEQUENCES-001.csv',index=False)
    ledger.to_csv(out/'QV-WHALE-V14-EVENT-LEDGER-001.csv',index=False)
    memory.to_csv(out/'QV-WHALE-V14-MEMORY-001.csv',index=False)
    summary.to_csv(out/'QV-WHALE-V14-SUMMARY-001.csv',index=False)
    splits.to_csv(out/'QV-WHALE-V14-WALK-FORWARD-SPLITS-001.csv',index=False)
    oos.to_csv(out/'QV-WHALE-V14-OOS-RESULTS-001.csv',index=False)
    bridge.to_csv(out/'QV-WHALE-V14-RECOMMENDATION-EVIDENCE-001.csv',index=False)
    (out/'QV-WHALE-V14-RECOMMENDATION-CONTRACT-001.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
    report={'engine':'QV-WHALE-HUNTER-INSTITUTIONAL-INTELLIGENCE','version':VERSION,'status':'PASS','production_approved':False,'event_rows':len(ledger),'memory_rows':len(memory),'bridge_rows':len(bridge),'walk_forward_splits':len(splits),'oos_rows':len(oos),'false_signal_rate':false_signal_rate(memory),'calibration_status':'NOT_CALIBRATED','recommendation_role':'EVIDENCE_ONLY','shadow_gate':gate,'promotion_gate':'REAL_EGX_QUALIFICATION + OOS + WALK_FORWARD + SAMPLE_SIZE + REGIME_STABILITY + OOS_CALIBRATION + SHADOW'}
    (out/'QV-WHALE-V14-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
