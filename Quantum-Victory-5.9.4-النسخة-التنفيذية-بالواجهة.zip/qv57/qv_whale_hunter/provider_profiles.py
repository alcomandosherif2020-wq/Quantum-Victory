PROFILES={
'EGID_OFFICIAL':{'mode':'http','base_url':'https://ticker.egidegypt.com','env_url':'QV_EGID_BASE_URL','env_key':'QV_EGID_TOKEN','marketwatch_path':'/api/Feed/GetEGXMarketWatch','depth_path':'/api/Feed/GetMarketDepth','status_path':'/api/Feed/GetMarketStatus'},
'EGX_NEWS_RAPIDAPI':{'mode':'http','env_url':'EGX_NEWS_URL','env_key':'EGX_NEWS_API_KEY'},
'EGXAPI':{'mode':'websocket_or_http','env_url':'EGXAPI_URL','env_key':'EGXAPI_KEY'},
'EGXPILOT':{'mode':'http_or_mcp','env_url':'EGXPILOT_URL','env_key':'EGXPILOT_API_KEY'},
'BORSA_SELF_HOSTED':{'mode':'http','env_url':'BORSA_URL','env_key':'BORSA_API_KEY'},
'TRADIFY':{'mode':'adapter_required','note':'Official/documented feed or export only; no reverse engineering.'},
'MONITOR_STOCKS':{'mode':'adapter_required','note':'Official/documented feed or export only; no reverse engineering.'}}
