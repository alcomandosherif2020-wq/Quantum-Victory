from __future__ import annotations
import hashlib, json, math
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

VERSION='5.4.0'

@dataclass(frozen=True)
class Split:
    name:str; start:str; end:str; purpose:str

@dataclass(frozen=True)
class Experiment:
    experiment_id:str
    dataset_sha256:str
    splits:tuple[Split,...]
    embargo_bars:int
    seed:int
    costs_bps:float
    slippage_bps:float
    frozen_features:bool=True


def sha256_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()


def make_protocol(dataset_sha256, *, seed=20260905, embargo_bars=1, costs_bps=10.0, slippage_bps=5.0):
    splits=(
        Split('train','T0','T60','model_selection'),
        Split('validation','T61','T75','hyperparameter_lock'),
        Split('oos_1','T76','T90','first_unseen_test'),
        Split('oos_2','T91','T100','second_unseen_test'),
    )
    payload={'dataset_sha256':dataset_sha256,'splits':[asdict(s) for s in splits],
             'embargo_bars':embargo_bars,'seed':seed,'costs_bps':costs_bps,'slippage_bps':slippage_bps}
    eid=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:16]
    return Experiment(eid,dataset_sha256,splits,embargo_bars,seed,costs_bps,slippage_bps)


def validate_protocol(exp):
    errors=[]
    if not exp.dataset_sha256 or len(exp.dataset_sha256)!=64: errors.append('dataset_sha256')
    if exp.embargo_bars<0: errors.append('negative_embargo')
    if exp.costs_bps<0 or exp.slippage_bps<0: errors.append('negative_cost')
    names=[s.name for s in exp.splits]
    if len(names)!=len(set(names)): errors.append('duplicate_split')
    required={'train','validation','oos_1','oos_2'}
    if not required.issubset(names): errors.append('missing_split')
    return {'status':'PASS' if not errors else 'BLOCKED','errors':errors,'version':VERSION}


def realized_edge(gross_return, turnover, costs_bps=10.0, slippage_bps=5.0):
    """Return net edge after explicit round-trip implementation costs."""
    net=float(gross_return) - float(turnover)*(costs_bps+slippage_bps)/10000.0
    return net


def bootstrap_mean(values, n=2000, seed=20260905):
    import numpy as np
    x=np.asarray(values,dtype=float)
    if x.size==0: return {'status':'BLOCKED','reason':'empty'}
    rng=np.random.default_rng(seed)
    means=rng.choice(x,size=(n,x.size),replace=True).mean(axis=1)
    lo,hi=np.quantile(means,[.025,.975])
    return {'status':'PASS','mean':float(x.mean()),'ci95_low':float(lo),'ci95_high':float(hi),'n':int(x.size),'seed':seed}


def calibration_bins(probabilities, outcomes, bins=10):
    import numpy as np
    p=np.asarray(probabilities,dtype=float); y=np.asarray(outcomes,dtype=float)
    if len(p)!=len(y) or len(p)==0: return {'status':'BLOCKED'}
    rows=[]
    for lo in np.linspace(0,1,bins+1)[:-1]:
        hi=lo+1/bins; mask=(p>=lo)&((p<hi) if hi<1 else (p<=hi))
        if mask.any(): rows.append({'lo':float(lo),'hi':float(hi),'n':int(mask.sum()),'pred':float(p[mask].mean()),'actual':float(y[mask].mean())})
    ece=sum(r['n']*abs(r['pred']-r['actual']) for r in rows)/len(p)
    return {'status':'PASS','ece':float(ece),'bins':rows}
