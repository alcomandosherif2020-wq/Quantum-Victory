from __future__ import annotations
import ast
import numpy as np
import pandas as pd

FUTURE_PREFIXES=('fwd_','forward_','mfe_','mae_','outcome_','label_')
BUY_PHASES={'EMERGING','ACCUMULATING','EXPANDING','CONFIRMED','CONTINUING'}
SELL_PHASES={'PROFIT_TAKING','DISTRIBUTING','EXITING'}


def _num(r,c,default=0.0):
    v=pd.to_numeric(pd.Series([r.get(c, np.nan)]),errors='coerce').iloc[0]
    return default if pd.isna(v) else float(v)

def _txt(r,c,default=''):
    v=r.get(c,default)
    return default if pd.isna(v) else str(v)

def _list(v):
    if isinstance(v,list): return v
    if v is None or (isinstance(v,float) and np.isnan(v)): return []
    try:
        z=ast.literal_eval(str(v)); return z if isinstance(z,list) else [str(v)]
    except Exception: return [str(v)] if str(v) else []


def prior_reliability(memory: pd.DataFrame, decisions: pd.DataFrame, min_samples: int=30) -> pd.DataFrame:
    """Prior-only reliability snapshot. It never uses same-day/future outcomes."""
    if memory is None or memory.empty or decisions.empty:
        return pd.DataFrame({'_key':decisions.index,'reliability_score':np.nan,'reliability_n':0,'reliability_status':'UNAVAILABLE'})
    m=memory.copy(); d=decisions.copy()
    if 'session_date' not in m or 'session_date' not in d:
        return pd.DataFrame({'_key':d.index,'reliability_score':np.nan,'reliability_n':0,'reliability_status':'UNAVAILABLE'})
    m['_date']=pd.to_datetime(m.session_date,errors='coerce'); d['_date']=pd.to_datetime(d.session_date,errors='coerce')
    # memory rows are historical observations with forward outcomes already computed.
    outcome_cols=[c for c in ['fwd_ret_1','fwd_ret_3','fwd_ret_5'] if c in m.columns]
    if not outcome_cols:
        return pd.DataFrame({'_key':d.index,'reliability_score':np.nan,'reliability_n':0,'reliability_status':'NO_OOS_OUTCOME_COLUMNS'})
    rows=[]
    for idx,r in d.iterrows():
        hist=m[m['_date'] < r['_date']].copy()
        state=_txt(r,'sequence_state',_txt(r,'state',''))
        if state and 'sequence_state' in hist.columns:
            hist=hist[hist.sequence_state.astype(str)==state]
        # Reliability is a bounded evidence-quality score, not a probability.
        vals=[]
        for c in outcome_cols:
            if c in hist:
                z=pd.to_numeric(hist[c],errors='coerce').dropna()
                if len(z): vals.append(float((z>0).mean()))
        n=len(hist)
        if n>=min_samples and vals:
            hit=float(np.mean(vals)); score=float(np.clip(100*(2*hit-1),-100,100))
            status='SUFFICIENT_PRIOR_SAMPLE'
        else:
            score=np.nan; status='INSUFFICIENT_PRIOR_SAMPLE'
        rows.append({'_key':idx,'reliability_score':score,'reliability_n':n,'reliability_status':status})
    return pd.DataFrame(rows)


def fuse_scenarios(df: pd.DataFrame, reliability: pd.DataFrame|None=None) -> pd.DataFrame:
    x=df.copy()
    if x.empty: return x
    rel={}
    if reliability is not None and not reliability.empty and '_key' in reliability:
        rel=reliability.set_index('_key').to_dict('index')
    out=[]
    for idx,r in x.iterrows():
        radar=_num(r,'defended_radar_score',_num(r,'whale_radar_score',0))
        intensity=_num(r,'flow_intensity',0); confirm=_num(r,'confirmation_score',0); unc=_num(r,'uncertainty_score',50)
        trap=_num(r,'false_whale_trap_score',0); relrow=rel.get(idx,{})
        relscore=relrow.get('reliability_score',np.nan); reln=int(relrow.get('reliability_n',0) or 0); relstatus=relrow.get('reliability_status','UNAVAILABLE')
        direction=_txt(r,'radar_direction',_txt(r,'direction','NEUTRAL_OR_MIXED'))
        phase=_txt(r,'lifecycle_phase','')
        seq=_txt(r,'sequence_state',_txt(r,'state',''))
        size=_txt(r,'whale_size_class',_txt(r,'size_class','MICRO_FLOW'))
        mkt=_num(r,'relative_to_market_flow',_num(r,'relative_flow_to_market',0))
        sec=_num(r,'relative_to_sector_flow',_num(r,'relative_flow_to_sector',0))
        ema=bool(r.get('ema_bull',False)); above=bool(r.get('above_ema20',False))
        rsi=_num(r,'rsi14',50); ret5=_num(r,'ret5',0)
        buy=0.0; sell=0.0; support=[]; conflict=[]; warnings=[]
        # Whale/institutional evidence: capped components, never a probability.
        buy += 0.35*np.clip(max(radar,0),0,100) + 0.20*np.clip(intensity,0,100) + 0.15*np.clip(confirm,0,100)
        sell += 0.35*np.clip(max(-radar,0),0,100) + 0.20*np.clip(intensity,0,100) + 0.15*np.clip(confirm,0,100)
        if direction=='BUY_SIDE': buy+=15; support.append('BUY_SIDE_LIQUIDITY_FOOTPRINT')
        elif direction=='SELL_SIDE': sell+=15; support.append('SELL_SIDE_LIQUIDITY_FOOTPRINT')
        if phase in BUY_PHASES: buy+=12; support.append('ACCUMULATION_LIFECYCLE')
        if phase in SELL_PHASES: sell+=12; support.append('DISTRIBUTION_EXIT_LIFECYCLE')
        if seq=='ACCUMULATION_SEQUENCE': buy+=10; support.append('MULTI_SESSION_ACCUMULATION')
        if seq=='DISTRIBUTION_SEQUENCE': sell+=10; support.append('MULTI_SESSION_DISTRIBUTION')
        # Technical context.
        if ema and above: buy+=8; support.append('TREND_ALIGNMENT')
        elif not ema and not above: sell+=6; support.append('TREND_WEAKNESS')
        if rsi>=55: buy+=4
        elif rsi<=45: sell+=4
        if ret5>0: buy+=3
        elif ret5<0: sell+=3
        if mkt>0: buy+=5; support.append('MARKET_RELATIVE_STRENGTH')
        elif mkt<0: sell+=5; support.append('MARKET_RELATIVE_WEAKNESS')
        if sec>0: buy+=5; support.append('SECTOR_RELATIVE_STRENGTH')
        elif sec<0: sell+=5; support.append('SECTOR_RELATIVE_WEAKNESS')
        if trap>=50:
            buy*=max(0,1-trap/140); sell*=max(0,1-trap/140)
            warnings.append('FALSE_WHALE_DEFENSE_REDUCES_SIGNAL_STRENGTH')
        if trap>=70: warnings.append('LIQUIDITY_TRAP_RISK_HIGH')
        if unc>=70: warnings.append('HIGH_UNCERTAINTY')
        if relstatus!='SUFFICIENT_PRIOR_SAMPLE': warnings.append('HISTORICAL_RELIABILITY_NOT_ESTABLISHED')
        if size in {'LARGE_WHALE','MEGA_WHALE'}: support.append('HIGH_LIQUIDITY_SCALE_OBSERVED')
        net=buy-sell
        evidence=float(np.clip(abs(net),0,100))
        confirmation=float(np.clip(confirm,0,100))
        uncertainty=float(np.clip(unc + (15 if relstatus!='SUFFICIENT_PRIOR_SAMPLE' else 0) + (10 if trap>=50 else 0),0,100))
        if trap>=70:
            scenario='LIQUIDITY_TRAP_OR_DISTRIBUTION_RISK'
        elif sell-buy>=18 or phase in {'EXITING','DISTRIBUTING'}:
            scenario='BEARISH_DISTRIBUTION_EXIT_PRESSURE'
        elif buy-sell>=22 and confirm>=45:
            scenario='BULLISH_INSTITUTIONAL_ACCUMULATION_OR_CONTINUATION'
        elif buy-sell>=10:
            scenario='EARLY_BULLISH_ACCUMULATION'
        elif abs(net)<10 and unc<65:
            scenario='NEUTRAL_MIXED_FLOW'
        else:
            scenario='UNCERTAIN_MIXED_FLOW'
        # Explicit invalidation conditions, not price targets.
        if scenario.startswith('BULLISH') or scenario.startswith('EARLY_BULLISH'):
            invalid=['sustained SELL_SIDE footprint','lifecycle shifts to DISTRIBUTING/EXITING','trap score reaches BLOCK zone','loss of sector/market relative support']
        elif scenario.startswith('BEARISH') or scenario.startswith('LIQUIDITY'):
            invalid=['sustained BUY_SIDE footprint with improving confirmation','lifecycle shifts to CONFIRMED/CONTINUING accumulation','trap risk resolves and follow-through improves']
        else:
            invalid=['directional evidence becomes persistent','uncertainty materially declines','cross-market/sector context confirms one side']
        if relstatus=='SUFFICIENT_PRIOR_SAMPLE':
            reliability=float(np.clip(relscore,-100,100))
        else: reliability=np.nan
        # Scenario score is deliberately distinct from probability.
        scenario_score=float(np.clip((evidence*0.45)+(confirmation*0.25)+((100-uncertainty)*0.20)+((abs(reliability) if np.isfinite(reliability) else 0)*0.10),0,100))
        if trap>=70: scenario_score*=0.55
        out.append({
            'scenario_id':f'QVSF-{idx+1:08d}','primary_scenario':scenario,'scenario_score':round(scenario_score,4),
            'evidence_score':round(evidence,4),'confirmation_score':round(confirmation,4),
            'reliability_score':None if not np.isfinite(reliability) else round(reliability,4),'reliability_n':reln,
            'reliability_status':relstatus,'uncertainty_score':round(uncertainty,4),'trap_penalty':round(trap,4),
            'supporting_evidence':' | '.join(dict.fromkeys(support)),'conflicting_evidence':' | '.join(dict.fromkeys(conflict)),
            'invalidation_conditions':' | '.join(invalid),'warnings':' | '.join(dict.fromkeys(warnings)),
            'probability':None,'calibration_status':'NOT_CALIBRATED','no_fixed_price_prediction':True,
            'recommendation_role':'EVIDENCE_ONLY','identity_claim':False
        })
    return pd.concat([x.reset_index(drop=True),pd.DataFrame(out)],axis=1)
