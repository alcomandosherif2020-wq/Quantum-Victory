from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .v18_pipeline import run as run_v18
from .market_radar import build_market_radar

VERSION='1.9.0'

def run(df, out_dir, **kwargs):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    run_v18(df,out,**kwargs)
    defended=pd.read_csv(out/'QV-WHALE-V18-DEFENSE-001.csv')
    stock, market = build_market_radar(defended)
    stock.to_csv(out/'QV-WHALE-V19-STOCK-RADAR-001.csv',index=False)
    market.to_csv(out/'QV-WHALE-V19-MARKET-RADAR-001.csv',index=False)
    top=stock.sort_values(['date','radar_strength'],ascending=[True,False]).groupby('date',as_index=False).head(10)
    top.to_csv(out/'QV-WHALE-V19-TOP10-001.csv',index=False)
    report={'engine':'QV-WHALE-HUNTER-MARKET-WIDE-LIQUIDITY-RADAR','version':VERSION,'status':'PASS','production_approved':False,
            'rows_scanned':len(defended),'stock_rows':len(stock),'market_sessions':len(market),
            'future_outcomes_used':False,'identity_claim':False,
            'ranking_principle':'Ranks observable liquidity footprints; it does not identify actors or guarantee outcomes.',
            'next_gates':['SCENARIO_FUSION','RECOMMENDATION_FUSION','REAL_EGX_DATA_QUALIFICATION','OOS','WALK_FORWARD','CALIBRATION','CHAMPION_CHALLENGER','SHADOW','PRODUCTION_GATE']}
    (out/'QV-WHALE-V19-REPORT-001.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
