from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .live_liquidity_sniper import scan, latest_alerts
ENGINE='QV-LIVE-SESSION-ENGINE'; VERSION='1.1.0'
class LiveSessionEngine:
    def __init__(self,out_dir='QV-LIVE-SESSION-RUN',cooldown_seconds=60,**scan_kwargs):
        self.out=Path(out_dir); self.out.mkdir(parents=True,exist_ok=True); self.cooldown_seconds=cooldown_seconds; self.scan_kwargs=scan_kwargs; self.last_alert={}; self.history=[]
    def process(self,batch:pd.DataFrame,daily_baseline=None):
        if batch is None or batch.empty:return pd.DataFrame()
        scored=scan(batch,daily_baseline=daily_baseline,**self.scan_kwargs)
        if scored.empty:return scored
        self.history.append(scored); alerts=latest_alerts(scored)
        keep=[]
        for _,r in alerts.iterrows():
            sym=r['symbol']; ts=pd.to_datetime(r['timestamp'],errors='coerce'); prev=self.last_alert.get(sym)
            if prev is None or (ts-prev).total_seconds()>=self.cooldown_seconds: keep.append(r); self.last_alert[sym]=ts
        out=pd.DataFrame(keep)
        if not out.empty:
            p=self.out/'QV-LIVE-ALERT-STREAM.csv'; out.to_csv(p,mode='a',header=not p.exists(),index=False)
        return out
    def snapshot(self): return {'engine':ENGINE,'version':VERSION,'status':'RUNNING','alerts_emitted':len(self.last_alert),'symbols_seen':len(self.last_alert),'production_approved':False,'evidence_only':True,'identity_claim':False,'probability_output':None,'fixed_price_target':None}
