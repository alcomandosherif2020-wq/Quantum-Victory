from __future__ import annotations
import os
from .source_mesh import SourceSpec

def configured_sources():
    sources=[SourceSpec('EGID_OFFICIAL','https://ticker.egidegypt.com/api/Feed/GetEGXMarketWatch',priority=10,requires_key=True,key_env='QV_EGID_TOKEN',legal_status='official_provider_account',coverage='market_watch')]
    egxapi=os.getenv('EGXAPI_URL')
    if egxapi:
        sources.append(SourceSpec('EGXAPI',egxapi,priority=20,requires_key=True,key_env='EGXAPI_KEY',legal_status='provider_account',coverage='real_time'))
    borsa=os.getenv('BORSA_URL')
    if borsa:
        sources.append(SourceSpec('BORSA_SELF_HOSTED',borsa,priority=30,requires_key=False,legal_status='self_hosted_provider_terms',coverage='quote'))
    return sources
