from __future__ import annotations
import hashlib
import numpy as np
import pandas as pd

VERSION = '1.7.0'

BUY_STATES = {'ACCUMULATION_SEQUENCE'}
SELL_STATES = {'DISTRIBUTION_SEQUENCE'}

PHASES = (
    'EMERGING', 'ACCUMULATING', 'EXPANDING', 'CONFIRMED',
    'CONTINUING', 'PROFIT_TAKING', 'DISTRIBUTING', 'EXITING',
    'MIXED', 'DORMANT'
)


def _num(x, default=0.0):
    try:
        v = float(pd.to_numeric(pd.Series([x]), errors='coerce').iloc[0])
        return default if not np.isfinite(v) else v
    except Exception:
        return default


def _phase(row, previous_phase=None):
    state = str(row.get('sequence_state', 'NO_SEQUENCE') or 'NO_SEQUENCE')
    direction = str(row.get('radar_direction', 'NEUTRAL_OR_MIXED') or 'NEUTRAL_OR_MIXED')
    intensity = _num(row.get('flow_intensity'))
    strength = _num(row.get('institutional_flow_score'))
    confirmation = _num(row.get('confirmation_score'))
    uncertainty = _num(row.get('uncertainty_score'))
    buy_n = _num(row.get('buy_event_count'))
    sell_n = _num(row.get('sell_event_count'))

    if uncertainty >= 75 and intensity < 40:
        return 'MIXED'
    if state in SELL_STATES or direction == 'SELL_SIDE':
        if previous_phase in {'ACCUMULATING','EXPANDING','CONFIRMED','CONTINUING'} and sell_n >= buy_n:
            return 'PROFIT_TAKING'
        return 'EXITING' if intensity >= 70 and strength < 0 else 'DISTRIBUTING'
    if state in BUY_STATES or direction == 'BUY_SIDE':
        if intensity >= 85 and confirmation >= 60:
            return 'CONFIRMED'
        if previous_phase in {'CONFIRMED','CONTINUING'} and intensity >= 60:
            return 'CONTINUING'
        if previous_phase in {'EMERGING','ACCUMULATING'} and intensity >= 60:
            return 'EXPANDING'
        if intensity >= 50:
            return 'ACCUMULATING'
        return 'EMERGING'
    if intensity >= 50:
        return 'MIXED'
    return 'DORMANT'


def build_lifecycle(df: pd.DataFrame, max_gap_sessions: int = 3) -> pd.DataFrame:
    """Track observable liquidity-footprint episodes using only current/past rows.

    This is behavioral tracking, not actor identification. Episode IDs represent
    continuity of an observed footprint and are not claimed to identify a trader.
    """
    x = df.copy()
    if x.empty:
        return pd.DataFrame(columns=[
            'symbol','session_date','lifecycle_episode_id','lifecycle_phase',
            'previous_phase','phase_age','episode_age','size_class','flow_intensity',
            'direction','phase_changed','episode_started','episode_ended','tracking_note'
        ])
    if 'symbol' not in x or 'session_date' not in x:
        raise ValueError('LIFECYCLE_REQUIRES_SYMBOL_AND_SESSION_DATE')
    x['_date'] = pd.to_datetime(x['session_date'], errors='coerce')
    if x['_date'].isna().any():
        raise ValueError('INVALID_SESSION_DATE')
    x = x.sort_values(['symbol','_date'], kind='mergesort').reset_index(drop=True)

    out=[]
    for symbol, g in x.groupby('symbol', sort=False):
        previous_phase = None
        previous_date = None
        episode_id = None
        episode_age = 0
        phase_age = 0
        previous_intensity = 0.0
        previous_active = False
        for _, r in g.iterrows():
            date = r['_date']
            phase = _phase(r, previous_phase)
            intensity = _num(r.get('flow_intensity'))
            size = str(r.get('whale_size_class','MICRO_FLOW'))
            direction = str(r.get('radar_direction','NEUTRAL_OR_MIXED'))
            gap = (date - previous_date).days if previous_date is not None else None
            active = phase not in {'DORMANT','MIXED'}
            continuity = previous_date is not None and (gap is not None and gap <= max_gap_sessions)
            starts = episode_id is None or (not continuity) or (not active and previous_active)
            if starts and active:
                seed = f'{symbol}|{date.date()}|{len(out)}|QV-WHALE-LIFECYCLE'
                episode_id = 'QWL-' + hashlib.sha256(seed.encode()).hexdigest()[:16].upper()
                episode_age = 1
                phase_age = 1
                started = True
            elif active:
                episode_age += 1
                phase_age = phase_age + 1 if phase == previous_phase else 1
                started = False
            else:
                if episode_id is not None and previous_active:
                    ended = True
                else:
                    ended = False
                started = False
                phase_age = 0
                # retain episode id for audit continuity until a later active event starts a new one
                episode_age = episode_age
            ended = bool(previous_active and not active)
            if not active and starts:
                episode_id = episode_id
            if active and not continuity and previous_date is not None:
                episode_age = 1
                phase_age = 1
            phase_changed = previous_phase is not None and phase != previous_phase
            out.append({
                'symbol':symbol,
                'session_date':r['session_date'],
                'lifecycle_episode_id':episode_id,
                'lifecycle_phase':phase,
                'previous_phase':previous_phase,
                'phase_age':phase_age,
                'episode_age':episode_age,
                'size_class':size,
                'flow_intensity':round(intensity,4),
                'direction':direction,
                'phase_changed':phase_changed,
                'episode_started':bool(started),
                'episode_ended':ended,
                'tracking_note':'behavioral footprint continuity; not actor identity'
            })
            previous_phase=phase
            previous_date=date
            previous_intensity=intensity
            previous_active=active
    return pd.DataFrame(out)


def summarize_lifecycles(lifecycle: pd.DataFrame) -> pd.DataFrame:
    if lifecycle.empty:
        return pd.DataFrame(columns=['symbol','lifecycle_episode_id','start_date','end_date','sessions','peak_intensity','peak_size_class','dominant_direction','terminal_phase'])
    rows=[]
    for (symbol,eid), g in lifecycle.groupby(['symbol','lifecycle_episode_id'], dropna=False, sort=False):
        if pd.isna(eid):
            continue
        rows.append({
            'symbol':symbol,
            'lifecycle_episode_id':eid,
            'start_date':g['session_date'].iloc[0],
            'end_date':g['session_date'].iloc[-1],
            'sessions':len(g),
            'peak_intensity':float(pd.to_numeric(g['flow_intensity'],errors='coerce').max()),
            'peak_size_class':g.loc[pd.to_numeric(g['flow_intensity'],errors='coerce').idxmax(), 'size_class' if 'size_class' in g.columns else 'whale_size_class'],
            'dominant_direction':(g['direction'] if 'direction' in g.columns else g['radar_direction']).mode().iloc[0] if not (g['direction'] if 'direction' in g.columns else g['radar_direction']).mode().empty else 'NEUTRAL_OR_MIXED',
            'terminal_phase':g['lifecycle_phase'].iloc[-1]
        })
    return pd.DataFrame(rows)
