# -*- coding: utf-8 -*-
from pathlib import Path
import tempfile, sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from qv_whale_hunter.بوابة_الجاهزية_التشغيلية import بوابة_الجاهزية_التشغيلية

def run():
    with tempfile.TemporaryDirectory() as td:
        b=بوابة_الجاهزية_التشغيلية(Path(td)/'حالة.json')
        base={k:True for k in b.الأدلة_الإلزامية}
        r=b.فحص(base, السماح_بالإنتاج=False)
        assert r.جاهز_للمعالجة is True and r.جاهز_للتنبيه is False and r.الحالة=='جاهز_للمعالجة'
        r=b.فحص({**base,'تعارض_مصادر':True}, السماح_بالإنتاج=True)
        assert r.جاهز_للتنبيه is False and 'تعارض بين المصادر' in r.الأسباب
        r=b.فحص({**base,'بيانات_وهمية':True}, السماح_بالإنتاج=True)
        assert r.جاهز_للتنبيه is False
        r=b.فحص(base, السماح_بالإنتاج=True)
        assert r.جاهز_للتنبيه is True and r.الحالة=='جاهز_للتنبيه'
    return 4
if __name__=='__main__': print(f'نجحت {run()} اختبارات الإصدار 4.20')
