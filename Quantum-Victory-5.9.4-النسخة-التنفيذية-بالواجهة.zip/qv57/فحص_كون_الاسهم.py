from qv_whale_hunter.مكتشف_كون_الاسهم import فحص_التغطية
import json, sys

if __name__ == '__main__':
    الرموز=sys.argv[1:] or ['COMI','ABUK','ETEL','SWDY','EFIH']
    print(json.dumps(فحص_التغطية(الرموز), ensure_ascii=False, indent=2))
