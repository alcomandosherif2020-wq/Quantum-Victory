# -*- coding: utf-8 -*-
"""بوابة التشغيل النهائية: ملف واحد، تقرير واحد، وحكم واحد قابل للتتبع."""
from __future__ import annotations
import argparse, json
from pathlib import Path
import pandas as pd
from qv_whale_hunter.المحرك_العالمي_الموحد import المحرك_العالمي_الموحد


def تحميل(path):
    p = Path(path)
    if p.suffix.lower() == '.csv':
        return pd.read_csv(p)
    if p.suffix.lower() == '.json':
        d = json.loads(p.read_text(encoding='utf-8'))
        if isinstance(d, dict):
            for key in ('التاريخ_اليومي', 'الأسهم', 'البيانات', 'rows'):
                if key in d and isinstance(d[key], list):
                    frame=pd.DataFrame(d[key])
                    if 'الرمز' not in frame.columns and d.get('الرمز') is not None:
                        frame['الرمز']=d['الرمز']
                    return frame
            if isinstance(d.get('صف'), dict):
                frame=pd.DataFrame([d['صف']])
                if 'الرمز' not in frame.columns and d.get('الرمز') is not None:
                    frame['الرمز']=d['الرمز']
                return frame
        return pd.DataFrame(d)
    raise ValueError('صيغة البيانات غير مدعومة؛ استخدم CSV أو JSON')


def تحميل_مصادر(path):
    """تحميل صفوف المصالحة من الحزمة الأصلية إن وُجدت، دون اختلاق مصدر."""
    p=Path(path)
    if p.suffix.lower() != '.json':
        return None
    try:
        d=json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        return None
    raw=d.get('المصادر') if isinstance(d,dict) else None
    if not isinstance(raw,list):
        return None
    out={}
    for item in raw:
        if not isinstance(item,dict) or not isinstance(item.get('صف'),dict):
            continue
        name=str(item.get('الاسم','مصدر_غير_مسمى'))
        row=item['صف']
        out[name]=pd.DataFrame([row])
    return out or None


def نتيجة_ملخص_تمرير(d, source_path):
    """يمنع تشغيل ملخص مصالحة/تحليل على أنه سلسلة OHLCV تاريخية كاملة."""
    if not isinstance(d,dict) or 'المصالحة' not in d or 'التحليل' not in d:
        return None
    ref=d.get('المصالحة',{}).get('المرجع',{})
    return {
        'نوع_التقرير':'بطاقة_السهم_العالمية', 'الإصدار':'1.0.0',
        'الحالة':'محجوب', 'التوصية':'لا_قرار',
        'درجة_الأدلة':None, 'الاحتمال':None, 'السعر_المستهدف':None,
        'الإنتاج_مصرح':False,
        'الأسباب':['المدخل_ملخص_تمرير_وليس_سلسلة_OHLCV_تاريخية','يلزم_ملف_السلسلة_التاريخية_الكامل'],
        'الأدلة':[], 'البيانات':{'عدد_السجلات':d.get('عدد_الصفوف'),'آخر_تاريخ':ref.get('التاريخ')},
        'التحليل_الفني':{}, 'السيولة':{}, 'المصالحة':d.get('المصالحة',{}),
        'الأحداث':{}, 'حالة_المصادر':{'اسم':str(source_path),'متصل':False,'حي_موثق':False},
        'بوابات_السلامة':{'حارس_البيانات':'محجوب','دلالة_الافتتاح':None,'الإنتاج_مصرح':False},
        'تنبيه_علمي':'ملخص المصالحة لا يكفي لإعادة بناء المؤشرات الفنية أو فحص السلسلة الزمنية.'
    }

def تحميل_أحداث(path):
    if not path:
        return None
    d = json.loads(Path(path).read_text(encoding='utf-8'))
    return d.get('الأحداث', d) if isinstance(d, dict) else d


def حفظ_ذري(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    tmp.replace(path)


def main():
    ap = argparse.ArgumentParser(description='كوانتوم فيكتوري — التشغيل العالمي النهائي')
    ap.add_argument('بيانات')
    ap.add_argument('--دلالة-الافتتاح', default=None)
    ap.add_argument('--المخرج', default='تقارير_كوانتوم')
    ap.add_argument('--الأحداث', default=None)
    args = ap.parse_args()
    raw_json=None
    if str(args.بيانات).lower().endswith('.json'):
        try: raw_json=json.loads(Path(args.بيانات).read_text(encoding='utf-8'))
        except Exception: raw_json=None
    summary=نتيجة_ملخص_تمرير(raw_json,args.بيانات)
    if summary is not None:
        out=Path(args.المخرج)
        path=out if out.suffix.lower()=='.json' else out/f"{summary.get('المصالحة',{}).get('الرمز','غير_معروف')}.json"
        حفظ_ذري(path,summary)
        print(json.dumps(summary,ensure_ascii=False,indent=2))
        print(f'تم حجب ملخص التمرير: {path}')
        return 0
    df = تحميل(args.بيانات)
    أحداث = تحميل_أحداث(args.الأحداث)
    مصادر = تحميل_مصادر(args.بيانات)
    engine = المحرك_العالمي_الموحد()
    out = Path(args.المخرج)
    # إذا كان المخرج ملف JSON صريحًا نستخدمه للسهم الواحد،
    # أما المسح متعدد الأسهم فيُحفظ في مجلد بجانب الملف.
    مخرج_ملف_صريح = out.suffix.lower() == '.json'
    if مخرج_ملف_صريح:
        out.parent.mkdir(parents=True, exist_ok=True)
    else:
        out.mkdir(parents=True, exist_ok=True)
    if 'الرمز' in df.columns and df['الرمز'].astype(str).nunique(dropna=True) > 1:
        if مخرج_ملف_صريح:
            out = out.parent / out.stem
            out.mkdir(parents=True, exist_ok=True)
        التقارير = {}
        for الرمز, جزء in df.groupby('الرمز', sort=True):
            التقرير = engine.تشغيل(جزء.reset_index(drop=True), دلالة_الافتتاح=args.دلالة_الافتتاح, مصادر=مصادر, أحداث=أحداث, مصدر_البيانات=str(args.بيانات))
            التقارير[str(الرمز)] = التقرير
            حفظ_ذري(out / f'{الرمز}.json', التقرير)
        الملخص = {'نوع_التشغيل':'مسح_متعدد_الأسهم','عدد_الأسهم':len(التقارير),'التقارير':التقارير}
        حفظ_ذري(out / 'ملخص_المسح_العالمي.json', الملخص)
        print(json.dumps(الملخص, ensure_ascii=False, indent=2, default=str))
        print(f'تم حفظ {len(التقارير)} بطاقة سهم في: {out}')
        return 0
    التقرير = engine.تشغيل(df, دلالة_الافتتاح=args.دلالة_الافتتاح, مصادر=مصادر, أحداث=أحداث, مصدر_البيانات=str(args.بيانات))
    الرمز = str(التقرير.get('الرمز', 'غير_معروف'))
    path = out if مخرج_ملف_صريح else out / f'{الرمز}.json'
    حفظ_ذري(path, التقرير)
    print(json.dumps(التقرير, ensure_ascii=False, indent=2, default=str))
    print(f'تم حفظ التقرير: {path}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
