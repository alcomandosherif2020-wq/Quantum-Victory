# -*- coding: utf-8 -*-
"""مربط المصادر التلقائي — كوانتوم فيكتوري 4.18
طبقة آمنة تربط مركز التحديث بالمصادر المسموح بها دون اختلاق بيانات.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
import hashlib, json, math, time
from pathlib import Path

@dataclass
class تعريف_مصدر:
    الاسم: str
    الدور: str
    الفترة_ثانية: int
    الحالة_الاعتمادية: str = "غير موصول"
    نوع_البيانات: str = ""
    موثوقية_المصدر: str = "غير مقيمة"
    الحد_الأقصى_للفشل: int = 3
    أقصى_تأخير_ثوان: int = 120

@dataclass
class حالة_مصدر:
    الاسم: str
    آخر_تشغيل: str | None = None
    آخر_نجاح: str | None = None
    عدد_النجاح: int = 0
    عدد_الفشل: int = 0
    الحالة: str = "غير موصول"
    المحاولات_التالية: int = 0
    التراجع_حتى: str | None = None
    آخر_خطأ: str | None = None
    آخر_نتيجة: dict | None = None

class مربط_المصادر_التلقائي:
    def __init__(self, state_path="حالة_المصادر_التلقائية.json"):
        self.state_path = Path(state_path)
        self.defs: dict[str, تعريف_مصدر] = {}
        self.states: dict[str, حالة_مصدر] = {}
        self.adapters = {}
        self._تحميل()

    def تسجيل(self, تعريف: تعريف_مصدر, دالة=None):
        self.defs[تعريف.الاسم] = تعريف
        self.states.setdefault(تعريف.الاسم, حالة_مصدر(تعريف.الاسم))
        if دالة is not None:
            self.adapters[تعريف.الاسم] = دالة

    def _الآن(self):
        return datetime.now(timezone.utc)

    def _iso(self, dt):
        return dt.astimezone(timezone.utc).isoformat()

    def مستحق(self, الاسم):
        st = self.states[الاسم]; d = self.defs[الاسم]; now = self._الآن()
        if st.التراجع_حتى:
            try:
                if now < datetime.fromisoformat(st.التراجع_حتى): return False
            except ValueError: pass
        if not st.آخر_تشغيل: return True
        try: return (now - datetime.fromisoformat(st.آخر_تشغيل)).total_seconds() >= d.الفترة_ثانية
        except ValueError: return True

    def _مهلة_التراجع(self, failures):
        return min(3600, 2 ** max(0, failures - 1) * 5)

    def تشغيل_مصدر(self, الاسم, force=False):
        if الاسم not in self.defs: raise KeyError(الاسم)
        if not force and not self.مستحق(الاسم): return {"الحالة":"غير مستحق","المصدر":الاسم}
        st=self.states[الاسم]; now=self._الآن(); st.آخر_تشغيل=self._iso(now)
        fn=self.adapters.get(الاسم)
        if fn is None:
            st.الحالة="غير موصول"; self._حفظ()
            return {"الحالة":"غير موصول","المصدر":الاسم,"سبب":"لا يوجد موصل فعلي مسجل"}
        try:
            result=fn()
            if result is None: result={}
            if not isinstance(result, dict): result={"البيانات":result}
            st.عدد_النجاح += 1; st.عدد_الفشل=0; st.الحالة="ناجح"
            st.آخر_نجاح=self._iso(now); st.آخر_خطأ=None; st.التراجع_حتى=None; st.المحاولات_التالية=0; st.آخر_نتيجة=result
            self._حفظ()
            return {"الحالة":"ناجح","المصدر":الاسم,"النتيجة":result}
        except Exception as exc:
            st.عدد_الفشل += 1; st.الحالة="فشل"; st.آخر_خطأ=f"{type(exc).__name__}: {exc}"
            wait=self._مهلة_التراجع(st.عدد_الفشل)
            st.التراجع_حتى=self._iso(now+timedelta(seconds=wait)); st.المحاولات_التالية += 1
            if st.عدد_الفشل >= self.defs[الاسم].الحد_الأقصى_للفشل: st.الحالة="قاطع_دائرة"
            self._حفظ()
            return {"الحالة":st.الحالة,"المصدر":الاسم,"خطأ":st.آخر_خطأ,"إعادة_المحاولة_بعد_ثوان":wait}

    def تشغيل_المستحق(self):
        return [self.تشغيل_مصدر(n) for n in self.defs if self.مستحق(n)]

    def _حفظ(self):
        payload={"الإصدار":"4.18","المصادر":[asdict(x) for x in self.defs.values()],"الحالات":{k:asdict(v) for k,v in self.states.items()}}
        raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2).encode('utf-8')
        payload["بصمة_الحالة"]=hashlib.sha256(raw).hexdigest()
        self.state_path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')

    def _تحميل(self):
        if not self.state_path.exists(): return
        try:
            p=json.loads(self.state_path.read_text(encoding='utf-8'))
            for x in p.get('مصادر',[]): self.defs[x['الاسم']]=تعريف_مصدر(**{k:v for k,v in x.items() if k in تعريف_مصدر.__dataclass_fields__})
            for k,v in p.get('الحالات',{}).items(): self.states[k]=حالة_مصدر(**{a:b for a,b in v.items() if a in حالة_مصدر.__dataclass_fields__})
            for name in self.defs: self.states.setdefault(name, حالة_مصدر(name))
        except Exception:
            pass
