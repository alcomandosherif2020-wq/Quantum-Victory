from dataclasses import dataclass, field
from datetime import datetime, timezone

@dataclass
class حالة_المراقبة:
    جودة_البيانات: float
    حداثة_البيانات: float
    توافق_المصادر: float
    سلامة_المحركات: float
    استقرار_السوق: float
    مخاطر_الإشارة: float
    موانع: list[str] = field(default_factory=list)

    def تقييم(self):
        درجات=[self.جودة_البيانات,self.حداثة_البيانات,self.توافق_المصادر,self.سلامة_المحركات,self.استقرار_السوق]
        if self.موانع:
            return "إيقاف آمن", 0.0
        أقل=min(درجات)
        if أقل < 0.5 or self.مخاطر_الإشارة >= 0.85:
            return "تحذير", أقل
        if أقل < 0.75:
            return "مراقبة", أقل
        return "طبيعي", أقل

def لقطة(حالة):
    مستوى, درجة=حالة.تقييم()
    return {
        "وقت_اللقطة":datetime.now(timezone.utc).isoformat(),
        "الحالة":مستوى,
        "درجة_الجاهزية":round(درجة,4),
        "الأسباب_المانعة":حالة.موانع,
    }
