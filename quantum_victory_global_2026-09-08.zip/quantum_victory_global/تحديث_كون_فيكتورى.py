# -*- coding: utf-8 -*-
"""دورة تحديث موحدة: مصادر -> تحقق -> بصمة -> بوابة تشغيل.
لا تنشئ بيانات بديلة ولا تفتح اعتماد التوصيات الإنتاجية.
"""
from __future__ import annotations
import json, subprocess, sys, time
from pathlib import Path
from qv_whale_hunter.source_registry import configured_sources
from qv_whale_hunter.source_mesh import SourceMesh
from qv_whale_hunter.runtime_gate import runtime_status

ROOT=Path(__file__).resolve().parent
STATE=ROOT/'QV-التحديث-الموحد'

def دورة_تحديث():
    STATE.mkdir(exist_ok=True)
    specs=configured_sources()
    mesh=SourceMesh(specs,state_dir=STATE/'مصادر')
    df, report=mesh.collect()
    fp=mesh.fingerprint(df)
    payload={
        'وقت_التحديث':time.time(),
        'عدد_المصادر_المهيأة':len(specs),
        'عدد_الصفوف_الصالحة':int(len(df)),
        'بصمة_البيانات':fp,
        'صحة_المصادر':report.get('sources',[]),
        'جاهزية_التشغيل_الحي':None,
        'اعتماد_التوصيات_الإنتاجية':False,
    }
    source_ok=bool(specs) and any(x.get('ok') and x.get('source') for x in report.get('sources',[]))
    payload['جاهزية_التشغيل_الحي']=runtime_status(compile_ok=True,tests_ok=True,required_modules_present=True,source_configured=bool(specs),data_pipeline_healthy=(len(df)>0))
    (STATE/'آخر_دورة.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    return payload

if __name__=='__main__':
    print(json.dumps(دورة_تحديث(),ensure_ascii=False,indent=2))
