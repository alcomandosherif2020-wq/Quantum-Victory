# -*- coding: utf-8 -*-
"""ممر البيانات اللحظية متعدد المصادر لكوانتوم فيكتوري.
لا ينشئ بيانات بديلة، ولا يدعي اللحظية إلا إذا اجتازت البيانات بوابة المصدر والزمن والجودة.
"""
from __future__ import annotations
import json, os, time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Iterator

import pandas as pd

try:
    import requests
except Exception:
    requests = None

try:
    import websocket
except Exception:
    websocket = None

ENGINE = "QV-REALTIME-MARKET-BUS"
VERSION = "1.0.0"

@dataclass
class إعداد_المصدر:
    الاسم: str
    النوع: str
    الرابط: str
    المفتاح_البيئي: str | None
    الأولوية: int
    أقصى_عمر_ثانية: int
    موثوق_لحظيا: bool
    ملاحظات: str = ""

المصادر = [
    إعداد_المصدر(
        "EGXAPI",
        "REST/WS",
        os.getenv("EGXAPI_URL", "https://api.egxapi.com/v2"),
        "EGXAPI_KEY",
        10, 15, True,
        "مصدر معلن عن بيانات لحظية وبيانات دفتر الأوامر؛ يتطلب مفتاح وصول."
    ),
    إعداد_المصدر(
        "مزود_بيانات_البورصة_المصرية",
        "REST",
        os.getenv("QV_EGID_URL", "https://ticker.egidegypt.com/api/Feed/GetEGXMarketWatch"),
        "QV_EGID_TOKEN",
        20, 30, True,
        "مسار موثق للمزود؛ لا يستخدم دون اعتماد/توثيق الحساب المناسب."
    ),
    إعداد_المصدر(
        "EGX_NEWS",
        "REST",
        os.getenv("QV_EGXNEWS_URL", ""),
        "QV_EGXNEWS_KEY",
        30, 60, True,
        "يُفعّل فقط عند ضبط نقطة وصول مرخصة ومفتاحها."
    ),
]


def _token(env_name: str | None) -> str | None:
    return os.getenv(env_name) if env_name else None


def _headers(source: إعداد_المصدر) -> dict[str, str]:
    h = {"Accept": "application/json", "User-Agent": "QuantumVictory/RealtimeBus-1.0"}
    token = _token(source.المفتاح_البيئي)
    if token:
        h["Authorization"] = f"Bearer {token}"
        h["X-API-Key"] = token
    return h


def _records(payload: Any) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        keys = ("data", "result", "results", "quotes", "trades", "items", "marketWatch", "stocks", "symbols")
        for key in keys:
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
            if isinstance(value, dict):
                nested = _records(value)
                if nested:
                    return nested
        return [payload]
    return []


def _field(row: dict, *names):
    for name in names:
        if name in row and row[name] is not None:
            return row[name]
    return None


def توحيد_البيانات(records: Iterable[dict], source_name: str) -> pd.DataFrame:
    rows = []
    now = pd.Timestamp.now(tz="Africa/Cairo")
    for r in records:
        if not isinstance(r, dict):
            continue
        rows.append({
            "symbol": _field(r, "symbol", "ticker", "code", "Symbol", "SymbolCode", "SecurityCode"),
            "timestamp": _field(r, "timestamp", "time", "datetime", "dateTime", "Time", "LastTradeTime") or now,
            "price": _field(r, "price", "last", "Last", "LastPrice", "Close", "close"),
            "volume": _field(r, "volume", "qty", "Volume", "TotalVolume", "TradedVolume"),
            "bid": _field(r, "bid", "Bid", "BestBid", "BidPrice"),
            "ask": _field(r, "ask", "Ask", "BestAsk", "AskPrice"),
            "bid_volume": _field(r, "bid_volume", "BidVolume", "BestBidVolume"),
            "ask_volume": _field(r, "ask_volume", "AskVolume", "BestAskVolume"),
            "turnover": _field(r, "turnover", "value", "Value", "Turnover", "TradedValue"),
            "open": _field(r, "open", "Open"),
            "high": _field(r, "high", "High"),
            "low": _field(r, "low", "Low"),
            "previous_close": _field(r, "previous_close", "PreviousClose", "PrevClose"),
            "source": source_name,
            "ingested_at": now,
        })
    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["symbol","timestamp","price","volume","bid","ask","bid_volume","ask_volume","turnover","open","high","low","previous_close","source","ingested_at"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)
    df["ingested_at"] = pd.to_datetime(df["ingested_at"], errors="coerce", utc=True)
    for c in ["price","volume","bid","ask","bid_volume","ask_volume","turnover","open","high","low","previous_close"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["symbol"] = df["symbol"].astype(str).str.strip().str.upper()
    df = df.dropna(subset=["symbol", "price", "volume"])
    df = df[(df["price"] > 0) & (df["volume"] >= 0)]
    df = df[(df["bid"].isna()) | (df["ask"].isna()) | ((df["bid"] >= 0) & (df["ask"] >= 0) & (df["ask"] >= df["bid"]))]
    return df.sort_values(["symbol","timestamp"]).drop_duplicates(["symbol","timestamp","price","volume","source"]).reset_index(drop=True)


def فحص_اللحظية(df: pd.DataFrame, أقصى_عمر_ثانية: int = 30) -> dict:
    if df is None or df.empty:
        return {"الحالة":"لا_بيانات", "صالح_للتنبيه":False, "عدد_الصفوف":0}
    ts = pd.to_datetime(df["timestamp"], errors="coerce", utc=True).dropna()
    if ts.empty:
        return {"الحالة":"زمن_غير_صالح", "صالح_للتنبيه":False, "عدد_الصفوف":len(df)}
    age = max(0.0, (pd.Timestamp.now(tz="UTC") - ts.max()).total_seconds())
    return {
        "الحالة": "لحظي_صالح" if age <= أقصى_عمر_ثانية else "متقادم",
        "صالح_للتنبيه": age <= أقصى_عمر_ثانية,
        "عمر_آخر_بيان_ثانية": round(age, 3),
        "عدد_الصفوف": int(len(df)),
        "آخر_بيان": ts.max().isoformat(),
    }


def جلب_rest(source: إعداد_المصدر, timeout: float = 8.0) -> tuple[pd.DataFrame, dict]:
    if requests is None:
        return pd.DataFrame(), {"المصدر":source.الاسم,"نجح":False,"خطأ":"requests غير متاح"}
    token = _token(source.المفتاح_البيئي)
    if source.الاسم == "EGXAPI" and not token:
        return pd.DataFrame(), {"المصدر":source.الاسم,"نجح":False,"حالة":"ينقص_مفتاح_الوصول"}
    if source.الاسم == "مزود_بيانات_البورصة_المصرية" and not token:
        return pd.DataFrame(), {"المصدر":source.الاسم,"نجح":False,"حالة":"ينقص_اعتماد_المزود"}
    if not source.الرابط:
        return pd.DataFrame(), {"المصدر":source.الاسم,"نجح":False,"حالة":"غير_مضبوط"}
    بدأ = time.monotonic()
    try:
        r = requests.get(source.الرابط, headers=_headers(source), timeout=timeout)
        r.raise_for_status()
        df = توحيد_البيانات(_records(r.json()), source.الاسم)
        freshness = فحص_اللحظية(df, source.أقصى_عمر_ثانية)
        return df, {"المصدر":source.الاسم,"نجح":not df.empty,"زمن_الاستجابة_مللي":round((time.monotonic()-بدأ)*1000,2), **freshness}
    except Exception as e:
        return pd.DataFrame(), {"المصدر":source.الاسم,"نجح":False,"زمن_الاستجابة_مللي":round((time.monotonic()-بدأ)*1000,2),"خطأ":type(e).__name__,"تفصيل":str(e)[:240]}


def حالة_الممر() -> dict:
    return {
        "المحرك": ENGINE,
        "الإصدار": VERSION,
        "الوقت": datetime.now(timezone.utc).isoformat(),
        "المصادر": [asdict(x) for x in المصادر],
        "المفتاح_موجود": {x.الاسم: bool(_token(x.المفتاح_البيئي)) for x in المصادر},
        "الإنتاج_مصرح": False,
        "التنبيهات_الحية": False,
        "ملاحظة": "لا يتم فتح التنبيه الحي إلا بعد تحقق المصدر والزمن والجودة والمطابقة عبر مصدر ثانٍ عند توفره.",
    }


def تشغيل_دورة(مجلد="QV-REALTIME-RUN") -> tuple[pd.DataFrame, dict]:
    out = Path(مجلد); out.mkdir(parents=True, exist_ok=True)
    all_frames = []
    health = []
    for source in sorted(المصادر, key=lambda x: x.الأولوية):
        df, report = جلب_rest(source)
        health.append(report)
        if not df.empty:
            all_frames.append(df)
    merged = pd.concat(all_frames, ignore_index=True) if all_frames else pd.DataFrame()
    if not merged.empty:
        merged.to_csv(out / "البيانات_اللحظية_الموحدة.csv", index=False, encoding="utf-8-sig")
    report = {**حالة_الممر(), "فحص_المصادر": health, "عدد_الصفوف": int(len(merged))}
    (out / "حالة_الممر.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return merged, report


def تشغيل_مستمر(مجلد="QV-REALTIME-RUN", فترة_ثانية=5, دورة_واحدة=None):
    while True:
        df, report = تشغيل_دورة(مجلد)
        if دورة_واحدة:
            return df, report
        time.sleep(max(1, float(فترة_ثانية)))
