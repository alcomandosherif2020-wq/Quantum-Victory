# -*- coding: utf-8 -*-
"""تشغيل المحرك على تدفق السوق اللحظي الحقيقي بعد اجتياز بوابات المصدر والجودة."""
from __future__ import annotations
import json, os, time
from pathlib import Path
import pandas as pd
from .ممر_البيانات_اللحظية import تشغيل_دورة, فحص_اللحظية
from .live_session_engine import LiveSessionEngine

ENGINE="QV-REALTIME-INTEGRATED-ENGINE"
VERSION="1.0.0"

class المحرك_اللحظي:
    def __init__(self, مجلد="QV-REALTIME-INTEGRATED-RUN", فترة_ثانية=None):
        self.مجلد=Path(مجلد); self.مجلد.mkdir(parents=True,exist_ok=True)
        self.فترة_ثانية=float(فترة_ثانية or os.getenv("QV_REALTIME_POLL_SECONDS","5"))
        self.قناص=LiveSessionEngine(out_dir=self.مجلد/"التنبيهات", cooldown_seconds=60)
        self.عدد_الدورات=0
        self.آخر_حالة=None

    def دورة(self):
        df, report = تشغيل_دورة(self.مجلد/"المصدر")
        freshness=فحص_اللحظية(df,30) if not df.empty else {"الحالة":"لا_بيانات","صالح_للتنبيه":False}
        alerts=pd.DataFrame()
        if not df.empty and freshness.get("صالح_للتنبيه"):
            alerts=self.قناص.process(df)
        state={
            "المحرك":ENGINE,"الإصدار":VERSION,
            "عدد_الدورات":self.عدد_الدورات+1,
            "عدد_البيانات":int(len(df)),
            "اللحظية":freshness,
            "عدد_التنبيهات":int(len(alerts)),
            "الإنتاج_مصرح":False,
            "التنبيهات_الحية":bool(not alerts.empty),
            "الهوية_المؤسسية":False,
            "الاحتمال":None,
            "هدف_سعري_ثابت":None,
            "مصادر":report.get("فحص_المصادر",[]),
        }
        self.عدد_الدورات+=1; self.آخر_حالة=state
        (self.مجلد/"حالة_المحرك_اللحظي.json").write_text(json.dumps(state,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
        return df, alerts, state

    def تشغيل(self, دورات=None):
        while دورات is None or self.عدد_الدورات<int(دورات):
            self.دورة()
            if دورات is None or self.عدد_الدورات<int(دورات): time.sleep(max(1,self.فترة_ثانية))
        return self.آخر_حالة

if __name__=="__main__":
    المحرك_اللحظي().تشغيل()
