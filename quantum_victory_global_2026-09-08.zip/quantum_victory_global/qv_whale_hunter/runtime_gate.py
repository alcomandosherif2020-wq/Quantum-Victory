"""Quantum Victory runtime gate.
Separates technical/live-service readiness from scientific recommendation approval.
A deployable service may run in evidence/shadow mode while the scientific gate
continues to protect against unverified production recommendations.
"""
from __future__ import annotations
from pathlib import Path
import json


def runtime_status(*, compile_ok: bool, tests_ok: bool, required_modules_present: bool,
                   source_configured: bool = True, data_pipeline_healthy: bool = True) -> dict:
    checks = {
        'software_integrity': bool(compile_ok and tests_ok),
        'required_modules': bool(required_modules_present),
        'source_configuration': bool(source_configured),
        'data_pipeline_health': bool(data_pipeline_healthy),
    }
    ready = all(checks.values())
    return {
        'runtime_ready': ready,
        'status': 'READY' if ready else 'BLOCKED',
        'checks': checks,
        'mode': 'LIVE_EVIDENCE' if ready else 'SAFE_STOP',
        'recommendation_production_approved': False,
        'note': 'Runtime readiness is not scientific production approval.'
    }


def load_release_runtime(path: str | Path) -> dict:
    p = Path(path)
    if not p.exists():
        return runtime_status(compile_ok=False, tests_ok=False, required_modules_present=False,
                              source_configured=False, data_pipeline_healthy=False)
    d = json.loads(p.read_text(encoding='utf-8'))
    si = d.get('software_integrity', {})
    impl = d.get('gate_implementation', {})
    return runtime_status(
        compile_ok=bool(si.get('compile')),
        tests_ok=si.get('pytest_returncode') == 0,
        required_modules_present=bool(impl) and all(bool(v.get('present')) for v in impl.values()),
        source_configured=True,
        data_pipeline_healthy=True,
    )
