import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
def test_core_files_exist():
    required = ["app.py", "QV-HISTORICAL-SNAPSHOT-ENGINE-001.py", "docs/QV_خط_الأساس_الموحد_2026-09-08.json", "docs/QV_سجل_المصادر_والتكامل.json", "data/historical/ABUK/ABUK_historical_snapshot_2026-09-08_reconciled.csv"]
    assert all((ROOT / p).exists() for p in required)
def test_baseline_keeps_production_closed():
    data = json.loads((ROOT / "docs/QV_خط_الأساس_الموحد_2026-09-08.json").read_text(encoding="utf-8"))
    assert data["بوابة_الإنتاج"]["الحالة"] == "مغلقة"
def test_snapshot_manifest_is_pass_but_not_production():
    data = json.loads((ROOT / "data/historical/ABUK/QV-HISTORICAL-SNAPSHOT-MANIFEST-2026-09-08.json").read_text(encoding="utf-8"))
    assert data["status"] == "PASS"
    assert data["production_approved"] is False
    assert data["excluded_future_rows"] == 0
