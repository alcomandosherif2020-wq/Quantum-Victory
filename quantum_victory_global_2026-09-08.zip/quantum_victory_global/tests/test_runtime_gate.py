from qv_whale_hunter.runtime_gate import runtime_status


def test_runtime_can_be_ready_without_scientific_production_approval():
    r = runtime_status(compile_ok=True, tests_ok=True, required_modules_present=True)
    assert r['runtime_ready'] is True
    assert r['mode'] == 'LIVE_EVIDENCE'
    assert r['recommendation_production_approved'] is False


def test_runtime_blocks_on_software_failure():
    r = runtime_status(compile_ok=False, tests_ok=True, required_modules_present=True)
    assert r['runtime_ready'] is False
    assert r['mode'] == 'SAFE_STOP'
