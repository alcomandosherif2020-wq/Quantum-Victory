#!/usr/bin/env python3
import csv,json,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
ENGINE='QV-HISTORICAL-SNAPSHOT-ENGINE-001'; VERSION='1.0.0'
REQ=['symbol','session_date','open','high','low','close','volume','source_id','source_version','eligibility_time','row_fingerprint']

def sha(s): return hashlib.sha256(s.encode()).hexdigest()
def parse_dt(x):
    if not x: return None
    return datetime.fromisoformat(x.replace('Z','+00:00'))
def canon(row): return '|'.join(f'{k}={row.get(k," ")}' for k in sorted(row))
def main(inp,asof,out):
    p=Path(inp); out=Path(out); out.mkdir(parents=True,exist_ok=True)
    rows=list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
    errors=[]; eligible=[]; future=[]; seen=set()
    ad=parse_dt(asof)
    if ad is None: errors.append({'gate':'asof','reason':'INVALID_DECISION_TIME'})
    if rows and any(c not in rows[0] for c in REQ): errors.append({'gate':'schema','reason':'MISSING_REQUIRED_COLUMN'})
    for i,r in enumerate(rows,2):
        rid=f'ROW-{i:06d}'; key=(r.get('symbol',''),r.get('session_date',''))
        try: et=parse_dt(r.get('eligibility_time'))
        except: et=None
        reason=None
        if not all(r.get(c) for c in REQ): reason='MISSING_REQUIRED_FIELD'
        elif et is None: reason='INVALID_ELIGIBILITY_TIME'
        elif ad and et>ad:
            future.append({'row_id':rid,'symbol':key[0],'session_date':key[1],'eligibility_time':r.get('eligibility_time'),'reason':'FUTURE_INFORMATION_BLOCKED'})
            continue
        elif key in seen: reason='DUPLICATE_BUSINESS_KEY'
        if reason: errors.append({'row':rid,'reason':reason}); continue
        seen.add(key); eligible.append(r)
    eligible.sort(key=lambda r:(r.get('session_date',''),r.get('symbol','')))
    snap_payload='\n'.join(canon(r) for r in eligible)
    snapshot_id='QV-SNAPSHOT-'+sha(asof+'\n'+snap_payload)[:24].upper()
    fingerprint=sha(snapshot_id+'|'+ENGINE+'|'+VERSION+'|'+p.read_text(encoding='utf-8-sig'))
    store=out/'QV-HISTORICAL-SNAPSHOT.csv'
    fields=list(rows[0].keys()) if rows else REQ
    with store.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(eligible)
    manifest={'snapshot_id':snapshot_id,'engine':ENGINE,'version':VERSION,'decision_time':asof,'input':str(p),'input_sha256':sha(p.read_text(encoding='utf-8-sig')),'row_count':len(eligible),'excluded_future_rows':len(future),'errors':errors,'future_exclusions':future,'snapshot_fingerprint':fingerprint,'point_in_time_rule':'eligibility_time <= decision_time','production_approved':False,'status':'PASS' if not errors else 'BLOCKED'}
    (out/'QV-HISTORICAL-SNAPSHOT-MANIFEST-001.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
if __name__=='__main__':
    if len(sys.argv)!=4: raise SystemExit('usage: engine.py INPUT ASOF_ISO OUTPUT_DIR')
    main(sys.argv[1],sys.argv[2],sys.argv[3])
