# -*- coding: utf-8 -*-
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import json, sys, traceback

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        b=json.dumps(obj,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path=='/':
            p=ROOT/'واجهة_كوانتوم_فيكتوري_تحليل_السهم_٥_٩.html'
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path=='/حالة':
            self._send(200,{'الحالة':'متصل','المحركات':{'التحليل_الفني':True,'المحرك_العالمي_الموحد':True,'تقرير_السهم_العالمي':True,'قرار_الأدلة':True},'الإنتاج_مصرح':False,'التشغيل_الحي_متاح':True,'وضع_التشغيل':'أدلة حية / ظل','ملاحظة_الإنتاج':'اعتماد التوصيات الإنتاجية يبقى منفصلًا عن جاهزية التشغيل'}); return
        self._send(404,{'خطأ':'غير موجود'})
    def do_POST(self):
        if self.path!='/تحليل': self._send(404,{'خطأ':'غير موجود'}); return
        try:
            n=int(self.headers.get('Content-Length','0')); body=json.loads(self.rfile.read(n).decode('utf-8'))
            import pandas as pd
            from qv_whale_hunter.المحرك_العالمي_الموحد import المحرك_العالمي_الموحد
            rows=body.get('البيانات',[])
            if not rows: return self._send(400,{'خطأ':'أدخل بيانات الشموع أولاً'})
            df=pd.DataFrame(rows)
            if 'الرمز' not in df.columns: df['الرمز']=body.get('الرمز','غير_معروف')
            result=المحرك_العالمي_الموحد().تشغيل(df,دلالة_الافتتاح='افتتاح_الجلسة',مصدر_البيانات=body.get('مصدر','إدخال_يدوي'))
            self._send(200,result)
        except Exception as e:
            self._send(500,{'خطأ':str(e),'التفاصيل':traceback.format_exc()})

if __name__=='__main__':
    print('واجهة كوانتوم فيكتوري تعمل على http://127.0.0.1:8765')
    HTTPServer(('127.0.0.1',8765),Handler).serve_forever()
